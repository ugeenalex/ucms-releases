/* ============================================================
   КОЛЛЕКЦИИ в админке: блог, новости, портфолио, каталог.

   Коллекция — настройки в db.settings.collections; запись — обычная
   страница с полем collection (дата, обложка, анонс, теги, черновик).
   Данные (добавить/удалить/сохранить) — server-bridge.js, здесь только
   разметка: группа «Коллекции» в сайдбаре, панель настроек коллекции,
   поля записи в «Параметрах записи», превью модуля «Список записей».
   ============================================================ */
(function () {
  'use strict';
  var App = window.App;
  function S() { return App._state; }
  function K() { return App.kit; }

  // Записи коллекции в порядке сайта: по дате (новые сверху) или вручную
  function entriesOf(collId) {
    var s = S(), c = App.collById(collId);
    var list = s.pages.map(function (p, i) { return { p: p, i: i }; }).filter(function (x) { return x.p.coll === collId; });
    var byOrder = function (a, b) { return (a.p.order || 0) - (b.p.order || 0); };
    if (c && c.sort === 'manual') return list.sort(byOrder);
    return list.sort(function (a, b) { return String(b.p.date || '').localeCompare(String(a.p.date || '')) || byOrder(a, b); });
  }
  App.collEntries = entriesOf;

  function fmtDate(d) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(d || ''))) return '';
    var p = d.split('-');
    return p[2] + '.' + p[1] + '.' + p[0];
  }

  /* ── Раздел «Коллекции» (как «Медиа»): слева список коллекций, справа записи выбранной;
     в правой панели — настройки выбранной коллекции. Запись открывается на холсте раздела «Страницы». ── */
  var CV = { q: '', f: 'all' };   // поиск и фильтр списка записей (на время работы админки)
  function curColl() {
    var s = S(), colls = s.collections || [];
    if (!colls.some(function (c) { return c.id === s.collSel; })) s.collSel = colls.length ? colls[0].id : null;
    return s.collSel ? App.collById(s.collSel) : null;
  }
  App.collPick = function (id) { var s = S(); s.collSel = id; CV.q = ''; App.render(); };
  // Панель настроек коллекции: показать/скрыть (на узком экране по умолчанию скрыта)
  App.collSettings = function (open) { var s = S(); s.collSetOpen = open == null ? !document.querySelector('.ad-insp[data-insp]:not([hidden])') : !!open; App.render(); };
  App.collSearch = function (v) { CV.q = v; var el = document.querySelector('[data-coll-rows]'); if (el) el.outerHTML = rowsHTML(curColl()); };
  App.collFilter = function (v) { CV.f = v; App.renderView(); };
  // Открыть запись: раздел «Страницы», её холст и параметры
  App.collOpenEntry = function (i) { var s = S(); s.view = 'page'; s.drawer = null; App.selectPage(i); App.render(); };
  App.collNew = function () {
    var before = (S().collections || []).length;
    App.addCollection();
    var s = S(), colls = s.collections || [];
    if (colls.length > before) { s.collSel = colls[colls.length - 1].id; s.view = 'coll'; s.drawer = null; App.render(); }
  };
  App.collNewEntry = function (id) { App.addEntry(id); };   // новая запись сразу открывается для правки
  App.collMove = function (i, dir) { App.moveEntry(i, dir); App.renderView(); };
  // удаление записи: сначала она становится текущей (данные текущей страницы сохраняются как обычно)
  App.collDelEntry = function (i) { var s = S(); if (s.sel !== i) App.selectPage(i); App.deletePage(); s.view = 'coll'; s.drawer = null; App.render(); };
  // Из записи — назад к её коллекции
  App.collBack = function () { var s = S(), p = s.pages[s.sel]; if (p && p.coll) s.collSel = p.coll; App.setView('coll'); };

  function rowsHTML(c) {
    var k = K(), list = c ? entriesOf(c.id) : [], manual = c && c.sort === 'manual', q = CV.q.trim().toLowerCase();
    var shown = list.filter(function (x) {
      if (CV.f === 'draft' && !x.p.draft) return false;
      if (CV.f === 'pub' && x.p.draft) return false;
      return !q || String(x.p.title || '').toLowerCase().indexOf(q) >= 0 || String(x.p.slug || '').toLowerCase().indexOf(q) >= 0;
    });
    if (!list.length) return '<div class="cl-rows" data-coll-rows><div class="md-empty">' + _t('Записей пока нет.') + ' <button type="button" class="ad-linkbtn" onclick="' + k.call('collNewEntry', [c.id]) + '">' + _t('Написать первую') + '</button></div></div>';
    if (!shown.length) return '<div class="cl-rows" data-coll-rows><div class="md-empty">' + _t('Ничего не найдено') + '</div></div>';
    var canMove = manual && !q && CV.f === 'all';
    return '<div class="cl-rows" data-coll-rows>' + shown.map(function (x, n) {
      var p = x.p, slug = String(p.slug || '').replace(/^\//, '');
      return '<div class="cl-row' + (p.draft ? ' is-draft' : '') + '">' +
        '<button type="button" class="cl-row__open" onclick="' + k.call('collOpenEntry', [x.i]) + '" title="' + k.escAttr(_t('Открыть запись')) + '">' +
        '<span class="cl-row__img">' + (p.cover ? '<img src="' + k.escAttr(p.cover) + '" alt="" loading="lazy">' : k.ico('page', 16)) + '</span>' +
        '<span class="cl-row__t"><b>' + k.esc(p.title || _t('Без названия')) + '</b><small>/' + k.esc((c.slug || '') + '/' + slug) + '</small></span>' +
        '<span class="cl-row__d">' + (p.draft ? '<em class="ad-coll__draft">' + _t('черновик') + '</em>' : k.esc(fmtDate(p.date))) + '</span></button>' +
        '<span class="cl-row__a">' +
        (canMove ? k.ib('up', _t('Выше'), k.call('collMove', [x.i, -1]), { disabled: n === 0 }) + k.ib('down', _t('Ниже'), k.call('collMove', [x.i, 1]), { disabled: n === shown.length - 1 }) : '') +
        k.ib('pencil', _t('Открыть запись'), k.call('collOpenEntry', [x.i])) +
        k.ib('del', _t('Удалить запись'), k.call('collDelEntry', [x.i]), { danger: true }) + '</span></div>';
    }).join('') + '</div>';
  }

  App.renderCollView = function () {
    var s = S(), k = K(), colls = s.collections || [], c = curColl();
    var head = '<div class="ad-sec-h"><h1>' + _t('Коллекции') + '</h1><p>' + _t('Блог, новости, портфолио: записи с датой, обложкой и тегами. Список записей на сайте выводит страница-список.') + '</p></div>';
    if (!colls.length) {
      return head + '<section class="ad-panel cl-empty">' + k.ico('coll', 28) + '<b>' + _t('Коллекций пока нет') + '</b>' +
        '<span>' + _t('Создайте блог — вместе с ним появится страница-список, на которой выводятся записи.') + '</span>' +
        '<button type="button" class="ad-b ad-b--primary" onclick="App.collNew()">' + k.ico('plus', 15) + _t('Создать блог') + '</button></section>';
    }
    var side = '<aside class="md-side"><div class="md-side__h">' + _t('Коллекции') + '</div>' + colls.map(function (x) {
      var on = c && x.id === c.id;
      return '<div class="md-fold' + (on ? ' is-on' : '') + '"><button type="button" class="md-fold__b" onclick="' + k.call('collPick', [x.id]) + '">' + k.ico('coll', 15) +
        '<span>' + k.esc(x.name || _t('Без названия')) + '</span><small>' + entriesOf(x.id).length + '</small></button></div>';
    }).join('') + '<button type="button" class="md-fold__new" onclick="App.collNew()">' + k.ico('plus', 14) + _t('Новая коллекция') + '</button>' +
      '<div class="md-side__hint">' + _t('Настройки выбранной коллекции — в панели справа.') + '</div></aside>';
    var list = entriesOf(c.id), drafts = list.filter(function (x) { return x.p.draft; }).length;
    var refs = App.pageRefs() || [], li = refs.findIndex(function (p) { return p.id === c.listPageId; });
    var listPage = li >= 0 ? '<span class="cl-listpage">' + k.ico('pages', 14) + _t('Страница-список:') + ' <button type="button" class="ad-linkbtn" onclick="' + k.call('collOpenList', [c.id]) + '">«' + k.esc(refs[li].title) + '»</button></span>'
      : '<span class="cl-listpage is-warn">' + _t('Страница-список не выбрана — записи нигде не выводятся списком') + '</span>';
    var main = '<div class="md-main"><section class="ad-panel md-tools">' +
      '<div class="md-tools__row"><button type="button" class="ad-b ad-b--primary" onclick="' + k.call('collNewEntry', [c.id]) + '">' + k.ico('plus', 15) + _t('Новая запись') + '</button>' +
      listPage + '<button type="button" class="ad-b ad-b--sm" onclick="App.collSettings()">' + k.ico('sliders', 14) + _t('Настройки коллекции') + '</button>' +
      '<input class="ad-in md-search" placeholder="' + k.escAttr(_t('Поиск по названию')) + '" value="' + k.escAttr(CV.q) + '" oninput="App.collSearch(this.value)"></div>' +
      '<div class="md-tools__row">' + k.segm([['all', _t('Все') + ' · ' + list.length], ['pub', _t('Опубликованы') + ' · ' + (list.length - drafts)], ['draft', _t('Черновики') + ' · ' + drafts]], CV.f, function (v) { return k.call('collFilter', [v]); }) +
      (c.sort === 'manual' ? '<span class="md-sum">' + _t('Порядок — вручную, стрелками') + '</span>' : '<span class="md-sum">' + _t('По дате, новые сверху') + '</span>') + '</div></section>' +
      rowsHTML(c) + '</div>';
    return head + '<div class="md-layout">' + side + main + '</div>';
  };

  /* ── Панель настроек коллекции ── */
  var TR = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't',
    у: 'u', ф: 'f', х: 'h', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya', і: 'i', ї: 'yi', є: 'ye', ґ: 'g' };
  // Папка коллекции: латиница (кириллица транслитерируется), цифры, «-», «_»
  function cleanSlug(v) {
    return String(v || '').toLowerCase().replace(/[а-яёіїєґ]/g, function (ch) { return TR[ch] != null ? TR[ch] : ''; })
      .replace(/[^a-z0-9_-]+/g, '-').replace(/-+/g, '-').replace(/^-/, '');
  }
  // Страница-список, которая ещё называется/адресуется как коллекция, переименовывается вместе с ней
  function listRow(c) {
    var refs = App.pageRefs() || [], i = refs.findIndex(function (p) { return p.id === c.listPageId; });
    return i >= 0 ? i : -1;
  }
  App.setCollName = function (id, v) {
    var s = S(), c = App.collById(id); if (!c) return;
    var i = listRow(c), row = s.pages[i];
    if (row && row.title === c.name && v.trim() && !s.pages.some(function (p, k) { return k !== i && p.title === v; })) {
      row.title = v;
      if (i === s.sel) { s.pageTitle = v; App.renderPageHead(); App.renderTop(); }
    }
    App.setCollField(id, 'name', v);
  };
  App.setCollSlug = function (id, v) {
    var s = S(), c = App.collById(id); if (!c) return;
    var clean = cleanSlug(v), i = listRow(c), row = s.pages[i];
    if (row && clean && row.slug === '/' + c.slug + '.html' && !s.pages.some(function (p, k) { return k !== i && !p.coll && p.slug === '/' + clean + '.html'; })) {
      row.slug = '/' + clean + '.html';
      if (i === s.sel) s.pageSlug = clean;
    }
    App.setCollField(id, 'slug', clean);
    var inp = document.getElementById('coll-slug');
    if (inp && inp.value !== clean) { var pos = Math.min(inp.selectionStart || 0, clean.length); inp.value = clean; inp.setSelectionRange(pos, pos); }
    App.renderPageHead();
  };
  App.collCleanSlug = cleanSlug;
  App.collOpenList = function (id) {
    var c = App.collById(id); if (!c) return;
    var i = (App.pageRefs() || []).findIndex(function (p) { return p.id === c.listPageId; });
    if (i >= 0) { App.selectPage(i); S().drawer = null; App.render(); }
  };
  App.renderCollDrawer = function (id) {
    var s = S(), k = K(), UI = k.UI, c = App.collById(id);
    if (!c) { s.drawer = null; return '<div data-insp hidden></div>'; }
    var set = function (f, val, r) { return 'App.setCollField(' + k.jsArg(id) + ',' + k.jsArg(f) + ',' + val + (r ? ',true' : '') + ')'; };
    var refs = App.pageRefs() || [];
    var pages = refs.filter(function (p, i) { return s.pages[i] && !s.pages[i].coll; });
    var listOk = pages.some(function (p) { return p.id === c.listPageId; });
    var opts = '<option value=""' + (listOk ? '' : ' selected') + '>' + _t('— нет —') + '</option>' + pages.map(function (p) {
      return '<option value="' + k.escAttr(p.id) + '"' + (p.id === c.listPageId ? ' selected' : '') + '>' + k.esc(p.title) + '</option>';
    }).join('');
    var sw = function (label, f, defOn) {
      var on = defOn ? c[f] !== false : !!c[f];
      return UI.sw(label, on, set(f, on ? 'false' : 'true', true));
    };
    // переключение между записями: по умолчанию и сверху, и снизу (старое showNav: false — выключено)
    var navSw = function (label, f) {
      var on = c[f] == null ? c.showNav !== false : c[f] !== false;
      return UI.sw(label, on, set(f, on ? 'false' : 'true', true));
    };
    var count = entriesOf(id).length;
    return '<aside class="ad-insp ad-insp--drawer" data-insp aria-label="' + k.escAttr(_t('Настройки коллекции')) + '"><div class="ad-insp__h"><div class="ad-insp__ic">' + k.ico('coll', 15) + '</div><div class="ad-insp__t">' + _t('Коллекция') + '</div>' +
      k.ib('close', _t('Скрыть настройки'), 'App.collSettings(false)') + '</div><div class="ad-insp__b">' +
      UI.field(_t('Название'), '<input id="coll-name" class="ad-in" value="' + k.escAttr(c.name) + '" oninput="App.setCollName(' + k.jsArg(id) + ',this.value)">', _t('Страница-список с тем же названием переименуется вместе с коллекцией.')) +
      UI.field(_t('Папка на сайте'), '<div class="ad-affix"><span>/</span><input id="coll-slug" value="' + k.escAttr(c.slug) + '" oninput="App.setCollSlug(' + k.jsArg(id) + ',this.value)"><span>/' + _t('запись') + '.html</span></div>',
        _t('Латиница, цифры, «-». Записи лежат в этой папке: <code>/') + k.esc(c.slug || 'blog') + _t('/моя-запись.html</code>.')) +
      UI.field(_t('Страница со списком'), '<select class="ad-in" onchange="' + set('listPageId', 'this.value', true) + '">' + opts + '</select>',
        _t('На неё ведёт ссылка «назад» со страницы записи, она же подсвечивается в меню. Список выводит модуль «Список записей».') +
        (listOk ? ' <button type="button" class="ad-linkbtn" onclick="App.collOpenList(' + k.jsArg(id) + ')">' + _t('Открыть') + '</button>' : '')) +
      UI.field(_t('Порядок записей'), k.segm([['date', _t('По дате, новые сверху')], ['manual', _t('Вручную')]], c.sort === 'manual' ? 'manual' : 'date', function (v) { return set('sort', k.jsArg(v), true); }),
        c.sort === 'manual' ? _t('Порядок меняется стрелками в списке записей.') : '') +
      '<div class="ad-f" style="gap:4px"><span class="ad-eyebrow2">' + _t('Страница записи') + '</span>' +
      sw(_t('Заголовок (название записи)'), 'showTitle', true) + sw(_t('Дата'), 'showDate', true) +
      sw(_t('Обложка над текстом'), 'showCoverTop', false) + sw(_t('Теги'), 'showTags', false) +
      navSw(_t('Переключение записей сверху'), 'navTop') + navSw(_t('Переключение записей снизу'), 'navBottom') +
      '<span class="ad-f__hint">' + _t('Выводятся над и под блоками записи. Выключите заголовок, если оформляете его блоками сами. Обложка в карточках списка настраивается в модуле «Список записей».') + '</span></div>' +
      UI.btn(_t('Новая запись'), k.call('addEntry', [id]), { variant: 'accent', icon: 'plus' }) +
      '<span class="ad-f__hint">' + _t('Записей: ') + count + '</span>' +
      '</div><div class="ad-insp__f"><button type="button" class="ad-b ad-b--sm ad-b--danger" onclick="' + k.call('deleteCollection', [id]) + '">' + k.ico('del', 13) + _t('Удалить коллекцию') + '</button>' +
      '</div></aside>';
  };

  /* ── Поля записи в «Параметрах записи» ── */
  App.entryCoverUpload = function () {
    App.uploadImageAt(function (src) { App.setEntryField('cover', src, true); });
  };
  App.entryTagKey = function (e, el) {
    if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); App.entryTagAdd(el.value); var n = document.getElementById('entry-tag'); if (n) n.focus(); }
  };
  App.renderEntrySection = function () {
    var s = S(), k = K(), UI = k.UI, en = s.pageEntry;
    if (!en) return '';
    var colls = s.collections || [];
    var collSel = colls.length > 1 ? UI.field(_t('Коллекция'), '<select class="ad-in" onchange="App.setEntryField(\'collection\',this.value,true)">' + colls.map(function (c) {
      return '<option value="' + k.escAttr(c.id) + '"' + (c.id === en.collection ? ' selected' : '') + '>' + k.esc(c.name) + '</option>';
    }).join('') + '</select>') : '';
    var cover = en.cover
      ? '<div class="ad-media ad-seo__img"><img src="' + k.escAttr(en.cover) + '" alt=""><div class="ad-media__bar">' +
        UI.btn(_t('Заменить'), 'App.entryCoverUpload()', { sm: true, icon: 'upload', cls: 'ad-b--glass' }) + UI.btn(_t('Убрать'), "App.setEntryField('cover','',true)", { sm: true, cls: 'ad-b--glass' }) + '</div></div>'
      : '<button type="button" class="ad-drop" style="height:84px" onclick="App.entryCoverUpload()">' + k.ico('upload', 18) + '<b>' + _t('Обложка') + '</b><small>' + _t('Пусто — первая картинка записи') + '</small></button>';
    var sugg = App.collTags(en.collection).filter(function (t) { return en.tags.indexOf(t) < 0; }).slice(0, 12);
    var tags = '<div class="ad-tagchips">' + en.tags.map(function (t) {
      return '<span class="ad-tagchip is-on">' + k.esc(t) + '<button type="button" aria-label="' + k.escAttr(_t('Удалить тег')) + '" onclick="' + k.call('entryTagDel', [t]) + '">×</button></span>';
    }).join('') + '</div>' +
      '<input id="entry-tag" class="ad-in ad-in--sm" placeholder="' + k.escAttr(_t('Новый тег — Enter')) + '" onkeydown="App.entryTagKey(event,this)" onblur="if(this.value.trim())App.entryTagAdd(this.value)">' +
      (sugg.length ? '<div class="ad-tagchips">' + sugg.map(function (t) {
        return '<button type="button" class="ad-tagchip" onclick="' + k.call('entryTagAdd', [t]) + '">+ ' + k.esc(t) + '</button>';
      }).join('') + '</div>' : '');
    return '<div class="ad-f" style="gap:10px">' + collSel +   // заголовок «Запись» — у группы (app.js)
      '<div style="display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:end">' +
      UI.field(_t('Дата'), '<input class="ad-in" type="date" value="' + k.escAttr(en.date) + '" onchange="App.setEntryField(\'date\',this.value)">') +
      '<div class="ad-f">' + UI.sw(_t('Черновик'), en.draft, 'App.setEntryField(\'draft\',' + (en.draft ? 'false' : 'true') + ',true)') + '</div></div>' +
      (en.draft ? '<span class="ad-f__hint ad-warn">' + _t('Черновик не попадает на сайт и в списки записей.') + '</span>' : '') +
      cover +
      UI.field(_t('Анонс'), '<textarea class="ad-in ad-tr__ta" rows="3" placeholder="' + k.escAttr(_t('Пусто — начало первого текста записи')) + '" oninput="App.setEntryField(\'excerpt\',this.value)">' + k.esc(en.excerpt) + '</textarea>',
        _t('Показывается в списке записей и в описании для поиска.')) +
      UI.field(_t('Теги'), tags, _t('По тегам посетитель фильтрует список записей.')) + '</div>';
  };
  App.entryChips = function () {
    var s = S(), k = K(), en = s.pageEntry, c = App.collById(en.collection);
    return '<span class="ad-chip">' + k.ico('coll', 12) + k.esc(c ? c.name : '') + '</span>' +
      (en.draft ? '<span class="ad-chip"><span class="ad-dot ad-dot--off"></span>' + _t('Черновик') + '</span>'
        : '<span class="ad-chip">' + k.esc(fmtDate(en.date) || _t('без даты')) + '</span>');
  };

  /* ── Превью «Списка записей» на холсте ── */
  App.collPreview = function (m) {
    var k = K(), c = App.collById(m.collection);
    if (!c) return '<div class="ad-pv ad-pv--muted">' + _t('Выберите коллекцию') + '</div>';
    var list = entriesOf(c.id).filter(function (x) { return !x.p.draft; });
    if (!list.length) return '<div class="ad-pv ad-pv--muted">' + k.esc(c.name) + ' · ' + _t('записей пока нет') + '</div>';
    var cols = m.layout === 'list' ? 1 : Math.min(4, parseInt(m.cols, 10) || 3);
    var per = parseInt(m.perPage, 10) || 0;
    var shown = list.slice(0, Math.min(per || 8, 8));
    return '<div class="ad-pv__cards" style="grid-template-columns:repeat(' + cols + ',minmax(0,1fr))">' + shown.map(function (x) {
      var p = x.p;
      // без обложки — карточка без места под картинку (как на сайте)
      return '<div>' + (m.showCover !== false && p.cover ? '<img src="' + k.escAttr(p.cover) + '" alt="" loading="lazy">' : '') +
        '<span>' + k.esc(p.title) + '</span>' + (m.showDate !== false && p.date ? '<em class="ad-pv__cardbtn">' + k.esc(fmtDate(p.date)) + '</em>' : '') + '</div>';
    }).join('') + '</div>' +
      '<div class="ad-pv ad-pv--muted">' + k.esc(c.name) + ' · ' + list.length + _t(' зап.') + (per && list.length > per ? ' · ' + _t('по ') + per + _t(', «Показать ещё»') : '') + '</div>';
  };
})();

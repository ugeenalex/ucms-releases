'use strict';
// «Ссылки»: подстраницы раздела (все или выбранные) и/или свои пункты; вид — список, со значками, плитки.
// Свои ссылки — m.items (обычный список элементов). Настройки пунктов-страниц — m.pageOpts: [{ id, page, … }]
// (описание, картинка, бейдж…); название, ссылку и SEO-описание даёт сама страница. Картинки — .ad-li-up (server-bridge.js).
(function () {
  function S() { return window.App && App._state; }
  // Страницы сайта (без записей коллекций) с родителем (id; строку обновляет и смена родителя до сохранения)
  function sitePages() {
    return ((S() || {}).pages || []).filter(function (p) { return !p.coll; }).map(function (p) {
      return { id: p.id, title: p.title, desc: p.desc || '', parent: p.parent || '' };
    });
  }
  function sourcePages(m) {
    var all = sitePages().filter(function (p) { return p.parent === (m.parent || ''); });
    return m.pagesMode === 'selected' ? all.filter(function (p) { return m.selected && m.selected[p.id]; }) : all;
  }
  // Строки списка для холста и редактора: [{ title, o: пункт (настройки), page? }]
  CMS.linksRows = function (m) {
    var items = m.items || [], opts = m.pageOpts || [], rows = [];
    if (m.source !== 'manual') sourcePages(m).forEach(function (p) {
      var o = opts.filter(function (it) { return it.page === p.id; })[0] || { page: p.id };
      rows.push({ title: p.title, o: o, page: p });
    });
    items.filter(function (it) { return String(it.title || '').trim(); }).forEach(function (it) { rows.push({ title: it.title, o: it }); });
    return rows;
  };
  CMS.linksHeading = function (m) {
    if (m.heading === 'none') return '';
    if (m.heading === 'custom') return m.title || '';
    var p = m.source !== 'manual' && m.parent ? sitePages().filter(function (x) { return x.id === m.parent; })[0] : null;
    return p ? p.title : '';
  };
  // Поле пункта (свой или страницы): ввод — без перерисовки, переключатели — с ней
  CMS.handlers.linksSet = function (tree, modId, itemId, field, value, render) {
    var m = App.getModule(tree, modId); if (!m) return;
    var it = CMS.linksItem(m, itemId); if (!it) return;
    it[field] = value;
    if (render) App.renderModule(tree, modId);
  };
  // Пункт по id; 'new:<страница>' — создать настройки этой страницы
  CMS.linksItem = function (m, itemId) {
    var it = (m.items || []).concat(m.pageOpts || []).filter(function (x) { return x.id === itemId; })[0];
    if (it || !/^new:/.test(itemId)) return it || null;
    var page = itemId.slice(4);
    it = (m.pageOpts || []).filter(function (x) { return x.page === page; })[0];
    if (!it) { it = { id: 'po' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), page: page }; (m.pageOpts = m.pageOpts || []).push(it); }
    return it;
  };
  // Форма значка: обычная (скругление в px) или фигура. Старое radius: 'circle' — «Овал».
  var SHAPES = function () { return [['', _t('Обычная')], ['oval', _t('Овал')], ['rhombus', _t('Ромб')], ['triangle', _t('Треугольник')], ['star', _t('Звезда')]]; };
  function shapeOf(o) { return o.shape || (o.radius === 'circle' ? 'oval' : 'round'); }   // 'round' — обычная (скругление в px)
  function radiusOf(o) { var r = parseInt(o.radius, 10); return isNaN(r) ? '' : String(r); }

  CMS.editor('links', function (mod, ctx) {
    var ui = ctx.ui, J = ctx.jsArg, esc = ctx.esc, ea = ctx.escAttr, pagesSrc = mod.source !== 'manual';
    mod.items = mod.items || [];
    // настройки страницы создаются при первой правке (id 'new:<страница>'), просмотр модуль не меняет
    var html = ui.field('', ui.segm([['pages', _t('Страницы сайта')], ['manual', _t('Только свои ссылки')]], pagesSrc ? 'pages' : 'manual', function (k) { return ctx.set('source', J(k)); }),
      pagesSrc ? _t('Новые страницы раздела появятся в списке сами. Свои ссылки добавляются после страниц.') : '');
    if (pagesSrc) {
      var tops = sitePages().filter(function (p) { return !p.parent && sitePages().some(function (c) { return c.parent === p.id; }); });
      html += ui.field(_t('Раздел'), '<select class="ad-in" onchange="' + ctx.set('parent', 'this.value') + '">' +
        '<option value=""' + (mod.parent ? '' : ' selected') + '>' + esc(_t('Страницы верхнего уровня')) + '</option>' +
        tops.map(function (p) { return '<option value="' + ea(p.id) + '"' + (mod.parent === p.id ? ' selected' : '') + '>' + esc(_t('Подстраницы: ') + p.title) + '</option>'; }).join('') + '</select>') +
        ui.field(_t('Страницы'), ui.segm([['all', _t('Все')], ['selected', _t('Выбранные')]], mod.pagesMode || 'all', function (k) { return ctx.set('pagesMode', J(k)); }));
      if (mod.pagesMode === 'selected') {
        var cands = sitePages().filter(function (p) { return p.parent === (mod.parent || ''); });
        html += '<div class="ad-checks">' + (cands.length ? cands.map(function (p) {
          var on = !!(mod.selected && mod.selected[p.id]);
          return '<button type="button" role="checkbox" aria-checked="' + on + '" class="ad-check' + (on ? ' is-on' : '') + '" onclick="' + ctx.act('m.selected = m.selected || {}; var k=' + J(p.id) + '; m.selected[k]=!m.selected[k];') + '">' +
            '<span class="ad-check__box">' + (on ? ui.ico('check', 12) : '') + '</span>' + esc(p.title) + '</button>';
        }).join('') : '<span class="ad-f__hint">' + _t('В разделе нет страниц') + '</span>') + '</div>';
      }
    }
    var srcHtml = html; html = '';
    var hd = mod.heading === 'custom' ? 'custom' : mod.heading === 'none' || !pagesSrc ? 'none' : 'auto';
    html += ui.field(_t('Заголовок'), ui.segm((pagesSrc ? [['auto', _t('Название раздела')]] : []).concat([['custom', _t('Свой')], ['none', _t('Без заголовка')]]), hd, function (k) { return ctx.set('heading', J(k)); }),
      hd === 'auto' && !mod.parent ? _t('У страниц верхнего уровня нет раздела — заголовка не будет.') : '') +
      (mod.heading === 'custom' ? ui.input({ value: mod.title, placeholder: _t('Например, «Продукты»'), oninput: ctx.set('title', 'this.value', true) }) : '') +
      ui.field(_t('Вид'), ui.segm([['list', _t('Список')], ['rich', _t('Значок и описание')], ['tiles', _t('Плитки')]], mod.view || 'list', function (k) { return ctx.act('m.view=' + J(k) + '; if (m.view !== \'list\') m.media = true;'); })) +
      ui.field(_t('Колонок'), ui.segm([['1', '1'], ['2', '2'], ['3', '3'], ['4', '4']], String(mod.cols || 1), function (k) { return ctx.set('cols', k); }), _t('На телефоне — одна (плитки — две).')) +
      ui.sw(_t('Описания под названием'), mod.showDesc !== false, ctx.act('m.showDesc = m.showDesc === false;'));
    var lookHtml = html; html = ui.sw(_t('Значки и картинки'), !!mod.media, ctx.act('m.media = !m.media;'));
    if (mod.media) {
      var size = parseInt(mod.iconSize, 10) || 40;
      var gShape = shapeOf(mod);
      html += ui.field(_t('Размер значков'), ui.stepper(size, ctx.set('iconSize', Math.max(16, size - 4)), ctx.set('iconSize', Math.min(200, size + 4)), ' px')) +
        ui.field(_t('Форма значков'), '<select class="ad-in" onchange="' + ctx.set('shape', 'this.value') + '">' + SHAPES().map(function (r) {
          var v = r[0] || 'round';
          return '<option value="' + v + '"' + (gShape === v ? ' selected' : '') + '>' + esc(r[1]) + '</option>'; }).join('') + '</select>', _t('Общая для всех; у пункта можно задать свою.')) +
        (gShape !== 'round' ? '' : ui.field(_t('Скругление'), '<div class="ad-affix"><input type="number" min="0" max="200" placeholder="' + ea(_t('как в теме')) + '" value="' + ea(radiusOf(mod)) + '" oninput="' + ctx.set('radius', 'this.value', true) + '"><span>px</span></div>',
          _t('Пусто — как в теме. Половина размера значка — круг.')));
    }
    var mediaHtml = html; html = '';

    // Пункт: картинка/эмодзи, описание, бейдж, выделение, свой размер и скругление
    var itemFields = function (it, set, page) {
      var mini = function (label, html) { return '<label class="ad-li-mini"><span>' + esc(label) + '</span>' + html + '</label>'; };
      var setR = function (field) { return 'App.linksSet(' + [ctx.tree, mod.id, it.id, field].map(J).join(',') + ',this.value,true)'; };
      var thumb = mod.media ? (it.image
        ? '<button type="button" class="ad-gi__thumb ad-li-up" data-item="' + it.id + '" data-field="image" title="' + ea(_t('Заменить картинку')) + '"><img src="' + ea(it.image) + '" alt=""></button>'
        : '<button type="button" class="ad-gi__thumb ad-li-up" data-item="' + it.id + '" data-field="image" aria-label="' + ea(_t('Загрузить картинку')) + '">' + ui.ico('upload', 18) + '</button>') : '';
      var name = page ? '<div class="ad-in" style="display:flex;align-items:center;background:var(--fill-2)">' + esc(page.title) + '</div>'
        : ui.input({ value: it.title, placeholder: _t('Название'), oninput: set('title') });
      var own = mod.media
        ? '<div class="ad-li-grid">' +
          mini(_t('Эмодзи'), '<input class="ad-in ad-in--sm" placeholder="⚡" maxlength="4" value="' + ea(it.icon || '') + '" oninput="' + set('icon') + '"' + (it.image ? ' disabled title="' + ea(_t('Есть картинка')) + '"' : '') + '>') +
          mini(_t('Форма'), '<select class="ad-in ad-in--sm" onchange="' + setR('shape') + '">' + [['', _t('Общая')]].concat(SHAPES().map(function (r) { return [r[0] || 'round', r[1]]; })).map(function (r) {
            return '<option value="' + ea(r[0]) + '"' + ((it.shape || (it.radius === 'circle' ? 'oval' : '')) === r[0] ? ' selected' : '') + '>' + esc(r[1]) + '</option>'; }).join('') + '</select>') +
          mini(_t('Размер'), '<div class="ad-affix"><input type="number" min="12" max="200" placeholder="' + ea(String(parseInt(mod.iconSize, 10) || 40)) + '" value="' + ea(it.size || '') + '" oninput="' + set('size') + '"><span>px</span></div>') +
          mini(_t('Скругление'), '<div class="ad-affix"><input type="number" min="0" max="200" placeholder="' + ea(radiusOf(mod) || _t('общее')) + '" value="' + ea(radiusOf(it)) + '" oninput="' + set('radius') + '"><span>px</span></div>') + '</div>' +
          (it.image ? '<div><button type="button" class="ad-b ad-b--sm" onclick="App.linksSet(' + [ctx.tree, mod.id, it.id, 'image'].map(J).join(',') + ',\'\',true)">' + _t('Убрать картинку') + '</button></div>' : '')
        : '';
      return '<div class="ad-gi__row">' + thumb + '<div class="ad-gi__fields">' + name +
        '<div class="ad-li-badge">' + ui.input({ value: it.badge, placeholder: _t('Бейдж: New, −20%'), oninput: set('badge') }) +
        '<button type="button" class="ad-li-bold' + (it.bold ? ' is-on' : '') + '" aria-pressed="' + !!it.bold + '" onclick="App.linksSet(' + [ctx.tree, mod.id, it.id, 'bold'].map(J).join(',') + ',' + !it.bold + ',true)">' + _t('Жирным') + '</button></div></div></div>' +
        (mod.showDesc !== false ? '<textarea class="ad-in ad-tr__ta" rows="2" placeholder="' + ea(page ? (page.desc ? _t('Из SEO-описания: ') + page.desc : _t('Описание (необязательно)')) : _t('Описание (необязательно)')) + '" oninput="' + set('desc') + '">' + esc(it.desc || '') + '</textarea>' : '') +
        own + (page ? '' : ctx.linkField(ctx.tree, mod.id, it.link, ctx.pages, ctx.itemPath(it.id), _t('Куда ведёт')));
    };
    if (pagesSrc) {
      var rows = sourcePages(mod);
      html += '<div class="ad-f"><span class="ad-f__l">' + _t('Страницы в списке') + ' · ' + rows.length + '</span><div class="ad-li-list">' + (rows.length ? rows.map(function (p) {
        var it = (mod.pageOpts || []).filter(function (x) { return x.page === p.id; })[0] || { id: 'new:' + p.id, page: p.id };
        var set = function (field) { return 'App.linksSet(' + [ctx.tree, mod.id, it.id, field].map(J).join(',') + ',this.value)'; };
        return '<div class="ad-li">' + itemFields(it, set, p) + '</div>';
      }).join('') : '<div class="ad-empty2">' + _t('В разделе нет страниц') + '</div>') + '</div></div>';
    }
    // свои ссылки — обычный список элементов (↑ ↓ ✕)
    var listHtml = ui.list(ctx, mod.items, pagesSrc ? _t('Свои ссылки') : _t('Ссылки'), _t('Ссылка'), function (it, set) { return itemFields(it, set, null); });
    html += listHtml;
    var itemsHtml = html; html = '';
    html += ui.sw(_t('Ссылка «Показать все» внизу'), !!mod.showMore, ctx.act('m.showMore = !m.showMore; m.more = m.more || { link: { linkType: \'none\' } };'));
    if (mod.showMore) {
      html += ui.input({ value: mod.moreText, placeholder: _t('Показать все →'), oninput: ctx.set('moreText', 'this.value', true) }) +
        ctx.linkField(ctx.tree, mod.id, (mod.more || {}).link, ctx.pages, 'more:' + ctx.tree + ':' + mod.id, _t('Куда ведёт'));
    }
    var nItems = (pagesSrc ? sourcePages(mod).length : 0) + mod.items.length;
    var content = ui.group('mod.links.src', _t('Источник'), srcHtml, { summary: pagesSrc ? (mod.pagesMode === 'selected' ? _t('выбранные страницы') : _t('страницы раздела')) : _t('свои ссылки') }) +
      ui.group('mod.links.items', _t('Ссылки в списке') + ' · ' + nItems, itemsHtml) +
      ui.group('mod.links.more', _t('«Показать все»'), html, { summary: mod.showMore ? _t('вкл') : _t('выкл') });
    var look = ui.group('mod.links.look', _t('Заголовок и вид'), lookHtml, { summary: ({ list: _t('список'), rich: _t('значок и описание'), tiles: _t('плитки') }[mod.view || 'list']) + ' · ' + (mod.cols || 1) + _t(' кол.') }) +
      ui.group('mod.links.media', _t('Значки и картинки'), mediaHtml, { summary: mod.media ? (parseInt(mod.iconSize, 10) || 40) + ' px' : _t('выкл') });
    return ui.tabs('mod.links', [['items', _t('Ссылки'), content, nItems], ['look', _t('Вид'), look]]);
  });
})();

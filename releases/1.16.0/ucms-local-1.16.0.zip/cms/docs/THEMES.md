# Темы UCMS

Тема — папка `themes/<Имя>/`:

- `theme.css` — становится `style.css` сайта;
- `theme.json` — шрифт темы (заполняется из админки: «Тема → Шрифт темы»);
- любые файлы (шрифты, картинки) — копируются в корень сайта, в CSS на них
  можно ссылаться относительными путями.

## Что делает тема, а что — админка

**Тема — только внешний вид:** цвета, шрифты, вид модулей (кнопки, меню,
формы, галереи…).

**Раскладку задаёт админка**, механика — в движке (`ucms.css`, подключается
перед темой): ширина блоков, поля по краям, отступы, колонки, выравнивание,
фон блока, видимость на ПК/телефоне. Одинаково для шапки, контента и подвала.
Не задавайте в теме `max-width`, `padding`, `margin` для `.site-header`,
`.site-main`, `.site-footer`, `.layout-row`, `.layout-col` — иначе тема начнёт
спорить с настройками блоков.

Размеры каркаса меняются токенами в `:root` темы:

| Токен | По умолчанию | Что это |
|---|---|---|
| `--content-width` | 1440px | ширина «Контейнера» |
| `--narrow-width` | 960px | ширина «Узко» |
| `--gutter` | 16–32px | поля по краям экрана |
| `--col-gap` | 24px | промежуток между колонками |
| `--row-gap` | 28px | промежуток между блоками |
| `--block-gap` | 18px | промежуток между модулями в колонке |
| `--main-pad` | 48px | отступ контента сверху и снизу |
| `--header-pad` / `--footer-pad` | 14px / 32px | отступы шапки и подвала |
| `--bg-pad` | 40px | внутренний отступ блока с фоном |
| `--menu-full-bg` / `--menu-full-fg` | градиент акцента / #fff | меню на весь экран |

## Разметка

```html
<header class="site-header">
  <div class="layout-row [ваш-класс] [row--…]" id="якорь">
    <div class="layout-col [col--center|col--right]">модули</div>
    …
    <div class="layout-after">модули блока под колонками</div>
  </div>
</header>
<main class="site-main"> …блоки… </main>
<footer class="site-footer"> …блоки… </footer>
```

Модуль — элемент с классами `block block-<тип>`: `block-heading`, `block-text`,
`block-image`, `block-gallery`, `block-video`, `block-button` (`.btn-cta`),
`block-divider`, `block-form`, `block-sitename`, `block-menu`, `block-langswitch`,
`block-html`, `block-features`, `block-faq`, `block-cards`, `block-quote`,
`block-pricing`, `block-counters`, `block-table`, `block-map`, `block-countdown`,
`block-social`, `block-crumbs`, `block-spacer`, `block-tabs` (`tabs--h|v`, `tabs--pills`;
`.tabs-list` → `.tabs-tab.is-on`, `.tabs-panel` с обычными `.layout-row` внутри).

Коллекции: «Список записей» — `block-cards-group block-coll coll--grid|coll--list`
(внутри та же разметка `.card`, что у «Карточек», плюс `.card-date` и кнопка
`.coll-more`). Страница записи — `<main class="site-main coll-entry">`: первый
ряд `.coll-head-row` (`.coll-head` → `.coll-date`, `h1`, `.coll-tags`,
`.coll-cover`), последний — `.coll-nav-row` (`.coll-nav__prev`, `__back`, `__next`).

Базовый вид новых модулей задан в `ucms.css` — тема может переопределить любой
из них. Выравнивание колонки передаётся модулям переменной `--ucms-justify`
(`flex-start` / `center` / `flex-end`) — используйте её в модулях на flex.

Свой `robots.txt` в папке темы заменит сгенерированный.

**Стиль проекта.** В админке (Тема → Стиль проекта) владелец сайта может
переопределить токены `--paper`, `--panel`, `--ink`, `--muted`, `--accent`,
`--line`, `--radius`, `--font-body`, `--font-head` и размер текста `body` —
блок дописывается после темы. Чтобы тема слушалась этих настроек, берите цвета,
скругления и шрифты из токенов, а не пишите значения напрямую.

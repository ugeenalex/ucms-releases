# Выпуск версии

1. `VERSION` — новый номер (`X.Y.Z`; тестовая — `X.Y.Z-beta.N`).
2. `CHANGELOG.md` — раздел `## X.Y.Z — дата` со списком изменений (он же станет
   текстом «Что нового» в UCMS).
3. Коммит в `main` репозитория `ugeenalex/UCMS`.
4. `node tools/make-release.js` → в папке `release/`:
   `ucms-X.Y.Z.zip`, `ucms-X.Y.Z-sha256.txt`, `notes-X.Y.Z.md`.
5. github.com/ugeenalex/ucms-releases → **Releases → Draft a new release**:
   - Tag: `vX.Y.Z` (Create new tag), Title: `UCMS X.Y.Z`;
   - описание — содержимое `notes-X.Y.Z.md`;
   - прикрепить **оба** файла: `ucms-X.Y.Z.zip` и `ucms-X.Y.Z-sha256.txt`
     (без файла контрольной суммы UCMS обновление не установит);
   - тестовая версия — отметить **Set as a pre-release**;
   - **Publish release**.

Через несколько минут UCMS у пользователей покажет «Доступна новая версия»
(или сразу — по «Проверить сейчас»).

Удалить релиз можно в любой момент — у тех, кто уже обновился, ничего не сломается.

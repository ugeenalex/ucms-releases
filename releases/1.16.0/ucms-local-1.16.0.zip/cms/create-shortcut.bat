@echo off
chcp 65001 >nul
rem Создаёт ярлык «UCMS» на рабочем столе: двойной клик — запуск сервера и открытие админки.
rem Окно сервера открывается свёрнутым; чтобы остановить UCMS, закройте его на панели задач.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\UCMS.lnk'); $s.TargetPath='%~dp0start.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.IconLocation='%~dp0engine\admin\ucms.ico'; $s.Description='UCMS admin'; $s.Save()"
if errorlevel 1 (
  echo Не удалось создать ярлык.
) else (
  echo Готово: на рабочем столе появился ярлык UCMS.
)
pause

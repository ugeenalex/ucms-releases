#!/usr/bin/env node
/**
 * Запускалка UCMS.
 *   Windows: start.bat (или ярлык с рабочего стола — create-shortcut.bat)
 *   macOS:   start.command
 *   Linux:   node start.js
 * Если сервер уже запущен (например, из автозапуска), просто открывает админку.
 * Флаг --no-browser — запустить сервер без открытия браузера (для автозапуска).
 */
const { spawn, exec } = require('child_process');
const http = require('http');
const path = require('path');

const PORT = process.env.PORT || 3000;
const URL = `http://localhost:${PORT}/`;   // стартовая страница со списком проектов
const noBrowser = process.argv.includes('--no-browser');

function openBrowser() {
  const cmd = process.platform === 'win32' ? `start "" "${URL}"` : process.platform === 'darwin' ? `open "${URL}"` : `xdg-open "${URL}"`;
  exec(cmd, () => {});
}

// Уже работает? GET /api/ping отвечает { app: 'ucms' }
function ping() {
  return new Promise(resolve => {
    const req = http.get(`http://127.0.0.1:${PORT}/api/ping`, { timeout: 800 }, res => {
      let body = '';
      res.on('data', c => { body += c; });
      res.on('end', () => { try { resolve(JSON.parse(body).app === 'ucms'); } catch (e) { resolve(false); } });
    });
    req.on('timeout', () => { req.destroy(); resolve(false); });
    req.on('error', () => resolve(false));
  });
}

ping().then(running => {
  if (running) {
    console.log(`UCMS уже запущен: ${URL}`);
    if (!noBrowser) openBrowser();
    setTimeout(() => process.exit(0), 300);
    return;
  }
  // Код выхода 75 — сервер обновился и просит перезапуска: поднимаем его снова (уже без браузера)
  const run = openIt => {
    const srv = spawn(process.execPath, [path.join(__dirname, 'engine', 'server.js')], {
      stdio: 'inherit',
      env: { ...process.env, OPEN_BROWSER: openIt ? '1' : '0', UCMS_LAUNCHER: '1' },
    });
    srv.on('exit', code => {
      if (code === 75) { console.log('Перезапуск UCMS после обновления…'); setTimeout(() => run(false), 300); return; }
      process.exit(code || 0);
    });
  };
  run(!noBrowser);
});

@echo off
chcp 65001 >nul
rem Включает/выключает запуск UCMS при входе в Windows (сервер стартует свёрнутым, без браузера).
rem Админка тогда всегда доступна по адресу http://localhost:3000/admin/ — например, из закладки.
set "LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\UCMS.lnk"
if exist "%LNK%" (
  del "%LNK%"
  echo Автозапуск UCMS выключен.
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut($env:LNK); $s.TargetPath='%~dp0start.bat'; $s.Arguments='--no-browser'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.IconLocation='%~dp0engine\admin\ucms.ico'; $s.Save()"
  echo Автозапуск UCMS включён: сервер будет запускаться при входе в Windows.
)
pause

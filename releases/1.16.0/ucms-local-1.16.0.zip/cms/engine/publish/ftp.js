'use strict';
/**
 * Минимальный FTP/FTPS-клиент на net/tls (без зависимостей).
 * Умеет ровно то, что нужно для публикации и получения проекта: вход, PASV, MKD, STOR, RETR, SIZE, DELE, QUIT.
 * FTPS — «явный» (AUTH TLS на порту 21), как у большинства хостингов.
 * Data-соединения в FTPS переиспользуют TLS-сессию управляющего канала —
 * этого требуют vsftpd/ProFTPD/FileZilla Server по умолчанию.
 */
const net = require('net');
const tls = require('tls');

class FtpError extends Error {
  constructor(message, code) { super(message); this.code = code; }
}

class FtpClient {
  constructor(opts) {
    this.host = opts.host;
    this.port = opts.port || 21;
    this.user = opts.user || 'anonymous';
    this.password = opts.password || '';
    this.secure = !!opts.secure;
    this.allowSelfSigned = !!opts.allowSelfSigned;
    this.timeout = opts.timeout || 20000;
    this.sock = null;
    this.buf = '';
    this.lines = [];        // накопленные строки текущего ответа
    this.waiters = [];      // ожидающие ответа
    this.early = [];        // ответы, пришедшие раньше, чем их начали ждать (150 и 226 одним пакетом при RETR)
    this.session = null;    // TLS-сессия для data-каналов
    this.madeDirs = new Set();
  }

  _tlsOpts(socket) {
    return { socket, servername: net.isIP(this.host) ? undefined : this.host, rejectUnauthorized: !this.allowSelfSigned, session: this.session || undefined };
  }

  _attach(sock) {
    this.sock = sock;
    sock.setEncoding('utf8');
    sock.setTimeout(this.timeout, () => sock.destroy(new FtpError('Сервер не отвечает (таймаут)')));
    sock.on('data', d => this._onData(d));
    sock.on('error', e => this._fail(e));
    sock.on('close', () => this._fail(new FtpError('Соединение закрыто сервером')));
  }

  _fail(err) {
    const w = this.waiters.splice(0);
    w.forEach(x => x.reject(err));
  }

  // Ответ FTP: «123 текст» или многострочный «123-…» … «123 текст».
  _onData(chunk) {
    this.buf += chunk;
    let i;
    while ((i = this.buf.indexOf('\n')) >= 0) {
      const line = this.buf.slice(0, i).replace(/\r$/, '');
      this.buf = this.buf.slice(i + 1);
      this.lines.push(line);
      const first = this.lines[0];
      const m = /^(\d{3})([ -])/.exec(first);
      if (!m) { this.lines = []; continue; }
      if (m[2] === ' ' || (line.startsWith(m[1] + ' ') && this.lines.length > 1)) {
        const resp = { code: +m[1], text: this.lines.join('\n') };
        this.lines = [];
        const w = this.waiters.shift();
        if (w) w.resolve(resp); else this.early.push(resp);
      }
    }
  }

  _read() {
    if (this.early.length) return Promise.resolve(this.early.shift());
    return new Promise((resolve, reject) => this.waiters.push({ resolve, reject }));
  }

  async send(cmd, okCodes) {
    const p = this._read();
    this.sock.write(cmd + '\r\n');
    const r = await p;
    if (okCodes && !okCodes.includes(r.code)) {
      const shown = cmd.startsWith('PASS ') ? 'PASS ***' : cmd;
      throw new FtpError(`${shown}: ${r.text}`, r.code);
    }
    return r;
  }

  async connect() {
    const raw = net.connect({ host: this.host, port: this.port });
    await new Promise((res, rej) => { raw.once('connect', res); raw.once('error', rej); raw.setTimeout(this.timeout, () => raw.destroy(new FtpError('Не удалось подключиться (таймаут)'))); });
    this._attach(raw);
    const hello = await this._read();
    if (hello.code !== 220) throw new FtpError(`Сервер ответил: ${hello.text}`, hello.code);
    if (this.secure) {
      await this.send('AUTH TLS', [234]);
      raw.removeAllListeners('data'); raw.removeAllListeners('close'); raw.removeAllListeners('error');
      const t = tls.connect(this._tlsOpts(raw));
      t.on('session', s => { this.session = s; });
      await new Promise((res, rej) => { t.once('secureConnect', res); t.once('error', rej); });
      this._attach(t);
    }
    const u = await this.send(`USER ${this.user}`, [230, 331]);
    if (u.code === 331) await this.send(`PASS ${this.password}`, [230, 202]);
    if (this.secure) { await this.send('PBSZ 0', [200]); await this.send('PROT P', [200]); }
    await this.send('TYPE I', [200]);
  }

  // Пассивный режим. IP из ответа PASV игнорируем — за NAT он часто внутренний.
  async _dataSocket() {
    const r = await this.send('PASV', [227]);
    const m = /(\d+),(\d+),(\d+),(\d+),(\d+),(\d+)/.exec(r.text);
    if (!m) throw new FtpError(`Не понял ответ PASV: ${r.text}`);
    const port = (+m[5]) * 256 + (+m[6]);
    const raw = net.connect({ host: this.host, port });
    await new Promise((res, rej) => { raw.once('connect', res); raw.once('error', rej); });
    if (!this.secure) return raw;
    return raw;   // TLS поднимаем после команды STOR (сервер начинает рукопожатие после 150)
  }

  async mkdirp(dir) {
    const parts = dir.split('/').filter(Boolean);
    let cur = dir.startsWith('/') ? '' : '.';
    for (const p of parts) {
      cur = cur === '.' ? p : `${cur}/${p}`;
      const path = dir.startsWith('/') && !cur.startsWith('/') ? `/${cur}` : cur;
      if (this.madeDirs.has(path)) continue;
      const r = await this.send(`MKD ${path}`);
      if (![257, 250, 550, 521, 553].includes(r.code)) throw new FtpError(`MKD ${path}: ${r.text}`, r.code);
      this.madeDirs.add(path);   // 550 «уже существует» — тоже ок
    }
  }

  async put(buffer, remotePath) {
    const raw = await this._dataSocket();
    const pre = this._read();
    this.sock.write(`STOR ${remotePath}\r\n`);
    const r1 = await pre;
    if (![125, 150].includes(r1.code)) { raw.destroy(); throw new FtpError(`STOR ${remotePath}: ${r1.text}`, r1.code); }
    let data = raw;
    if (this.secure) {
      data = tls.connect(this._tlsOpts(raw));
      await new Promise((res, rej) => { data.once('secureConnect', res); data.once('error', rej); });
    }
    const done = this._read();
    await new Promise((res, rej) => {
      data.once('error', rej);
      data.end(buffer, res);
    });
    await new Promise(res => { if (data.destroyed) res(); else data.once('close', res); });
    const r2 = await done;
    if (![226, 250].includes(r2.code)) throw new FtpError(`STOR ${remotePath}: ${r2.text}`, r2.code);
  }

  // Скачать файл → Buffer. Нет файла — FtpError с кодом 550.
  async get(remotePath, limit = 500 * 1024 * 1024) {
    const raw = await this._dataSocket();
    const pre = this._read();
    this.sock.write(`RETR ${remotePath}\r\n`);
    const r1 = await pre;
    if (![125, 150].includes(r1.code)) { raw.destroy(); throw new FtpError(`RETR ${remotePath}: ${r1.text}`, r1.code); }
    let data = raw;
    if (this.secure) {
      data = tls.connect(this._tlsOpts(raw));
      await new Promise((res, rej) => { data.once('secureConnect', res); data.once('error', rej); });
    }
    const done = this._read();
    const chunks = []; let size = 0;
    await new Promise((res, rej) => {
      data.on('data', d => { size += d.length; if (size > limit) { data.destroy(); rej(new FtpError(`Файл слишком большой: ${remotePath}`)); return; } chunks.push(d); });
      data.once('error', rej);
      data.once('end', res);
      data.once('close', res);
    });
    const r2 = await done;
    if (![226, 250].includes(r2.code)) throw new FtpError(`RETR ${remotePath}: ${r2.text}`, r2.code);
    return Buffer.concat(chunks);
  }

  // Есть ли файл: SIZE (RFC 3659) → размер или null
  async size(remotePath) {
    const r = await this.send(`SIZE ${remotePath}`);
    return r.code === 213 ? parseInt(r.text.slice(4), 10) : null;
  }

  async remove(remotePath) {
    const r = await this.send(`DELE ${remotePath}`);
    return r.code === 250;
  }

  async close() {
    if (!this.sock || this.sock.destroyed) return;
    try { await Promise.race([this.send('QUIT'), new Promise(r => setTimeout(r, 1500))]); } catch (e) { /* уже закрыто */ }
    this.sock.removeAllListeners('close');
    this.sock.destroy();
  }
}

module.exports = { FtpClient, FtpError };

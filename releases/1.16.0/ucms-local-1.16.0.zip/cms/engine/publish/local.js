'use strict';
/**
 * Публикация в папку на этом же сервере (веб-версия, UCMS_PUBLISH_DIR) — например, в
 * httpdocs домена в Plesk. Как FTP-публикация, только без сети:
 *   • копируются только изменившиеся файлы (sha1 сверяется с прошлой публикацией);
 *   • удаляются только файлы, которые UCMS сама положила раньше и которых больше нет в сборке;
 *   • чужие файлы в папке (.well-known, свои скрипты, файлы хостинга) не трогаются.
 * Запись — через временный файл и переименование: посетитель не увидит недописанную страницу.
 * Состояние — <проект>/.publish/local-<хеш папки>.json.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function listFiles(dir, base = dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, e.name);
    if (e.isDirectory()) listFiles(abs, base, out);
    else if (e.isFile()) out.push(path.relative(base, abs).split(path.sep).join('/'));
  }
  return out;
}
const sha1 = b => crypto.createHash('sha1').update(b).digest('hex');

function publishToDir({ outputDir, targetDir, contentDir }) {
  const target = path.resolve(targetDir);
  if (!fs.existsSync(target) || !fs.statSync(target).isDirectory()) throw new Error(`Папка публикации не найдена: ${target}`);
  const stateFile = path.join(contentDir, '.publish', `local-${sha1(target).slice(0, 12)}.json`);
  let state = {};
  try { state = JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch (e) { /* первая публикация */ }

  const files = listFiles(outputDir);
  const next = {};
  let copied = 0, skipped = 0, deleted = 0;
  for (const rel of files) {
    const buf = fs.readFileSync(path.join(outputDir, rel));
    const h = sha1(buf);
    const dst = path.join(target, ...rel.split('/'));
    if (!path.resolve(dst).startsWith(target + path.sep)) continue;
    next[rel] = h;
    if (state[rel] === h && fs.existsSync(dst)) { skipped++; continue; }
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    const tmp = `${dst}.ucms-tmp-${process.pid}`;
    fs.writeFileSync(tmp, buf);
    fs.renameSync(tmp, dst);
    copied++;
  }
  // свои прежние файлы, которых больше нет в сборке
  for (const rel of Object.keys(state)) {
    if (next[rel]) continue;
    const dst = path.join(target, ...rel.split('/'));
    if (!path.resolve(dst).startsWith(target + path.sep)) continue;
    try { fs.unlinkSync(dst); deleted++; } catch (e) { /* уже нет */ }
    // пустые папки, оставшиеся после удаления (но не саму папку публикации)
    let dir = path.dirname(dst);
    while (dir.startsWith(target + path.sep)) {
      try { if (fs.readdirSync(dir).length) break; fs.rmdirSync(dir); } catch (e) { break; }
      dir = path.dirname(dir);
    }
  }
  fs.mkdirSync(path.dirname(stateFile), { recursive: true });
  fs.writeFileSync(stateFile, JSON.stringify(next), 'utf8');
  return { copied, skipped, deleted, total: files.length };
}

module.exports = { publishToDir };

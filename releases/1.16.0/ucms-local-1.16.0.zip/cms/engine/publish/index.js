'use strict';
/**
 * Публикация папки output/ проекта на хостинг по FTP/FTPS (+ исходники проекта — project.js).
 * Загружаются только изменившиеся файлы: хэши уже отправленных хранятся в
 * .publish/<сервер>.json в папке проекта. Файлы, которые мы раньше загрузили, а теперь
 * их нет в output, удаляются с сервера (чужие файлы на сервере не трогаем).
 * Настройки подключения — publish.json в папке проекта (пароли не уходят в db.json и на сервер).
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const { FtpClient } = require('./ftp');
const project = require('./project');

const DEFAULTS = {
  protocol: 'ftps', host: '', port: 21, user: '', password: '', dir: '/', allowSelfSigned: false,
  // Проект на сервере (project.js): хранить исходники рядом с сайтом, папка ('' — по умолчанию), шифрование
  projectSync: true, projectDir: '', encrypt: false, projectPassword: '',
};
function client(cfg) {
  return new FtpClient({ host: cfg.host, port: cfg.port, user: cfg.user, password: cfg.password, secure: cfg.protocol !== 'ftp', allowSelfSigned: cfg.allowSelfSigned });
}
function cleanConfig(input, cur = DEFAULTS) {
  return {
    protocol: input.protocol === 'ftp' ? 'ftp' : 'ftps',
    host: String(input.host || '').trim().replace(/^s?ftps?:\/\//i, '').replace(/\/.*$/, ''),
    port: Math.min(65535, Math.max(1, parseInt(input.port, 10) || 21)),
    user: String(input.user || '').trim(),
    password: input.password ? String(input.password) : cur.password,
    dir: String(input.dir || '/').trim() || '/',
    allowSelfSigned: !!input.allowSelfSigned,
    projectSync: input.projectSync !== false,
    projectDir: String(input.projectDir || '').trim(),
    encrypt: !!input.encrypt,
    projectPassword: input.clearProjectPassword ? '' : input.projectPassword ? String(input.projectPassword) : cur.projectPassword,
  };
}
function stateKey(cfg, extra) { return crypto.createHash('sha1').update(`${cfg.host}|${cfg.port}|${cfg.user}|${extra}`).digest('hex').slice(0, 16); }

function createPublisher({ contentDir, outputDir, version }) {
  const CONFIG = path.join(contentDir, 'publish.json');
  const STATE_DIR = path.join(contentDir, '.publish');

  function readConfig() {
    try { return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(CONFIG, 'utf8')) }; } catch (e) { return { ...DEFAULTS }; }
  }
  function publicConfig() {
    const c = readConfig();
    const out = { ...c, hasPassword: !!c.password, hasProjectPassword: !!c.projectPassword, project: project.target(c) };
    delete out.password; delete out.projectPassword;
    return out;
  }
  // Пустой пароль в форме = «не менять сохранённый».
  function saveConfig(input) {
    const next = cleanConfig(input, readConfig());
    fs.writeFileSync(CONFIG, JSON.stringify(next, null, 2), 'utf8');
    return publicConfig();
  }

  function remotePath(cfg, rel) { return path.posix.join(cfg.dir || '/', rel); }

  function stateFile(cfg) { return path.join(STATE_DIR, `${stateKey(cfg, cfg.dir)}.json`); }
  // Версия проекта, которую этот компьютер последней отправил или получил (для проверки «на сервере новее»)
  function knownFile(cfg) { return path.join(STATE_DIR, `${stateKey(cfg, project.target(cfg).dir)}.project.json`); }
  function readKnown(cfg) { try { return JSON.parse(fs.readFileSync(knownFile(cfg), 'utf8')); } catch (e) { return {}; } }
  function writeKnown(cfg, rev) {
    fs.mkdirSync(STATE_DIR, { recursive: true });
    fs.writeFileSync(knownFile(cfg), JSON.stringify({ rev, at: Date.now() }), 'utf8');
  }
  function readState(cfg) { try { return JSON.parse(fs.readFileSync(stateFile(cfg), 'utf8')); } catch (e) { return {}; } }
  function writeState(cfg, st) {
    fs.mkdirSync(STATE_DIR, { recursive: true });
    fs.writeFileSync(stateFile(cfg), JSON.stringify(st), 'utf8');
  }
  function resetState() { fs.rmSync(stateFile(readConfig()), { force: true }); }

  function listFiles(dir, base = dir, out = []) {
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      const abs = path.join(dir, ent.name);
      if (ent.isDirectory()) listFiles(abs, base, out);
      else out.push({ abs, rel: path.relative(base, abs).split(path.sep).join('/') });
    }
    return out;
  }

  function check(cfg) {
    if (!cfg.host) throw new Error('Не указан сервер');
    if (!cfg.user) throw new Error('Не указан логин');
  }

  // Подключение + можно ли писать в папку проекта (выше публичной папки хостинг иногда не пускает)
  async function test() {
    const cfg = readConfig(); check(cfg);
    const c = client(cfg);
    const t = project.target(cfg);
    let projectWritable = null;
    try {
      await c.connect(); await c.mkdirp(cfg.dir || '/');
      if (t.enabled) {
        try {
          await c.mkdirp(t.dir);
          const probe = path.posix.join(t.dir, `.ucms-test-${Date.now()}`);
          await c.put(Buffer.from('ok'), probe); await c.remove(probe);
          projectWritable = true;
        } catch (e) { projectWritable = false; }
      }
    } finally { await c.close(); }
    return { ok: true, project: { ...t, writable: projectWritable } };
  }

  // Что с проектом на сервере: none — ещё не отправлялся; same — как у нас; remote-newer — изменён с другого компьютера
  async function status() {
    const cfg = readConfig();
    const t = project.target(cfg);
    if (!cfg.host || !t.enabled) return { configured: !!cfg.host, enabled: t.enabled, target: t };
    const c = client(cfg);
    try {
      await c.connect();
      const remote = await project.readManifest(c, t.dir);
      const known = readKnown(cfg).rev || '';
      return { configured: true, enabled: true, target: t, remote, known, mine: !!remote && remote.computer === os.hostname(),
        state: !remote ? 'none' : remote.rev === known ? 'same' : 'remote-newer' };
    } finally { await c.close(); }
  }

  // Получить проект с сервера в этот (открытый) проект. apply(pkg) — сервер записывает данные
  // (резервная копия, снимок истории, db.json); затем докачиваются картинки.
  async function pull(onProgress, apply) {
    const cfg = readConfig(); check(cfg);
    const t = project.target(cfg);
    const c = client(cfg);
    try {
      onProgress({ phase: 'connect', done: 0, total: 0, current: cfg.host });
      await c.connect();
      const remote = await project.readManifest(c, t.dir);
      if (!remote) throw new Error('На сервере нет проекта — сначала опубликуйте сайт');
      onProgress({ phase: 'download', done: 0, total: 0, current: remote.file });
      const pkg = await project.fetchPackage(c, t.dir, remote, cfg.projectPassword);
      await apply(pkg);
      const up = await project.downloadUploads(c, cfg, pkg.uploads, path.join(contentDir, 'uploads'), (done, total, rel) => onProgress({ phase: 'files', done, total, current: rel }));
      markUploads(cfg, up.got);
      writeKnown(cfg, remote.rev);
      return { rev: remote.rev, remote, missing: up.missing };
    } finally { await c.close(); }
  }
  // Скачанные картинки уже лежат на сервере — следующая публикация их не перезаливает
  function markUploads(cfg, got) {
    const st = readState(cfg);
    Object.entries(got).forEach(([rel, h]) => { st[`uploads/${rel}`] = h; });
    writeState(cfg, st);
  }

  // onProgress({ phase, done, total, current }). force — опубликовать, даже если на сервере проект новее.
  async function publish(onProgress, { force = false } = {}) {
    const cfg = readConfig(); check(cfg);
    const files = listFiles(outputDir);
    const state = readState(cfg);
    const changed = [];
    for (const f of files) {
      const hash = crypto.createHash('sha1').update(fs.readFileSync(f.abs)).digest('hex');
      if (state[f.rel] !== hash) changed.push({ ...f, hash });
    }
    const present = new Set(files.map(f => f.rel));
    const removed = Object.keys(state).filter(rel => !present.has(rel));
    const total = changed.length + removed.length;
    onProgress({ phase: 'connect', done: 0, total, current: cfg.host });

    const c = client(cfg);
    const t = project.target(cfg);
    let done = 0, remote = null, projectResult = null, projectError = null;
    try {
      await c.connect();
      // Сайт изменили с другого компьютера — не затираем ни сайт, ни проект, пока не решат
      if (t.enabled) {
        remote = await project.readManifest(c, t.dir);
        const known = readKnown(cfg).rev || '';
        if (remote && remote.rev !== known && !force) {
          const e = new Error('Проект на сервере изменён с другого компьютера');
          e.code = 'REMOTE_NEWER'; e.remote = remote; throw e;
        }
      }
      await c.mkdirp(cfg.dir || '/');
      for (const f of changed) {
        onProgress({ phase: 'upload', done, total, current: f.rel });
        const remote = remotePath(cfg, f.rel);
        await c.mkdirp(path.posix.dirname(remote));
        await c.put(fs.readFileSync(f.abs), remote);
        state[f.rel] = f.hash;
        if (++done % 10 === 0) writeState(cfg, state);   // обрыв на середине не заставит грузить всё заново
      }
      for (const rel of removed) {
        onProgress({ phase: 'delete', done, total, current: rel });
        await c.remove(remotePath(cfg, rel));
        delete state[rel];
        done++;
      }
      // Исходники проекта — после сайта. Ошибка здесь не отменяет публикацию сайта.
      if (t.enabled) {
        onProgress({ phase: 'project', done, total, current: t.dir });
        try {
          projectResult = await project.pushProject(c, { contentDir, cfg, version, prev: remote });
          writeKnown(cfg, projectResult.rev);
        } catch (e) { projectError = { message: e.message, code: e.code || '' }; }
      }
    } finally {
      writeState(cfg, state);
      await c.close();
    }
    return { uploaded: changed.length, deleted: removed.length, skipped: files.length - changed.length, total: files.length,
      project: projectResult && { rev: projectResult.rev, dir: projectResult.dir, unchanged: !!projectResult.unchanged }, projectError };
  }

  return { readConfig, publicConfig, saveConfig, resetState, test, publish, status, pull,
    _mark: (cfg, got, rev) => { markUploads(cfg, got); writeKnown(cfg, rev); } };
}

// ── Без открытого проекта: «Добавить существующий → С сервера» ──
// Найти проект на сервере. С паролем — расшифровать и показать название.
async function inspectRemote(input, password) {
  const cfg = cleanConfig(input);
  if (!cfg.host || !cfg.user) throw new Error('Укажите сервер и логин');
  const c = client(cfg);
  try {
    await c.connect();
    const found = await project.findProject(c, cfg);
    if (!found) return { found: false, site: project.target(cfg).site };
    const m = found.manifest;
    const out = { found: true, dir: found.dir, encrypted: !!m.encrypted, updatedAt: m.updatedAt, computer: m.computer, engine: m.engine, title: m.title || '', pages: m.pages };
    if (m.encrypted && password) {
      const pkg = await project.fetchPackage(c, found.dir, m, password);
      out.title = pkg.db.settings.siteTitle || ''; out.pages = pkg.db.pages.length; out.passwordOk = true;
    }
    return out;
  } finally { await c.close(); }
}

// Скачать проект в новую папку: пакет, картинки, настройки публикации (с паролями — они вводились здесь)
async function cloneRemote(input, password, destDir, version, onProgress) {
  const cfg = cleanConfig(input);
  const c = client(cfg);
  try {
    onProgress({ phase: 'connect', done: 0, total: 0, current: cfg.host });
    await c.connect();
    const found = await project.findProject(c, cfg);
    if (!found) throw new Error('На сервере нет проекта UCMS');
    onProgress({ phase: 'download', done: 0, total: 0, current: found.manifest.file });
    const pkg = await project.fetchPackage(c, found.dir, found.manifest, password);
    const db = project.writePackage(pkg, destDir);
    fs.writeFileSync(path.join(destDir, 'db.json'), JSON.stringify(db, null, 2), 'utf8');
    const full = { ...cfg, projectDir: found.dir, projectPassword: found.manifest.encrypted ? String(password || '') : cfg.projectPassword, encrypt: !!found.manifest.encrypted };
    fs.writeFileSync(path.join(destDir, 'publish.json'), JSON.stringify(full, null, 2), 'utf8');
    const pub = createPublisher({ contentDir: destDir, outputDir: path.join(destDir, 'output'), version });
    const up = await project.downloadUploads(c, full, pkg.uploads, path.join(destDir, 'uploads'), (done, total, rel) => onProgress({ phase: 'files', done, total, current: rel }));
    pub._mark(full, up.got, found.manifest.rev);
    return { title: db.settings.siteTitle || '', missing: up.missing, rev: found.manifest.rev };
  } finally { await c.close(); }
}

module.exports = { createPublisher, inspectRemote, cloneRemote };

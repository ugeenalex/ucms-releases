/* ============================================================
   ИСТОРИЯ: отмена/повтор действий и версии сайта.

   1) Отмена/повтор (Ctrl+Z / Ctrl+Shift+Z, Ctrl+Y, кнопки ↶ ↷ вверху).
      После каждого действия (клик, ввод, перетаскивание — с паузой 600 мс)
      снимаем состояние админки (App.undoSnap — JSON без темы) и кладём в стек,
      если оно изменилось. Отмена — применить предыдущий снимок
      (App.undoApply), сохраняется он обычным автосохранением.
      В полях ввода и в тексте Ctrl+Z — родная отмена браузера.
      Память: не больше UNDO_LIMIT шагов и UNDO_MAX_CHARS символов на весь
      стек — старые шаги вытесняются.

   2) Версии (раздел «История»): снимки db.json на сервере (lib/history.js).
      Можно вернуть версию целиком, одну страницу, шапку или подвал;
      перед возвратом сервер сам сохраняет текущее состояние.
   ============================================================ */
(function () {
  'use strict';
  var App = window.App;
  var UNDO_LIMIT = 100;
  var UNDO_MAX_CHARS = 40e6;   // ≈80 МБ строк в памяти — потолок для очень больших сайтов
  var U = { stack: [], idx: -1, chars: 0, timer: null, ready: false };
  var H = { list: null, open: {}, busy: '', editing: null, error: '' };

  function S() { return App._state; }
  function K() { return App.kit; }
  function toast(t, bad) { if (App.toast) App.toast(t, bad); }

  /* ══════════════ Отмена / повтор ══════════════ */
  function canUndo() { return U.ready && U.idx > 0; }
  function canRedo() { return U.ready && U.idx < U.stack.length - 1; }
  function refreshButtons() {
    var u = document.querySelector('[data-undo]'), r = document.querySelector('[data-redo]');
    if (u) u.disabled = !canUndo();
    if (r) r.disabled = !canRedo();
  }
  function trim() {
    while (U.stack.length > 1 && (U.stack.length > UNDO_LIMIT || U.chars > UNDO_MAX_CHARS)) {
      U.chars -= U.stack.shift().length; U.idx--;
    }
  }
  function capture() {
    clearTimeout(U.timer); U.timer = null;
    if (!U.ready || !App.undoSnap) return;
    var j = App.undoSnap();
    if (!j || U.stack[U.idx] === j) return;
    // новое действие после отмены — ветка «повтора» пропадает
    U.stack.slice(U.idx + 1).forEach(function (x) { U.chars -= x.length; });
    U.stack.length = U.idx + 1;
    U.stack.push(j); U.chars += j.length; U.idx++;
    trim(); refreshButtons();
  }
  function schedule() {
    if (!U.ready) return;
    clearTimeout(U.timer);
    U.timer = setTimeout(capture, 600);
  }
  // Вызывает мост после загрузки данных. keep — перезагрузка после возврата версии:
  // стек сохраняем, новое состояние становится шагом (его можно отменить).
  App.undoBaseline = function (keep) {
    if (keep && U.ready) { U.timer = setTimeout(capture, 0); return; }
    U.stack = []; U.idx = -1; U.chars = 0; U.ready = true;
    setTimeout(function () { capture(); refreshButtons(); }, 0);
  };
  function go(dir) {
    if (U.timer) capture();                    // незафиксированное действие — сначала в стек
    var to = U.idx + dir;
    if (!U.ready || to < 0 || to >= U.stack.length) return;
    U.idx = to;
    App.undoApply(U.stack[to]);
    // после применения состояние нормализуется (id, значения по умолчанию) — запоминаем его
    var j = App.undoSnap();
    if (j) { U.chars += j.length - U.stack[to].length; U.stack[to] = j; }
    refreshButtons();
    toast(dir < 0 ? _t('Отменено') : _t('Повторено'));
  }
  App.undo = function () { go(-1); };
  App.redo = function () { go(1); };
  App.undoButtons = function () {
    var k = K();
    return '<div class="ad-undo">' +
      '<button type="button" class="ad-ib" data-undo aria-label="' + k.escAttr(_t('Отменить (Ctrl+Z)')) + '" title="' + k.escAttr(_t('Отменить (Ctrl+Z)')) + '" onclick="App.undo()"' + (canUndo() ? '' : ' disabled') + '>' + k.ico('undo', 16) + '</button>' +
      '<button type="button" class="ad-ib" data-redo aria-label="' + k.escAttr(_t('Повторить (Ctrl+Shift+Z)')) + '" title="' + k.escAttr(_t('Повторить (Ctrl+Shift+Z)')) + '" onclick="App.redo()"' + (canRedo() ? '' : ' disabled') + '>' + k.ico('redo', 16) + '</button></div>';
  };

  // Любое действие в админке → снимок через паузу. Слушатели на document — один раз на всё время работы.
  ['click', 'input', 'change', 'drop', 'paste'].forEach(function (ev) {
    document.addEventListener(ev, function (e) {
      if (e.target && e.target.closest && e.target.closest('[data-undo],[data-redo]')) return;
      schedule();
    });
  });
  function editable(el) {
    return el && (el.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName));
  }
  document.addEventListener('keydown', function (e) {
    if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
    if (document.body.classList.contains('pv-open')) return;   // открыт предпросмотр
    var undo = e.code === 'KeyZ' && !e.shiftKey, redo = (e.code === 'KeyZ' && e.shiftKey) || e.code === 'KeyY';
    if (!undo && !redo) return;
    if (editable(document.activeElement)) { schedule(); return; }   // в поле — отмена браузера
    e.preventDefault();
    if (undo) App.undo(); else App.redo();
  });

  /* ══════════════ Версии сайта ══════════════ */
  var REASON = { auto: _t('Автосохранение'), manual: _t('Версия'), 'before-restore': _t('Перед возвратом версии'), 'before-import': _t('Перед импортом') };
  var PART = { header: _t('Шапка'), footer: _t('Подвал'), languages: _t('Языки'), collections: _t('Коллекции'), site: _t('Настройки сайта') };

  function rerender() { if (S().view === 'history' && App.renderView) App.renderView(); }
  App.loadHistory = function () {
    H.error = '';
    return App.api.get('/api/history').then(function (d) { H.list = d.versions || []; rerender(); })
      .catch(function (e) { H.error = e.message; H.list = H.list || []; rerender(); });
  };

  function dayLabel(ts) {
    var d = new Date(ts), now = new Date();
    var start = function (x) { return new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime(); };
    var diff = Math.round((start(now) - start(d)) / 864e5);
    if (diff === 0) return _t('Сегодня');
    if (diff === 1) return _t('Вчера');
    return d.toLocaleDateString(window.ADMIN_LANG || 'ru', { day: 'numeric', month: 'long', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
  }
  function timeLabel(ts) { var d = new Date(ts); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
  function kb(n) { return n >= 1048576 ? (n / 1048576).toFixed(1) + ' ' + _t('МБ') : Math.max(1, Math.round(n / 1024)) + ' ' + _t('КБ'); }

  App.historySave = function () {
    var inp = document.getElementById('hist-name'), name = inp ? inp.value.trim() : '';
    H.busy = _t('Сохраняю…'); rerender();
    App.persistNow().then(function () { return App.api.post('/api/history/save', { label: name || _t('Версия') }); })
      .then(function () { H.busy = ''; toast(_t('Версия сохранена')); return App.loadHistory(); })
      .catch(function (e) { H.busy = ''; rerender(); toast(_t('Ошибка: ') + e.message, true); });
  };
  App.historyToggle = function (id) {
    if (H.open[id]) { delete H.open[id]; rerender(); return; }
    H.open[id] = 'loading'; rerender();
    // сравниваем с сохранённым состоянием — сначала сохраняем текущие правки
    App.persistNow().then(function () { return App.api.get('/api/history/diff?id=' + encodeURIComponent(id)); })
      .then(function (d) { if (H.open[id]) H.open[id] = d.diff; rerender(); })
      .catch(function (e) { delete H.open[id]; rerender(); toast(_t('Ошибка: ') + e.message, true); });
  };
  App.historyRestore = function (id, part, label) {
    var v = (H.list || []).filter(function (x) { return x.id === id; })[0];
    if (!v) return;
    if (part === 'all' && !confirm(_t('Вернуть сайт к версии от ') + new Date(v.at).toLocaleDateString(window.ADMIN_LANG || 'ru', { day: 'numeric', month: 'long' }) + ', ' + timeLabel(v.at) + '?\n' +
      _t('Текущее состояние сохранится в истории, а возврат можно отменить (Ctrl+Z).'))) return;
    capture();   // текущее состояние — шагом отмены: возврат версии можно отменить Ctrl+Z
    H.busy = _t('Возвращаю…'); rerender();
    App.persistNow()
      .then(function () { return App.api.post('/api/history/restore', { id: id, part: part }); })
      .then(function () { return App.reloadData(true); })
      .then(function () {
        H.busy = ''; H.open = {};
        toast(part === 'all' ? _t('Версия возвращена') : (label || _t('Часть версии')) + _t(' — возвращено'));
        return App.loadHistory();
      })
      .catch(function (e) { H.busy = ''; rerender(); toast(_t('Ошибка: ') + e.message, true); });
  };
  App.historyEdit = function (id) { H.editing = H.editing === id ? null : id; rerender(); var el = document.getElementById('hist-rename'); if (el) el.focus(); };
  App.historyRename = function (id) {
    var el = document.getElementById('hist-rename'); if (!el) return;
    App.api.post('/api/history/rename', { id: id, label: el.value }).then(function () { H.editing = null; return App.loadHistory(); })
      .catch(function (e) { toast(_t('Ошибка: ') + e.message, true); });
  };
  App.historyDelete = function (id) {
    if (!confirm(_t('Удалить эту версию из истории?'))) return;
    App.api.post('/api/history/delete', { id: id }).then(function () { delete H.open[id]; return App.loadHistory(); })
      .catch(function (e) { toast(_t('Ошибка: ') + e.message, true); });
  };

  function diffHTML(v, d) {
    var k = K(), J = k.jsArg;
    if (d === 'loading') return '<div class="hs-diff hs-diff--muted">' + _t('Сравниваю…') + '</div>';
    if (!d.pages.length && !d.parts.length) return '<div class="hs-diff hs-diff--muted">' + _t('Совпадает с текущим состоянием сайта.') + '</div>';
    var rows = d.pages.map(function (p) {
      var noun = p.entry ? _t('Запись') : _t('Страница');
      var st = p.status === 'changed' ? _t('изменена') : p.status === 'removed' ? _t('удалена позже') : _t('добавлена позже');
      var title = k.esc(p.title || _t('Без названия')) + (p.oldTitle ? ' <small>(' + _t('была «') + k.esc(p.oldTitle) + '»)</small>' : '');
      var btn = p.status === 'added' ? '<span class="hs-note">' + _t('при возврате всей версии исчезнет') + '</span>'
        : '<button type="button" class="ad-b ad-b--sm ad-b--line" onclick="App.historyRestore(' + J(v.id) + ',' + J('page:' + p.id) + ',' + J(p.title) + ')">' + (p.status === 'removed' ? _t('Вернуть') : _t('Вернуть эту')) + '</button>';
      return '<div class="hs-row"><span class="hs-chip hs-chip--' + p.status + '">' + st + '</span><span class="hs-row__t"><em>' + noun + '</em> ' + title + '</span>' + btn + '</div>';
    });
    d.parts.forEach(function (part) {
      var btn = part === 'header' || part === 'footer'
        ? '<button type="button" class="ad-b ad-b--sm ad-b--line" onclick="App.historyRestore(' + J(v.id) + ',' + J(part) + ',' + J(PART[part]) + ')">' + _t('Вернуть эту') + '</button>'
        : '<span class="hs-note">' + _t('только при возврате всей версии') + '</span>';
      rows.push('<div class="hs-row"><span class="hs-chip hs-chip--changed">' + _t('изменено') + '</span><span class="hs-row__t">' + k.esc(PART[part] || part) + '</span>' + btn + '</div>');
    });
    return '<div class="hs-diff"><div class="hs-diff__h">' + _t('Отличия этой версии от текущего сайта') + '</div>' + rows.join('') + '</div>';
  }

  App.renderHistoryView = function () {
    var k = K(), J = k.jsArg;
    var head = '<div class="ad-sec-h"><h1>' + _t('История') + '</h1><p>' +
      _t('Последние действия отменяются кнопками ↶ ↷ вверху или Ctrl+Z / Ctrl+Shift+Z. Ниже — версии сайта: они сохраняются сами, пока вы работаете (не чаще раза в 10 минут), и перед каждым возвратом. Вернуть можно всю версию или одну страницу, шапку, подвал.') + '</p></div>';
    var save = '<section class="ad-panel"><div class="ad-panel__t">' + _t('Сохранить версию') + '</div>' +
      '<div class="hs-save"><input id="hist-name" class="ad-in" placeholder="' + k.escAttr(_t('Например, «Перед редизайном главной»')) + '" onkeydown="if(event.key===\'Enter\')App.historySave()">' +
      '<button type="button" class="ad-b ad-b--primary" onclick="App.historySave()"' + (H.busy ? ' disabled' : '') + '>' + k.ico('check', 14) + _t('Сохранить') + '</button></div>' +
      '<span class="ad-f__hint">' + _t('Версии с названием не удаляются автоматически. Остальные хранятся: все за последние сутки, дальше — по одной за день, 30 дней.') + '</span>' +
      (H.busy ? '<span class="md-busy">' + k.esc(H.busy) + '</span>' : '') + '</section>';
    if (!H.list) return head + save + '<div class="md-empty">' + _t('Загрузка…') + '</div>';
    if (H.error) return head + save + '<div class="md-empty">' + k.esc(H.error) + '</div>';
    if (!H.list.length) return head + save + '<div class="md-empty">' + _t('Версий пока нет — первая появится при сохранении изменений.') + '</div>';
    var html = '', day = '';
    H.list.forEach(function (v) {
      var dl = dayLabel(v.at);
      if (dl !== day) { if (day) html += '</div>'; day = dl; html += '<div class="hs-day"><div class="hs-day__t">' + k.esc(dl) + '</div>'; }
      var open = H.open[v.id];
      var name = v.label ? '<b>' + k.esc(v.label) + '</b>' : '<span>' + k.esc(REASON[v.reason] || v.reason) + '</span>';
      var meta = v.pages + ' ' + _t('стр.') + (v.entries ? ' · ' + v.entries + ' ' + _t('зап.') : '') + ' · ' + kb(v.size) + (v.by ? ' · ' + _t('правки:') + ' ' + k.esc(v.by) : '');
      var rename = H.editing === v.id
        ? '<div class="hs-rename"><input id="hist-rename" class="ad-in ad-in--sm" value="' + k.escAttr(v.label) + '" placeholder="' + k.escAttr(_t('Название версии')) + '" onkeydown="if(event.key===\'Enter\')App.historyRename(' + J(v.id) + ');if(event.key===\'Escape\')App.historyEdit(' + J(v.id) + ')">' +
          '<button type="button" class="ad-b ad-b--sm ad-b--dark" onclick="App.historyRename(' + J(v.id) + ')">' + _t('Готово') + '</button></div>' : '';
      html += '<div class="hs-item' + (open ? ' is-open' : '') + (v.label ? ' is-named' : '') + '">' +
        '<div class="hs-item__h"><span class="hs-time">' + timeLabel(v.at) + '</span><span class="hs-name">' + name + '<small>' + meta + '</small></span>' +
        '<button type="button" class="ad-b ad-b--sm" onclick="App.historyToggle(' + J(v.id) + ')" aria-expanded="' + !!open + '">' + (open ? _t('Скрыть') : _t('Что изменилось')) + '</button>' +
        '<button type="button" class="ad-b ad-b--sm ad-b--line" onclick="App.historyRestore(' + J(v.id) + ',\'all\')"' + (H.busy ? ' disabled' : '') + '>' + k.ico('history', 13) + _t('Вернуть версию') + '</button>' +
        k.ib('pencil', _t('Название'), 'App.historyEdit(' + J(v.id) + ')') + k.ib('del', _t('Удалить версию'), 'App.historyDelete(' + J(v.id) + ')', { danger: true }) + '</div>' +
        rename + (open ? diffHTML(v, open) : '') + '</div>';
    });
    return head + save + '<section class="ad-panel hs-list">' + html + '</div></section>';
  };
})();

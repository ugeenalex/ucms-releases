// Lightweight syntax highlighter for the CMS code editors.
// Emits inline-styled <span>s (dark theme) so no stylesheet is needed.
// window.SyntaxHL.html(src) / .css(src) return highlighted HTML strings.
(function () {
  var C = {
    punct: '#8b8778',
    comment: '#6f6d5f',
    tag: '#7fc99a',
    attr: '#8fb8e6',
    string: '#c98a5a',
    prop: '#8fb8e6',
    value: '#c98a5a',
    selector: '#e6b95a',
    atrule: '#e6b95a',
    func: '#7fc99a'
  };
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function span(color, text) {
    return '<span style="color:' + color + '">' + text + '</span>';
  }

  // ---- HTML ----
  function tagHTML(tag) {
    var isClose = tag.slice(0,2) === '</';
    var isSelf  = tag.slice(-2) === '/>';
    var rawLead  = isClose ? 2 : 1;
    var rawTrail = isSelf  ? 2 : 1;
    var inner = tag.slice(rawLead, tag.length - rawTrail);
    var nm = inner.match(/^[a-zA-Z][\w:-]*/);
    var name = nm ? nm[0] : '';
    // Escape attrs for safe innerHTML output
    var attrs = esc(inner.slice(name.length));
    // Match attr=&quot;value&quot; or attr='value' in the escaped string
    attrs = attrs.replace(/([a-zA-Z_:][\w:-]*)(=)(&quot;[^<]*?&quot;|'[^']*')/g, function (m, n, eq, v) {
      return span(C.attr, n) + span(C.punct, eq) + span(C.string, v);
    });
    // Escape < > in the delimiters themselves
    var lead  = isClose ? '&lt;/' : '&lt;';
    var trail = isSelf  ? '/&gt;' : '&gt;';
    return span(C.punct, lead) + span(C.tag, esc(name)) + attrs + span(C.punct, trail);
  }
  function hlHTML(src) {
    var out = '', i = 0, n = src.length;
    while (i < n) {
      if (src.substr(i, 4) === '<!--') {
        var end = src.indexOf('-->', i);
        var seg = end < 0 ? src.slice(i) : src.slice(i, end + 3);
        out += span(C.comment, esc(seg));
        i += seg.length;
        if (end < 0) break;
        continue;
      }
      if (src[i] === '<') {
        var gt = src.indexOf('>', i);
        if (gt < 0) { out += esc(src.slice(i)); break; }
        out += tagHTML(src.slice(i, gt + 1));
        i = gt + 1;
        continue;
      }
      var lt = src.indexOf('<', i);
      if (lt < 0) lt = n;
      out += esc(src.slice(i, lt));
      i = lt;
    }
    return out;
  }

  // ---- CSS (single pass so emitted markup is never re-scanned) ----
  function hlCSS(src) {
    var e = esc(src);
    var re = /(\/\*[\s\S]*?\*\/)|("[^"]*"|'[^']*')|(#[0-9a-fA-F]{3,8}\b)|(@[\w-]+)|(-{0,2}[a-zA-Z][\w-]*)(\s*:)|(\.[a-zA-Z][\w-]*|#[a-zA-Z][\w-]*)|([a-zA-Z_-]+)(\()|(\b\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|s|ms|deg|fr|pt)?\b)/g;
    return e.replace(re, function (m, comment, str, hex, at, prop, propColon, sel, fn, fnParen, num) {
      if (comment != null) return span(C.comment, comment);
      if (str != null) return span(C.string, str);
      if (hex != null) return span(C.value, hex);
      if (at != null) return span(C.atrule, at);
      if (prop != null) return span(C.prop, prop) + propColon;
      if (sel != null) return span(C.selector, sel);
      if (fn != null) return span(C.func, fn) + fnParen;
      if (num != null) return span(C.value, num);
      return m;
    });
  }

  window.SyntaxHL = { html: hlHTML, css: hlCSS, esc: esc };
})();

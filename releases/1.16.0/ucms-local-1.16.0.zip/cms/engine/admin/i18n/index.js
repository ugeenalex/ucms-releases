/* Язык интерфейса админки.
   _t('русский текст') → перевод на выбранный язык. Тексты в коде — по-русски
   (исходный язык); словари — i18n/<код>.js. Перевод сначала ищется для строки
   целиком, затем по фрагментам: текст между HTML-тегами и в значениях атрибутов
   переводится отдельно, разметка и вставленные значения остаются как есть.
   Язык хранится в браузере (localStorage), смена — с перезагрузкой админки. */
(function () {
  'use strict';
  var KEY = 'ucms-admin-lang';
  var LANGS = window.UCMS_I18N || {};
  var lang = 'ru';
  try { lang = localStorage.getItem(KEY) || 'ru'; } catch (e) { /* приватный режим */ }
  if (!LANGS[lang]) lang = 'ru';
  var dict = (LANGS[lang] && LANGS[lang].dict) || {};
  var RUN = /[^<>"]*[А-Яа-яЁё][^<>"]*/g;
  var cache = new Map();
  var missing = new Set();   // для разработки: window.UCMS_I18N_MISSING — чего нет в словаре

  function t(s) {
    if (lang === 'ru' || typeof s !== 'string') return s;
    var hit = cache.get(s);
    if (hit !== undefined) return hit;
    var out = dict[s] !== undefined ? dict[s] : s.replace(RUN, function (run) {
      var m = /^(\s*)([\s\S]*?)(\s*)$/.exec(run), tr = dict[m[2]];
      if (tr === undefined) { missing.add(m[2]); return run; }
      return m[1] + tr + m[3];
    });
    cache.set(s, out);
    return out;
  }

  window._t = t;   // _t, а не t: в коде админки t — частое имя переменной (дерево)
  window.UCMS_I18N_MISSING = missing;
  window.ADMIN_LANG = lang;
  window.ADMIN_LANGS = Object.keys(LANGS).map(function (code) { return { code: code, label: LANGS[code].label || code }; });
  window.setAdminLang = function (code) {
    try { localStorage.setItem(KEY, code); } catch (e) { /* ignore */ }
  };
  /* Выпадающее меню языка интерфейса — общее для админки и списка проектов.
     window.adminLangMenu() → HTML кнопки и списка. Перед перезагрузкой вызывается
     window.UCMS_LANG.beforeReload (если задан и вернул Promise — ждём его: админка
     сохраняет несохранённое). Один слушатель кликов на документ — на всё время работы. */
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }
  var GLOBE = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" aria-hidden="true"><circle cx="8" cy="8" r="6"/><path d="M2 8h12M8 2c1.7 1.7 2.5 3.7 2.5 6S9.7 12.3 8 14M8 2C6.3 3.7 5.5 5.7 5.5 8s.8 4.3 2.5 6"/></svg>';
  var CHEV = '<svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m4 6 4 4 4-4"/></svg>';
  var CHECK = '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3.5 8.5 3 3 6-7"/></svg>';
  // full — на кнопке название языка («Русский»), иначе код («RU»)
  window.adminLangMenu = function (extraClass, full) {
    var langs = window.ADMIN_LANGS;
    if (langs.length < 2) return '';
    var title = t('Язык интерфейса');
    return '<div class="ad-langdd' + (extraClass ? ' ' + extraClass : '') + '" data-langdd>' +
      '<button type="button" class="ad-langdd__btn" aria-haspopup="listbox" aria-expanded="false" title="' + esc(title) + '" aria-label="' + esc(title) + ': ' + esc(LANGS[lang].label || lang) + '">' +
      GLOBE + '<span>' + esc(full ? (LANGS[lang].label || lang) : lang.toUpperCase()) + '</span>' + CHEV + '</button>' +
      '<div class="ad-langdd__menu" role="listbox" aria-label="' + esc(title) + '" hidden>' + langs.map(function (l) {
        var on = l.code === lang;
        return '<button type="button" role="option" aria-selected="' + on + '" class="ad-langdd__i' + (on ? ' is-on' : '') + '" data-lang="' + esc(l.code) + '">' +
          '<span class="ad-langdd__code">' + esc(l.code.toUpperCase()) + '</span><span>' + esc(l.label) + '</span>' + (on ? CHECK : '') + '</button>';
      }).join('') + '</div></div>';
  };
  window.UCMS_LANG = { beforeReload: null };
  function closeAll(except) {
    document.querySelectorAll('[data-langdd]').forEach(function (dd) {
      if (dd === except) return;
      dd.querySelector('.ad-langdd__menu').hidden = true;
      dd.querySelector('.ad-langdd__btn').setAttribute('aria-expanded', 'false');
    });
  }
  function pick(code) {
    if (code === lang) { closeAll(); return; }
    window.setAdminLang(code);
    var before = window.UCMS_LANG.beforeReload && window.UCMS_LANG.beforeReload();
    var go = function () { location.reload(); };
    if (before && typeof before.then === 'function') before.then(go, go); else go();
  }
  document.addEventListener('click', function (e) {
    var dd = e.target.closest && e.target.closest('[data-langdd]');
    if (!dd) { closeAll(); return; }
    var item = e.target.closest('.ad-langdd__i');
    if (item) { pick(item.getAttribute('data-lang')); return; }
    if (e.target.closest('.ad-langdd__btn')) {
      var menu = dd.querySelector('.ad-langdd__menu'), open = menu.hidden;
      closeAll(dd);
      menu.hidden = !open;
      dd.querySelector('.ad-langdd__btn').setAttribute('aria-expanded', String(open));
    }
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeAll(); });

  document.documentElement.lang = lang;
  document.title = t('UCMS — Админка');
})();

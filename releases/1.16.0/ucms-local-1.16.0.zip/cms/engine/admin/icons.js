// Единый набор UI-иконок админки «Витрина» — чистый JS, без библиотек.
// viewBox 18×18, stroke=currentColor, ширина линии 1.6, скруглённые концы.
// Icons.svg('chevron-down', 14) -> HTML-строка <svg>...</svg>
(function () {
  var P = {
    'chevron-down':  '<path d="M5 7 9 11l4-4"/>',
    'cloud':         '<path d="M5.5 14h7.2a3.3 3.3 0 0 0 .5-6.55A4.5 4.5 0 0 0 4.6 8.2 2.9 2.9 0 0 0 5.5 14Z"/>',
    'key':           '<circle cx="6" cy="12" r="3.2"/><path d="m8.3 9.7 6.2-6.2M12.6 5.4l1.7 1.7M10.9 7.1l1.3 1.3"/>',
    'chevron-up':    '<path d="M5 11 9 7l4 4"/>',
    'chevron-left':  '<path d="M11 5 7 9l4 4"/>',
    'chevron-right': '<path d="M7 5l4 4-4 4"/>',
    'plus':          '<path d="M9 4v10M4 9h10"/>',
    'close':         '<path d="M5 5l8 8M13 5l-8 8"/>',
    'check':         '<path d="m4 9.5 3 3 6.5-7.5"/>',
    'search':        '<circle cx="8" cy="8" r="5"/><path d="m12.5 12.5 3 3"/>',
    'page':          '<rect x="3.5" y="2.5" width="11" height="13" rx="1.8"/><path d="M6.5 6.5h5M6.5 9.5h5M6.5 12.5h3"/>',
    'page-add':      '<rect x="3.5" y="2.5" width="11" height="13" rx="1.8"/><path d="M9 6.5v5M6.5 9h5"/>',
    'trash':         '<path d="M4 5.5h10M7 5.5V4h4v1.5M5.5 5.5v9h7v-9M7.5 8.5v4M10.5 8.5v4"/>',
    'pencil':        '<path d="M12 3.5 14.5 6 6 14.5H3.5V12z"/>',
    'eye':           '<path d="M1.5 9S4.5 3.5 9 3.5 16.5 9 16.5 9 13.5 14.5 9 14.5 1.5 9 1.5 9Z"/><circle cx="9" cy="9" r="2.2"/>',
    'preview':       '<path d="M10.5 3.5H14.5V7.5M14.5 3.5 9.5 8.5M8 4.5H5A1.5 1.5 0 0 0 3.5 6V13A1.5 1.5 0 0 0 5 14.5H12A1.5 1.5 0 0 0 13.5 13V10"/>',
    'download':      '<path d="M9 3.5v8M5.5 8 9 11.5 12.5 8M4 14.5h10"/>',
    'undo':          '<path d="M6.5 4 3.5 7l3 3"/><path d="M3.5 7H11a3.5 3.5 0 0 1 0 7H7"/>',
    'upload':        '<path d="M9 12V4M5.5 7.5 9 4l3.5 3.5M4 14h10"/>',
    'columns':       '<rect x="2.5" y="3" width="5" height="12" rx="1.3"/><rect x="10.5" y="3" width="5" height="12" rx="1.3"/>',
    'grid':          '<rect x="2.5" y="2.5" width="5.6" height="5.6" rx="1.3"/><rect x="9.9" y="2.5" width="5.6" height="5.6" rx="1.3"/><rect x="2.5" y="9.9" width="5.6" height="5.6" rx="1.3"/><rect x="9.9" y="9.9" width="5.6" height="5.6" rx="1.3"/>',
    'scroll':        '<rect x="5" y="4.5" width="8" height="9" rx="1.5"/><path d="M2.5 6.5v5M15.5 6.5v5"/>',
    'height':        '<path d="M9 3v12M6 5.5 9 3l3 2.5M6 12.5 9 15l3-2.5"/>',
    'drag':          '<circle cx="6.5" cy="4.5" r="1" fill="currentColor" stroke="none"/><circle cx="11.5" cy="4.5" r="1" fill="currentColor" stroke="none"/><circle cx="6.5" cy="9" r="1" fill="currentColor" stroke="none"/><circle cx="11.5" cy="9" r="1" fill="currentColor" stroke="none"/><circle cx="6.5" cy="13.5" r="1" fill="currentColor" stroke="none"/><circle cx="11.5" cy="13.5" r="1" fill="currentColor" stroke="none"/>',
    'image':         '<rect x="2.5" y="4" width="13" height="10" rx="2"/><circle cx="6.3" cy="7.8" r="1.1"/><path d="m3.5 13 3.3-3 2.8 2.3 2.2-1.7 2.7 2.4"/>',
    'play':          '<path d="M6 4.5v9l7-4.5z"/>',
    'list':          '<path d="M6 5h9M6 9h9M6 13h9"/><circle cx="3" cy="5" r=".8" fill="currentColor" stroke="none"/><circle cx="3" cy="9" r=".8" fill="currentColor" stroke="none"/><circle cx="3" cy="13" r=".8" fill="currentColor" stroke="none"/>',
    'quote':         '<path d="M4 10.5c0-2 1.3-3.4 3.2-3.9L6.8 8c-.9.3-1.3.9-1.3 1.6H7v3.4H4v-2.5ZM10.5 10.5c0-2 1.3-3.4 3.2-3.9L13.3 8c-.9.3-1.3.9-1.3 1.6h1.5v3.4h-3v-2.5Z"/>',
    'link':          '<path d="M7.5 10.5a2.6 2.6 0 0 0 3.7 0l2.2-2.2a2.6 2.6 0 0 0-3.7-3.7l-.9.9"/><path d="M10.5 7.5a2.6 2.6 0 0 0-3.7 0l-2.2 2.2a2.6 2.6 0 0 0 3.7 3.7l.9-.9"/>',
    'fit-stretch':   '<path d="M4 7V4h3M14 7V4h-3M4 11v3h3M14 11v3h-3"/>',
    'fit-center':    '<path d="M9 3v3M9 12v3M3 9h3M12 9h3"/><circle cx="9" cy="9" r="2.4"/>',
    'fit-fixed':     '<rect x="3.5" y="3.5" width="11" height="11" rx="2"/><path d="M7 9h4M9 7v4"/>',
    'eyedropper':    '<path d="m3 15 1-3 6.5-6.5 2 2L6 13l-3 1z"/><path d="M12 4.5l1.5-1.5a1.6 1.6 0 0 1 2.3 2.3L14.3 6.8z"/>',
    'save':          '<path d="M4 3.5h7.5L15 6.5v7a1.5 1.5 0 0 1-1.5 1.5H4.5A1.5 1.5 0 0 1 3 13.5V5A1.5 1.5 0 0 1 4.5 3.5Z"/><path d="M6 3.5v3h5M6.5 15v-4h5v4"/>',
    'user':          '<path d="M9 9.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/><path d="M3.5 15c0-2.6 2.5-4 5.5-4s5.5 1.4 5.5 4"/>',
    'mail':          '<rect x="2.5" y="4.5" width="13" height="9" rx="2"/><path d="m3 5.5 6 5 6-5"/>',
    'phone':         '<rect x="5.5" y="2.5" width="7" height="13" rx="2"/><path d="M8 13.5h2"/>',
    'folder':        '<path d="M2.5 5.5V4a1 1 0 0 1 1-1h3.6l1.6 1.8H14.5a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1h-11a1 1 0 0 1-1-1z"/>',
    'copy':          '<rect x="6" y="6" width="9" height="9" rx="1.6"/><path d="M12 6V4.2A1.2 1.2 0 0 0 10.8 3H4.2A1.2 1.2 0 0 0 3 4.2v6.6A1.2 1.2 0 0 0 4.2 12H6"/>',
    'up':            '<path d="M9 14.5v-11M4.5 8 9 3.5 13.5 8"/>',
    'eraser':        '<path d="M8 15.5h7.5"/><path d="M3 11.6 9.6 5l4.4 4.4-6.1 6.1H5.4z"/><path d="m6.6 8 4.4 4.4"/>',
    'lang':          '<circle cx="9" cy="9" r="6.5"/><path d="M2.5 9h13M9 2.5c1.8 1.8 2.7 4 2.7 6.5S10.8 13.7 9 15.5M9 2.5C7.2 4.3 6.3 6.5 6.3 9s.9 4.7 2.7 6.5"/>',
    'message':       '<path d="M3.5 4h11v8H7l-3 3v-3H3.5z"/>',
  };
  window.Icons = {
    svg: function (name, size, extra) {
      var s = size || 16;
      var inner = P[name];
      if (!inner) return '';
      return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 18 18" fill="none" ' +
        'stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"' +
        (extra ? ' ' + extra : '') + '>' + inner + '</svg>';
    }
  };
})();

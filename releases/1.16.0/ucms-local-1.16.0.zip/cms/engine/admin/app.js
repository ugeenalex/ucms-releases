/* ============================================================
   Витрина — статическая админка (конструктор страниц)
   Чистый HTML/CSS/JS. Без React/Babel/сторонних библиотек, без сервера.
   Рендер: точечный (renderModule / renderBlock / renderInsp / renderOutline …);
   полный innerHTML-рендер — только видимого раздела и только при загрузке
   или смене страницы. Текстовые поля пишут в state без перерисовки (oninput),
   чтобы не терять фокус/курсор при наборе текста.
   ============================================================ */
(function () {
  'use strict';

  /* ---------------- утилиты ---------------- */
  // Уникальный id. Раньше был счётчик с 1 на каждую загрузку — новые модули
  // получали id уже существующих (m25 == m25), и правка шла не в тот модуль.
  var _seq = 0;
  function uid(pre) { return pre + Date.now().toString(36) + (++_seq).toString(36) + Math.random().toString(36).slice(2, 5); }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  var escAttr = esc;
  // Безопасный JS-литерал для подстановки в onclick="…" (кавычки, слэши, <>&).
  function jsArg(v) { return esc(JSON.stringify(String(v == null ? '' : v))); }

  function getEmbedUrl(url) {
    if (!url) return '';
    var yt = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([-\w]{11})/);
    if (yt) return 'https://www.youtube.com/embed/' + yt[1] + '?autoplay=1';
    var vm = url.match(/vimeo\.com\/(\d+)/);
    if (vm) return 'https://player.vimeo.com/video/' + vm[1] + '?autoplay=1';
    return url;
  }
  /* ---------------- новый модуль по типу ---------------- */
  // Модули-списки (items[]): шаблон нового элемента и настройки модуля.
  var NO_LINK = function () { return { linkType: 'none' }; };
  var LIST_ITEM = {
    faq: function () { return { id: uid('g'), q: _t('Вопрос'), a: _t('Ответ') }; },
    features: function () { return { id: uid('g'), image: '', title: _t('Преимущество'), text: _t('Короткое описание') }; },
    cards: function () { return { id: uid('g'), image: '', title: _t('Карточка'), text: _t('Короткое описание'), btnText: '', link: NO_LINK() }; },
    pricing: function () { return { id: uid('g'), name: _t('Тариф'), price: '990 ₽', period: _t('/ мес'), features: _t('Возможность 1\nВозможность 2'), btnText: _t('Выбрать'), link: NO_LINK(), highlight: false }; },
    counters: function () { return { id: uid('g'), value: '100', suffix: '+', label: _t('подпись') }; },
    social: function () { return { id: uid('g'), network: 'telegram', url: '' }; },
    // вкладка: название + свои блоки (UI-формат, как дерево страницы)
    tabs: function () { return { id: uid('g'), title: _t('Вкладка'), blocks: [{ id: uid('b'), mods: [], cols: [], cssClass: '', style: {} }] }; },
  };
  var LIST_DEFAULTS = {
    faq: function () { return { openFirst: false }; },
    features: function () { return { cols: 3, iconSide: 'top' }; },
    cards: function () { return { cols: 3, clickMode: 'button', filter: false, tags: [], allLabel: _t('Все') }; },
    pricing: function () { return {}; },
    counters: function () { return {}; },
    social: function () { return { style: 'icons' }; },
    tabs: function () { return { orient: 'h', tabStyle: 'line' }; },
  };
  function newModule(type) {
    var base = { id: uid('m'), type: type };
    if (type === 'title') return Object.assign(base, { level: 'H2', text: _t('Новый заголовок'), link: { linkType: 'none' } });
    if (type === 'text') return Object.assign(base, { html: _t('<p>Текст блока…</p>'), _codeMode: false });
    if (type === 'image') return Object.assign(base, { caption: '', alt: '', preview: false, link: { linkType: 'none' } });
    if (type === 'gallery') return Object.assign(base, {
      mode: 'grid', cols: 3, height: 450, preview: false,
      items: [0, 1, 2, 3].map(function () { return { id: uid('g'), title: '', caption: '', alt: '', link: { linkType: 'none' } }; }),
    });
    if (type === 'video') return Object.assign(base, { url: '', preview: false, cover: '', _modal: false });
    if (type === 'form') return Object.assign(base, {
      formType: 'simple', title: _t('Обратная связь'), fields: { name: true, email: true, phone: false, message: true },
      endpoint: '', embedUrl: '', embedHeight: 600,
    });
    if (type === 'sitename') return base;
    if (type === 'menu') return Object.assign(base, { menuType: 'list', pagesMode: 'all', selected: {} });
    if (type === 'lang') return Object.assign(base, { langMode: 'list' });
    if (type === 'button') return Object.assign(base, { text: _t('Кнопка'), link: { linkType: 'none' } });
    if (type === 'divider') return Object.assign(base, { width: 2 });
    if (type === 'html') return Object.assign(base, { code: _t('<h2>Произвольный HTML</h2>\n<p>Этот блок использует стили сайта.</p>'), _preview: false });
    if (type === 'spacer') return Object.assign(base, { height: 48, heightMobile: '' });
    if (type === 'quote') return Object.assign(base, { text: _t('Отличный сервис: всё сделали быстро и аккуратно.'), author: _t('Имя Фамилия'), role: _t('Клиент'), src: '' });
    if (type === 'map') return Object.assign(base, { url: '', height: 400 });
    if (type === 'table') return Object.assign(base, { header: true, data: _t('Услуга | Срок | Цена\nКонсультация | 1 день | 5 000 ₽\nПроект | 2 недели | 50 000 ₽') });
    if (type === 'countdown') return Object.assign(base, { until: new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 16), title: '', doneText: '' });
    if (type === 'crumbs') return Object.assign(base, { showOnHome: false });
    if (type === 'tabs') return Object.assign(base, LIST_DEFAULTS.tabs(), { items: [1, 2].map(function (n) { var it = LIST_ITEM.tabs(); it.title = _t('Вкладка ') + n; return it; }) });
    if (type === 'collection') return Object.assign(base, { collection: ((state.collections || [])[0] || {}).id || '', layout: 'grid', cols: 3, perPage: 9, filter: true, showCover: true, showDate: true, showExcerpt: true, readLabel: '', moreLabel: '', allLabel: '' });
    if (type === 'social') return Object.assign(base, LIST_DEFAULTS.social(), { items: ['telegram', 'whatsapp', 'email'].map(function (n) { var it = LIST_ITEM.social(); it.network = n; return it; }) });
    if (LIST_ITEM[type]) return Object.assign(base, LIST_DEFAULTS[type](), { items: [0, 1, 2].map(function () { return LIST_ITEM[type](); }) });
    if (App.PKG && App.PKG[type]) return App.PKG[type].create(base);   // подключаемый модуль: значения по описанию полей (packages.js)
    return base;
  }

  /* ---------------- состояние ---------------- */
  var state = {
    view: 'page', hf: 'header', plang: 'RU',
    selected: null,   // { tree, kind: 'mod' | 'block', id } — что открыто в инспекторе
    drawer: null,     // 'page' — панель «Параметры страницы» вместо инспектора
    sel: 0, pages: [],
    pageTitle: '', pageSlug: '', inMenu: true, menuOrder: 0, menuPos: 'root',
    headerVisible: true, footerVisible: true,
    siteName: '',
    moduleSw: (function () { var o = {}; MODULES.forEach(function (m) { o[m.key] = !MODULE_OFF_BY_DEFAULT[m.key]; }); return o; })(),
    pageBg: newBg(),
    trees: { page: [], header: [], footer: [] },
    themeFontName: '', themeFontUrl: '',
    themeName: 'default', themes: [], newThemeName: '',
    themeCss: '',
    langs: [{ code: 'RU', name: _t('Русский'), isDefault: true }],
    newLangCode: '', newLangName: '', apiKey: '', editLangIdx: null, editLangCode: '', editLangName: '',
    openPopover: null, // строка-идентификатор открытого поповера/дропдауна
  };

  /* ---------------- поиск модуля в дереве ---------------- */
  function locateModule(treeName, modId) {
    var tree = state.trees[treeName];
    for (var bi = 0; bi < tree.length; bi++) {
      var b = tree[bi];
      for (var mi = 0; mi < b.mods.length; mi++) if (b.mods[mi].id === modId) return { container: b.mods, index: mi, blockId: b.id, blockIndex: bi, colIndex: -1 };
      for (var ci = 0; ci < b.cols.length; ci++) {
        var c = b.cols[ci];
        for (var mj = 0; mj < c.mods.length; mj++) if (c.mods[mj].id === modId) return { container: c.mods, index: mj, blockId: b.id, blockIndex: bi, colIndex: ci };
      }
    }
    return null;
  }
  function getModule(treeName, modId) { var loc = state.trees[treeName] && locateModule(treeName, modId); return loc ? loc.container[loc.index] : null; }
  function findBlock(treeName, blockId) { return (state.trees[treeName] || []).filter(function (x) { return x.id === blockId; })[0] || null; }

  /* ---- вложенные деревья: блоки внутри модуля «Вкладки» ----
     Каждая вкладка — своё дерево блоков с именем 'tab-<модуль>-<вкладка>' в state.trees
     (тот же массив, что item.blocks). Все операции с блоками и модулями работают с ним
     как с деревом страницы; NESTED помнит, в каком дереве лежит модуль-владелец. */
  var NESTED = {};
  function nestedName(modId, tabId) { return 'tab-' + modId + '-' + tabId; }
  function registerTabs(parentTree, m) {
    (m.items || []).forEach(function (it) {
      it.blocks = it.blocks || [];
      var tn = nestedName(m.id, it.id);
      state.trees[tn] = it.blocks;
      NESTED[tn] = { parent: parentTree, modId: m.id, tabId: it.id };
    });
  }
  function eachMod(blocks, fn) { (blocks || []).forEach(function (b) { b.mods.forEach(fn); b.cols.forEach(function (c) { c.mods.forEach(fn); }); }); }
  // Полная пересборка реестра (после загрузки, смены страницы, отмены): лишние деревья убираем
  function syncNested() {
    Object.keys(NESTED).forEach(function (k) { delete state.trees[k]; });
    NESTED = {};
    ['page', 'header', 'footer'].forEach(function (root) {
      eachMod(state.trees[root], function (m) { if (m.type === 'tabs') registerTabs(root, m); });
    });
  }
  // Корневое дерево (страница/шапка/подвал) для вложенного
  function rootTree(t) { var guard = 0; while (NESTED[t] && guard++ < 10) t = NESTED[t].parent; return t; }
  function nestedCount(blocks) { var n = 0; eachMod(blocks, function () { n++; }); return n; }
  function pageTitles() { return state.pages.map(function (p) { return p.title; }); }
  // Записи коллекций в меню не попадают — дерево меню только из обычных страниц
  function menuTreeOf() { return state.pages.filter(function (p) { return !p.coll; }).map(function (p) { return { title: p.title, child: p.child }; }); }

  /* ============================================================
     App — глобальные обработчики (вызываются из инлайн onclick/oninput)
     ============================================================ */
  var App = {};
  window.App = App;
  // Модуль доступен на сайте: встроенный — всегда, необязательный (optional) — если установлен в сайт
  App.modAvailable = function (m) { return !m.optional || !!(App.PKG && App.PKG[m.key]); };
  App._state = state; // exposed for server-bridge.js
    App.uid = uid;
  App.getModule = getModule;
  App.rootTree = rootTree;

  /* ============================================================
     НАВИГАЦИЯ И ТОЧЕЧНЫЕ РЕНДЕРЫ
     Каркас: [data-side] сайдбар · [data-top] верхняя панель ·
     [data-view] холст/раздел · [data-insp] инспектор или панель параметров.
     Полный рендер — только при загрузке, смене раздела и страницы.
     ============================================================ */
  // Дерево, которое сейчас на холсте (null — раздел настроек без холста).
  function curTree() { return state.view === 'page' ? 'page' : state.view === 'hf' ? state.hf : null; }

  App.render = function () { renderRoot(); };
  function swap(selector, html) {
    var el = document.querySelector(selector);
    if (!el) { renderRoot(); return false; }
    el.outerHTML = html; return true;
  }
  App.renderView    = function () { state.openPopover = null; swap('[data-view]', renderView()); };
  App.renderSide    = function () { swap('[data-side]', renderSide()); };
  App.renderOutline = function () { var el = document.querySelector('[data-outline]'); if (el) el.outerHTML = renderOutline(); };
  App.renderTop     = function () { swap('[data-top]', renderTop()); };
  App.renderInsp    = function () { swap('[data-insp]', renderInsp()); };
  App.renderPageHead = function () { var el = document.querySelector('[data-pagehead]'); if (el) el.outerHTML = renderPageHead(); };
  App.renderBg      = function () { var el = document.querySelector('[data-bg="page"]'); if (el) el.outerHTML = renderBackgroundSettings(); App.renderPageHead(); };
  App.renderSettings = App.renderView;   // языки, модули, тема перерисовывают свой раздел

  // Права пользователя (веб-версия и подключённый сайт). Локально — без ограничений.
  // Сервер проверяет те же права сам; здесь — только чтобы не показывать недоступное.
  App.can = function (perm) {
    var w = App.webInfo;
    if (!w || w.role === 'owner') return true;
    if (!w.perms) return w.role === 'editor' ? perm !== 'transfer' : true;   // сервер 1.12: роль «редактор»
    return w.perms.indexOf(perm) >= 0;
  };
  var VIEW_PERM = { page: 'content', hf: 'layout', media: 'media', publish: 'publish', theme: 'design', langs: 'settings', site: 'settings', history: 'history' };
  App.viewAllowed = function (v) { return !VIEW_PERM[v] || App.can(VIEW_PERM[v]); };
  App.firstView = function () {
    var all = ['page', 'hf', 'media', 'publish', 'theme', 'langs', 'site', 'history'].filter(App.viewAllowed);
    return all[0] || (App.web ? 'engine' : 'page');
  };
  App.setView = function (v) {
    if (!App.viewAllowed(v)) v = App.firstView();
    state.view = v; state.openPopover = null; state.selected = null; state.drawer = null;
    renderRoot();
    if (v === 'publish' && App.loadPublish) App.loadPublish();
    if (v === 'site' && App.loadBackups) App.loadBackups();
    if (v === 'media' && App.loadMedia) App.loadMedia();
    if (v === 'history' && App.loadHistory) App.loadHistory();
    if (v === 'engine' && App.loadEngine) App.loadEngine();
  };
  App.setHeaderSticky = function (v) { state.headerSticky = !!v; App.renderView(); };
  App.setHf = function (v) { state.hf = v; state.selected = null; renderRoot(); };
  App.setPlang = function (v) { state.plang = v; state.openPopover = null; App.renderTop(); App.refreshTranslations(); App.renderPageHead(); };
  App.selectPage = function (i) { state.sel = i; state.openPopover = null; state.selected = null; renderRoot(); };

  /* ---- выбор элемента на холсте → инспектор ---- */
  App.select = function (tree, kind, id) {
    state.selected = id ? { tree: tree, kind: kind, id: id } : null;
    state.drawer = null; state.openPopover = null;
    var olds = document.querySelectorAll('.ad-view .is-sel');
    for (var i = 0; i < olds.length; i++) olds[i].classList.remove('is-sel');
    if (id) {
      var el = document.querySelector(kind === 'block' ? '[data-block="' + tree + ':' + id + '"]' : '[data-card="' + tree + ':' + id + '"]');
      if (el) el.classList.add('is-sel');
    }
    App.renderInsp(); App.renderOutline();
  };
  // Выбор из дерева структуры: ещё и прокрутить холст к элементу.
  App.reveal = function (tree, kind, id) {
    App.select(tree, kind, id);
    var el = document.querySelector(kind === 'block' ? '[data-block="' + tree + ':' + id + '"]' : '[data-card="' + tree + ':' + id + '"]');
    if (el && el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  };
  App.openDrawer = function (name) {
    state.drawer = state.drawer === name ? null : name; state.openPopover = null;
    if (state.drawer) {
      var keep = state.drawer; App.select(null, null, null); state.drawer = keep;   // снимаем выделение с холста
    }
    App.renderInsp();
  };
  // Текст в инспекторе меняет модуль без перерисовки (фокус!) — превью на холсте
  // обновляем в следующем кадре, пачкой на все нажатия.
  var _pvQueued = false;
  function queuePreview() {
    if (_pvQueued || !state.selected || state.selected.kind !== 'mod') return;
    _pvQueued = true;
    requestAnimationFrame(function () {
      _pvQueued = false;
      var sel = state.selected; if (!sel || sel.kind !== 'mod') return;
      var m = getModule(sel.tree, sel.id);
      var card = document.querySelector('[data-card="' + sel.tree + ':' + sel.id + '"]');
      if (m && card) card.outerHTML = modCardHTML(sel.tree, m);
    });
  }
  document.addEventListener('input', function (e) { if (e.target.closest && e.target.closest('[data-insp]')) queuePreview(); });

  /* ---- поповеры ----
     Id поповера содержит пару <tree>:<id> модуля или блока
     (link:mod:page:m1, formtype:footer:m4, addmod:page:b2:c1 …) —
     по ней находим, что перерисовать. */
  function ownerOf(id) {
    if (!id) return null;
    var parts = String(id).split(':');
    for (var i = 0; i < parts.length - 1; i++) {
      if (!state.trees[parts[i]]) continue;
      if (getModule(parts[i], parts[i + 1])) return { tree: parts[i], modId: parts[i + 1] };
      if (findBlock(parts[i], parts[i + 1])) return { tree: parts[i], blockId: parts[i + 1] };
    }
    return null;
  }
  var POPOVER_RENDER = {
    menupos: function () { App.renderInsp(); return true; },
  };
  function renderPopoverHost(id) {
    if (id == null) return true;
    if (/^addtpl:/.test(id)) { swapAddRow(id.split(':')[1]); return true; }
    var o = ownerOf(id);
    if (o && o.modId) { App.renderModule(o.tree, o.modId); return true; }
    if (o && o.blockId) { App.renderBlock(o.tree, o.blockId); return true; }
    return POPOVER_RENDER[id] ? POPOVER_RENDER[id]() : false;
  }
  function renderPopoverOwners(prev, next) {
    var a = renderPopoverHost(prev);
    var b = prev === next ? true : renderPopoverHost(next);
    return a && b;
  }
  App.togglePopover = function (id) {
    var prev = state.openPopover;
    state.openPopover = (prev === id) ? null : id;
    if (!renderPopoverOwners(prev, state.openPopover)) renderRoot();
  };
  App.closeAllPopovers = function () {
    if (!state.openPopover) return;
    var prev = state.openPopover; state.openPopover = null;
    if (!renderPopoverOwners(prev, null)) renderRoot();
  };

  /* ---- простые текстовые поля (без перерисовки — сохраняем фокус) ---- */
  App.setField = function (name, value) { state[name] = value; };
  App.setMenuPos = function (v) { state.menuPos = v; state.openPopover = null; App.renderInsp(); App.renderPageHead(); };
  App.toggleBool = function (name) { state[name] = !state[name]; App.renderInsp(); App.renderPageHead(); };
  App.toggleModuleSw = function (key) { state.moduleSw[key] = !state.moduleSw[key]; App.renderSettings(); };

  /* ---- шрифт сайта ---- */
  function googleFamilies(url) {
    var m = String(url || '').match(/fonts\.googleapis\.com\/css2?\?(.*)$/);
    if (!m) return [];
    return m[1].split('&').filter(function (kv) { return kv.indexOf('family=') === 0; }).map(function (kv) {
      return decodeURIComponent(kv.slice(7).split(':')[0].replace(/\+/g, ' ')).trim();
    }).filter(Boolean);
  }
  function fontHint(s) {
    var fams = googleFamilies(s.themeFontUrl);
    if (!s.themeFontName) return _t('Название пустое — используется шрифт из CSS темы (--font-body / --font-head).');
    if (fams.length && fams.indexOf(s.themeFontName) < 0) {
      return _t('<span style="color:var(--danger,#c0392b)">По ссылке подключается «') + esc(fams.join('», «')) + _t('», а в названии указан «') + esc(s.themeFontName) + _t('» — шрифт не применится.</span>');
    }
    return _t('Шрифт «') + esc(s.themeFontName) + _t('» перекрывает шрифт темы. Очистите название, чтобы вернуть шрифт темы.');
  }
  function updateFontHint() {
    var el = document.querySelector('[data-font-hint]'); if (el) el.innerHTML = fontHint(state);
    var sample = document.querySelector('[data-font-sample]'); if (sample) sample.style.fontFamily = state.themeFontName ? "'" + state.themeFontName.replace(/['"\\<>]/g, '') + "', var(--font)" : '';
    ensureFontPreview();
  }
  App.setFontName = function (v) { state.themeFontName = v.trim(); updateFontHint(); };
  // Вставили ссылку Google Fonts — если название не совпадает ни с одним семейством
  // из ссылки, подставляем первое (частая ошибка: ссылка на один шрифт, имя — другого).
  App.setFontUrl = function (v) {
    state.themeFontUrl = v.trim();
    var fams = googleFamilies(state.themeFontUrl);
    if (fams.length && fams.indexOf(state.themeFontName) < 0) {
      state.themeFontName = fams[0];
      var inp = document.querySelector('[data-font-name]'); if (inp) inp.value = fams[0];
    }
    updateFontHint();
  };

  /* ---- языки ---- */
  App.addLang = function () {
    var code = (state.newLangCode || '').trim(); if (!code) return;
    state.langs.push({ code: code, name: (state.newLangName || '').trim() || code, isDefault: false });
    state.newLangCode = ''; state.newLangName = ''; App.renderSettings();
  };
  App.delLang = function (i) { state.langs.splice(i, 1); App.renderSettings(); };
  App.editLangStart = function (i) { state.editLangIdx = i; state.editLangCode = state.langs[i].code; state.editLangName = state.langs[i].name; App.renderSettings(); };
  App.editLangCancel = function () { state.editLangIdx = null; App.renderSettings(); };
  App.editLangSave = function (i) {
    var l = state.langs[i]; if (!l) return;
    l.code = (state.editLangCode || '').trim() || l.code;
    l.name = (state.editLangName || '').trim() || l.name;
    state.editLangIdx = null; App.renderSettings();
  };

  /* ============================================================
     ФОН (страница и блок) — один формат с сервером:
     { type: 'none'|'color'|'gradient'|'image'|'pattern', color, gradientFrom, gradientTo,
       gradientAngle, image, stretch, fixed, overlay (блок), light (блок) }.
     Цвета выбираются Coloris: поле <input data-coloris> сам пикер
     изменяет без перерисовки, мы только пишем значение и обновляем превью.
     ============================================================ */
  function newBg() { return { type: 'none', color: '#f4f4f1', gradientFrom: '#5b3fc8', gradientTo: '#c99a2e', gradientAngle: 135, image: '', stretch: true, fixed: false, overlay: 0, light: false,
    parallax: false, pxOrientation: 'up', pxScale: 1.3, pxDelay: 0.4, pxSmooth: true, pxMax: 0 }; }
  function normBg(bg) { var b = newBg(); if (bg) Object.keys(bg).forEach(function (k) { if (bg[k] != null) b[k] = bg[k]; }); return b; }
  // target: 'page' или 'block:<tree>:<blockId>'
  function bgOf(target) {
    if (target === 'page') return state.pageBg;
    var p = target.split(':'), b = findBlock(p[1], p[2]); if (!b) return null;
    b.style = b.style || {};
    return (b.style.bg = normBg(b.style.bg));
  }
  function bgCss(bg) {
    if (bg.type === 'color') return 'background:' + bg.color;
    if (bg.type === 'gradient') return 'background:linear-gradient(' + (parseInt(bg.gradientAngle, 10) || 0) + 'deg,' + bg.gradientFrom + ',' + bg.gradientTo + ')';
    if ((bg.type === 'image' || bg.type === 'pattern') && bg.image) {
      var ov = bg.overlay ? 'linear-gradient(rgba(0,0,0,' + bg.overlay / 100 + '),rgba(0,0,0,' + bg.overlay / 100 + ')),' : '';
      return 'background:' + ov + 'url(\'' + String(bg.image).replace(/'/g, '%27') + '\') ' + (bg.type === 'pattern' ? 'repeat' : 'center/cover no-repeat') + ',' + bg.color;
    }
    return '';
  }
  function afterBg(target, full) {
    if (target === 'page') { if (full) App.renderBg(); App.renderPageHead(); return; }
    var p = target.split(':');
    if (full) App.renderInsp();
    var sw = document.querySelector('[data-block="' + p[1] + ':' + p[2] + '"] [data-blk-swatch]');
    if (sw && !full) sw.setAttribute('style', bgCss(bgOf(target)));
    else App.renderBlock(p[1], p[2]);
  }
  // Изменение поля фона. live=true — ввод (цвет/угол): без перерисовки, только превью.
  App.bgSet = function (target, field, value, live) {
    var bg = bgOf(target); if (!bg) return;
    bg[field] = value;
    if (live) {
      var prev = document.querySelector('[data-bg-prev="' + target + '"]');
      if (prev) prev.setAttribute('style', bgCss(bg));
      var lab = document.querySelector('[data-bg-angle="' + target + '"]');
      if (lab && field === 'gradientAngle') lab.textContent = value + '°';
      afterBg(target, false);
      return;
    }
    afterBg(target, true);
  };
  App.getBgForDb = function () {
    var bg = state.pageBg;
    if (!bg || bg.type === 'none') return { type: 'none' };
    var out = { type: bg.type };
    if (bg.type === 'color') out.color = bg.color;
    if (bg.type === 'gradient') { out.gradientFrom = bg.gradientFrom; out.gradientTo = bg.gradientTo; out.gradientAngle = parseInt(bg.gradientAngle, 10) || 0; }
    if (bg.type === 'image' || bg.type === 'pattern') { out.image = bg.image; out.color = bg.color; out.fixed = !!bg.fixed; }
    if (bg.type === 'image') {
      out.stretch = bg.stretch !== false; out.position = 'center';
      if (bg.parallax) ['parallax', 'pxOrientation', 'pxScale', 'pxDelay', 'pxSmooth', 'pxMax'].forEach(function (k) { out[k] = bg[k]; });
    }
    return out;
  };
  App.setBgFromDb = function (bg) { state.pageBg = normBg(bg); };
  // Поле цвета под Coloris: разметку обёртки .clr-field рисуем сами — пикер
  // подхватывает такие поля делегированием, отдельная инициализация не нужна.
  function colorInput(value, oninput, label) {
    return '<div class="clr-field" style="color:' + escAttr(value) + '"><button type="button" aria-labelledby="clr-open-label"></button>' +
      '<input class="ad-in ad-in--mono ad-color" data-coloris aria-label="' + esc(label) + '" value="' + escAttr(value) + '" oninput="' + oninput + '"></div>';
  }

  /* ---- дерево: блоки / колонки / модули ----
     Каждая операция меняет state и перерисовывает минимум: свой блок на холсте,
     дерево структуры в сайдбаре и — если затронут выбранный элемент — инспектор. */
  function blockIndex(treeName, blockId) {
    return state.trees[treeName].findIndex(function (b) { return b.id === blockId; });
  }
  // Выбранный элемент мог исчезнуть (удалён модуль/блок) — сбрасываем инспектор.
  function syncSelection() {
    var sel = state.selected; if (!sel) return;
    var alive = sel.kind === 'block' ? findBlock(sel.tree, sel.id) : getModule(sel.tree, sel.id);
    if (!alive) { state.selected = null; App.renderInsp(); }
  }
  // Номера блоков в заголовках зависят от порядка — перерисовываем список целиком
  // (дёшево: только холст текущего дерева, без сайдбара/инспектора).
  function renderBlocks(treeName) {
    var host = document.querySelector('[data-blocks="' + treeName + '"]');
    if (!host) { renderRoot(); return; }
    host.innerHTML = state.trees[treeName].map(function (b, i) { return renderBlockCard(treeName, b, i); }).join('');
    App.renderOutline(); syncSelection();
  }
  App.renderBlock = function (treeName, blkId) {
    var i = blockIndex(treeName, blkId);
    var el = document.querySelector('[data-block="' + treeName + ':' + blkId + '"]');
    if (i < 0 || !el) { renderBlocks(treeName); return; }
    el.outerHTML = renderBlockCard(treeName, state.trees[treeName][i], i);
    App.renderOutline(); syncSelection();
  };
  // Модуль: инспектор (если открыт) + карточка на холсте.
  App.renderModule = function (treeName, modId) {
    var m = getModule(treeName, modId); if (!m) return;
    var sel = state.selected;
    if (sel && sel.kind === 'mod' && sel.tree === treeName && sel.id === modId) {
      var body = document.querySelector('[data-insp] [data-mid="' + modId + '"]');
      if (body) body.innerHTML = renderModuleEditor(treeName, m, pageTitles(), menuTreeOf());
    }
    var card = document.querySelector('[data-card="' + treeName + ':' + modId + '"]');
    if (card) card.outerHTML = modCardHTML(treeName, m);
  };

  App.addBlockAt = function (treeName, idx) {
    var blk = { id: uid('b'), mods: [], cssClass: '', cols: [], style: {} };
    state.trees[treeName].splice(idx, 0, blk);
    state.selected = { tree: treeName, kind: 'block', id: blk.id };
    renderBlocks(treeName); App.renderInsp();
  };
  App.addBlockEnd = function (treeName) { App.addBlockAt(treeName, state.trees[treeName].length); };
  App.moveBlock = function (treeName, blockId, dir) {
    var tree = state.trees[treeName], i = blockIndex(treeName, blockId), to = i + dir;
    if (i < 0 || to < 0 || to >= tree.length) return;
    tree.splice(to, 0, tree.splice(i, 1)[0]);
    renderBlocks(treeName); App.renderInsp();
  };
  App.delBlock = function (treeName, blockId) {
    var i = blockIndex(treeName, blockId); if (i < 0) return;
    var b = state.trees[treeName][i];
    var n = b.mods.length + b.cols.reduce(function (a, c) { return a + c.mods.length; }, 0);
    if (n && !confirm(_t('Удалить блок вместе с модулями (') + n + ')?')) return;
    state.trees[treeName].splice(i, 1);
    renderBlocks(treeName);
  };
  // Класс блока: пишем в state, а метку на холсте обновляем точечно (фокус в поле не теряется).
  App.setBlockClass = function (treeName, blockId, value) {
    var b = findBlock(treeName, blockId); if (!b) return;
    b.cssClass = value.trim();
    var head = document.querySelector('[data-block="' + treeName + ':' + blockId + '"] [data-cls]');
    if (head) head.outerHTML = blockClassChip(treeName, b);
    App.renderOutline();
  };
  App.addColumn = function (treeName, blockId) {
    var b = findBlock(treeName, blockId); if (!b || b.cols.length >= 4) return;
    b.cols.push({ id: uid('c'), mods: [], width: '', unit: '%' });
    App.renderBlock(treeName, blockId); refreshBlockInsp(treeName, blockId);
  };
  App.moveColumn = function (treeName, blockId, colId, dir) {
    var b = findBlock(treeName, blockId); if (!b) return;
    var i = b.cols.findIndex(function (c) { return c.id === colId; }), to = i + dir;
    if (i < 0 || to < 0 || to >= b.cols.length) return;
    b.cols.splice(to, 0, b.cols.splice(i, 1)[0]);
    App.renderBlock(treeName, blockId); refreshBlockInsp(treeName, blockId);
  };
  App.delColumn = function (treeName, blockId, colId) {
    var b = findBlock(treeName, blockId); if (!b) return;
    var c = b.cols.filter(function (x) { return x.id === colId; })[0];
    if (c && c.mods.length && !confirm(_t('Удалить колонку вместе с модулями (') + c.mods.length + ')?')) return;
    b.cols = b.cols.filter(function (x) { return x.id !== colId; });
    App.renderBlock(treeName, blockId); refreshBlockInsp(treeName, blockId);
  };
  App.setColWidth = function (treeName, blockId, colId, value) {
    var b = findBlock(treeName, blockId); if (!b) return;
    var c = b.cols.filter(function (x) { return x.id === colId; })[0]; if (!c) return;
    c.width = value.replace(/[^\d.]/g, '');
    App.renderBlock(treeName, blockId);   // инспектор не трогаем — в нём фокус
  };
  App.setColAlign = function (treeName, blockId, colId, align) {
    var b = findBlock(treeName, blockId); if (!b) return;
    var c = b.cols.filter(function (x) { return x.id === colId; })[0]; if (!c) return;
    c.align = align;
    App.renderBlock(treeName, blockId); refreshBlockInsp(treeName, blockId);
  };
  App.setColUnit = function (treeName, blockId, colId, unit) {
    var b = findBlock(treeName, blockId); if (!b) return;
    var c = b.cols.filter(function (x) { return x.id === colId; })[0]; if (!c) return;
    c.unit = unit;
    App.renderBlock(treeName, blockId); refreshBlockInsp(treeName, blockId);
  };
  function refreshBlockInsp(treeName, blockId) {
    var sel = state.selected;
    if (sel && sel.kind === 'block' && sel.tree === treeName && sel.id === blockId) App.renderInsp();
  }

  /* ---- настройки блока (style) и дублирование ---- */
  // style: { width, pad, valign, gap, reverse, anchor, hide, bg } — пустые значения = как в теме.
  App.setBlockStyle = function (tree, blockId, key, value, live) {
    var b = findBlock(tree, blockId); if (!b) return;
    b.style = b.style || {};
    if (key === 'anchor') value = String(value).trim().replace(/^#/, '').replace(/[^\p{L}\p{N}_-]+/gu, '-').replace(/^-+|-+$/g, '');
    b.style[key] = value;
    App.renderBlock(tree, blockId);
    if (!live) refreshBlockInsp(tree, blockId);
  };
  // Глубокая копия с новыми id — у копии не должно быть общих id с оригиналом.
  function reidModule(m) {
    m.id = uid('m');
    (m.items || []).forEach(function (it) { it.id = uid('g'); (it.blocks || []).forEach(reidBlock); });   // у «Вкладок» — и блоки внутри
    return m;
  }
  function cloneData(o) { return JSON.parse(JSON.stringify(o)); }
  function reidBlock(b) {
    b.id = uid('b');
    b.mods = b.mods || []; b.cols = b.cols || []; b.style = b.style || {};
    b.mods.forEach(reidModule);
    b.cols.forEach(function (c) { c.id = uid('c'); c.mods.forEach(reidModule); });
    if (b.style.anchor) b.style.anchor = '';   // якорь должен быть уникальным
    return b;
  }

  /* ---- шаблоны секций: блок целиком (в формате движка) в db.settings.sectionTemplates ---- */
  function tplCount(row) {
    var n = (row.blocks || []).length;
    (row.columns || []).forEach(function (c) { n += (c.blocks || []).length; });
    return n;
  }
  App.saveTemplate = function (tree, blockId) {
    var b = findBlock(tree, blockId); if (!b || !App.convert) return;
    var inp = document.getElementById('insp-tpl-name');
    var name = (inp && inp.value.trim()) || _t('Шаблон ') + ((state.templates || []).length + 1);
    state.templates = state.templates || [];
    state.templates.push({ id: uid('t'), name: name, row: App.convert.toRow(cloneData(b)) });
    App.renderInsp(); swapAddRow(tree);
  };
  App.insertTemplate = function (tree, tplId) {
    var tpl = (state.templates || []).filter(function (x) { return x.id === tplId; })[0];
    if (!tpl || !App.convert) return;
    var blk = reidBlock(App.convert.toBlock(cloneData(tpl.row)));
    state.trees[tree].push(blk);
    state.openPopover = null;
    state.selected = { tree: tree, kind: 'block', id: blk.id };
    renderBlocks(tree); App.renderInsp(); swapAddRow(tree);
  };
  App.delTemplate = function (tree, tplId) {
    var tpl = (state.templates || []).filter(function (x) { return x.id === tplId; })[0];
    if (!tpl || !confirm(_t('Удалить шаблон «') + tpl.name + _t('»? Блоки, уже вставленные на страницы, останутся.'))) return;
    state.templates = state.templates.filter(function (x) { return x.id !== tplId; });
    swapAddRow(tree);
  };
  function addRowHTML(t) {
    var pid = 'addtpl:' + t, open = state.openPopover === pid, tpls = state.templates || [];
    var html = '<div class="ad-addrow" data-addrow="' + t + '"><button type="button" class="ad-addblk" onclick="' + call('addBlockEnd', [t]) + '">' + ico('plus', 15) + _t('Добавить блок</button>');
    if (tpls.length) {
      html += '<div class="ad-addrow__tpl" data-dd><button type="button" class="ad-addblk ad-addblk--tpl" aria-expanded="' + open + '" onclick="' + call('togglePopover', [pid]) + '">' + ico('copy', 15) + _t('Из шаблона</button>') +
        (open ? _t('<div class="ad-pal ad-pal--tpl" role="dialog" aria-label="Шаблоны секций"><div class="ad-pal__h">Шаблоны секций</div>') + tpls.map(function (tp) {
          return '<div class="ad-tpl"><button type="button" class="ad-pal__i" onclick="' + call('insertTemplate', [t, tp.id]) + '"><span class="ad-pal__ic">' + ico('cols', 14) + '</span>' +
            '<span class="ad-tpl__n">' + esc(tp.name) + '<small>' + tplCount(tp.row) + _t(' мод.</small></span></button>') + ib('del', _t('Удалить шаблон'), call('delTemplate', [t, tp.id]), { danger: true }) + '</div>';
        }).join('') + '</div>' : '') + '</div>';
    }
    return html + '</div>';
  }
  function swapAddRow(t) { var el = document.querySelector('[data-addrow="' + t + '"]'); if (el) el.outerHTML = addRowHTML(t); }
  App.dupModule = function (tree, modId) {
    var loc = locateModule(tree, modId); if (!loc) return;
    var copy = reidModule(cloneData(loc.container[loc.index]));
    delete copy._modal;
    loc.container.splice(loc.index + 1, 0, copy);
    state.selected = { tree: tree, kind: 'mod', id: copy.id };
    App.renderBlock(tree, loc.blockId); App.renderInsp();
  };
  App.dupBlock = function (tree, blockId) {
    var i = blockIndex(tree, blockId); if (i < 0) return;
    var copy = reidBlock(cloneData(state.trees[tree][i]));
    state.trees[tree].splice(i + 1, 0, copy);
    state.selected = { tree: tree, kind: 'block', id: copy.id };
    renderBlocks(tree); App.renderInsp();
  };

  // Новый модуль — в конец блока или колонки, сразу выбран в инспекторе.
  App.addMod = function (treeName, blockId, colId, type) {
    var b = findBlock(treeName, blockId); if (!b) return;
    var host = colId ? (b.cols.filter(function (x) { return x.id === colId; })[0] || {}).mods : b.mods;
    if (!host) return;
    var m = newModule(type); host.push(m);
    state.openPopover = null;
    state.selected = { tree: treeName, kind: 'mod', id: m.id };
    App.renderBlock(treeName, blockId); App.renderInsp();
  };
  App.moveModule = function (treeName, modId, dir) {
    var loc = locateModule(treeName, modId); if (!loc) return;
    var to = loc.index + dir; if (to < 0 || to >= loc.container.length) return;
    loc.container.splice(to, 0, loc.container.splice(loc.index, 1)[0]);
    App.renderBlock(treeName, loc.blockId);
  };
  App.delModule = function (treeName, modId) {
    var loc = locateModule(treeName, modId); if (!loc) return;
    loc.container.splice(loc.index, 1);
    App.renderBlock(treeName, loc.blockId);
  };
  App.setModuleField = function (treeName, modId, field, value, noRender) {
    var m = getModule(treeName, modId); if (!m) return;
    m[field] = value; if (!noRender) App.renderModule(treeName, modId);
  };
  App.moduleAction = function (treeName, modId, fn) {
    var m = getModule(treeName, modId); if (!m) return;
    fn(m); App.renderModule(treeName, modId);
  };

  /* ---- модуль «Текст»: визуальный/код ---- */
  App.textToggleMode = function (treeName, modId) {
    var m = getModule(treeName, modId); if (!m) return;
    m._codeMode = !m._codeMode; App.renderModule(treeName, modId);
  };
  /* ---- очистка HTML (вставка в «Текст» и кнопка «Очистить стили») ----
     Оставляем только смысловую разметку, которую понимает тема: абзацы, подзаголовки,
     списки, цитаты, жирный/курсив, ссылки, переносы. Стили, классы, шрифты, span'ы,
     служебные теги Word/Google Docs, картинки и скрипты — убираем. Разбор через
     DOMParser: ничего из вставленного не выполняется и не загружается. */
  var Clean = (function () {
    var BLOCK = { P: 'p', DIV: 'p', SECTION: 'p', ARTICLE: 'p', HEADER: 'p', FOOTER: 'p', MAIN: 'p', PRE: 'p', TR: 'p', DT: 'p', DD: 'p', FIGCAPTION: 'p',
      H1: 'h2', H2: 'h2', H3: 'h3', H4: 'h4', H5: 'h4', H6: 'h4', BLOCKQUOTE: 'blockquote', UL: 'ul', OL: 'ol', LI: 'li' };
    var INLINE = { STRONG: 'strong', B: 'strong', EM: 'em', I: 'em' };
    var DROP = { SCRIPT: 1, STYLE: 1, META: 1, LINK: 1, TITLE: 1, HEAD: 1, IMG: 1, PICTURE: 1, SVG: 1, VIDEO: 1, AUDIO: 1, IFRAME: 1, OBJECT: 1,
      EMBED: 1, NOSCRIPT: 1, TEMPLATE: 1, BUTTON: 1, INPUT: 1, SELECT: 1, TEXTAREA: 1, FORM: 1, CANVAS: 1 };
    var parser = new DOMParser();
    function txt(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
    function safeHref(h) {
      h = String(h || '').trim();
      return /^(https?:|mailto:|tel:|ucms:page\/|\/|#)/i.test(h) || /^[\w./-]+\.html(#.*)?$/i.test(h) ? h : '';
    }
    function hasBlockChild(el) {
      for (var i = 0; i < el.children.length; i++) if (BLOCK[el.children[i].tagName.toUpperCase()]) return true;
      return false;
    }
    function inner(el, inList) { var h = ''; el.childNodes.forEach(function (c) { h += conv(c, inList); }); return h; }
    function conv(n, inList) {
      if (n.nodeType === 3) return txt(n.nodeValue.replace(/[\s\u00a0]+/g, function (m) { return /\u00a0/.test(m) && m.length === 1 ? '\u00a0' : ' '; }));
      if (n.nodeType !== 1) return '';
      var tag = n.tagName.toUpperCase();
      if (n.hasAttribute('data-caret')) return '<span data-caret></span>';
      if (tag.indexOf(':') >= 0) return inner(n, inList);          // o:p и прочее из Word
      if (DROP[tag]) return '';
      if (tag === 'BR') return '<br>';
      if (tag === 'A') { var href = safeHref(n.getAttribute('href')), b = inner(n, inList); return href && b.trim() ? '<a href="' + txt(href).replace(/"/g, '&quot;') + '">' + b + '</a>' : b; }
      if (BLOCK[tag]) {
        var t = BLOCK[tag];
        if (t === 'ul' || t === 'ol') { var items = inner(n, true).trim(); return items ? '<' + t + '>' + items + '</' + t + '>' : ''; }
        if (t === 'li') { var li = inner(n, true).trim(); return li ? '<li>' + li + '</li>' : ''; }
        // внутри пункта списка абзацы не нужны; обёртки с блоками внутри — разворачиваем
        if (inList && t === 'p') return inner(n, true) + ' ';
        if (t === 'p' && hasBlockChild(n)) return inner(n, inList);
        var body = inner(n, inList).trim();
        return body ? '<' + t + '>' + body + '</' + t + '>' : '';
      }
      var it = INLINE[tag] || '';
      var st = (n.getAttribute('style') || '').toLowerCase();
      if (tag === 'B' && /font-weight\s*:\s*(normal|400)/.test(st)) it = '';   // обёртка Google Docs
      if (!it && /font-weight\s*:\s*(bold|[6-9]00)/.test(st)) it = 'strong';
      else if (!it && /font-style\s*:\s*italic/.test(st)) it = 'em';
      var inn = inner(n, inList);
      return it && inn.trim() ? '<' + it + '>' + inn + '</' + it + '>' : inn;
    }
    // Текст и строчные теги верхнего уровня собираем в абзацы.
    function paragraphs(html) {
      var body = parser.parseFromString('<body>' + html + '</body>', 'text/html').body, out = '', run = '';
      var flush = function () { if (run.replace(/<br>|<span data-caret><\/span>|\s|\u00a0/g, '')) out += '<p>' + run.trim() + '</p>'; else if (/data-caret/.test(run)) out += '<p>' + run + '</p>'; run = ''; };
      body.childNodes.forEach(function (c) {
        if (c.nodeType === 1 && BLOCK[c.tagName.toUpperCase()]) { flush(); out += c.outerHTML; }
        else run += c.nodeType === 3 ? txt(c.nodeValue) : c.outerHTML;
      });
      flush();
      return out.replace(/<p>(\s|<br>)*<\/p>/g, '');
    }
    // Полная очистка: только абзацы и переносы строк — без жирного, курсива,
    // заголовков, списков (пункт → абзац), цитат и ссылок.
    function plain(dirty) {
      var body = parser.parseFromString(paragraphs(inner(parser.parseFromString(String(dirty || ''), 'text/html').body, false)), 'text/html').body;
      function text(n) {
        var h = '';
        n.childNodes.forEach(function (c) { h += c.nodeType === 3 ? txt(c.nodeValue) : c.tagName === 'BR' ? '<br>' : text(c); });
        return h;
      }
      var out = '';
      body.childNodes.forEach(function (c) {
        if (c.nodeType !== 1) return;
        if (c.tagName === 'UL' || c.tagName === 'OL') c.querySelectorAll('li').forEach(function (li) { var t = text(li).trim(); if (t) out += '<p>' + t + '</p>'; });
        else { var t2 = text(c).trim(); if (t2) out += '<p>' + t2 + '</p>'; }
      });
      return out;
    }
    return {
      plain: plain,
      html: function (dirty) {
        var doc = parser.parseFromString(String(dirty || ''), 'text/html');
        return paragraphs(inner(doc.body, false));
      },
      text: function (plain) {
        return String(plain || '').replace(/\r\n?/g, '\n').split(/\n{2,}/).map(function (p) { return p.trim(); }).filter(Boolean)
          .map(function (p) { return '<p>' + txt(p).replace(/\n/g, '<br>') + '</p>'; }).join('');
      },
    };
  })();
  App.cleanHtml = Clean.html;

  // Вставка в визуальный редактор: чистим и вставляем сами (execCommand('insertHTML')
  // в Chrome сам добавляет inline-стили). Метка курсора помогает вернуть каретку
  // после нормализации, которая заодно убирает абзацы, вложенные в абзацы.
  document.addEventListener('paste', function (e) {
    var rich = e.target && e.target.closest && e.target.closest('.ad-rich');
    if (!rich || !e.clipboardData) return;
    e.preventDefault();
    var html = e.clipboardData.getData('text/html'), plain = e.clipboardData.getData('text/plain');
    var clean = html ? Clean.html(html) : Clean.text(plain);
    // одиночный абзац вставляем строкой, чтобы не разрывать текущий абзац
    var single = /^<p>((?:(?!<\/?p>).)*)<\/p>$/.exec(clean);
    if (single) {
      clean = single[1];
      // пробелы по краям вставки важны внутри строки («слово вставка слово»)
      if (/^\s/.test(plain)) clean = ' ' + clean;
      if (/\s$/.test(plain)) clean += ' ';
    }
    // каретка — в конце последнего вставленного абзаца/пункта, а не перед текстом после него
    var MARK = '<span data-caret></span>', tail = /(<\/(?:p|h[2-4]|blockquote|li)>(?:<\/(?:ul|ol)>)?)$/;
    clean = tail.test(clean) ? clean.replace(tail, MARK + '$1') : clean + MARK;
    var sel = window.getSelection();
    if (!sel.rangeCount || !rich.contains(sel.anchorNode)) { rich.focus(); sel = window.getSelection(); }
    var r = sel.getRangeAt(0);
    r.deleteContents();
    var tpl = document.createElement('template');
    tpl.innerHTML = clean;
    r.insertNode(tpl.content);
    rich.innerHTML = Clean.html(rich.innerHTML);
    var mark = rich.querySelector('[data-caret]');
    if (mark) {
      var nr = document.createRange(); nr.setStartBefore(mark); nr.collapse(true);
      sel.removeAllRanges(); sel.addRange(nr); mark.remove();
    }
    rich.dispatchEvent(new Event('input', { bubbles: true }));
  });

  // Кнопка «Очистить стили»: тот же фильтр ко всему тексту модуля.
  // «Очистить стили»: есть выделение — убираем всё оформление только у него
  // (жирный, курсив, ссылки, заголовок → абзац, пункт списка → абзац);
  // нет выделения — у всего текста модуля остаются только абзацы.
  App.textClean = function (treeName, modId) {
    var m = getModule(treeName, modId); if (!m) return;
    var ed = document.querySelector('[data-visual="' + modId + '"]');
    var sel = window.getSelection();
    var inEd = ed && sel.rangeCount && !sel.isCollapsed && ed.contains(sel.anchorNode) && ed.contains(sel.focusNode);
    if (inEd && document.execCommand) {
      document.execCommand('removeFormat');
      document.execCommand('unlink');
      if (document.queryCommandState('insertUnorderedList')) document.execCommand('insertUnorderedList');
      if (document.queryCommandState('insertOrderedList')) document.execCommand('insertOrderedList');
      document.execCommand('formatBlock', false, '<p>');
      ed.innerHTML = Clean.html(ed.innerHTML);   // заодно снять стили, которые мог добавить браузер
      m.html = ed.innerHTML; queuePreview();
      if (App.toast) App.toast(_t('Оформление выделенного текста убрано'));
      return;
    }
    var before = m.html || '', after = Clean.plain(before);
    if (after === before) { if (App.toast) App.toast(_t('Лишних стилей нет')); return; }
    if (!confirm(_t('Убрать всё оформление текста? Останутся только абзацы: без жирного, курсива, заголовков, списков и ссылок. Чтобы очистить только часть текста, сначала выделите её.'))) return;
    m.html = after; App.renderModule(treeName, modId);
    if (App.toast) App.toast(_t('Стили очищены'));
  };

  /* ---- ссылка в тексте: свой диалог вместо prompt ----
     Ссылка на страницу сайта хранится как ucms:page/<id>[#якорь] — генератор
     подставляет правильный адрес для каждого языка (папки, переведённые slug'и). */
  var _tlink = null;
  function closestLink(node, root) {
    for (var n = node; n && n !== root; n = n.parentNode) if (n.nodeType === 1 && n.tagName === 'A') return n;
    return null;
  }
  App.textLinkOpen = function (treeName, modId) {
    var ed = document.querySelector('[data-visual="' + modId + '"]'); if (!ed) return;
    var sel = window.getSelection();
    var range = sel.rangeCount && ed.contains(sel.anchorNode) ? sel.getRangeAt(0).cloneRange() : null;
    var a = range ? closestLink(range.startContainer, ed) : null;
    var href = a ? a.getAttribute('href') || '' : '';
    var m = /^ucms:page\/([^#]+)(?:#(.*))?$/.exec(href);
    _tlink = { tree: treeName, modId: modId, range: range, a: a,
      mode: m ? 'page' : 'url', url: m ? '' : href, pageId: m ? m[1] : '', anchor: m ? (m[2] || '') : '' };
    renderTextLink();
  };
  function renderTextLink() {
    if (!_tlink) return;
    var box = document.querySelector('[data-tlink="' + _tlink.modId + '"]'); if (!box) return;
    var L = _tlink, pages = App.pageRefs ? App.pageRefs() : [];
    var pageTitle = (pages.filter(function (p) { return p.id === L.pageId; })[0] || {}).title;
    var anchors = pageTitle && App.pageAnchors ? App.pageAnchors(pageTitle) : [];
    var html = '<div class="ad-f__row"><span class="ad-f__l">' + (L.a ? _t('Изменить ссылку') : _t('Новая ссылка')) + '</span></div>' +
      segm([['url', _t('Адрес (URL)')], ['page', _t('Страница сайта')]], L.mode, function (k) { return 'App.textLinkSet(\'mode\',' + jsArg(k) + ',true)'; });
    if (L.mode === 'url') {
      html += '<input class="ad-in ad-in--mono" data-tlink-url aria-label="' + escAttr(_t('Адрес ссылки')) + '" placeholder="https://… , mailto:… , tel:… , #якорь" value="' + escAttr(L.url) + '" oninput="App.textLinkSet(\'url\',this.value)">';
    } else {
      html += '<select class="ad-in ad-select" aria-label="' + escAttr(_t('Страница')) + '" onchange="App.textLinkSet(\'pageId\',this.value,true)"><option value="">' + _t('Выберите страницу') + '</option>' +
        pages.map(function (p) { return '<option value="' + escAttr(p.id) + '"' + (p.id === L.pageId ? ' selected' : '') + '>' + esc(p.title) + '</option>'; }).join('') + '</select>';
      if (L.pageId) {
        html += '<select class="ad-in ad-select" aria-label="' + escAttr(_t('Якорь')) + '" onchange="App.textLinkSet(\'anchor\',this.value)"><option value="">' + _t('Без якоря — начало страницы') + '</option>' +
          anchors.map(function (a) { return '<option value="' + escAttr(a.anchor) + '"' + (a.anchor === L.anchor ? ' selected' : '') + '>#' + esc(a.anchor) + ' — ' + esc(a.label) + '</option>'; }).join('') + '</select>';
      }
    }
    html += '<div class="ad-btnrow">' + UI.btn(_t('Применить'), 'App.textLinkApply()', { variant: 'dark', sm: true }) +
      (L.a ? UI.btn(_t('Убрать ссылку'), 'App.textLinkRemove()', { sm: true, variant: 'danger' }) : '') +
      UI.btn(_t('Отмена'), 'App.textLinkClose()', { sm: true }) + '</div>' +
      (L.range && L.range.collapsed && !L.a ? '<span class="ad-f__hint">' + _t('Текст не выделен — вставится сама ссылка. Чтобы сделать ссылкой слово, сначала выделите его.') + '</span>' : '');
    box.innerHTML = html;
    box.hidden = false;
    var u = box.querySelector('[data-tlink-url]'); if (u && !L.url) u.focus();
  }
  App.textLinkSet = function (field, value, rerender) {
    if (!_tlink) return;
    _tlink[field] = value;
    if (field === 'pageId') _tlink.anchor = '';
    if (rerender) renderTextLink();
  };
  App.textLinkClose = function () {
    if (!_tlink) return;
    var box = document.querySelector('[data-tlink="' + _tlink.modId + '"]'); if (box) { box.hidden = true; box.innerHTML = ''; }
    _tlink = null;
  };
  function tlinkDone(ed) {
    ed.dispatchEvent(new Event('input', { bubbles: true }));   // → mod.html и превью
    App.textLinkClose();
  }
  App.textLinkApply = function () {
    var L = _tlink; if (!L) return;
    var href = L.mode === 'page' ? (L.pageId ? 'ucms:page/' + L.pageId + (L.anchor ? '#' + L.anchor : '') : '') : String(L.url || '').trim();
    if (!href || !/^(https?:\/\/|mailto:|tel:|ucms:page\/|#|\/)/i.test(href) && !/^[\w./-]+\.html(#.*)?$/i.test(href)) {
      if (L.mode === 'url' && href && !/^[a-z]+:/i.test(href)) href = 'https://' + href;   // «example.com» → https://example.com
      else { if (App.toast) App.toast(_t('Укажите адрес или выберите страницу')); return; }
    }
    var ed = document.querySelector('[data-visual="' + L.modId + '"]'); if (!ed) return;
    if (L.a && ed.contains(L.a)) { L.a.setAttribute('href', href); tlinkDone(ed); return; }
    var sel = window.getSelection(), range = L.range;
    if (!range || !ed.contains(range.startContainer)) { range = document.createRange(); range.selectNodeContents(ed); range.collapse(false); }
    sel.removeAllRanges(); sel.addRange(range);
    if (range.collapsed) {
      var a = document.createElement('a');
      a.setAttribute('href', href);
      var title = L.mode === 'page' ? ((App.pageRefs().filter(function (p) { return p.id === L.pageId; })[0] || {}).title || href) : href.replace(/^mailto:|^tel:/, '');
      a.textContent = title;
      range.insertNode(a);
      range.setStartAfter(a); range.collapse(true); sel.removeAllRanges(); sel.addRange(range);
    } else {
      document.execCommand('createLink', false, href);
    }
    tlinkDone(ed);
  };
  App.textLinkRemove = function () {
    var L = _tlink; if (!L || !L.a) return;
    var ed = document.querySelector('[data-visual="' + L.modId + '"]');
    var a = L.a; while (a.firstChild) a.parentNode.insertBefore(a.firstChild, a); a.remove();
    tlinkDone(ed);
  };

  App.textExec = function (treeName, modId, cmd, val) {
    var wrap = document.querySelector('[data-visual="' + modId + '"]');
    if (!wrap) return;
    wrap.focus();
    try { document.execCommand(cmd, false, val || null); } catch (e) {}
    App.setModuleField(treeName, modId, 'html', wrap.innerHTML, true);
  };

  /* ---- модуль «HTML»: предпросмотр ---- */
  App.htmlTogglePreview = function (treeName, modId) {
    var m = getModule(treeName, modId); if (!m) return;
    m._preview = !m._preview; App.renderModule(treeName, modId);
    if (m._preview) {
      setTimeout(function () {
        var frame = document.querySelector('[data-frame="' + modId + '"]');
        var font = state.themeFontUrl ? '<link rel="stylesheet" href="' + escAttr(state.themeFontUrl) + '">' : '';
        if (frame) frame.srcdoc = '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8">' + font + '<link rel="stylesheet" href="/output/style.css">' +
          '<style>body{margin:12px;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;color:var(--ink)}</style></head><body>' + (m.code || '') + '</body></html>';
      }, 0);
    }
  };
  App.paintCode = function (el, treeName, modId, field) {
    var lang = field === 'themeCss' ? 'css' : 'html';
    var value = el.value;
    if (field === 'themeCss') { state.themeCss = value; } else { App.setModuleField(treeName, modId, field, value, true); }
    var pre = el.previousElementSibling;
    if (pre) pre.innerHTML = (lang === 'css' ? SyntaxHL.css(value) : SyntaxHL.html(value)) + '\n';
  };
  App.syncCodeScroll = function (el) {
    var pre = el.previousElementSibling;
    if (pre) { pre.scrollTop = el.scrollTop; pre.scrollLeft = el.scrollLeft; }
  };

  /* ---- модуль «Видео» ---- */
  App.videoOpenModal = function (treeName, modId) {
    var m = getModule(treeName, modId); if (!m || !m.url) return;
    m._modal = true; App.renderModule(treeName, modId);
  };
  App.videoCloseModal = function (treeName, modId) {
    var m = getModule(treeName, modId); if (!m) return;
    m._modal = false; App.renderModule(treeName, modId);
  };
  App.videoClearCover = function (treeName, modId) {
    var m = getModule(treeName, modId); if (!m) return;
    m.cover = ''; App.renderModule(treeName, modId);
  };

  /* ---- галерея: элементы + drag&drop ---- */
  App.galAddItem = function (treeName, modId) {
    var m = getModule(treeName, modId); if (!m) return;
    m.items.push({ id: uid('g'), title: '', caption: '', alt: '', link: { linkType: 'none' } }); App.renderModule(treeName, modId);
  };
  App.galDelItem = function (treeName, modId, itemId) {
    var m = getModule(treeName, modId); if (!m) return;
    m.items = m.items.filter(function (it) { return it.id !== itemId; }); App.renderModule(treeName, modId);
  };
  App.galSetItemField = function (treeName, modId, itemId, field, value) {
    var m = getModule(treeName, modId); if (!m) return;
    var it = m.items.filter(function (x) { return x.id === itemId; })[0]; if (it) it[field] = value;
  };
  var dragCtx = null; // { treeName, modId, from }
  App.galDragStart = function (treeName, modId, idx) { dragCtx = { treeName: treeName, modId: modId, from: idx }; };
  App.galDrop = function (treeName, modId, idx) {
    if (!dragCtx || dragCtx.modId !== modId || dragCtx.from === idx) { dragCtx = null; return; }
    var m = getModule(treeName, modId); if (!m) { dragCtx = null; return; }
    var arr = m.items; var x = arr.splice(dragCtx.from, 1)[0]; arr.splice(idx, 0, x);
    dragCtx = null; App.renderModule(treeName, modId);
  };

  /* ---- модули-списки: общие операции над m.items ---- */
  function listItem(tree, modId, itemId) {
    var m = getModule(tree, modId); if (!m) return null;
    var i = (m.items || []).findIndex(function (x) { return x.id === itemId; });
    return i < 0 ? null : { m: m, i: i };
  }
  App.listAdd = function (tree, modId) {
    var m = getModule(tree, modId); if (!m) return;
    var make = LIST_ITEM[m.type] || (App.PKG && App.PKG[m.type] && App.PKG[m.type].newItem);
    if (!make) return;
    m.items = m.items || []; m.items.push(make()); App.renderModule(tree, modId);
  };
  App.listDel = function (tree, modId, itemId) {
    var r = listItem(tree, modId, itemId); if (!r) return;
    var it = r.m.items[r.i];
    if (r.m.type === 'tabs' && nestedCount(it.blocks) && !confirm(_t('Удалить вкладку «') + (it.title || '') + _t('» вместе с содержимым?'))) return;
    r.m.items.splice(r.i, 1); App.renderModule(tree, modId);
  };
  App.listMove = function (tree, modId, itemId, dir) {
    var r = listItem(tree, modId, itemId); if (!r) return;
    var to = r.i + dir; if (to < 0 || to >= r.m.items.length) return;
    r.m.items.splice(to, 0, r.m.items.splice(r.i, 1)[0]); App.renderModule(tree, modId);
  };
  // Ввод в поле элемента — без перерисовки (фокус); превью обновит слушатель input инспектора.
  App.listSet = function (tree, modId, itemId, field, value) {
    var r = listItem(tree, modId, itemId); if (r) r.m.items[r.i][field] = value;
  };
  /* ---- карточки: ключевые слова фильтра (m.tags = [{ id, name }], у карточки — it.tags = [id…]) ---- */
  App.tagAdd = function (tree, modId) {
    var m = getModule(tree, modId); if (!m) return;
    m.tags = m.tags || []; m.tags.push({ id: uid('k'), name: '' });
    App.renderModule(tree, modId);
    var inputs = document.querySelectorAll('[data-insp] .ad-pxbox .ad-colrow input'); if (inputs.length) inputs[inputs.length - 1].focus();
  };
  App.tagSet = function (tree, modId, tagId, name) {   // ввод — без перерисовки, подписи в карточках обновим на blur
    var m = getModule(tree, modId); if (!m) return;
    var tg = (m.tags || []).filter(function (x) { return x.id === tagId; })[0]; if (tg) tg.name = name;
  };
  App.tagDel = function (tree, modId, tagId) {
    var m = getModule(tree, modId); if (!m) return;
    m.tags = (m.tags || []).filter(function (x) { return x.id !== tagId; });
    (m.items || []).forEach(function (it) { if (it.tags) it.tags = it.tags.filter(function (id) { return id !== tagId; }); });
    App.renderModule(tree, modId);
  };
  App.cardTagToggle = function (tree, modId, itemId, tagId) {
    var r = listItem(tree, modId, itemId); if (!r) return;
    var it = r.m.items[r.i]; it.tags = it.tags || [];
    var i = it.tags.indexOf(tagId);
    if (i >= 0) it.tags.splice(i, 1); else it.tags.push(tagId);
    App.renderModule(tree, modId);
  };

  App.listFlip = function (tree, modId, itemId, field) {
    var r = listItem(tree, modId, itemId); if (!r) return;
    r.m.items[r.i][field] = !r.m.items[r.i][field]; App.renderModule(tree, modId);
  };

  /* ---- клик вне поповера — закрыть ---- */
  document.addEventListener('mousedown', function (e) {
    if (state.openPopover && !e.target.closest('[data-dd]')) App.closeAllPopovers();
  });

  /* ============================================================
     Разметка: общие виджеты
     ============================================================ */
  function toggleHTML(on, dataToggle, onclick, label) {
    return '<button type="button" role="switch" aria-checked="' + !!on + '" class="ad-toggle' + (on ? ' is-on' : '') + '"' +
      (dataToggle ? ' data-toggle="' + dataToggle + '"' : '') + (label ? ' aria-label="' + esc(label) + '"' : '') + ' onclick="' + onclick + '">' +
      '<span class="ad-toggle__knob"></span></button>';
  }

  // path — 'mod:<tree>:<modId>' или 'gal:<tree>:<modId>:<itemId>'.
  function linkFieldHTML(treeName, modId, link, pages, path, label) {
    var lt = (link && link.linkType) || 'none', P = jsArg(path), pid = 'page:' + path;
    var html = '<div class="ad-f" data-dd><span class="ad-f__l">' + esc(label || _t('Ссылка')) + '</span>' +
      segm([['none', _t('Нет')], ['external', 'URL'], ['inner', _t('Страница')], ['file', _t('Файл')]], lt, function (k) { return 'App.patchLink(' + P + ',{linkType:' + jsArg(k) + '})'; });
    // Файл из медиатеки (PDF, DOCX, архив…): скачать или открыть в браузере
    if (lt === 'file') {
      var file = (link && link.file) || '';
      html += '<button type="button" class="ad-in ad-in--pick" onclick="App.pickLinkFile(' + P + ')">' + ico('down', 14) +
        '<span' + (file ? '' : ' style="color:var(--mut-2)"') + '>' + esc(file ? fileLabel(file) : _t('Выберите файл')) + '</span>' + ico('chevd', 13) + '</button>' +
        UI.sw(_t('Скачивать файл'), !link || link.download !== false, 'App.patchLink(' + P + ',{download:' + (link && link.download === false ? 'true' : 'false') + '})') +
        '<span class="ad-f__hint">' + (link && link.download === false ? _t('Файл откроется в новой вкладке (PDF и картинки браузер покажет сам).') : _t('Посетитель сразу скачает файл под его исходным именем.')) + '</span>';
    }
    if (lt === 'external') {
      html += _t('<input class="ad-in ad-in--mono" aria-label="Адрес ссылки" placeholder="https://…" value="') + escAttr((link && link.url) || '') + '" oninput="App.patchLink(' + P + ',{url:this.value},true)">';
    }
    if (lt === 'inner') {
      var page = (link && link.page) || null, open = state.openPopover === pid;
      html += '<div class="ad-dd"><button type="button" class="ad-in ad-in--pick" aria-expanded="' + open + '" onclick="App.togglePopover(' + jsArg(pid) + ')">' +
        ico('pages', 14) + '<span' + (page ? '' : ' style="color:var(--mut-2)"') + '>' + esc(page || _t('Выберите страницу')) + '</span>' + ico('chevd', 13) + '</button>' +
        (open ? popoverHTML(pages.map(function (p) {
          return '<div class="ad-popover__row' + (p === page ? ' ad-popover__row--active' : '') + '" onclick="App.patchLink(' + P + ',{page:' + jsArg(p) + ',anchor:\'\'})">' + esc(p) + '</div>';
        }).join(''), { scroll: true }) : '') + '</div>';
      // Якорь на выбранной странице: блоки с якорем на ней + в шапке/подвале
      if (page) {
        var anchors = App.pageAnchors ? App.pageAnchors(page) : [], aid = 'anc:' + path, aopen = state.openPopover === aid, cur = (link && link.anchor) || '';
        if (anchors.length || cur) {
          html += '<div class="ad-dd"><button type="button" class="ad-in ad-in--pick" aria-expanded="' + aopen + '" onclick="App.togglePopover(' + jsArg(aid) + ')">' +
            ico('hash', 14) + '<span' + (cur ? '' : ' style="color:var(--mut-2)"') + '>' + esc(cur ? '#' + cur : _t('Без якоря — начало страницы')) + '</span>' + ico('chevd', 13) + '</button>' +
            (aopen ? popoverHTML(['<div class="ad-popover__row' + (cur ? '' : ' ad-popover__row--active') + '" onclick="App.patchLink(' + P + ',{anchor:\'\'})">' + _t('Без якоря — начало страницы') + '</div>']
              .concat(anchors.map(function (a) {
                return '<div class="ad-popover__row' + (a.anchor === cur ? ' ad-popover__row--active' : '') + '" onclick="App.patchLink(' + P + ',{anchor:' + jsArg(a.anchor) + '})">#' + esc(a.anchor) + ' <small style="color:var(--mut-2)">' + esc(a.label) + '</small></div>';
              })).join(''), { scroll: true }) : '') + '</div>';
        } else {
          html += '<span class="ad-f__hint">' + _t('Чтобы вести к блоку, задайте блоку якорь (инспектор блока).') + '</span>';
        }
      }
    }
    return html + '</div>';
  }
  // Имя файла без метки времени загрузки: «/uploads/files/1729…-price.pdf» → «price.pdf»
  function fileLabel(p) { return String(p || '').split('/').pop().replace(/^\d{10,}-/, ''); }
  App.pickLinkFile = function (path) { App.pickFile(function (url) { App.patchLink(path, { file: url }); }); };
  // Объект, чья ссылка правится: модуль или элемент галереи.
  function linkHost(path) {
    var parts = String(path).split(':');
    var m = getModule(parts[1], parts[2]);
    if (!m) return null;
    if (parts[0] === 'gal') return (m.items || []).filter(function (x) { return x.id === parts[3]; })[0] || null;
    return m;
  }
  // Единая точка правки ссылки (тип / URL / страница). noRender — для oninput.
  App.patchLink = function (path, patch, noRender) {
    var host = linkHost(path); if (!host) return;
    host.link = Object.assign({}, host.link, patch);
    if (noRender) return;
    state.openPopover = null;
    var o = ownerOf(path); if (o) App.renderModule(o.tree, o.modId);
  };

  // Выпадающий список печатается ВНУТРИ своего контейнера .ad-dd (position:relative)
  // как position:absolute-оверлей (см. .ad-popover в admin.css).
  function popoverHTML(innerHtml, opts) {
    opts = opts || {};
    var cls = 'ad-popover' + (opts.scroll ? ' ad-popover--scroll' : '');
    var style = opts.width ? ' style="width:' + opts.width + 'px;right:auto"' : '';
    return '<div class="' + cls + '"' + style + '>' + innerHtml + '</div>';
  }

  /* ============================================================
     Разметка: BackgroundSettings
     ============================================================ */
  // Параллакс фото-фона (на основе simpleParallax.js): направление, масштаб, задержка, ограничение.
  var PX_DIRS = [['up', _t('Вверх')], ['down', _t('Вниз')], ['left', _t('Влево')], ['right', _t('Вправо')], ['up left', _t('Вверх и влево')], ['up right', _t('Вверх и вправо')], ['down left', _t('Вниз и влево')], ['down right', _t('Вниз и вправо')]];
  function parallaxFields(bg, set, kind) {
    var html = UI.sw(_t('Параллакс при прокрутке'), !!bg.parallax, set('parallax', bg.parallax ? 'false' : 'true'));
    if (!bg.parallax) return html;
    var sc = Math.round((parseFloat(bg.pxScale) || 1.3) * 10) / 10, dl = Math.round((parseFloat(bg.pxDelay) || 0) * 10) / 10, mx = parseInt(bg.pxMax, 10) || 0;
    var r1 = function (v) { return Math.round(v * 10) / 10; };
    return html + '<div class="ad-pxbox">' +
      UI.field(_t('Направление движения'), _t('<select class="ad-in ad-select" aria-label="Направление параллакса" onchange="') + set('pxOrientation', 'this.value') + '">' +
        PX_DIRS.map(function (d) { return '<option value="' + d[0] + '"' + ((bg.pxOrientation || 'up') === d[0] ? ' selected' : '') + '>' + d[1] + '</option>'; }).join('') + '</select>') +
      UI.field(_t('Сила эффекта (масштаб)'), UI.stepper('×' + sc.toFixed(1), set('pxScale', r1(Math.max(1.1, sc - 0.1))), set('pxScale', r1(Math.min(2.5, sc + 0.1)))),
        _t('Чем больше масштаб, тем сильнее сдвиг картинки.')) +
      UI.field(_t('Задержка'), UI.stepper(dl ? dl.toFixed(1) + _t(' с') : _t('нет'), set('pxDelay', r1(Math.max(0, dl - 0.1))), set('pxDelay', r1(Math.min(3, dl + 0.1)))),
        _t('Картинка «догоняет» прокрутку с запаздыванием.')) +
      UI.sw(_t('Плавное замедление'), bg.pxSmooth !== false, set('pxSmooth', bg.pxSmooth === false ? 'true' : 'false')) +
      UI.field(_t('Ограничить смещение'), UI.stepper(mx ? mx + '%' : _t('нет'), set('pxMax', Math.max(0, mx - 10)), set('pxMax', Math.min(90, mx + 10))),
        _t('Эффект останавливается, пройдя этот процент пути.')) +
      '<span class="ad-f__hint">' + (kind === 'page' ? _t('Картинка закреплена на весь экран и смещается по мере прокрутки страницы.') : _t('Эффект на основе simpleParallax.js.')) +
      _t(' При «уменьшить движение» в системе посетителя картинка неподвижна.</span></div>');
  }

  // Редактор фона. kind: 'page' (с узором и режимами картинки) или 'block' (затемнение, светлый текст).
  function renderBgEditor(target, bg, kind) {
    var T = jsArg(target);
    var types = [['none', _t('Нет')], ['color', _t('Цвет')], ['gradient', _t('Градиент')], ['image', _t('Фото')]];
    if (kind === 'page') types.push(['pattern', _t('Узор')]);
    var set = function (f, v, live) { return 'App.bgSet(' + T + ',' + jsArg(f) + ',' + v + (live ? ',true' : '') + ')'; };
    var html = '<div class="ad-bg" data-bg="' + escAttr(target) + '">' + segm(types, bg.type, function (k) { return set('type', jsArg(k)); });
    if (bg.type === 'color') {
      html += '<div class="ad-bg__prev" data-bg-prev="' + escAttr(target) + '" style="' + escAttr(bgCss(bg)) + '"></div>' +
        UI.field(_t('Цвет'), colorInput(bg.color, set('color', 'this.value', true), _t('Цвет фона')));
    }
    if (bg.type === 'gradient') {
      html += '<div class="ad-bg__prev" data-bg-prev="' + escAttr(target) + '" style="' + escAttr(bgCss(bg)) + '"></div>' +
        '<div class="ad-bg__two">' + UI.field(_t('Начало'), colorInput(bg.gradientFrom, set('gradientFrom', 'this.value', true), _t('Цвет начала'))) +
        UI.field(_t('Конец'), colorInput(bg.gradientTo, set('gradientTo', 'this.value', true), _t('Цвет конца'))) + '</div>' +
        _t('<div class="ad-f"><div class="ad-f__row"><span class="ad-f__l">Угол</span><span class="ad-bg__val" data-bg-angle="') + escAttr(target) + '">' + (parseInt(bg.gradientAngle, 10) || 0) + '°</span></div>' +
        _t('<input type="range" class="ad-range" min="0" max="360" step="5" aria-label="Угол градиента" value="') + (parseInt(bg.gradientAngle, 10) || 0) + '" oninput="' + set('gradientAngle', 'this.value', true) + '"></div>';
    }
    if (bg.type === 'image' || bg.type === 'pattern') {
      html += bg.image
        ? '<div class="ad-media ad-bg__media"><div class="ad-bg__prev ad-bg__prev--img" data-bg-prev="' + escAttr(target) + '" style="' + escAttr(bgCss(bg)) + '"></div><div class="ad-media__bar">' +
          UI.btn(_t('Заменить'), '', { sm: true, icon: 'upload', cls: 'ad-bg-up ad-b--glass' }) + UI.btn(_t('Убрать'), set('image', "''"), { sm: true, cls: 'ad-b--glass' }) + '</div></div>'
        : '<button type="button" class="ad-drop ad-bg-up">' + ico('upload', 20) + '<b>' + (bg.type === 'pattern' ? _t('Загрузить плитку узора') : _t('Загрузить изображение')) + '</b><small>JPG, PNG, WebP, SVG</small></button>';
      if (kind === 'page' && bg.type === 'image' && !bg.parallax) {   // с параллаксом картинка всегда на весь экран
        html += UI.field(_t('Размер'), segm([['cover', _t('Растянуть'), 'imgFill'], ['center', _t('Как есть'), 'imgNatural']], bg.stretch === false ? 'center' : 'cover',
          function (k) { return set('stretch', k === 'cover' ? 'true' : 'false'); }));
      }
      if (kind === 'block') {
        html += _t('<div class="ad-f"><div class="ad-f__row"><span class="ad-f__l">Затемнение</span><span class="ad-bg__val" data-bg-ov>') + (bg.overlay || 0) + '%</span></div>' +
          _t('<input type="range" class="ad-range" min="0" max="80" step="5" aria-label="Затемнение картинки" value="') + (bg.overlay || 0) + '" oninput="this.previousElementSibling.lastChild.textContent=this.value+\'%\';' + set('overlay', '+this.value', true) + '"></div>';
      }
      html += UI.field(_t('Цвет под картинкой'), colorInput(bg.color, set('color', 'this.value', true), _t('Цвет под картинкой')));
      if (bg.type === 'image') html += parallaxFields(bg, set, kind);
      if (kind === 'page' && !(bg.type === 'image' && bg.parallax)) html += UI.sw(_t('Не прокручивать вместе со страницей'), !!bg.fixed, set('fixed', bg.fixed ? 'false' : 'true'));
    }
    if (kind === 'block' && bg.type !== 'none') {
      html += UI.sw(_t('Светлый текст (для тёмного фона)'), !!bg.light, set('light', bg.light ? 'false' : 'true'));
    }
    return html + '</div>';
  }
  function renderBackgroundSettings() { return renderBgEditor('page', state.pageBg, 'page'); }

  /* ============================================================
     Разметка: редактор модуля (плагины engine/admin/modules/*.js)
     ============================================================ */
  /* ============================================================
     UI-кит редакторов модулей (ctx.ui) — единый вид полей во всех
     engine/admin/modules/*.js. Возвращает HTML-строки.
     ============================================================ */
  var UI = {
    field: function (label, inner, hint) {
      return '<div class="ad-f">' + (label ? '<span class="ad-f__l">' + esc(label) + '</span>' : '') + inner +
        (hint ? '<span class="ad-f__hint">' + hint + '</span>' : '') + '</div>';
    },
    // o: { value, oninput, placeholder, mono, type, aria }
    input: function (o) {
      return '<input class="ad-in' + (o.mono ? ' ad-in--mono' : '') + '"' + (o.type ? ' type="' + o.type + '"' : '') +
        ' aria-label="' + esc(o.aria || o.placeholder || '') + '" placeholder="' + esc(o.placeholder || '') + '" value="' + escAttr(o.value == null ? '' : o.value) + '"' +
        (o.oninput ? ' oninput="' + o.oninput + '"' : '') + '>';
    },
    segm: function (options, active, onclickOf) { return segm(options, active, onclickOf); },
    sw: function (label, on, onclick) { return '<div class="ad-sw"><span>' + esc(label) + '</span>' + toggleHTML(on, '', onclick, label) + '</div>'; },
    // o: { icon, variant: 'line' | 'accent' | 'danger' | 'dark', sm, cls }
    btn: function (label, onclick, o) {
      o = o || {};
      return '<button type="button" class="ad-b' + (o.sm ? ' ad-b--sm' : '') + (o.variant ? ' ad-b--' + o.variant : '') + (o.cls ? ' ' + o.cls : '') + '"' +
        (onclick ? ' onclick="' + onclick + '"' : '') + '>' + (o.icon ? ico(o.icon, 14) : '') + esc(label) + '</button>';
    },
    stepper: function (value, onMinus, onPlus, suffix) {
      return _t('<div class="ad-step"><button type="button" class="ad-ib" aria-label="Меньше" onclick="') + onMinus + '">' + ico('minus', 14) + '</button>' +
        '<span>' + esc(value) + (suffix || '') + _t('</span><button type="button" class="ad-ib" aria-label="Больше" onclick="') + onPlus + '">' + ico('plus', 14) + '</button></div>';
    },
    note: function (html) { return '<div class="ad-note2">' + html + '</div>'; },
    // Список элементов модуля: карточки с ↑ ↓ ✕. renderItem(item, set) → поля; set(field) → oninput.
    list: function (ctx, items, title, noun, renderItem, hint) {
      var t = ctx.tree, id = ctx.mod.id, J = jsArg, n = items.length;
      return '<div class="ad-f"><div class="ad-f__row"><span class="ad-f__l">' + esc(title) + ' · ' + n + '</span>' +
        UI.btn(noun, 'App.listAdd(' + J(t) + ',' + J(id) + ')', { sm: true, variant: 'accent', icon: 'plus' }) + '</div><div class="ad-li-list">' +
        (n ? items.map(function (it, i) {
          var set = function (field) { return 'App.listSet(' + [t, id, it.id, field].map(J).join(',') + ',this.value)'; };
          return '<div class="ad-li"><div class="ad-li__h"><span class="ad-gi__n">' + (i + 1) + '</span><span style="flex:1"></span>' +
            ib('up', _t('Выше'), 'App.listMove(' + [t, id, it.id].map(J).join(',') + ',-1)', { disabled: i === 0 }) +
            ib('down', _t('Ниже'), 'App.listMove(' + [t, id, it.id].map(J).join(',') + ',1)', { disabled: i === n - 1 }) +
            ib('del', _t('Удалить'), 'App.listDel(' + [t, id, it.id].map(J).join(',') + ')', { danger: true }) + '</div>' + renderItem(it, set) + '</div>';
        }).join('') : _t('<div class="ad-empty2">Пусто — нажмите «') + esc(noun) + '»</div>') + '</div>' +
        (hint ? '<span class="ad-f__hint">' + hint + '</span>' : '') + '</div>';
    },
    ico: ico, ib: ib,
  };
  App.UI = UI;

  // Контекст, передаваемый в плагинные редакторы (engine/admin/modules/*.js).
  // Даёт модулю доступ к приватным хелперам app.js, чтобы файл был самодостаточным.
  function editorCtx(treeName, mod, pages, menuTree) {
    return {
      tree: treeName, mod: mod, pages: pages, menuTree: menuTree,
      path: 'mod:' + treeName + ':' + mod.id,
      itemPath: function (itemId) { return 'gal:' + treeName + ':' + mod.id + ':' + itemId; },
      popId: function (kind) { return kind + ':' + treeName + ':' + mod.id; },
      openPopover: state.openPopover, jsArg: jsArg,
      siteName: state.siteName,
      esc: esc, escAttr: escAttr, linkField: linkFieldHTML,
      popover: popoverHTML, toggle: toggleHTML, embedUrl: getEmbedUrl,
      ui: UI,
      // App.setModuleField для этого модуля; value — JS-выражение ('this.value', jsArg(x), число)
      set: function (field, value, noRender) {
        return 'App.setModuleField(' + jsArg(treeName) + ',' + jsArg(mod.id) + ',' + jsArg(field) + ',' + value + (noRender ? ',true' : '') + ')';
      },
      // App.moduleAction для этого модуля; body — тело function(m){…}
      act: function (body) { return 'App.moduleAction(' + jsArg(treeName) + ',' + jsArg(mod.id) + ',function(m){' + body + '})'; },
      // Вызов App.fn(tree, id, ...args) с экранированием
      call: function (fn) {
        var args = [treeName, mod.id].concat(Array.prototype.slice.call(arguments, 1));
        return call(fn, args);
      },
    };
  }

  function renderModuleEditor(treeName, mod, pages, menuTree) {
    // Вариант Б: редактор каждого типа блока живёт в engine/admin/modules/<type>.js
    // и регистрируется через CMS.editor(). Незнакомый тип → пустой редактор.
    if (window.CMS && CMS.hasEditor && CMS.hasEditor(mod.type)) {
      return CMS.editors[mod.type](mod, editorCtx(treeName, mod, pages, menuTree));
    }
    return '';
  }

  /* ============================================================
     Разметка: общие примитивы каркаса
     ============================================================ */
  var ICO = {
    pages: '<path d="M4 1.8h5.5L13 5.3v8.9H4z"/><path d="M9.3 1.8v3.7H13"/>',
    media: '<rect x="2" y="3" width="12" height="10" rx="1.5"/><circle cx="6" cy="6.5" r="1.2"/><path d="m2.5 12 3.5-3.5 2.5 2.5 2-2 3 3"/>',
    history: '<path d="M2.5 8a5.5 5.5 0 1 0 1.6-3.9"/><path d="M2.3 2.6v2.6h2.6M8 5v3.2l2.2 1.4"/>',
    undo: '<path d="M5.5 3 2.5 6l3 3"/><path d="M2.5 6H10a3.5 3.5 0 0 1 0 7H6"/>', redo: '<path d="M10.5 3l3 3-3 3"/><path d="M13.5 6H6a3.5 3.5 0 0 0 0 7h4"/>',
    coll: '<rect x="2.5" y="5.5" width="11" height="8" rx="1.3"/><path d="M4 3.5h8M5.5 1.8h5"/>',
    logout: '<path d="M6 2.5H3.5a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1H6"/><path d="M10 5l3 3-3 3M13 8H6.5"/>',
    folders: '<path d="M2 5.5V3.5a1 1 0 0 1 1-1h3l1.5 1.5H13a1 1 0 0 1 1 1v1"/><rect x="2" y="5.5" width="12" height="8" rx="1"/>',
    cloud: '<path d="M4.5 12.5a3 3 0 0 1-.4-6A4.5 4.5 0 0 1 12.8 6a3.3 3.3 0 0 1-.3 6.5"/><path d="M8 14V8.5M5.8 10.5 8 8.3l2.2 2.2"/>',
    hf: '<rect x="2" y="2" width="12" height="12" rx="2"/><path d="M2 5.5h12M2 10.5h12"/>',
    theme: '<path d="M8 2a6 6 0 1 0 0 12c1 0 1.4-.7 1.1-1.5-.4-1 .2-1.9 1.3-1.9H12a2 2 0 0 0 2-2A6 6 0 0 0 8 2z"/><circle cx="5" cy="7" r=".8"/><circle cx="8" cy="4.8" r=".8"/><circle cx="11" cy="6.6" r=".8"/>',
    langs: '<circle cx="8" cy="8" r="6"/><path d="M2 8h12M8 2c1.7 1.7 2.5 3.7 2.5 6S9.7 12.3 8 14M8 2C6.3 3.7 5.5 5.7 5.5 8s.8 4.3 2.5 6"/>',
    site: '<rect x="2" y="2" width="5" height="5" rx="1"/><rect x="9" y="2" width="5" height="5" rx="1"/><rect x="2" y="9" width="5" height="5" rx="1"/><rect x="9" y="9" width="5" height="5" rx="1"/>',
    plus: '<path d="M8 3v10M3 8h10"/>', minus: '<path d="M3 8h10"/>',
    upload: '<path d="M8 10.5V2.5M4.5 6 8 2.5 11.5 6M2.5 10.5v3h11v-3"/>', play: '<path d="M5 3.5v9l7.5-4.5z"/>',
    up: '<path d="M8 13V3M4 7l4-4 4 4"/>', down: '<path d="M8 3v10M4 9l4 4 4-4"/>',
    left: '<path d="M13 8H3M7 4 3 8l4 4"/>', right: '<path d="M3 8h10M9 4l4 4-4 4"/>',
    del: '<path d="M2.5 4h11M6 4V2.5h4V4M4 4l.7 9.5h6.6L12 4"/>',
    key: '<circle cx="5.5" cy="10.5" r="3"/><path d="m7.6 8.4 5.9-5.9M11.5 4.5l1.5 1.5M10 6l1.2 1.2"/>',
    copy: '<rect x="5.5" y="5.5" width="8" height="8" rx="1.5"/><path d="M10.5 5.5V3.5a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2"/>',
    hash: '<path d="M6 2.5 4.5 13.5M11.5 2.5 10 13.5M3 6h11M2.5 10h11"/>', eyeoff: '<path d="M2 2l12 12M6.6 6.6a2 2 0 0 0 2.8 2.8M4.2 4.4C2.6 5.5 1.5 8 1.5 8S4 13 8 13c1.4 0 2.6-.4 3.6-1M7 3.1A6.6 6.6 0 0 1 8 3c4 0 6.5 5 6.5 5a12 12 0 0 1-1.6 2.3"/>', close: '<path d="m4 4 8 8M12 4l-8 8"/>',
    grip: '<circle cx="6" cy="4" r=".9"/><circle cx="10" cy="4" r=".9"/><circle cx="6" cy="8" r=".9"/><circle cx="10" cy="8" r=".9"/><circle cx="6" cy="12" r=".9"/><circle cx="10" cy="12" r=".9"/>',
    cols: '<rect x="2" y="2.5" width="5" height="11" rx="1"/><rect x="9" y="2.5" width="5" height="11" rx="1"/>',
    chev: '<path d="m6 4 4 4-4 4"/>', chevd: '<path d="m4 6 4 4 4-4"/>',
    eye: '<path d="M1.5 8S4 3 8 3s6.5 5 6.5 5S12 13 8 13 1.5 8 1.5 8z"/><circle cx="8" cy="8" r="2"/>',
    bolt: '<path d="M9 1.5 3 9h5l-1 5.5L13 7H8z"/>',
    sliders: '<path d="M2 4h7M12 4h2M2 12h2M7 12h7"/><circle cx="10.5" cy="4" r="1.5"/><circle cx="5.5" cy="12" r="1.5"/>',
    check: '<path d="m3.5 8.5 3 3 6-7"/>', ext: '<path d="M9 2h5v5M14 2 7.5 8.5M12 9.5V14H2V4h4.5"/>',
    link: '<path d="M6.5 9.5a3 3 0 0 0 4.2 0l2.3-2.3a3 3 0 0 0-4.2-4.2L7.6 4.2M9.5 6.5a3 3 0 0 0-4.2 0L3 8.8A3 3 0 0 0 7.2 13l1.2-1.2"/>',
    cursor: '<path d="m3.5 2.5 9 4.5-4 1.3-1.5 4.2z"/>',
    settings: '<path d="M2.5 4.5h6M11.5 4.5h2M2.5 11.5h2M7.5 11.5h6"/><circle cx="10" cy="4.5" r="1.5"/><circle cx="6" cy="11.5" r="1.5"/>',
    // значки переключателей (segm): выравнивание, ширина, устройства, виды модулей
    alLeft: '<path d="M2.5 3.5h11M2.5 6.5h7M2.5 9.5h11M2.5 12.5h7"/>', alCenter: '<path d="M2.5 3.5h11M4.5 6.5h7M2.5 9.5h11M4.5 12.5h7"/>',
    alRight: '<path d="M2.5 3.5h11M6.5 6.5h7M2.5 9.5h11M6.5 12.5h7"/>',
    vaTop: '<path d="M2.5 2.5h11"/><rect x="5" y="4.5" width="6" height="6" rx="1"/>', vaCenter: '<path d="M1.5 8h2.5M12 8h2.5"/><rect x="5" y="5" width="6" height="6" rx="1"/>',
    vaBottom: '<path d="M2.5 13.5h11"/><rect x="5" y="5.5" width="6" height="6" rx="1"/>',
    inherit: '<rect x="2.5" y="2.5" width="11" height="11" rx="2" stroke-dasharray="2 2"/>',
    wContainer: '<path d="M1.5 3v10M14.5 3v10"/><rect x="4" y="4.5" width="8" height="7" rx="1"/>', wNarrow: '<path d="M1.5 3v10M14.5 3v10"/><rect x="6" y="4.5" width="4" height="7" rx="1"/>',
    wFull: '<path d="M1.5 8h13M4 5.5 1.5 8 4 10.5M12 5.5l2.5 2.5-2.5 2.5"/>',
    devAll: '<rect x="1.5" y="3" width="9" height="7" rx="1"/><path d="M4 13h4"/><rect x="11.5" y="6" width="3" height="7" rx=".8"/>',
    devDesktop: '<rect x="1.5" y="2.5" width="13" height="8.5" rx="1"/><path d="M5.5 14h5M8 11v3"/>', devPhone: '<rect x="4.5" y="1.5" width="7" height="13" rx="1.5"/><path d="M7.3 12.5h1.4"/>',
    vGrid: '<rect x="2" y="2" width="5" height="5" rx="1"/><rect x="9" y="2" width="5" height="5" rx="1"/><rect x="2" y="9" width="5" height="5" rx="1"/><rect x="9" y="9" width="5" height="5" rx="1"/>',
    vList: '<rect x="2" y="2.5" width="4" height="4" rx="1"/><rect x="2" y="9.5" width="4" height="4" rx="1"/><path d="M8 4h6M8 11h6"/>',
    vRow: '<path d="M1.5 8h3.5M6.25 8h3.5M11 8h3.5"/>', vBurger: '<path d="M3 4.5h10M3 8h10M3 11.5h10"/>',
    vFullscreen: '<path d="M2.5 6V2.5H6M10 2.5h3.5V6M13.5 10v3.5H10M6 13.5H2.5V10"/>', vDropdown: '<rect x="2.5" y="2" width="11" height="4" rx="1"/><path d="M4.5 9h7M4.5 12h5"/>',
    vSelect: '<rect x="2" y="4.5" width="12" height="7" rx="1.5"/><path d="m9.5 7 1.5 1.5L12.5 7"/>',
    vSlider: '<rect x="3.5" y="3.5" width="9" height="9" rx="1"/><path d="M1.5 6v4M14.5 6v4"/>', vScroll: '<rect x="1.5" y="4" width="5" height="8" rx="1"/><rect x="8" y="4" width="5" height="8" rx="1"/><path d="M14.5 4v8"/>',
    arrSides: '<rect x="4" y="4" width="8" height="8" rx="1"/><path d="M2.5 6.5 1 8l1.5 1.5M13.5 6.5 15 8l-1.5 1.5"/>', arrBottom: '<rect x="3" y="2" width="10" height="7.5" rx="1"/><path d="M6 11.5 4.5 13 6 14.5M10 11.5l1.5 1.5-1.5 1.5"/>',
    indDots: '<rect x="2.5" y="2.5" width="11" height="8" rx="1"/><path d="M6 13.2h.01M8 13.2h.01M10 13.2h.01" stroke-width="2"/>',
    indThumbs: '<rect x="2.5" y="2" width="11" height="7.5" rx="1"/><rect x="2.5" y="11" width="3" height="2.5" rx=".5"/><rect x="6.5" y="11" width="3" height="2.5" rx=".5"/><rect x="10.5" y="11" width="3" height="2.5" rx=".5"/>',
    none: '<circle cx="8" cy="8" r="5.5"/><path d="m4.2 11.8 7.6-7.6"/>',
    imgFill: '<rect x="1.5" y="3.5" width="13" height="9" rx="1"/><path d="m4 10.5 2.5-2.5 2 2 1.5-1.5 2.5 2"/>', imgNatural: '<path d="M1.5 3v10M14.5 3v10"/><rect x="4.5" y="5" width="7" height="6" rx="1"/>',
    tabsH: '<rect x="1.5" y="5" width="13" height="9" rx="1"/><path d="M1.5 5V2.5h4.5V5M6 3h4v2"/>', tabsV: '<rect x="5.5" y="1.5" width="9" height="13" rx="1"/><path d="M1.5 2.5h3M1.5 6h3M1.5 9.5h3"/>',
    tabLine: '<path d="M2 6.5h5M9 6.5h5"/><path d="M2 10h5" stroke-width="2.2"/>', tabPills: '<rect x="1.5" y="4.5" width="7" height="6" rx="3"/><path d="M10.5 7.5h4"/>',
    iconTop: '<rect x="5.5" y="1.5" width="5" height="5" rx="1"/><path d="M3 9.5h10M4.5 12.5h7"/>', iconLeft: '<rect x="1.5" y="3" width="5" height="5" rx="1"/><path d="M8.5 4h6M8.5 7h4.5M1.5 11h13M1.5 13.5h10"/>',
    sun: '<circle cx="8" cy="8" r="3"/><path d="M8 1.5v1.5M8 13v1.5M1.5 8H3M13 8h1.5M3.4 3.4l1 1M11.6 11.6l1 1M3.4 12.6l1-1M11.6 4.4l1-1"/>',
    moon: '<path d="M13.5 9.5A5.5 5.5 0 0 1 6.5 2.5a5.5 5.5 0 1 0 7 7z"/>',
    auto: '<circle cx="8" cy="8" r="6"/><path d="M8 2v12a6 6 0 0 0 0-12z" fill="currentColor" stroke="none"/>', pencil: '<path d="M11 2.5 13.5 5 6 12.5l-3 .5.5-3z"/>',
  };
  function ico(name, size, extra) {
    size = size || 16;
    return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' + (extra || '') + '>' + ICO[name] + '</svg>';
  }
  // onclick-вызов App.fn(...) с безопасно экранированными аргументами (числа — как есть).
  function call(fn, args) {
    return 'App.' + fn + '(' + (args || []).map(function (a) { return typeof a === 'number' ? a : jsArg(a); }).join(',') + ')';
  }
  function ib(icon, label, onclick, opts) {
    opts = opts || {};
    return '<button type="button" class="ad-ib' + (opts.danger ? ' ad-ib--danger' : '') + '" aria-label="' + esc(label) + '" title="' + esc(label) + '"' +
      (opts.disabled ? ' disabled' : '') + ' onclick="event.stopPropagation();' + onclick + '">' + ico(icon, 14) + '</button>';
  }
  // options: [ключ, подпись, иконка?]. С иконкой кнопка показывает только значок,
  // подпись — во всплывающей подсказке и для экранного диктора (понятно на любом языке).
  function segm(options, active, onclickOf) {
    return '<div class="ad-segm" role="group">' + options.map(function (o) {
      var on = o[0] === active, icon = o[2] && ICO[o[2]];
      return '<button type="button" class="ad-segm__o' + (icon ? ' ad-segm__o--ico' : '') + (on ? ' is-on' : '') + '" aria-pressed="' + on + '"' +
        (icon ? ' title="' + escAttr(o[1]) + '" aria-label="' + escAttr(o[1]) + '"' : '') + ' onclick="' + onclickOf(o[0]) + '">' + (icon ? ico(o[2], 16) : esc(o[1])) + '</button>';
    }).join('') + '</div>';
  }
  function isSel(tree, kind, id) { var s = state.selected; return !!s && s.tree === tree && s.kind === kind && s.id === id; }
  function colW(c) { return c.width ? c.width + (c.unit || '%') : _t('авто'); }

  /* ============================================================
     Переводы модулей. Выбран язык не по умолчанию (переключатель вверху) →
     холст показывает перевод, инспектор — поля перевода. Хранение:
     obj.translations[код_в_нижнем_регистре][поле] — его же читает сервер.
     ============================================================ */
  // Переводимые поля: [поле, подпись, вид]. Их же использует ИИ-перевод (server-bridge.js).
  App.TRANSLATABLE = {
    title:  [['text', _t('Текст заголовка'), 'line']],
    text:   [['html', _t('Текст'), 'rich']],
    html:   [['code', _t('HTML-код'), 'code']],
    button: [['text', _t('Текст кнопки'), 'line']],
    form:   [['title', _t('Заголовок формы'), 'line']],
    image:  [['caption', _t('Подпись'), 'line'], ['alt', _t('Alt-текст'), 'line']],
    quote:  [['text', _t('Текст цитаты'), 'area'], ['author', _t('Автор'), 'line'], ['role', _t('Подпись'), 'line']],
    cards:  [['allLabel', _t('Кнопка «показать всё»'), 'line']],
    collection: [['readLabel', _t('Подпись «Читать»'), 'line'], ['moreLabel', _t('Кнопка «Показать ещё»'), 'line'], ['allLabel', _t('Кнопка «показать всё»'), 'line'], ['emptyText', _t('Текст, если записей нет'), 'line']],
    table:  [['data', _t('Данные таблицы'), 'code']],
    countdown: [['title', _t('Заголовок'), 'line'], ['doneText', _t('Текст после окончания'), 'line']],
  };
  // Переводимые поля элементов модулей-списков: [поле, подпись, вид].
  App.ITEM_TRANSLATABLE = {
    gallery:  [['caption', _t('Подпись фото'), 'line']],
    faq:      [['q', _t('Вопрос'), 'line'], ['a', _t('Ответ'), 'area']],
    features: [['title', _t('Заголовок пункта'), 'line'], ['text', _t('Текст пункта'), 'area']],
    cards:    [['title', _t('Заголовок карточки'), 'line'], ['text', _t('Текст карточки'), 'area'], ['btnText', _t('Кнопка карточки'), 'line']],
    pricing:  [['name', _t('Тариф'), 'line'], ['price', _t('Цена'), 'line'], ['period', _t('Период'), 'line'], ['features', _t('Возможности'), 'area'], ['btnText', _t('Кнопка тарифа'), 'line']],
    counters: [['label', _t('Подпись цифры'), 'line']],
    tabs:     [['title', _t('Название вкладки'), 'line']],
  };
  function defLangCode() { var d = state.langs.filter(function (l) { return l.isDefault; })[0] || state.langs[0]; return d ? d.code : ''; }
  // Код языка перевода (нижний регистр) или null, если выбран язык по умолчанию.
  function trLang() { return state.plang && state.plang !== defLangCode() ? String(state.plang).toLowerCase() : null; }
  function trGet(obj, field, lc) { var t = obj.translations && obj.translations[lc]; return t && t[field] != null ? t[field] : ''; }
  // Значение для превью на холсте: перевод, если он есть.
  function tv(obj, field) { var lc = trLang(); return (lc && trGet(obj, field, lc)) || obj[field]; }
  // Поля модуля, которые есть что переводить (пустой исходник не переводим).
  function trFields(m) {
    var list = (App.TRANSLATABLE[m.type] || []).map(function (f) { return { obj: m, itemId: '', field: f[0], label: f[1], kind: f[2] }; });
    (App.ITEM_TRANSLATABLE[m.type] || []).forEach(function (f) {
      (m.items || []).forEach(function (it, i) { list.push({ obj: it, itemId: it.id, field: f[0], label: f[1] + ' ' + (i + 1), kind: f[2] }); });
    });
    if (m.type === 'cards' && m.filter) (m.tags || []).forEach(function (tg, i) { list.push({ obj: tg, tagId: tg.id, field: 'name', label: _t('Ключевое слово ') + (i + 1), kind: 'line' }); });
    return list.filter(function (f) { return String(f.obj[f.field] || '').trim(); });
  }
  function trMissing(m, lc) { return trFields(m).filter(function (f) { return !String(trGet(f.obj, f.field, lc)).trim(); }).length; }

  App.setTr = function (tree, modId, itemId, field, value) {
    var m = getModule(tree, modId), lc = trLang(); if (!m || !lc) return;
    var o = itemId ? (m.items || []).concat(m.tags || []).filter(function (x) { return x.id === itemId; })[0] : m; if (!o) return;
    o.translations = o.translations || {};
    var t = o.translations[lc] = o.translations[lc] || {};
    if (String(value).trim()) t[field] = value; else delete t[field];
    var cnt = document.querySelector('[data-tr-count]');
    if (cnt) cnt.textContent = trCountText(m, lc);
  };
  function trCountText(m, lc) {
    var total = trFields(m).length, miss = trMissing(m, lc);
    return miss ? _t('не переведено: ') + miss + _t(' из ') + total : _t('всё переведено');
  }
  function renderTrPanel(t, m) {
    var lc = trLang(); if (!lc) return '';
    var fields = trFields(m);
    var html = _t('<section class="ad-tr" aria-label="Перевод"><div class="ad-tr__h">') + ico('langs', 14) + _t('<b>Перевод · ') + esc(state.plang) + '</b>' +
      (fields.length ? '<span data-tr-count>' + trCountText(m, lc) + '</span>' : '') + '</div>';
    if (!fields.length) return html + _t('<span class="ad-f__hint">Здесь нечего переводить: у модуля нет текста на ') + esc(defLangCode()) + '.</span></section>';
    html += fields.map(function (f) {
      var orig = f.kind === 'rich' ? plainText(f.obj[f.field]) : String(f.obj[f.field]);
      var val = trGet(f.obj, f.field, lc);
      var h = 'App.setTr(' + [t, m.id, f.itemId || f.tagId || '', f.field].map(jsArg).join(',') + ',this.value)';
      var input = f.kind === 'line'
        ? '<input class="ad-in" aria-label="' + esc(f.label) + _t(' — перевод" placeholder="Перевод" value="') + escAttr(val) + '" oninput="' + h + '">'
        : '<textarea class="ad-in ad-tr__ta' + (f.kind === 'code' ? ' ad-in--mono' : '') + '" rows="4" spellcheck="' + (f.kind === 'code' ? 'false' : 'true') + '" aria-label="' + esc(f.label) + _t(' — перевод" placeholder="Перевод" oninput="') + h + '">' + esc(val) + '</textarea>';
      return '<div class="ad-f"><span class="ad-f__l">' + esc(f.label) + '</span><div class="ad-tr__orig">' + esc(orig.length > 240 ? orig.slice(0, 240) + '…' : orig) + '</div>' + input + '</div>';
    }).join('');
    return html + _t('<span class="ad-f__hint">Пустое поле — на сайте будет текст на ') + esc(defLangCode()) + '.' + (m.type === 'text' ? _t(' В тексте можно использовать HTML-теги.') : '') + '</span></section>';
  }
  // Перевод страницы (название, адрес) и названия сайта — в параметрах страницы и разделе «Сайт».
  App.setPageTr = function (field, value) {
    var lc = trLang(); if (!lc) return;
    state.pageTr = state.pageTr || {};
    var t = state.pageTr[lc] = state.pageTr[lc] || {};
    if (String(value).trim()) t[field] = value; else delete t[field];
  };
  App.setSiteTitleTr = function (code, value) {
    state.siteTitleTr = state.siteTitleTr || {};
    if (String(value).trim()) state.siteTitleTr[code] = value; else delete state.siteTitleTr[code];
  };
  // После ИИ-перевода или смены языка — обновить холст и инспектор.
  App.refreshTranslations = function () { var t = curTree(); if (t) renderBlocks(t); App.renderInsp(); };

  /* ============================================================
     Модуль на холсте: подпись типа + превью содержимого
     ============================================================ */
  var SOCIAL_RU = { telegram: 'Telegram', vk: _t('ВКонтакте'), whatsapp: 'WhatsApp', youtube: 'YouTube', instagram: 'Instagram', facebook: 'Facebook', x: 'X', github: 'GitHub', email: 'Email', phone: _t('Телефон'), site: _t('Сайт') };
  var MODE_RU = { grid: _t('сетка'), scroll: _t('лента'), slider: _t('слайдер') };
  var FORM_FIELDS = { name: _t('Имя'), email: 'Email', phone: _t('Телефон'), message: _t('Сообщение') };
  var _parser = new DOMParser();
  // Текст из HTML без загрузки ресурсов (DOMParser не грузит картинки/скрипты).
  function plainText(html) { return (_parser.parseFromString(String(html || ''), 'text/html').body.textContent || '').replace(/\s+/g, ' ').trim(); }

  function modMeta(m) {
    if (m.type === 'title') return m.level || 'H2';
    if (m.type === 'gallery') return (MODE_RU[m.mode] || _t('сетка')) + ' · ' + (m.items || []).filter(function (i) { return i.src; }).length + _t(' фото') + (m.mode !== 'grid' && parseInt(m.autoplay, 10) ? _t(' · авто ') + parseInt(m.autoplay, 10) + _t(' с') : '');
    if (m.type === 'menu') return m.menuType === 'drop' ? _t('бургер') : _t('список');
    if (m.type === 'lang') return m.langMode === 'drop' ? _t('выпадающий') : _t('списком');
    if (m.type === 'form') return m.formType === 'embed' ? _t('встроенная') : _t('простая');
    if (m.type === 'features') return (m.cols || 3) + _t(' кол. · ') + (m.items || []).length;
    if (m.type === 'faq') return (m.items || []).length + _t(' вопр.');
    if (m.type === 'spacer') return (parseInt(m.height, 10) || 0) + ' px';
    if (m.type === 'cards') return (m.cols || 3) + _t(' кол. · ') + (m.items || []).length + (m.clickMode === 'card' ? _t(' · клик по карточке') : '') + (m.filter ? _t(' · фильтр') : '');
    if (m.type === 'pricing' || m.type === 'counters' || m.type === 'social') return String((m.items || []).length);
    if (m.type === 'tabs') return (m.orient === 'v' ? _t('вертикальные') : _t('горизонтальные')) + ' · ' + (m.items || []).length;
    if (m.type === 'collection') { var cc = App.collById && App.collById(m.collection); return cc ? cc.name : _t('коллекция не выбрана'); }
    if (App.PKG && App.PKG[m.type]) return App.PKG[m.type].meta(m);
    return '';
  }
  function muted(t) { return '<div class="ad-pv ad-pv--muted">' + esc(t) + '</div>'; }
  function modPreview(m) {
    var def = MODULES.filter(function (x) { return x.key === m.type; })[0];
    if (def && !App.modAvailable(def)) return '<div class="ad-pv__ph">' + esc(_t('Модуль не установлен:') + ' ' + def.label) + '</div>' + muted(_t('На сайте не выводится. Установите его в «Сайт и модули».'));
    switch (m.type) {
      case 'title': return '<div class="ad-pv ad-pv--t' + (parseInt(String(m.level || 'H2').slice(1), 10) || 2) + '">' + esc(tv(m, 'text') || _t('Без текста')) + '</div>';
      case 'text': { var t = plainText(tv(m, 'html')); return t ? '<div class="ad-pv ad-pv--text">' + esc(t) + '</div>' : muted(_t('Пустой текст')); }
      case 'image': return (m.src ? '<img class="ad-pv__img" src="' + escAttr(m.src) + '" alt="" loading="lazy">' : _t('<div class="ad-pv__ph">Нет изображения</div>')) + (m.caption ? muted(tv(m, 'caption')) : '');
      case 'gallery': {
        var items = (m.items || []).slice(0, 8);
        return items.length ? '<div class="ad-pv__thumbs">' + items.map(function (it) { return it.src ? '<img src="' + escAttr(it.src) + '" alt="" loading="lazy">' : '<div></div>'; }).join('') + '</div>' : muted(_t('Нет изображений'));
      }
      case 'video': return m.cover ? '<img class="ad-pv__img" src="' + escAttr(m.cover) + '" alt="" loading="lazy">' : muted(m.url || _t('Ссылка на видео не задана'));
      case 'button': return '<span class="ad-pv__btn">' + esc(tv(m, 'text') || _t('Кнопка')) + '</span>';
      case 'form':
        if (m.formType === 'embed') return muted(m.embedUrl || _t('Ссылка на форму не задана'));
        return '<div class="ad-pv ad-pv--t4">' + esc(tv(m, 'title') || _t('Форма')) + '</div>' +
          muted(Object.keys(FORM_FIELDS).filter(function (k) { return m.fields && m.fields[k]; }).map(function (k) { return FORM_FIELDS[k]; }).join(' · ') || _t('Поля не выбраны'));
      case 'divider': return '<hr class="ad-pv__hr" style="border-top-width:' + (parseInt(m.width, 10) || 2) + 'px">';
      case 'html': { var code = String(tv(m, 'code') || '').split('\n').slice(0, 3).join('\n'); return code.trim() ? '<div class="ad-pv ad-pv--code">' + esc(code) + '</div>' : muted(_t('Пустой HTML')); }
      case 'menu': return muted(m.pagesMode === 'selected' ? _t('Выбранные страницы: ') + Object.keys(m.selected || {}).filter(function (k) { return m.selected[k]; }).length : _t('Все страницы сайта · ') + state.pages.length);
      case 'sitename': return '<div class="ad-pv ad-pv--t4">' + esc(state.siteName || _t('Название сайта')) + '</div>';
      case 'lang': return muted(state.langs.map(function (l) { return l.code; }).join(' · '));
      case 'cards': {
        if (!(m.items || []).length) return muted(_t('Нет карточек'));
        var ftags = m.filter ? (m.tags || []).filter(function (tg) { return (tg.name || '').trim(); }) : [];
        return (ftags.length ? '<div class="ad-pv__social"><span>' + esc(tv(m, 'allLabel') || _t('Все')) + '</span>' + ftags.map(function (tg) { return '<span class="is-empty">' + esc(tv(tg, 'name')) + '</span>'; }).join('') + '</div>' : '') +
          '<div class="ad-pv__cards" style="grid-template-columns:repeat(' + Math.min(4, m.cols || 3) + ',minmax(0,1fr))">' + m.items.slice(0, 8).map(function (it) {
            var linked = it.link && it.link.linkType && it.link.linkType !== 'none';
            return '<div>' + (it.image ? '<img src="' + escAttr(it.image) + '" alt="" loading="lazy">' : '<i></i>') + '<span>' + esc(tv(it, 'title') || _t('Карточка')) + '</span>' +
              (linked ? '<em class="ad-pv__cardbtn">' + esc(m.clickMode === 'card' ? (tv(it, 'btnText') || _t('вся карточка — ссылка')) : (tv(it, 'btnText') || _t('Подробнее'))) + ' →</em>' : '') + '</div>';
          }).join('') + '</div>';
      }
      case 'quote': return '<div class="ad-pv__quote">' + esc(tv(m, 'text') || _t('Цитата')) + '</div>' + (m.author ? muted('— ' + tv(m, 'author')) : '');
      case 'map': return '<div class="ad-pv__ph">' + (/https:\/\//.test(m.url || '') ? _t('Карта · ') + (parseInt(m.height, 10) || 400) + ' px' : _t('Вставьте код карты')) + '</div>';
      case 'table': {
        var rows = String(tv(m, 'data') || '').split('\n').filter(function (l) { return l.trim(); }).slice(0, 4);
        return rows.length ? '<table class="ad-pv__table">' + rows.map(function (r, ri) { var tg = ri === 0 && m.header !== false ? 'th' : 'td'; return '<tr>' + r.split('|').map(function (c) { return '<' + tg + '>' + esc(c.trim()) + '</' + tg + '>'; }).join('') + '</tr>'; }).join('') + '</table>' : muted(_t('Пустая таблица'));
      }
      case 'pricing': return (m.items || []).length ? '<div class="ad-pv__cards" style="grid-template-columns:repeat(' + Math.min(4, m.items.length) + ',minmax(0,1fr))">' + m.items.map(function (it) {
          return '<div class="' + (it.highlight ? 'is-hl' : '') + '"><span>' + esc(tv(it, 'name') || _t('Тариф')) + '</span><b>' + esc(tv(it, 'price') || '') + '</b></div>'; }).join('') + '</div>' : muted(_t('Нет тарифов'));
      case 'counters': return (m.items || []).length ? '<div class="ad-pv__cards" style="grid-template-columns:repeat(' + Math.min(4, m.items.length) + ',minmax(0,1fr))">' + m.items.map(function (it) {
          return '<div class="ad-pv__num"><b>' + esc((it.value || '') + (it.suffix || '')) + '</b><span>' + esc(tv(it, 'label') || '') + '</span></div>'; }).join('') + '</div>' : muted(_t('Нет цифр'));
      case 'countdown': return '<div class="ad-pv ad-pv--t4">' + esc(tv(m, 'title') || _t('Таймер')) + '</div>' + muted(m.until ? _t('до ') + String(m.until).replace('T', ' ') : _t('Дата не задана'));
      case 'social': return (m.items || []).length ? '<div class="ad-pv__social">' + m.items.map(function (it) { return '<span' + (it.url ? '' : ' class="is-empty"') + '>' + esc(SOCIAL_RU[it.network] || it.network) + '</span>'; }).join('') + '</div>' : muted(_t('Нет ссылок'));
      case 'crumbs': return muted(_t('Главная / … / ') + (state.pageTitle || _t('Страница')));
      case 'collection': return App.collPreview ? App.collPreview(m) : '';
      case 'spacer': return '<div class="ad-pv__spacer" style="height:' + Math.min(64, Math.max(10, parseInt(m.height, 10) || 0)) + 'px"></div>';
      case 'faq': return (m.items || []).length ? '<div class="ad-pv__faq">' + m.items.slice(0, 4).map(function (it) { return '<div>' + esc(tv(it, 'q') || _t('Вопрос')) + '<span>+</span></div>'; }).join('') + '</div>' : muted(_t('Нет вопросов'));
      case 'features': return (m.items || []).length ? '<div class="ad-pv__feat" style="grid-template-columns:repeat(' + Math.min(4, m.cols || 3) + ',minmax(0,1fr))">' + m.items.slice(0, 8).map(function (it) {
          return '<div><b>' + (it.image ? '<img src="' + escAttr(it.image) + '" alt="">' : esc(it.icon || '•')) + '</b><span>' + esc(tv(it, 'title') || '') + '</span></div>'; }).join('') + '</div>' : muted(_t('Нет пунктов'));
      default:
        if (App.PKG && App.PKG[m.type]) return App.PKG[m.type].preview(m, { tv: tv, muted: muted });
        // блок модуля, которого нет на сайте (удалили или сайт перенесли без него): данные целы
        return MODULE_LABEL[m.type] ? '' : '<div class="ad-pv__ph">' + esc(_t('Модуль не установлен:') + ' ' + m.type) + '</div>';
    }
  }
  function trNote(m) {
    var lc = trLang(); if (!lc) return '';
    var miss = trMissing(m, lc);
    return miss ? '<div class="ad-mc__tr">' + ico('langs', 12) + _t('Нет перевода на ') + esc(state.plang) + (miss > 1 ? ' · ' + miss + _t(' поля') : '') + '</div>' : '';
  }
  function linkNote(m) {
    var l = m.link; if (!l || !l.linkType || l.linkType === 'none') return '';
    var target = l.linkType === 'inner' ? (l.page ? l.page + (l.anchor ? ' #' + l.anchor : '') : _t('страница не выбрана'))
      : l.linkType === 'file' ? (l.file ? fileLabel(l.file) : _t('файл не выбран')) : (l.url || _t('URL не задан'));
    return '<div class="ad-mc__link">' + ico('link', 12) + esc(target) + '</div>';
  }
  // «Вкладки» на холсте: переключатель вкладок и конструктор блоков открытой вкладки
  var TAB_OPEN = {};   // modId → id открытой в админке вкладки (не сохраняется)
  function tabsPreview(tree, m) {
    var items = m.items || [];
    if (!items.length) return muted(_t('Нет вкладок'));
    var cur = items.filter(function (it) { return it.id === TAB_OPEN[m.id]; })[0] || items[0];
    var tn = nestedName(m.id, cur.id);
    return '<div class="ad-tabs' + (m.orient === 'v' ? ' ad-tabs--v' : '') + '" data-nested>' +
      '<div class="ad-tabs__list" role="tablist">' + items.map(function (it) {
        var on = it === cur, n = nestedCount(it.blocks);
        return '<button type="button" role="tab" aria-selected="' + on + '" class="ad-tabs__tab' + (on ? ' is-on' : '') + '" onclick="' + call('tabsOpen', [tree, m.id, it.id]) + '">' +
          esc(tv(it, 'title') || _t('Вкладка')) + (n ? '<small>' + n + '</small>' : '') + '</button>';
      }).join('') + '<button type="button" class="ad-tabs__add" title="' + escAttr(_t('Добавить вкладку')) + '" aria-label="' + escAttr(_t('Добавить вкладку')) + '" onclick="' + call('tabsAdd', [tree, m.id]) + '">' + ico('plus', 13) + '</button></div>' +
      '<div class="ad-tabs__body"><div data-blocks="' + tn + '" class="ad-tabs__blocks">' + state.trees[tn].map(function (b, i) { return renderBlockCard(tn, b, i); }).join('') + '</div>' +
      addRowHTML(tn) + '</div></div>';
  }
  App.tabsOpen = function (tree, modId, tabId) { TAB_OPEN[modId] = tabId; App.renderModule(tree, modId); };
  App.tabsAdd = function (tree, modId) {
    var m = getModule(tree, modId); if (!m) return;
    var it = LIST_ITEM.tabs(); it.title = _t('Вкладка ') + ((m.items || []).length + 1);
    m.items = m.items || []; m.items.push(it);
    TAB_OPEN[modId] = it.id;
    App.renderModule(tree, modId);
  };

  function modCardHTML(tree, m) {
    if (m.type === 'tabs') registerTabs(tree, m);
    var loc = locateModule(tree, m.id);
    var first = !loc || loc.index === 0, last = !loc || loc.index === loc.container.length - 1;
    var label = MODULE_LABEL[m.type] || m.type, meta = modMeta(m);
    return '<div class="ad-mc' + (isSel(tree, 'mod', m.id) ? ' is-sel' : '') + '" data-card="' + tree + ':' + m.id + '" draggable="true" tabindex="0" role="button" aria-label="' + esc(label) + '" ' +
      'onclick="var n=event.target.closest(\'[data-nested]\');if(event.target.isConnected&&(!n||!this.contains(n)))' + call('select', [tree, 'mod', m.id]) + '" onkeydown="if(event.key===\'Enter\'&&event.target===this)this.click()">' +
      '<div class="ad-mc__h">' + moduleIconHTML(m.type, 13) + '<span>' + esc(label) + (meta ? ' · ' + esc(meta) : '') + '</span>' +
      '<div class="ad-mc__tools">' +
      ib('up', _t('Выше'), call('moveModule', [tree, m.id, -1]), { disabled: first }) +
      ib('down', _t('Ниже'), call('moveModule', [tree, m.id, 1]), { disabled: last }) +
      ib('copy', _t('Дублировать'), call('dupModule', [tree, m.id])) +
      ib('del', _t('Удалить модуль'), call('delModule', [tree, m.id]), { danger: true }) +
      '</div></div>' + (m.type === 'tabs' ? tabsPreview(tree, m) : modPreview(m)) + linkNote(m) + trNote(m) + '</div>';
  }

  /* ============================================================
     Блок → колонки → модули
     ============================================================ */
  function blockClassChip(tree, b) {
    return b.cssClass
      ? '<span class="ad-blk__cls" data-cls>.' + esc(b.cssClass) + '</span>'
      : '<button type="button" class="ad-blk__cls ad-blk__cls--add" data-cls onclick="event.stopPropagation();' + call('editBlockClass', [tree, b.id]) + _t('">+ класс</button>');
  }
  App.editBlockClass = function (tree, blockId) {
    App.select(tree, 'block', blockId);
    var inp = document.getElementById('insp-blk-class'); if (inp) inp.focus();
  };
  // Кнопка «+ Модуль» с палитрой. Обёртка data-dd — клик внутри не закрывает поповер.
  function addModButton(tree, blockId, colId) {
    var pid = 'addmod:' + tree + ':' + blockId + ':' + (colId || '-');
    var open = state.openPopover === pid;
    var html = '<div data-dd style="position:relative">' +
      '<button type="button" class="ad-b ad-b--sm' + (open ? ' ad-b--accent' : '') + '" aria-expanded="' + open + '" onclick="' + call('togglePopover', [pid]) + '">' + ico('plus', 13) + _t('Модуль</button>');
    if (open) {
      html += _t('<div class="ad-pal" role="dialog" aria-label="Добавить модуль"><div class="ad-pal__h">Добавить модуль ') + (colId ? _t('в колонку') : _t('в блок')) + '</div><div class="ad-pal__g">' +
        MODULES.filter(function (m) { return App.modAvailable(m) && state.moduleSw[m.key] !== false && !(m.key === 'tabs' && NESTED[tree]); }).map(function (m) {   // вкладки во вкладках — нет
          return '<button type="button" class="ad-pal__i" onclick="' + call('addMod', [tree, blockId, colId || '', m.key]) + '"><span class="ad-pal__ic">' + moduleIconHTML(m.key, 14) + '</span>' + esc(m.label) + '</button>';
        }).join('') + '</div></div>';
    }
    return html + '</div>';
  }
  App.splitColumns = function (tree, blockId) {
    var b = findBlock(tree, blockId); if (!b) return;
    var n = b.cols.length ? 1 : 2;   // пустой блок сразу делим на две колонки
    for (var i = 0; i < n && b.cols.length < 4; i++) b.cols.push({ id: uid('c'), mods: [], width: '', unit: '%' });
    App.renderBlock(tree, blockId); refreshBlockInsp(tree, blockId);
  };

  var WIDTH_RU = { full: _t('На всю ширину'), narrow: _t('Узко') };
  // Метки настроек блока в заголовке карточки: фон, ширина, отступ, якорь, видимость.
  function blockBadges(b) {
    var st = b.style || {}, h = '';
    var bg = st.bg && st.bg.type && st.bg.type !== 'none' ? st.bg : null;
    if (bg) h += _t('<span class="ad-blk__sw" data-blk-swatch title="Фон" style="') + escAttr(bgCss(normBg(bg))) + '"></span>';
    if (bg && bg.type === 'image' && bg.parallax) h += _t('<span class="ad-blk__badge">Параллакс</span>');
    if (WIDTH_RU[st.width]) h += '<span class="ad-blk__badge">' + (st.width === 'full' && st.contain ? _t('Фон на всю ширину') : WIDTH_RU[st.width]) + '</span>';
    var pv = padValues(st);
    if (pv) h += '<span class="ad-blk__badge" title="' + escAttr(_t('Отступы сверху и снизу')) + '">↕ ' + pv[0] + ' / ' + pv[1] + '</span>';
    if (st.anchor) h += '<span class="ad-blk__badge ad-blk__badge--mono">#' + esc(st.anchor) + '</span>';
    if (st.hide) h += _t('<span class="ad-blk__badge" title="Видимость">') + ico('eyeoff', 12) + (st.hide === 'mobile' ? _t('Только ПК') : _t('Только телефон')) + '</span>';
    return h;
  }

  function renderBlockCard(tree, b, i) {
    var n = state.trees[tree].length;
    var html = '<section class="ad-blk' + (isSel(tree, 'block', b.id) ? ' is-sel' : '') + '" data-block="' + tree + ':' + b.id + _t('" aria-label="Блок ') + (i + 1) + '">' +
      '<div class="ad-blk__head" onclick="' + call('select', [tree, 'block', b.id]) + '">' +
      _t('<span class="ad-blk__grip" draggable="true" title="Перетащите, чтобы переместить блок">') + ico('grip', 14) + _t('</span><span class="ad-blk__name">Блок ') + (i + 1) + '</span>' + blockClassChip(tree, b) + blockBadges(b) +
      '<div class="ad-blk__tools">' +
      ib('up', _t('Блок выше'), call('moveBlock', [tree, b.id, -1]), { disabled: i === 0 }) +
      ib('down', _t('Блок ниже'), call('moveBlock', [tree, b.id, 1]), { disabled: i === n - 1 }) +
      ib('copy', _t('Дублировать блок'), call('dupBlock', [tree, b.id])) +
      ib('del', _t('Удалить блок'), call('delBlock', [tree, b.id]), { danger: true }) +
      '</div></div><div class="ad-blk__body">';
    if (b.cols.length) {
      html += '<div class="ad-cols2" style="grid-template-columns:repeat(' + b.cols.length + ',minmax(0,1fr))">' + b.cols.map(function (c) {
        var al = c.align || (b.style && b.style.align) || '';
        return '<div class="ad-col2"' + (al && al !== 'left' ? ' data-align="' + al + '"' : '') + '><div class="ad-col2__h">' + ico('cols', 12) + _t('<span class="ad-eyebrow2">Колонка</span>') +
          (c.align ? '<span class="ad-col2__w">' + ({ left: _t('лево'), center: _t('центр'), right: _t('право') })[c.align] + '</span>' : '') + '<span class="ad-col2__w">' + esc(colW(c)) + '</span></div>' +
          '<div class="ad-mods" data-drop="' + tree + ':' + b.id + ':' + c.id + '">' + c.mods.map(function (m) { return modCardHTML(tree, m); }).join('') +
          (c.mods.length ? '' : _t('<div class="ad-empty2">Пустая колонка</div>')) + '</div>' +
          '<div class="ad-col2__foot">' + addModButton(tree, b.id, c.id) + '</div></div>';
      }).join('') + '</div>';
    }
    var bal = b.style && b.style.align;
    html += '<div class="ad-mods" data-drop="' + tree + ':' + b.id + ':-"' + (bal && bal !== 'left' ? ' data-align="' + bal + '"' : '') + '>' + b.mods.map(function (m) { return modCardHTML(tree, m); }).join('') +
      (!b.cols.length && !b.mods.length ? _t('<div class="ad-empty2">Пустой блок — добавьте модуль или разбейте его на колонки</div>') : '') + '</div>';
    html += '</div><div class="ad-blk__foot">' + addModButton(tree, b.id, '') +
      '<button type="button" class="ad-b ad-b--sm" onclick="' + call('splitColumns', [tree, b.id]) + '"' + (b.cols.length >= 4 ? ' disabled' : '') + '>' + ico('cols', 13) + (b.cols.length ? _t('Колонка') : _t('Колонки')) + '</button>' +
      '</div></section>';
    return html;
  }

  /* ============================================================
     Сайдбар: разделы, страницы, структура, статус сохранения
     ============================================================ */
  // Основные разделы — всегда на виду; редкие и глобальные — в раскрывающейся группе «Настройки сайта»
  var NAV = [['page', 'pages', _t('Страницы')], ['hf', 'hf', _t('Шапка и подвал')], ['media', 'media', _t('Медиа')], ['publish', 'cloud', _t('Публикация')]];
  var NAV_SETTINGS_BASE = [['theme', 'theme', _t('Тема')], ['langs', 'langs', _t('Языки')], ['site', 'site', _t('Сайт и модули')], ['history', 'history', _t('История')]];
  // веб-версия: обновление движка живёт здесь (страницы «Проекты» на сервере нет)
  function navSettings() { return App.web ? NAV_SETTINGS_BASE.concat([['engine', 'cloud', 'UCMS']]) : NAV_SETTINGS_BASE; }
  var NAV_GROUP_KEY = 'ucms-nav-settings';
  function navGroupOpen() {
    if (navSettings().some(function (n) { return n[0] === state.view; })) return true;   // открытый раздел группы — группа раскрыта
    try { return localStorage.getItem(NAV_GROUP_KEY) === '1'; } catch (e) { return false; }
  }
  App.toggleNavGroup = function () {
    var open = !navGroupOpen();
    if (!open && navSettings().some(function (n) { return n[0] === state.view; })) return;   // не прячем открытый раздел
    try { localStorage.setItem(NAV_GROUP_KEY, open ? '1' : '0'); } catch (e) { /* без запоминания */ }
    App.renderSide();
  };
  function navItem(n, sub) {
    return '<button type="button" class="ad-nav__i' + (sub ? ' ad-nav__i--sub' : '') + (state.view === n[0] ? ' is-on' : '') + '" title="' + n[2] + '" onclick="' + call('setView', [n[0]]) + '">' + ico(n[1]) + '<span>' + n[2] + '</span></button>';
  }
  function renderSide() {
    var open = navGroupOpen(), inGroup = navSettings().some(function (n) { return n[0] === state.view; });
    var html = '<aside class="ad-side" data-side><div class="ad-brand"><div class="ad-brand__mark">U</div><div><div class="ad-brand__name">UCMS</div>' +
      '<div class="ad-brand__site" data-brand-site>' + esc(state.siteName || _t('Сайт без названия')) + '</div>' +
      (App.remote ? '<div class="ad-brand__srv" title="' + escAttr(_t('Сайт на сервере UCMS') + ': ' + App.remote.url) + '">' + ico('cloud', 11) + esc(App.remote.url.replace(/^https?:\/\//, '')) + '</div>' : '') + '</div></div>' +
      '<div class="ad-tools">' + langButton() + themeButton() + '</div>' +
      _t('<div class="ad-side__scroll"><nav class="ad-nav" aria-label="Разделы">') + NAV.filter(function (n) { return App.viewAllowed(n[0]); }).map(function (n) { return navItem(n); }).join('') +
      '<button type="button" class="ad-nav__i ad-nav__group' + (inGroup && !open ? ' is-on' : '') + '" aria-expanded="' + open + '" onclick="App.toggleNavGroup()">' +
        ico('settings') + '<span>' + _t('Настройки сайта') + '</span>' + ico(open ? 'chevd' : 'chev', 12, ' class="ad-nav__chev"') + '</button>' +
      (open ? '<div class="ad-nav__sub">' + navSettings().filter(function (n) { return App.viewAllowed(n[0]); }).map(function (n) { return navItem(n, true); }).join('') + '</div>' : '') +
      (App.web
        ? '<button type="button" class="ad-nav__i ad-nav__i--projects" onclick="App.logout()" title="' + escAttr(_t('Выйти') + (state.user ? ' (' + state.user + ')' : '')) + '">' + ico('logout') + '<span>' + _t('Выйти') + '</span></button>'
        : '<a class="ad-nav__i ad-nav__i--projects" href="/admin/projects.html" target="ucms-projects" title="' + escAttr(_t('Все проекты')) + '">' + ico('folders') + '<span>' + _t('Все проекты') + '</span></a>') +
      // новая версия движка: локально — страница «Проекты», в веб-версии — раздел «Движок»
      (state.updateAvailable ? (App.web
        ? '<button type="button" class="ad-nav__i ad-nav__upd" onclick="App.setView(\'engine\')" title="' + escAttr(_t('Доступна новая версия UCMS') + ' ' + state.updateAvailable) + '">' + ico('cloud') + '<span>' + _t('Обновление') + ' ' + esc(state.updateAvailable) + '</span></button>'
        : '<a class="ad-nav__i ad-nav__upd" href="/admin/projects.html" target="ucms-projects" title="' + escAttr(_t('Доступна новая версия UCMS') + ' ' + state.updateAvailable) + '">' + ico('cloud') + '<span>' + _t('Обновление') + ' ' + esc(state.updateAvailable) + '</span></a>') : '') + '</nav>';
    if (state.view === 'page') {
      html += _t('<div class="ad-side__h"><span class="ad-eyebrow2">Страницы сайта</span>') + ib('plus', _t('Добавить страницу'), 'App.addPage()') + '</div><div class="ad-list">' +
        state.pages.map(function (p, i) {
          if (p.coll) return '';   // записи — в разделе «Коллекции» ниже
          return '<button type="button" class="ad-list__i' + (i === state.sel ? ' is-on' : '') + '" style="padding-left:' + (p.child ? 26 : 10) + 'px" onclick="' + call('selectPage', [i]) + '">' +
            '<span>' + esc(p.title) + '</span><small>' + esc(String(p.slug || '').replace(/^\//, '').replace(/\.html$/, '')) + '</small></button>';
        }).join('') + '</div>' + (App.renderCollSide ? App.renderCollSide() : '');
    }
    return html + renderOutline() + '</div>' + renderStatus() + '</aside>';
  }
  /* ---- тема админки: Авто → Светлая → Тёмная ---- */
  var THEME_KEY = 'ucms-admin-theme';
  var THEME_NEXT = { auto: 'light', light: 'dark', dark: 'auto' };
  var THEME_LABEL = { auto: _t('Тема: как в системе'), light: _t('Тема: светлая'), dark: _t('Тема: тёмная') };
  var THEME_SHORT = { auto: _t('Авто'), light: _t('Светлая'), dark: _t('Тёмная') };
  var THEME_ICO = { auto: 'auto', light: 'sun', dark: 'moon' };
  var darkMq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  function themeMode() { try { return localStorage.getItem(THEME_KEY) || 'auto'; } catch (e) { return 'auto'; } }
  function applyTheme(mode) {
    var dark = mode === 'dark' || (mode === 'auto' && !!darkMq && darkMq.matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    setupColoris();
  }
  // Цветовой пикер Coloris: один на всю админку, поля [data-coloris] находит сам.
  var COLOR_SWATCHES = ['#1b1c1f', '#ffffff', '#f4f4f1', '#2e5bdb', '#1f8a5b', '#c99a2e', '#c8672b', '#b4312a', '#5b3fc8'];
  function setupColoris() {
    if (!window.Coloris) return;
    window.Coloris({
      el: '[data-coloris]', wrap: false, alpha: false, format: 'hex', swatches: COLOR_SWATCHES,
      themeMode: document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light',
      closeButton: true, closeLabel: _t('Готово'), a11y: { open: _t('Выбрать цвет'), close: _t('Закрыть'), marker: _t('Насыщенность и яркость'), hueSlider: _t('Тон'), input: _t('Код цвета'), instruction: _t('Стрелки меняют насыщенность и яркость') },
    });
  }
  setupColoris();
  // Системная тема сменилась, а выбрано «Авто» — следуем за ней (слушатель живёт всё время работы админки).
  if (darkMq && darkMq.addEventListener) darkMq.addEventListener('change', function () { if (themeMode() === 'auto') applyTheme('auto'); });
  /* ---- язык интерфейса админки: выпадающее меню (i18n/index.js), смена — с перезагрузкой ---- */
  function langButton() { return window.adminLangMenu ? window.adminLangMenu('ad-tools__lang', true) : ''; }
  // перед перезагрузкой на другом языке — сохраняем несохранённое
  if (window.UCMS_LANG) window.UCMS_LANG.beforeReload = function () {
    return state.dirty && App.persistNow ? App.persistNow() : null;
  };
  function themeButton() {
    var m = themeMode();
    return '<button type="button" class="ad-tools__btn ad-brand__theme" data-theme-btn aria-label="' + THEME_LABEL[m] + _t('. Переключить" title="') + THEME_LABEL[m] + '" onclick="App.cycleTheme()">' + ico(THEME_ICO[m], 14) + '<span>' + THEME_SHORT[m] + '</span></button>';
  }
  App.cycleTheme = function () {
    var next = THEME_NEXT[themeMode()];
    try { localStorage.setItem(THEME_KEY, next); } catch (e) {}
    applyTheme(next);
    var btn = document.querySelector('[data-theme-btn]'); if (btn) btn.outerHTML = themeButton();
  };

  // Дерево структуры. Строки блоков и модулей перетаскиваются; data-o описывает
  // место строки в дереве для расчёта вставки: kind:blockId:colId|-:index.
  function renderOutline() {
    var t = curTree(); if (!t) return '<div data-outline></div>';
    var sel = state.selected || {};
    function row(depth, icon, label, kind, id, o, extra, markable) {
      var on = markable && sel.tree === t && sel.kind === kind && sel.id === id;
      var draggable = o.split(':')[0] !== 'col';
      return '<button type="button" class="ad-list__i ad-list__i--tree' + (on ? ' is-on' : '') + '" style="padding-left:' + (10 + depth * 14) + 'px"' +
        ' data-o="' + o + '"' + (draggable ? ' data-o-id="' + id + '" draggable="true"' : '') + ' onclick="' + call('reveal', [t, kind, id]) + '">' +
        icon + '<span>' + label + '</span>' + (extra || '') + '</button>';
    }
    var rows = '';
    state.trees[t].forEach(function (b, i) {
      rows += row(0, ico('grip', 12), _t('Блок ') + (i + 1), 'block', b.id, 'block:' + b.id + ':-:' + i, b.cssClass ? '<code>.' + esc(b.cssClass) + '</code>' : '', true);
      b.cols.forEach(function (c) {
        rows += row(1, ico('cols', 12), _t('Колонка · ') + esc(colW(c)), 'block', b.id, 'col:' + b.id + ':' + c.id + ':0', '', false);
        c.mods.forEach(function (m, mi) { rows += row(2, moduleIconHTML(m.type, 12), esc(MODULE_LABEL[m.type] || m.type), 'mod', m.id, 'mod:' + b.id + ':' + c.id + ':' + mi, '', true); });
      });
      b.mods.forEach(function (m, mi) { rows += row(1, moduleIconHTML(m.type, 12), esc(MODULE_LABEL[m.type] || m.type), 'mod', m.id, 'mod:' + b.id + ':-:' + mi, '', true); });
    });
    return '<div data-outline data-outline-tree="' + t + _t('"><div class="ad-side__h"><span class="ad-eyebrow2">Структура</span></div><div class="ad-list">') +
      (rows || _t('<div class="ad-pv ad-pv--muted" style="padding:2px 10px">Пока нет блоков</div>')) + '</div></div>';
  }
  function renderStatus() {
    return '<div class="ad-status' + (state.dirty ? ' is-dirty' : '') + '" data-status><span class="ad-dot"></span><span data-status-text>' + esc(state.saveText || _t('Изменений нет')) + '</span>' +
      _t('<button type="button" class="ad-b ad-b--sm ad-b--line" onclick="App.save()" title="Сохранить (Ctrl+S)">Сохранить</button></div>');
  }
  // Статус сохранения обновляет server-bridge.js; без перерисовки сайдбара.
  App.setStatus = function (text, dirty) {
    state.saveText = text; state.dirty = !!dirty;
    var el = document.querySelector('[data-status]');
    if (!el) return;
    el.classList.toggle('is-dirty', !!dirty);
    el.querySelector('[data-status-text]').textContent = text;
  };
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.code === 'KeyS') { e.preventDefault(); if (App.save) App.save(); }
    if (e.key === 'Escape' && state.openPopover) App.closeAllPopovers();
  });

  /* ============================================================
     Верхняя панель
     ============================================================ */
  var VIEW_TITLE = { theme: _t('Тема'), langs: _t('Языки'), site: _t('Сайт и модули'), media: _t('Медиа'), history: _t('История'), publish: _t('Публикация'), engine: 'UCMS' };
  function renderTop() {
    var crumbs = state.view === 'page' ? [_t('Страницы'), state.pageTitle || _t('Без названия')]
      : state.view === 'hf' ? [_t('Шапка и подвал'), state.hf === 'header' ? _t('Шапка') : _t('Подвал')]
      : [_t('Настройки'), VIEW_TITLE[state.view]];
    var html = '<header class="ad-top" data-top><div class="ad-crumbs"><span>' + esc(crumbs[0]) + '</span>' + ico('chev', 12, ' style="color:var(--faint);flex:none"') + '<b>' + esc(crumbs[1]) + '</b></div><div class="ad-top__r">';
    if (state.langs.length > 1 && curTree()) {
      var def = (state.langs.filter(function (l) { return l.isDefault; })[0] || state.langs[0]).code;
      html += '<div style="min-width:' + (state.langs.length * 52) + 'px">' + segm(state.langs.map(function (l) { return [l.code, l.code]; }), state.plang, function (c) { return call('setPlang', [c]); }) + '</div>';
      if (state.view === 'page' && state.plang !== def && !App.hosted) html += '<button type="button" class="ad-b ad-b--line" onclick="' + call('aiTranslatePage', [state.plang]) + '">' + ico('langs', 14) + _t('<span>Перевести на ') + esc(state.plang) + '</span></button>';
    }
    html += (App.undoButtons ? App.undoButtons() : '') + '<button type="button" class="ad-b" onclick="App.openPreview()">' + ico('eye', 15) + _t('<span>Предпросмотр</span></button>') +
      (state.publish && state.publish.config && state.publish.config.host
        ? '<button type="button" class="ad-b ad-b--line" data-pub-top onclick="App.startPublish()"' + (state.publish.job && state.publish.job.running ? ' disabled' : '') + '>' + ico('cloud', 15) + _t('<span>Опубликовать</span></button>') : '') +
      (App.hosted   // сайт на сервере UCMS: сборка сразу видна посетителям — это и есть публикация
        ? (App.can('publish') ? '<button type="button" class="ad-b ad-b--primary" onclick="App.generate()">' + ico('cloud', 15) + '<span>' + _t('Опубликовать') + '</span></button>' : '') + '</div></header>'
        : '<button type="button" class="ad-b ad-b--primary" onclick="App.generate()">' + ico('bolt', 14) + _t('<span>Сгенерировать</span></button></div></header>'));
    return html;
  }

  /* ============================================================
     Холст (страница / шапка-подвал) и разделы настроек
     ============================================================ */
  function hfLabel() {
    if (state.headerVisible && state.footerVisible) return _t('Шапка · Подвал');
    if (state.headerVisible) return _t('Только шапка');
    if (state.footerVisible) return _t('Только подвал');
    return _t('Без шапки и подвала');
  }
  var BG_RU = { none: _t('нет'), color: _t('цвет'), gradient: _t('градиент'), image: _t('фото'), pattern: _t('узор') };
  // Папка записи коллекции в адресе: «blog/»
  function entryDir() { var c = state.pageEntry && App.collById && App.collById(state.pageEntry.collection); return c ? (c.slug || '') + '/' : ''; }
  function renderPageHead() {
    // На узком экране списка страниц в сайдбаре нет — переключатель прямо над холстом.
    var picker = _t('<select class="ad-in ad-ph__pages" aria-label="Страница" onchange="App.selectPage(+this.value)">') + state.pages.map(function (p, i) {
      return '<option value="' + i + '"' + (i === state.sel ? ' selected' : '') + '>' + (p.child || p.coll ? '— ' : '') + esc(p.title) + '</option>';
    }).join('') + '</select>';
    return '<div class="ad-ph" data-pagehead>' + picker + '<div class="ad-ph__t">' + esc(state.pageTitle || _t('Без названия')) + '</div><div class="ad-ph__chips">' +
      '<span class="ad-chip ad-chip--mono">/' + esc(entryDir()) + esc(state.pageSlug || '') + '.html</span>' +
      (state.pageEntry && App.entryChips ? App.entryChips()
        : '<span class="ad-chip"><span class="ad-dot' + (state.inMenu ? '' : ' ad-dot--off') + '"></span>' + (state.inMenu ? _t('В меню') : _t('Скрыта из меню')) + '</span>') +
      '<span class="ad-chip">' + hfLabel() + _t('</span><span class="ad-chip">Фон: ') + (BG_RU[state.pageBg.type] || _t('нет')) + (state.pageBg.type === 'image' && state.pageBg.parallax ? _t(' · параллакс') : '') + '</span>' +
      '<button type="button" class="ad-chip ad-chip--link" onclick="App.openDrawer(\'page\')">' + ico('sliders', 13) + (state.pageEntry ? _t('Параметры записи') : _t('Параметры страницы')) + '</button></div></div>';
  }
  function renderView() {
    var t = curTree();
    var html = '<div class="ad-main ad-view" data-view>';
    if (t) {
      html += '<div class="ad-main__inner">';
      if (state.view === 'page') html += renderPageHead();
      else html += '<div class="ad-ph"><div class="ad-ph__t">' + (t === 'header' ? _t('Шапка сайта') : _t('Подвал сайта')) + '</div>' +
        '<div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap"><div style="width:220px">' + segm([['header', _t('Шапка')], ['footer', _t('Подвал')]], state.hf, function (k) { return call('setHf', [k]); }) + '</div>' +
        _t('<span class="ad-f__hint">Общие для всех страниц. Скрыть на отдельной странице — в её параметрах.</span></div>') +
        (t === 'header' ? _t('<div class="ad-f" style="max-width:420px"><span class="ad-f__l">Шапка при прокрутке</span>') +
          segm([['', _t('Прокручивается со страницей')], ['sticky', _t('Закреплена')]], state.headerSticky ? 'sticky' : '', function (k) { return call('setHeaderSticky', [k]); }) + '</div>' : '') + '</div>';
      html += '<div data-blocks="' + t + '" style="display:flex;flex-direction:column;gap:16px">' +
        state.trees[t].map(function (b, i) { return renderBlockCard(t, b, i); }).join('') + '</div>' +
        addRowHTML(t) + '</div>';
    } else {
      html += '<div class="ad-main__inner ad-main__inner--wide">' + (state.view === 'theme' ? renderThemeView() : state.view === 'langs' ? renderLangsView() : state.view === 'publish' ? renderPublishView() : state.view === 'media' ? App.renderMediaView() : state.view === 'history' ? App.renderHistoryView() : state.view === 'engine' && App.renderEngineView ? App.renderEngineView() : renderSiteView()) + '</div>';
    }
    return html + '</div>';
  }
  function secHead(title, text) { return '<div class="ad-sec-h"><h1>' + esc(title) + '</h1><p>' + text + '</p></div>'; }

  App.setSiteName = function (v) {
    state.siteName = v;
    var el = document.querySelector('[data-brand-site]'); if (el) el.textContent = v || _t('Сайт без названия');
  };
  /* ---- публикация на хостинг (FTP/FTPS). Запросы к серверу — в server-bridge.js ---- */
  App.setPub = function (field, value) {
    var c = state.publish.form; c[field] = value;
    if (field === 'protocol' || field === 'allowSelfSigned' || field === 'projectSync' || field === 'encrypt') App.renderView();
  };
  function pubJobHTML(job) {
    if (!job || (!job.running && !job.phase)) return _t('<div class="ad-f__hint">Сайт ещё не публиковался из этой сессии.</div>');
    if (job.running) {
      var pct = job.total ? Math.round(job.done / job.total * 100) : 0;
      var what = job.phase === 'connect' ? _t('Подключение к ') + job.current : job.phase === 'project' ? _t('Сохраняю проект на сервере') : (job.phase === 'delete' ? _t('Удаляю ') : _t('Загружаю ')) + job.current;
      return '<div class="ad-pub__bar"><span style="width:' + pct + '%"></span></div><div class="ad-f__row"><span class="ad-f__hint ad-pub__cur">' + esc(what) + '</span><span class="ad-bg__val">' + job.done + ' / ' + job.total + '</span></div>';
    }
    if (job.phase === 'error' && job.code === 'REMOTE_NEWER') return '<div class="ad-pub__msg is-err">' + ico('close', 14) + '<span>' + _t('Не опубликовано: на сервере более новая версия с другого компьютера. Скачайте правки или опубликуйте поверх (плашка вверху).') + '</span></div>';
    if (job.phase === 'error') return '<div class="ad-pub__msg is-err">' + ico('close', 14) + _t('<span>Ошибка: ') + esc(job.error) + '</span></div>';
    var r = job.result || {};
    var t = new Date(job.finishedAt || Date.now());
    return '<div class="ad-pub__msg is-ok">' + ico('check', 14) + _t('<span>Опубликовано в ') + String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0') +
      _t(': загружено ') + r.uploaded + _t(', без изменений ') + r.skipped + (r.deleted ? _t(', удалено ') + r.deleted : '') + '.</span></div>' +
      (r.projectError ? '<div class="ad-pub__msg is-err">' + ico('close', 14) + '<span>' + _t('Проект на сервер не сохранён:') + ' ' + esc(r.projectError.message) + '</span></div>' : '');
  }
  App.renderPubJob = function () { var el = document.querySelector('[data-pub-job]'); if (el) el.innerHTML = pubJobHTML(state.publish.job); App.renderTop(); };
  // Подключённый сайт: копия на этом компьютере (с историей) — на случай отказа хостинга
  function remoteCopyPanel() {
    var c = App.remote.copy, busy = state.remoteCopyBusy;
    var when = c ? new Date(c.at) : null, p2 = function (n) { return String(n).padStart(2, '0'); };
    return '<section class="ad-panel"><div class="ad-panel__t">' + _t('Копия на этом компьютере') + '</div>' +
      '<span class="ad-f__hint">' + _t('Полная копия сайта с историей версий, раз в сутки при работе с сайтом. Хранятся последние 7. Если хостинг откажет — загрузите копию в любую UCMS через «Перенос».') + '</span>' +
      '<div class="ad-in" style="display:flex;align-items:center">' + (c ? p2(when.getDate()) + '.' + p2(when.getMonth() + 1) + '.' + when.getFullYear() + ' ' + p2(when.getHours()) + ':' + p2(when.getMinutes()) + ' · ' + fmtSize(c.size)
        : '<span style="color:var(--mut-2)">' + _t('копии ещё нет') + '</span>') + '</div>' +
      (state.remoteCopyErr ? '<div class="ad-pub__msg is-err">' + esc(state.remoteCopyErr) + '</div>' : '') +
      '<button type="button" class="ad-b ad-b--line"' + (busy ? ' disabled' : '') + ' onclick="App.remoteCopy()">' + ico('down', 14) + (busy ? _t('Скачиваю…') : _t('Сделать копию сейчас')) + '</button></section>';
  }
  App.remoteCopy = function () {
    state.remoteCopyBusy = true; state.remoteCopyErr = ''; App.renderView();
    fetch('/api/projects/remote-copy', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: (state.project || {}).id }) })
      .then(function (r) { return r.json(); }).then(function (d) {
        state.remoteCopyBusy = false;
        if (!d.ok) state.remoteCopyErr = d.error; else App.remote.copy = d.copy;
        App.renderView();
      }).catch(function (e) { state.remoteCopyBusy = false; state.remoteCopyErr = e.message; App.renderView(); });
  };
  function renderPublishView() {
    if (App.hosted) {
      var W = App.webInfo || {};
      // адрес сайта: из настроек сервера, из «Сайт и модули» или (сайт отдаёт сам UCMS) адрес сервера UCMS
      var url = W.siteUrl || state.siteUrl || (W.publishDir ? '' : (W.server || location.origin) + '/');
      return secHead(_t('Публикация'), W.server
        ? _t('Сайт подключён с сервера UCMS:') + ' ' + esc(W.server) + ' (' + esc(W.user) + ', ' + (W.role === 'owner' ? _t('владелец') : _t('редактор')) + '). ' + _t('Правки сохраняются сразу на сервере, «Опубликовать» собирает сайт там же.')
        : _t('Сайт работает на этом же сервере. «Опубликовать» собирает его из текущих данных — посетители сразу видят новую версию.')) +
        _t('<div class="ad-grid2"><section class="ad-panel"><div class="ad-panel__t">Сайт</div>') +
        (url ? '<div class="ad-f"><span class="ad-f__l">' + _t('Адрес') + '</span><a class="ad-in ad-in--mono" style="display:flex;align-items:center;text-decoration:none;color:var(--ac)" href="' + escAttr(url) + '" target="_blank" rel="noopener">' + esc(url) + '</a></div>' : '') +
        (W.publishDir ? '<div class="ad-f"><span class="ad-f__l">' + _t('Папка сайта на сервере') + '</span><div class="ad-in ad-in--mono" style="display:flex;align-items:center;color:var(--mut-2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(W.publishDir) + '</div></div>' : '') +
        '<button type="button" class="ad-b ad-b--primary ad-b--block" style="height:42px" onclick="App.generate()">' + ico('cloud', 16) + _t('Опубликовать изменения') + '</button>' +
        '<span class="ad-f__hint">' + _t('Пока не нажали «Опубликовать», правки видны только в предпросмотре.') + '</span>' +
        (state.lastPublished ? '<div class="ad-pub__msg is-ok">' + esc(state.lastPublished) + '</div>' : '') + '</section>' +
        (App.remote ? remoteCopyPanel() : '') + '</div>';
    }
    var P = state.publish || {}, c = P.form;
    if (!c) return secHead(_t('Публикация'), _t('Загрузка настроек…'));
    var inp = function (id, label, field, o) {
      o = o || {};
      return '<div class="ad-f"><label class="ad-f__l" for="' + id + '">' + label + '</label><input id="' + id + '" class="ad-in' + (o.mono ? ' ad-in--mono' : '') + '"' + (o.type ? ' type="' + o.type + '"' : '') +
        ' placeholder="' + escAttr(o.ph || '') + '" value="' + escAttr(c[field] == null ? '' : c[field]) + '" autocomplete="' + (o.ac || 'off') + '" oninput="App.setPub(' + jsArg(field) + ',this.value)">' +
        (o.hint ? '<span class="ad-f__hint">' + o.hint + '</span>' : '') + '</div>';
    };
    var running = P.job && P.job.running;
    return secHead(_t('Публикация'), _t('Загрузка сгенерированного сайта на хостинг по FTP. Каждый раз отправляются только изменившиеся файлы.')) +
      _t('<div class="ad-grid2"><section class="ad-panel"><div class="ad-panel__t">Подключение</div>') +
      UI.field(_t('Протокол'), segm([['ftps', _t('FTPS (защищённый)')], ['ftp', 'FTP']], c.protocol || 'ftps', function (k) { return 'App.setPub(\'protocol\',' + jsArg(k) + ')'; }),
        c.protocol === 'ftp' ? _t('<span style="color:var(--danger)">Пароль и файлы передаются открытым текстом. Используйте, только если хостинг не умеет FTPS.</span>') : _t('Явный TLS (AUTH TLS) на обычном порту — поддерживает большинство хостингов.')) +
      '<div style="display:grid;grid-template-columns:minmax(0,1fr) 96px;gap:10px">' + inp('pub-host', _t('Сервер'), 'host', { mono: true, ph: 'ftp.example.com' }) + inp('pub-port', _t('Порт'), 'port', { mono: true, ph: '21', type: 'number' }) + '</div>' +
      inp('pub-user', _t('Логин'), 'user', { ac: 'username' }) +
      inp('pub-pass', _t('Пароль'), 'password', { type: 'password', ac: 'new-password', ph: P.config && P.config.hasPassword ? _t('сохранён — оставьте пустым') : '', hint: _t('Хранится локально в publish.json (не в db.json).') }) +
      inp('pub-dir', _t('Папка на сервере'), 'dir', { mono: true, ph: '/public_html', hint: _t('Куда класть сайт: обычно <code>public_html</code>, <code>www</code> или <code>htdocs</code>.') }) +
      (c.protocol !== 'ftp' ? UI.sw(_t('Доверять самоподписанному сертификату'), !!c.allowSelfSigned, 'App.setPub(\'allowSelfSigned\',' + (c.allowSelfSigned ? 'false' : 'true') + ')') : '') +
      '<div style="display:flex;gap:8px;flex-wrap:wrap">' + UI.btn(_t('Сохранить'), 'App.savePublish()', { variant: 'dark' }) + UI.btn(_t('Проверить подключение'), 'App.testPublish()', { variant: 'line' }) + '</div>' +
      '<div data-pub-test>' + (P.testMsg || '') + '</div></section>' +
      _t('<section class="ad-panel"><div class="ad-panel__t">Публикация</div>') +
      _t('<span class="ad-f__hint">Перед отправкой сайт генерируется заново. Файлы, которые CMS раньше загрузила, а теперь их нет, удаляются с сервера; чужие файлы не трогаются.</span>') +
      '<button type="button" class="ad-b ad-b--primary ad-b--block" style="height:42px"' + (running || !(P.config && P.config.host) ? ' disabled' : '') + ' onclick="App.startPublish()">' + ico('cloud', 16) + _t('Сгенерировать и опубликовать</button>') +
      '<div data-pub-job>' + pubJobHTML(P.job) + '</div>' +
      '<div>' + UI.btn(_t('Загрузить всё заново при следующей публикации'), 'App.resetPublish()', { sm: true }) + '</div></section></div>' +
      (App.renderProjectPanel ? '<div class="ad-grid2" style="margin-top:20px">' + App.renderProjectPanel() + '</div>' : '');
  }

  /* ---- экспорт / импорт / резервные копии (запросы — в server-bridge.js) ---- */
  function fmtSize(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + _t(' МБ') : Math.max(1, Math.round(n / 1024)) + _t(' КБ'); }
  function backupPanel() {
    if (!App.can('transfer')) return '<section class="ad-panel" data-backup hidden></section>';
    var B = state.backup || {}, pend = B.pending;
    var html = _t('<section class="ad-panel" data-backup><div class="ad-panel__t">Перенос и резервные копии</div>') +
      _t('<div class="ad-f"><span class="ad-f__l">Скачать</span><div class="ad-btnrow">') +
      '<a class="ad-b ad-b--dark" href="/api/export?type=site" download>' + ico('down', 14) + _t('Весь сайт (.zip)</a>') +
      '<a class="ad-b ad-b--line" href="/api/export?type=site&history=1" download>' + ico('down', 14) + _t('С историей версий (.zip)') + '</a>' +
      '<a class="ad-b ad-b--line" href="/api/export?type=json" download>' + ico('down', 14) + _t('Только контент (.json)</a></div>') +
      _t('<span class="ad-f__hint">Архив сайта: страницы и настройки, картинки и темы — для переноса на другой компьютер. Пароль FTP и собранный сайт в архив не входят.</span>') +
      '<span class="ad-f__hint">' + _t('«С историей версий» — полная резервная копия: при загрузке версии из архива добавятся в «Историю».') + '</span></div>' +
      _t('<div class="ad-f"><span class="ad-f__l">Загрузить</span>') +
      '<label class="ad-b ad-b--line" style="align-self:flex-start;cursor:pointer">' + ico('upload', 14) + _t('Выбрать файл .zip или .json') +
      '<input type="file" accept=".zip,.json,application/zip,application/json" hidden onchange="App.importPick(this.files[0]);this.value=\'\'"></label></div>';
    if (pend) {
      var sm = pend.summary;
      html += '<div class="ad-note2 ad-import">' +
        '<b>' + esc(pend.fileName) + '</b> — ' + (sm.kind === 'site' ? _t('архив сайта') : _t('только контент')) + '<br>' +
        _t('Сайт «') + esc(sm.siteTitle || _t('без названия')) + _t('»: страниц ') + sm.pages + _t(', языки: ') + esc((sm.languages || []).join(', ').toUpperCase() || '—') +
        (sm.kind === 'site' ? _t(', картинок ') + sm.uploads + _t(', темы: ') + esc(sm.themes.join(', ') || '—') : '') +
        ((sm.modules || []).length ? _t(', модули: ') + esc(sm.modules.join(', ')) : '') + (sm.history ? _t(', версий в истории: ') + sm.history : '') + '.<br>' +
        _t('<span style="color:var(--danger)">Текущие страницы и настройки') + (sm.kind === 'site' ? _t(', картинки и темы') : '') + _t(' будут заменены.</span> ') +
        _t('Перед заменой автоматически сохранится резервная копия.') +
        '<div class="ad-btnrow" style="margin-top:10px">' + UI.btn(B.busy ? _t('Загружаю…') : _t('Заменить сайт'), 'App.importApply()', { variant: 'dark' }) + UI.btn(_t('Отмена'), 'App.importCancel()') + '</div></div>';
    }
    var list = B.list || [];
    html += _t('<div class="ad-f"><div class="ad-f__row"><span class="ad-f__l">Резервные копии · ') + list.length + '</span>' + UI.btn(_t('Создать сейчас'), 'App.backupNow()', { sm: true, variant: 'accent', icon: 'plus' }) + '</div>' +
      (list.length ? '<div class="ad-backups">' + list.map(function (b) {
        var m = /(\d{4})-(\d\d)-(\d\d)-(\d\d)-(\d\d)/.exec(b.name), when = m ? m[3] + '.' + m[2] + '.' + m[1] + ' ' + m[4] + ':' + m[5] : b.name;
        var why = /^before-import/.test(b.name) ? _t('перед импортом') : /^before-pull/.test(b.name) ? _t('перед получением с сервера') : _t('вручную');
        return '<a class="ad-backup" href="/api/backups/' + encodeURIComponent(b.name) + '" download>' + ico('down', 13) + '<span>' + when + '</span><small>' + why + ' · ' + fmtSize(b.size) + '</small></a>';
      }).join('') + '</div>' : _t('<div class="ad-f__hint">Пока нет. Копия создаётся автоматически перед каждым импортом; хранятся последние 10 в <code>backups</code>.</div>')) + '</div>';
    return html + '</section>';
  }
  App.renderBackup = function () { var el = document.querySelector('[data-backup]'); if (el) el.outerHTML = backupPanel(); };

  // Иконка сайта (favicon) — загрузку обрабатывает server-bridge.js (.ad-site-up)
  App.setFavicon = function (url) { state.siteFavicon = url || ''; App.renderView(); };
  function faviconField() {
    var f = state.siteFavicon;
    return '<div class="ad-f"><span class="ad-f__l">' + _t('Иконка сайта (favicon)') + '</span><div class="ad-fav">' +
      '<button type="button" class="ad-gi__thumb ad-site-up ad-fav__img" aria-label="' + escAttr(_t('Загрузить иконку')) + '">' +
      (f ? '<img src="' + escAttr(f) + '" alt="">' : ico('upload', 18)) + '</button>' +
      '<div class="ad-fav__txt"><span class="ad-f__hint">' + _t('Значок во вкладке браузера и в закладках. Лучше квадратная PNG или SVG от 512×512; подойдёт и .ico.') + '</span>' +
      (f ? UI.btn(_t('Убрать'), 'App.setFavicon(\'\')', { sm: true }) : '') + '</div></div></div>';
  }

  function renderSiteView() {
    return secHead(_t('Сайт и модули'), _t('Общие настройки сайта и набор модулей, доступных в палитре добавления.')) +
      '<div class="ad-grid2"><div class="ad-col-stack">' + _t('<section class="ad-panel"><div class="ad-panel__t">Название сайта</div>') +
      _t('<div class="ad-f"><input id="site-name" class="ad-in" aria-label="Название сайта" value="') + escAttr(state.siteName) + '" oninput="App.setSiteName(this.value)">' +
      _t('<span class="ad-f__hint">Выводится модулем «Имя сайта» и во вкладке браузера.</span></div>') +
      _t('<div class="ad-f"><label class="ad-f__l" for="site-url">Адрес сайта</label><input id="site-url" class="ad-in ad-in--mono" placeholder="https://example.com" value="') + escAttr(state.siteUrl || '') + '" oninput="App.setField(\'siteUrl\',this.value)">' +
      _t('<span class="ad-f__hint">Нужен для canonical, картинок в соцсетях и sitemap.xml. Если сайт лежит в подпапке — укажите её: https://example.com/site</span></div>') +
      faviconField() +
      state.langs.filter(function (l) { return !l.isDefault; }).map(function (l) {
        var lc = l.code.toLowerCase(), v = (state.siteTitleTr && state.siteTitleTr[lc]) || '';
        return '<div class="ad-f"><label class="ad-f__l" for="site-tr-' + esc(lc) + _t('">Название · ') + esc(l.code) + '</label><input id="site-tr-' + esc(lc) + '" class="ad-in" placeholder="' + escAttr(state.siteName) + '" value="' + escAttr(v) + '" oninput="App.setSiteTitleTr(' + jsArg(lc) + ',this.value)"></div>';
      }).join('') + '</section>' + backupPanel() + (App.renderPackagesPanel ? App.renderPackagesPanel() : '') + '</div>' +   // подключаемые — в левой колонке, под переносом
      _t('<section class="ad-panel"><div class="ad-panel__t">Модули</div><div class="ad-f__hint">Выключенный модуль пропадает из палитры. Уже добавленные на страницы остаются.</div>') +
      '<div class="ad-modgrid" style="grid-template-columns:repeat(2,minmax(0,1fr))">' + MODULES.filter(App.modAvailable).map(function (def) {
        var on = state.moduleSw[def.key];
        return '<div class="ad-modrow"><div class="ad-modrow__icon" style="background:' + (on ? 'var(--ac-soft)' : 'var(--fill)') + ';color:' + (on ? 'var(--ac)' : 'var(--faint)') + '">' + moduleIconHTML(def.key, 18) + '</div>' +
          '<span class="ad-modrow__label" style="color:' + (on ? 'var(--ink)' : 'var(--mut-2)') + '">' + esc(def.label) + '</span>' +
          toggleHTML(on, 'module-' + def.key, call('toggleModuleSw', [def.key])) + '</div>';
      }).join('') + '</div></section></div>';
  }

  function renderLangsView() {
    var s = state;
    var list = s.langs.map(function (l, i) {
      if (s.editLangIdx === i) {
        return '<div class="ad-panel" style="box-shadow:0 0 0 2px var(--ac);padding:14px;gap:10px"><div style="display:grid;grid-template-columns:90px minmax(0,1fr);gap:10px">' +
          _t('<input class="ad-in ad-in--mono" aria-label="Код языка" value="') + escAttr(s.editLangCode) + '" oninput="App.setField(\'editLangCode\',this.value)">' +
          _t('<input class="ad-in" aria-label="Название языка" value="') + escAttr(s.editLangName) + '" oninput="App.setField(\'editLangName\',this.value)"></div>' +
          _t('<div style="display:flex;justify-content:flex-end;gap:6px"><button type="button" class="ad-b" onclick="App.editLangCancel()">Отмена</button>') +
          '<button type="button" class="ad-b ad-b--dark" onclick="App.editLangSave(' + i + _t(')">Сохранить</button></div></div>');
      }
      return '<div style="display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:10px;box-shadow:0 0 0 1px var(--line-2)">' +
        '<span class="ad-chip ad-chip--mono" style="box-shadow:none;background:var(--fill)">' + esc(l.code) + '</span><span style="font-size:14px;font-weight:500">' + esc(l.name) + '</span>' +
        '<span style="margin-left:auto"></span>' + (l.isDefault ? _t('<span class="ad-chip" style="box-shadow:none;background:var(--ac-soft);color:var(--ac);font-weight:600">По умолчанию</span>') : '') +
        ib('pencil', _t('Изменить'), 'App.editLangStart(' + i + ')') + (l.isDefault ? '' : ib('del', _t('Удалить язык'), 'App.delLang(' + i + ')', { danger: true })) + '</div>';
    }).join('');
    return secHead(_t('Языки'), _t('Каждый язык — отдельная папка сайта. Переводы модулей делает ИИ из панели страницы: выберите язык вверху и нажмите «Перевести».')) +
      '<div class="ad-grid2"><div style="display:flex;flex-direction:column;gap:20px">' +
      _t('<section class="ad-panel"><div class="ad-panel__t">Языки сайта</div>') + list + '</section>' +
      _t('<section class="ad-panel"><div class="ad-panel__t">Добавить язык</div><div style="display:grid;grid-template-columns:90px minmax(0,1fr);gap:10px">') +
      _t('<div class="ad-f"><label class="ad-f__l" for="lang-code">Код</label><input id="lang-code" class="ad-in ad-in--mono" placeholder="EN" value="') + escAttr(s.newLangCode) + '" oninput="App.setField(\'newLangCode\',this.value)"></div>' +
      _t('<div class="ad-f"><label class="ad-f__l" for="lang-name">Название</label><input id="lang-name" class="ad-in" placeholder="English" value="') + escAttr(s.newLangName) + '" oninput="App.setField(\'newLangName\',this.value)"></div></div>' +
      '<button type="button" class="ad-b ad-b--dark ad-b--block" onclick="App.addLang()">' + ico('plus', 14) + _t('Добавить язык</button></section></div>') +
      (App.hosted ? _t('<section class="ad-panel"><div class="ad-panel__t">ИИ-перевод</div>') + '<span class="ad-f__hint">' + (App.remote
        ? _t('Для сайта, подключённого с сервера, ИИ-перевода пока нет: ключ API не должен попадать на сервер. Переводите вручную в инспекторе.')
        : _t('В веб-версии ИИ-перевода нет: ключ API не хранится на сервере. Переводите в локальной версии или вручную в инспекторе.')) + '</span></section></div>' :
      _t('<section class="ad-panel"><div class="ad-panel__t">ИИ-перевод</div>') +
      _t('<div class="ad-f"><label class="ad-f__l" for="api-key">Anthropic API-ключ</label><input id="api-key" class="ad-in ad-in--mono" type="password" placeholder="sk-ant-…" value="') + escAttr(s.apiKey) + '" oninput="App.setField(\'apiKey\',this.value)">' +
      _t('<span class="ad-f__hint">Хранится локально в db.json в открытом виде — это локальный инструмент без удалённого сервера.</span></div>') +
      _t('<div class="ad-f"><span class="ad-f__l">Модель</span><div class="ad-in ad-in--mono" style="display:flex;align-items:center;color:var(--mut-2)">claude-haiku-4-5</div></div></section></div>'));
  }

  // Шрифт темы для живого примера: подключаем ссылку в <head> админки.
  function ensureFontPreview() {
    var url = /^https:\/\//.test(state.themeFontUrl) ? state.themeFontUrl : '';
    var link = document.querySelector('link[data-font-preview]');
    if (!url) { if (link) link.remove(); return; }
    if (!link) { link = document.createElement('link'); link.rel = 'stylesheet'; link.setAttribute('data-font-preview', ''); document.head.appendChild(link); }
    if (link.getAttribute('href') !== url) link.setAttribute('href', url);
  }
  function fontPreviewStyle() { return state.themeFontName ? 'font-family:\'' + state.themeFontName.replace(/['"\\<>]/g, '') + '\',var(--font)' : ''; }
  function renderThemeView() {
    var s = state;
    return secHead(_t('Тема'), _t('Внешний вид сгенерированного сайта. Файл темы — источник истины: правки во внешнем редакторе подхватываются сами.')) +
      (App.renderBrandPanel ? App.renderBrandPanel() : '') +
      '<div class="ad-grid2"><div style="display:flex;flex-direction:column;gap:20px">' +
      _t('<section class="ad-panel"><div class="ad-panel__t">Темы</div><div class="ad-themes">') + (s.themes || []).map(function (t) {
        var on = t === s.themeName;
        return '<button type="button" class="ad-theme' + (on ? ' is-on' : '') + '" aria-pressed="' + on + '" onclick="' + call('switchTheme', [t]) + '"><div class="ad-theme__pv">Aa</div>' +
          '<div class="ad-theme__n">' + esc(t) + (on ? ico('check', 14) : '') + '</div></button>';
      }).join('') + '</div>' +
      _t('<div style="display:flex;gap:8px"><input class="ad-in" aria-label="Имя новой темы" placeholder="Имя новой темы" value="') + escAttr(s.newThemeName || '') + '" oninput="App.setField(\'newThemeName\',this.value)">' +
      '<button type="button" class="ad-b ad-b--line" onclick="App.createTheme()">' + ico('plus', 14) + _t('Создать из текущей</button></div>') +
      _t('<span class="ad-f__hint">Тема — папка <code>themes/&lt;Имя&gt;/</code> с файлом <code>theme.css</code>. Гайд: <code>docs/THEMES.md</code>.</span></section>') +
      _t('<section class="ad-panel"><div class="ad-panel__t">Шрифт темы «') + esc(s.themeName) + '»</div>' +
      _t('<span class="ad-f__hint" style="margin-top:-8px">У каждой темы свой шрифт — хранится в <code>themes/') + esc(s.themeName) + _t('/theme.json</code> и меняется вместе с темой. Шрифт только для этого сайта — в «Стиле проекта» выше.</span>') +
      _t('<div class="ad-f"><label class="ad-f__l" for="font-url">Ссылка на шрифт</label><input id="font-url" class="ad-in ad-in--mono" placeholder="https://fonts.googleapis.com/css2?family=…" value="') + escAttr(s.themeFontUrl) + '" oninput="App.setFontUrl(this.value)"></div>' +
      _t('<div class="ad-f"><label class="ad-f__l" for="font-name">Название семейства</label><input id="font-name" class="ad-in" data-font-name placeholder="пусто — шрифт из темы" value="') + escAttr(s.themeFontName) + '" oninput="App.setFontName(this.value)"></div>' +
      '<div data-font-hint class="ad-f__hint">' + fontHint(s) + '</div>' +
      '<div data-font-sample style="padding:14px 16px;border-radius:10px;background:var(--surf);font-size:24px;line-height:1.3;' + fontPreviewStyle() + _t('">Съешь же ещё этих мягких французских булок</div></section></div>') +
      _t('<section class="ad-code" aria-label="CSS темы"><div class="ad-code__h">theme.css <small>синхронизируется с файлом</small>') +
      (App.hosted ? '</div>' : '<button type="button" class="ad-b ad-b--sm" onclick="App.openThemeExternal()">' + ico('ext', 13) + _t('Во внешнем редакторе</button></div>')) +
      _t('<textarea class="ad-css-editor" spellcheck="false" wrap="off" aria-label="CSS темы" oninput="App.saveThemeCss(this.value)">') + esc(s.themeCss) + '</textarea>' +
      '<div class="ad-code__f">themes/' + esc(s.themeName) + '/theme.css</div></section></div>';
  }
  App.openThemeExternal = function () { fetch('/api/open-external', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"file":"css"}' }); };

  /* ============================================================
     Инспектор и панель параметров страницы
     ============================================================ */
  var INSP_IDLE = _t('<aside class="ad-insp is-idle" data-insp aria-label="Инспектор"><div class="ad-insp__b"><div class="ad-insp__empty">') + ico('cursor', 28) +
    _t('<b style="color:var(--ink);font-weight:600">Ничего не выбрано</b>Нажмите на блок или модуль на холсте — здесь появятся его настройки.</div></div></aside>');
  function renderInsp() {
    var t = curTree();
    if (!t) return '<div data-insp hidden></div>';
    if (state.drawer === 'page' && state.view === 'page') return renderPageDrawer();
    if (/^coll:/.test(state.drawer || '') && state.view === 'page' && App.renderCollDrawer) return App.renderCollDrawer(state.drawer.slice(5));
    var sel = state.selected;
    if (!sel || !state.trees[sel.tree] || rootTree(sel.tree) !== t) return INSP_IDLE;   // в т.ч. блоки внутри вкладок
    return sel.kind === 'block' ? renderBlockInsp(sel.tree, sel.id) : renderModInsp(sel.tree, sel.id);
  }
  function inspHead(icon, title, closeCall) {
    return '<div class="ad-insp__h"><div class="ad-insp__ic">' + icon + '</div><div class="ad-insp__t">' + esc(title) + '</div>' + ib('close', _t('Закрыть'), closeCall) + '</div>';
  }
  function renderModInsp(t, id) {
    var m = getModule(t, id); if (!m) return INSP_IDLE;
    var loc = locateModule(t, id), b = findBlock(t, loc.blockId), label = MODULE_LABEL[m.type] || m.type;
    var sep = ico('chev', 10, ' style="color:var(--faint)"');
    return _t('<aside class="ad-insp" data-insp aria-label="Настройки модуля">') + inspHead(moduleIconHTML(m.type, 15), label, call('select', [t, 'mod', ''])) +
      '<div class="ad-insp__b"><div class="ad-insp__crumbs"><button type="button" onclick="' + call('select', [t, 'block', b.id]) + _t('">Блок ') + (loc.blockIndex + 1) + (b.cssClass ? ' .' + esc(b.cssClass) : '') + '</button>' +
      (loc.colIndex >= 0 ? sep + _t('<span>Колонка ') + (loc.colIndex + 1) + '</span>' : '') + sep + '<b>' + esc(label) + '</b></div>' +
      renderTrPanel(t, m) + (trLang() ? _t('<div class="ad-tr__base"><span class="ad-eyebrow2">Основной язык · ') + esc(defLangCode()) + '</span></div>' : '') +
      '<div data-mid="' + m.id + '" data-tree="' + t + '">' + renderModuleEditor(t, m, pageTitles(), menuTreeOf()) + '</div></div>' +
      '<div class="ad-insp__f">' + ib('up', _t('Выше'), call('moveModule', [t, m.id, -1])) + ib('down', _t('Ниже'), call('moveModule', [t, m.id, 1])) + ib('copy', _t('Дублировать'), call('dupModule', [t, m.id])) +
      '<button type="button" class="ad-b ad-b--sm ad-b--danger" style="margin-left:auto" onclick="' + call('delModule', [t, m.id]) + '">' + ico('del', 13) + _t('Удалить модуль</button></div></aside>');
  }
  // Отступы блока сверху и снизу: «Как в теме» или свои значения в px (по умолчанию 48).
  // Старые размеры S/M/L/XL (до 1.8) показываются своими числами и переводятся в px при правке.
  var PAD_PX = { none: 0, s: 24, m: 48, l: 80, xl: 120 };
  function padValues(st) {
    if (st.pad === 'custom') return [st.padTop, st.padBottom];
    if (st.pad in PAD_PX) return [PAD_PX[st.pad], PAD_PX[st.pad]];
    return null;
  }
  function padField(t, b) {
    var st = b.style || {}, v = padValues(st), J = jsArg;
    var inp = function (i, label) {
      return '<label class="ad-padin"><span title="' + escAttr(label) + '">' + ico(i ? 'down' : 'up', 13) + '</span><input type="number" min="0" max="400" step="4" aria-label="' + escAttr(label) + '" value="' + escAttr(v ? v[i] : '') + '"' +
        ' oninput="App.setBlockPad(' + J(t) + ',' + J(b.id) + ',' + i + ',this.value)"><em>px</em></label>';
    };
    return UI.field(_t('Отступы сверху и снизу'),
      segm([['', _t('Как в теме'), 'theme'], ['custom', _t('Свои'), 'sliders']], v ? 'custom' : '', function (k) { return call('setBlockPadMode', [t, b.id, k]); }) +
      (v ? '<div class="ad-padrow">' + inp(0, _t('Сверху')) + inp(1, _t('Снизу')) + '</div>' : ''),
      v ? _t('На телефоне отступы уменьшаются на треть.') : '');
  }
  App.setBlockPadMode = function (t, blockId, mode) {
    var b = findBlock(t, blockId); if (!b) return;
    var st = b.style = b.style || {};
    if (mode === 'custom') { var v = padValues(st) || [48, 48]; st.pad = 'custom'; st.padTop = v[0]; st.padBottom = v[1]; }
    else { delete st.pad; delete st.padTop; delete st.padBottom; }
    App.renderBlock(t, blockId); refreshBlockInsp(t, blockId);
  };
  App.setBlockPad = function (t, blockId, i, value) {
    var b = findBlock(t, blockId); if (!b) return;
    var st = b.style = b.style || {};
    var v = padValues(st) || [48, 48], n = Math.max(0, Math.min(400, parseInt(value, 10) || 0));
    v[i] = n; st.pad = 'custom'; st.padTop = v[0]; st.padBottom = v[1];
    App.renderBlock(t, blockId);   // инспектор не перерисовываем — фокус в поле
  };
  function renderBlockInsp(t, id) {
    var i = blockIndex(t, id), b = state.trees[t][i]; if (!b) return INSP_IDLE;
    var st = b.style || {}, target = 'block:' + t + ':' + b.id;
    var sty = function (key) { return function (v) { return call('setBlockStyle', [t, b.id, key, v]); }; };
    var cols = b.cols.map(function (c, ci) {
      var a = [t, b.id, c.id];
      return _t('<div class="ad-colcard"><div class="ad-colrow"><span class="ad-colrow__n">Колонка ') + (ci + 1) + '</span><span style="flex:1"></span>' +
        ib('left', _t('Левее'), call('moveColumn', a.concat([-1])), { disabled: ci === 0 }) +
        ib('right', _t('Правее'), call('moveColumn', a.concat([1])), { disabled: ci === b.cols.length - 1 }) +
        ib('del', _t('Удалить колонку'), call('delColumn', a), { danger: true }) + '</div>' +
        _t('<div class="ad-colrow"><input class="ad-in ad-in--sm ad-in--mono" aria-label="Ширина колонки ') + (ci + 1) + _t('" placeholder="авто" value="') + escAttr(c.width) + '" oninput="App.setColWidth(' + a.map(jsArg).join(',') + ',this.value)">' +
        '<div style="flex:1;min-width:0">' + segm([['%', '%'], ['px', 'px']], c.unit || '%', function (u) { return call('setColUnit', a.concat([u])); }) + '</div></div>' +
        segm([['', _t('Как у блока'), 'inherit'], ['left', _t('Лево'), 'alLeft'], ['center', _t('Центр'), 'alCenter'], ['right', _t('Право'), 'alRight']], c.align || '', function (v) { return call('setColAlign', a.concat([v])); }) + '</div>';
    }).join('');
    var group = function (title, body) { return '<section class="ad-grp"><div class="ad-grp__t">' + title + '</div>' + body + '</section>'; };

    var look = UI.field(_t('Ширина'), segm([['', _t('Контейнер'), 'wContainer'], ['full', _t('На всю ширину'), 'wFull'], ['narrow', _t('Узко'), 'wNarrow']], st.width || '', sty('width')),
        st.width === 'full' ? _t('Блок растягивается на весь экран вместе с колонками; по краям остаются поля.')
          : st.width === 'narrow' ? _t('До 960 px (токен темы <code>--narrow-width</code>).') : _t('До 1440 px (токен темы <code>--content-width</code>).')) +
      (st.width === 'full' ? UI.sw(_t('Контент — по ширине страницы (только фон до краёв)'), !!st.contain, call('setBlockStyle', [t, b.id, 'contain', st.contain ? '' : '1'])) : '') +
      UI.field(_t('Выравнивание'), segm([['', _t('Лево'), 'alLeft'], ['center', _t('Центр'), 'alCenter'], ['right', _t('Право'), 'alRight']], st.align || '', sty('align')),
        b.cols.length ? _t('Для всех колонок блока; у колонки можно задать своё.') : '') +
      padField(t, b) +
      UI.field(_t('Фон'), renderBgEditor(target, normBg(st.bg), 'block'));

    var columns = (b.cols.length ? cols : _t('<div class="ad-note2">Колонок нет: модули идут друг под другом на всю ширину блока.</div>')) +
      (b.cols.length < 4 ? '<div><button type="button" class="ad-b ad-b--sm ad-b--accent" onclick="' + call('splitColumns', [t, b.id]) + '">' + ico('plus', 13) + (b.cols.length ? _t('Колонка') : _t('Разбить на 2 колонки')) + '</button></div>' : '');
    if (b.cols.length) {
      columns += UI.field(_t('Выравнивание по высоте'), segm([['', _t('Как в теме'), 'theme'], ['top', _t('Верх'), 'vaTop'], ['center', _t('Центр'), 'vaCenter'], ['bottom', _t('Низ'), 'vaBottom']], st.valign || '', sty('valign'))) +
        UI.field(_t('Промежуток'), segm([['', _t('Тема')], ['s', 'S'], ['m', 'M'], ['l', 'L']], st.gap || '', sty('gap'))) +
        UI.sw(_t('На телефоне — в обратном порядке'), !!st.reverse, call('setBlockStyle', [t, b.id, 'reverse', st.reverse ? '' : '1'])) +
        _t('<div class="ad-note2">Пустая ширина — колонка делит оставшееся место поровну. На телефоне колонки встают друг под другом.') +
        (b.mods.length ? _t(' Модули блока вне колонок выводятся под ними.') : '') + '</div>';
    }

    var anchorOk = !st.anchor || /^[\p{L}\p{N}_-]+$/u.test(st.anchor);
    var misc = _t('<div class="ad-f"><label class="ad-f__l" for="insp-blk-class">CSS-класс</label>') +
      _t('<input id="insp-blk-class" class="ad-in ad-in--mono" placeholder="например, features" value="') + escAttr(b.cssClass) + '" oninput="App.setBlockClass(' + jsArg(t) + ',' + jsArg(b.id) + ',this.value)">' +
      _t('<span class="ad-f__hint">Добавляется к <code>.layout-row</code> — стилизуйте блок в теме.</span></div>') +
      _t('<div class="ad-f"><label class="ad-f__l" for="insp-blk-anchor">Якорь</label><div class="ad-affix"><span>#</span>') +
      '<input id="insp-blk-anchor" placeholder="contacts" value="' + escAttr(st.anchor || '') + '" oninput="App.setBlockStyle(' + jsArg(t) + ',' + jsArg(b.id) + ',\'anchor\',this.value,true)"></div>' +
      '<span class="ad-f__hint">' + (anchorOk ? _t('Ссылка на блок: <code>страница.html#якорь</code> — в меню, кнопке или тексте.') : _t('Пробелы и знаки заменятся на «-».')) + '</span></div>' +
      UI.field(_t('Показывать'), segm([['', _t('Везде'), 'devAll'], ['mobile', _t('Только на ПК'), 'devDesktop'], ['desktop', _t('Только на телефоне'), 'devPhone']], st.hide || '', sty('hide'))) +
      _t('<div class="ad-f"><label class="ad-f__l" for="insp-tpl-name">Шаблон секции</label>') +
      _t('<input id="insp-tpl-name" class="ad-in" placeholder="Название шаблона">') + UI.btn(_t('Сохранить как шаблон'), call('saveTemplate', [t, b.id]), { variant: 'line', icon: 'copy' }) +
      _t('<span class="ad-f__hint">Блок целиком — с колонками, модулями и оформлением. Вставка: «Из шаблона» под блоками на любой странице.</span></div>');

    return _t('<aside class="ad-insp" data-insp aria-label="Настройки блока">') + inspHead(ico('cols', 15), _t('Блок ') + (i + 1), call('select', [t, 'block', ''])) +
      '<div class="ad-insp__b">' + group(_t('Оформление'), look) + group(_t('Колонки'), columns) + group(_t('Класс, якорь, видимость, шаблон'), misc) + '</div>' +
      '<div class="ad-insp__f">' + ib('up', _t('Блок выше'), call('moveBlock', [t, b.id, -1]), { disabled: i === 0 }) + ib('down', _t('Блок ниже'), call('moveBlock', [t, b.id, 1]), { disabled: i === state.trees[t].length - 1 }) +
      ib('copy', _t('Дублировать блок'), call('dupBlock', [t, b.id])) +
      '<button type="button" class="ad-b ad-b--sm ad-b--danger" style="margin-left:auto" onclick="' + call('delBlock', [t, b.id]) + '">' + ico('del', 13) + _t('Удалить блок</button></div></aside>');
  }

  // Поля страницы: пишем в state и точечно обновляем шапку холста и список страниц.
  App.setPageField = function (name, value) {
    state[name] = value;
    var p = state.pages[state.sel];
    if (p && name === 'pageTitle') p.title = value;
    if (p && name === 'pageSlug') p.slug = '/' + value + '.html';
    App.renderPageHead(); App.renderTop(); App.renderSide();
  };
  function pageTrSection() {
    var lc = trLang(); if (!lc) return '';
    var tr = (state.pageTr && state.pageTr[lc]) || {};
    return _t('<section class="ad-tr" aria-label="Перевод страницы"><div class="ad-tr__h">') + ico('langs', 14) + _t('<b>Перевод · ') + esc(state.plang) + '</b></div>' +
      _t('<div class="ad-f"><label class="ad-f__l" for="pg-tr-title">Название</label><input id="pg-tr-title" class="ad-in" placeholder="') + escAttr(state.pageTitle) + '" value="' + escAttr(tr.title || '') + '" oninput="App.setPageTr(\'title\',this.value)"></div>' +
      _t('<div class="ad-f"><label class="ad-f__l" for="pg-tr-slug">Адрес</label><div class="ad-affix"><span>/') + esc(lc) + '/</span><input id="pg-tr-slug" placeholder="' + escAttr(state.pageSlug) + '" value="' + escAttr(tr.slug || '') + '" oninput="App.setPageTr(\'slug\',this.value)"><span>.html</span></div></div>' +
      _t('<div class="ad-f"><label class="ad-f__l" for="pg-tr-desc">Описание для поиска</label><textarea id="pg-tr-desc" class="ad-in ad-tr__ta" rows="2" placeholder="') + escAttr((state.pageSeo || {}).description || '') + '" oninput="App.setPageTr(\'description\',this.value)">' + esc(tr.description || '') + '</textarea></div>' +
      (state.pageEntry ? _t('<div class="ad-f"><label class="ad-f__l" for="pg-tr-exc">Анонс</label><textarea id="pg-tr-exc" class="ad-in ad-tr__ta" rows="2" placeholder="') + escAttr(state.pageEntry.excerpt || '') + '" oninput="App.setPageTr(\'excerpt\',this.value)">' + esc(tr.excerpt || '') + '</textarea></div>' : '') +
      _t('<span class="ad-f__hint">Пусто — используется вариант на ') + esc(defLangCode()) + '.</span></section>';
  }
  App.setPageSeo = function (field, value, render) {
    state.pageSeo = state.pageSeo || {};
    state.pageSeo[field] = value;
    var c = document.querySelector('[data-seo-count]');
    if (c && field === 'description') { c.textContent = String(value).length + ' / 160'; c.classList.toggle('is-over', String(value).length > 160); }
    if (render) App.renderInsp();
  };
  function seoSection() {
    var seo = state.pageSeo || {}, len = String(seo.description || '').length;
    var img = seo.image
      ? '<div class="ad-media ad-seo__img"><img src="' + escAttr(seo.image) + '" alt=""><div class="ad-media__bar">' +
        UI.btn(_t('Заменить'), '', { sm: true, icon: 'upload', cls: 'ad-seo-up ad-b--glass' }) + UI.btn(_t('Убрать'), "App.setPageSeo('image','',true)", { sm: true, cls: 'ad-b--glass' }) + '</div></div>'
      : '<button type="button" class="ad-drop ad-seo-up" style="height:96px">' + ico('upload', 18) + _t('<b>Картинка для соцсетей</b><small>1200 × 630, JPG или PNG</small></button>');
    return _t('<div class="ad-f" style="gap:12px"><span class="ad-eyebrow2">Поиск и соцсети</span>') +
      _t('<div class="ad-f"><div class="ad-f__row"><label class="ad-f__l" for="pg-desc">Описание</label><span class="ad-seo__count') + (len > 160 ? ' is-over' : '') + '" data-seo-count>' + len + ' / 160</span></div>' +
      _t('<textarea id="pg-desc" class="ad-in ad-tr__ta" rows="3" placeholder="Коротко о странице — показывается в поиске и при отправке ссылки" oninput="App.setPageSeo(\'description\',this.value)">') + esc(seo.description || '') + '</textarea></div>' +
      img + UI.sw(_t('Скрыть страницу от поисковиков'), !!seo.noindex, "App.setPageSeo('noindex'," + (seo.noindex ? 'false' : 'true') + ",true)") +
      (state.siteUrl ? '' : _t('<span class="ad-f__hint">Укажите адрес сайта в разделе «Сайт и модули» — тогда появятся canonical, полноценная картинка для соцсетей и sitemap.xml.</span>')) + '</div>';
  }
  function renderPageDrawer() {
    var s = state, open = s.openPopover === 'menupos';
    var opts = [{ key: 'root', label: _t('В корне меню') }].concat(s.pages.filter(function (p) { return p.title !== s.pageTitle && !p.coll; }).map(function (p) { return { key: p.title, label: p.title }; }));
    var entry = !!s.pageEntry;
    var menuSec = entry ? (App.renderEntrySection ? App.renderEntrySection() : '') :
      _t('<div class="ad-f" style="gap:4px"><span class="ad-eyebrow2">Меню</span>') +
      _t('<div class="ad-sw"><span>Показывать в меню</span>') + toggleHTML(s.inMenu, 'inMenu', "App.toggleBool('inMenu')") + '</div>' +
      '<div style="display:grid;grid-template-columns:minmax(0,2fr) minmax(0,1fr);gap:10px">' +
      _t('<div class="ad-f"><span class="ad-f__l">Родитель</span><div class="ad-dd" data-dd><button type="button" class="ad-in ad-in--pick" aria-expanded="') + open + '" onclick="App.togglePopover(\'menupos\')">' +
      '<span>' + esc(s.menuPos === 'root' ? _t('В корне меню') : s.menuPos) + '</span>' + ico('chevd', 13) + '</button>' +
      (open ? popoverHTML(opts.map(function (o) {
        return '<div class="ad-popover__row' + (o.key === s.menuPos ? ' ad-popover__row--active' : '') + '" onclick="' + call('setMenuPos', [o.key]) + '">' + esc(o.label) + '</div>';
      }).join(''), { scroll: true }) : '') + '</div></div>' +
      _t('<div class="ad-f"><label class="ad-f__l" for="pg-order">Порядок</label><input id="pg-order" class="ad-in" type="number" value="') + escAttr(s.menuOrder) + '" oninput="App.setField(\'menuOrder\',this.value)"></div></div></div>';
    return '<aside class="ad-insp ad-insp--drawer" data-insp aria-label="' + escAttr(entry ? _t('Параметры записи') : _t('Параметры страницы')) + '"><div class="ad-insp__h"><div class="ad-insp__t">' + (entry ? _t('Параметры записи') : _t('Параметры страницы')) + '</div>' + ib('close', _t('Закрыть'), "App.openDrawer('page')") + '</div>' +
      '<div class="ad-insp__b">' +
      _t('<div class="ad-f"><label class="ad-f__l" for="pg-title">Название</label><input id="pg-title" class="ad-in" value="') + escAttr(s.pageTitle) + '" oninput="App.setPageField(\'pageTitle\',this.value)"></div>' +
      _t('<div class="ad-f"><label class="ad-f__l" for="pg-slug">Адрес</label><div class="ad-affix"><span>/') + esc(entryDir()) + '</span><input id="pg-slug" value="' + escAttr(s.pageSlug) + '" oninput="App.setPageField(\'pageSlug\',this.value)"><span>.html</span></div></div>' +
      menuSec +
      _t('<div class="ad-f" style="gap:4px"><span class="ad-eyebrow2">Показывать на странице</span>') +
      _t('<div class="ad-sw"><span>Шапку сайта</span>') + toggleHTML(s.headerVisible, 'headerVisible', "App.toggleBool('headerVisible')") + '</div>' +
      _t('<div class="ad-sw"><span>Подвал сайта</span>') + toggleHTML(s.footerVisible, 'footerVisible', "App.toggleBool('footerVisible')") + '</div></div>' +
      pageTrSection() + seoSection() +
      _t('<div class="ad-f" style="gap:10px"><span class="ad-eyebrow2">Фон страницы</span>') + renderBackgroundSettings() + '</div></div>' +
      '<div class="ad-insp__f"><button type="button" class="ad-b ad-b--sm ad-b--danger" onclick="App.deletePage()">' + ico('del', 13) + (entry ? _t('Удалить запись') : _t('Удалить страницу')) + '</button>' +
      _t('<button type="button" class="ad-b ad-b--dark" style="margin-left:auto" onclick="App.openDrawer(\'page\')">Готово</button></div></aside>');
  }

  /* ============================================================
     Перетаскивание: блоки (за ⠿ в заголовке) и модули (за карточку).
     Нативный HTML5 DnD, обработчики — делегированием на document,
     навешиваются один раз. Индикатор вставки — одна линия position:fixed.
     ============================================================ */
  App.moveModuleTo = function (tree, modId, blockId, colId, index) {
    var from = locateModule(tree, modId), b = findBlock(tree, blockId);
    if (!from || !b) return;
    var target = colId ? (b.cols.filter(function (c) { return c.id === colId; })[0] || {}).mods : b.mods;
    if (!target) return;
    if (target === from.container && from.index < index) index--;   // элемент уже вынут из этого же списка
    var m = from.container.splice(from.index, 1)[0];
    target.splice(Math.max(0, Math.min(index, target.length)), 0, m);
    if (from.blockId !== blockId) App.renderBlock(tree, from.blockId);
    App.renderBlock(tree, blockId);
    if (isSel(tree, 'mod', modId)) App.renderInsp();   // крошки «Блок › Колонка» поменялись
  };
  App.moveBlockTo = function (tree, blockId, index) {
    var list = state.trees[tree], i = blockIndex(tree, blockId);
    if (i < 0) return;
    if (i < index) index--;
    if (index === i) return;
    list.splice(index, 0, list.splice(i, 1)[0]);
    renderBlocks(tree); App.renderInsp();
  };

  var drag = null;   // { kind: 'mod' | 'block', tree, id }
  var dropAt = null; // { container, index }
  var line = null;
  function showLine(rect, y) {
    if (!line) { line = document.createElement('div'); line.className = 'ad-dropline'; document.body.appendChild(line); }
    line.style.cssText = 'left:' + rect.left + 'px;width:' + rect.width + 'px;top:' + (y - 1) + 'px;display:block';
  }
  function hideLine() { if (line) line.style.display = 'none'; }
  // Позиция вставки среди items по вертикали курсора.
  function insertIndex(items, y) {
    for (var i = 0; i < items.length; i++) {
      var r = items[i].getBoundingClientRect();
      if (y < r.top + r.height / 2) return { index: i, y: r.top - 4 };
    }
    var last = items[items.length - 1];
    return { index: items.length, y: last ? last.getBoundingClientRect().bottom + 4 : null };
  }
  function endDrag() {
    drag = null; dropAt = null; hideLine();
    document.body.classList.remove('is-dragging');
    var d = document.querySelector('.is-drag-src'); if (d) d.classList.remove('is-drag-src');
  }

  document.addEventListener('dragstart', function (e) {
    var t = e.target; if (!(t instanceof Element)) return;
    var orow = t.closest('[data-o-id]');
    if (orow) {
      var tree = orow.closest('[data-outline]').getAttribute('data-outline-tree');
      drag = { kind: orow.getAttribute('data-o').split(':')[0] === 'block' ? 'block' : 'mod', tree: tree, id: orow.getAttribute('data-o-id') };
      orow.classList.add('is-drag-src');
      document.body.classList.add('is-dragging');
      state.openPopover = null;
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', drag.id);
      return;
    }
    var grip = t.closest('.ad-blk__grip');
    var card = !grip && t.closest('[data-card]');
    if (!grip && !card) return;
    var key = (grip ? grip.closest('[data-block]').getAttribute('data-block') : card.getAttribute('data-card')).split(':');
    drag = { kind: grip ? 'block' : 'mod', tree: key[0], id: key[1] };
    var src = grip ? grip.closest('[data-block]') : card;
    src.classList.add('is-drag-src');
    document.body.classList.add('is-dragging');
    state.openPopover = null;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', drag.id);   // Firefox без данных не начинает перетаскивание
    if (grip && e.dataTransfer.setDragImage) e.dataTransfer.setDragImage(src, 24, 20);
  });
  // Вставка над деревом структуры: верх/низ строки → до/после элемента.
  // Блок: до/после блока (строки колонок и модулей считаются частью блока).
  // Модуль: над модулем — в его список; над колонкой — в её начало; над блоком — в конец модулей блока.
  function outlineTarget(rowEl, y) {
    var o = rowEl.getAttribute('data-o').split(':'), r = rowEl.getBoundingClientRect();
    var after = y > r.top + r.height / 2, kind = o[0], blockId = o[1], colId = o[2] === '-' ? '' : o[2], idx = +o[3];
    var lineY = after ? r.bottom : r.top;
    if (drag.kind === 'block') {
      var bi = blockIndex(drag.tree, blockId);
      if (kind === 'block') return { block: true, index: after ? bi + 1 : bi, y: lineY };
      return { block: true, index: bi + 1, y: null };   // y — над следующим блоком, считает dragover
    }
    if (kind === 'mod') return { blockId: blockId, colId: colId, index: after ? idx + 1 : idx, y: lineY };
    if (kind === 'col') return { blockId: blockId, colId: colId, index: 0, y: r.bottom };
    var b = findBlock(drag.tree, blockId);
    return { blockId: blockId, colId: '', index: b ? b.mods.length : 0, y: r.bottom };
  }

  document.addEventListener('dragover', function (e) {
    if (!drag || !(e.target instanceof Element)) return;
    var host, items, pos;
    var orow = e.target.closest('[data-outline] [data-o]');
    if (orow) {
      if (orow.closest('[data-outline]').getAttribute('data-outline-tree') !== drag.tree) { dropAt = null; hideLine(); return; }
      var tg = outlineTarget(orow, e.clientY);
      if (tg.block && tg.y == null) {
        // строка колонки/модуля: линия — над следующим блоком
        var next = orow.closest('.ad-list').querySelectorAll('[data-o^="block:"]')[tg.index];
        tg.y = next ? next.getBoundingClientRect().top : orow.getBoundingClientRect().bottom;
      }
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      showLine(orow.getBoundingClientRect(), tg.y);
      dropAt = { outline: tg };
      return;
    }
    if (drag.kind === 'mod') {
      // Мимо списка (отступы блока, подвал блока) — кладём в модули самого блока, под колонками.
      host = e.target.closest('[data-drop]');
      if (!host) { var blk = e.target.closest('[data-block]'); host = blk && blk.querySelector('[data-drop$=":-"]'); }
      if (!host || host.getAttribute('data-drop').split(':')[0] !== drag.tree) { dropAt = null; hideLine(); return; }
      items = Array.prototype.slice.call(host.querySelectorAll(':scope > [data-card]'));
    } else {
      host = e.target.closest('[data-blocks]');
      if (!host || host.getAttribute('data-blocks') !== drag.tree) { dropAt = null; hideLine(); return; }
      items = Array.prototype.slice.call(host.querySelectorAll(':scope > [data-block]'));
    }
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    pos = insertIndex(items, e.clientY);
    var rect = host.getBoundingClientRect();
    showLine(rect, pos.y == null ? rect.top + rect.height / 2 : pos.y);
    dropAt = { host: host, index: pos.index };
  });
  document.addEventListener('drop', function (e) {
    if (!drag || !dropAt) { endDrag(); return; }
    e.preventDefault();
    var d = drag, at = dropAt;
    endDrag();
    if (at.outline) {
      if (d.kind === 'block') { if (at.outline.block) App.moveBlockTo(d.tree, d.id, at.outline.index); return; }
      if (!at.outline.block) App.moveModuleTo(d.tree, d.id, at.outline.blockId, at.outline.colId, at.outline.index);
      return;
    }
    if (d.kind === 'block') { App.moveBlockTo(d.tree, d.id, at.index); return; }
    var p = at.host.getAttribute('data-drop').split(':');
    App.moveModuleTo(d.tree, d.id, p[1], p[2] === '-' ? '' : p[2], at.index);
  });
  document.addEventListener('dragend', endDrag);

  /* ============================================================
     Корневой рендер
     ============================================================ */
  function renderRoot() {
    syncNested();
    var rootEl = document.getElementById('root');
    var main = document.querySelector('[data-view]');
    var st = main ? main.scrollTop : 0;
    rootEl.innerHTML = '<div class="ad-app">' + renderSide() + '<div class="ad-center">' + (App.renderSyncBarHTML ? App.renderSyncBarHTML() : '') + renderTop() + renderView() + '</div>' + renderInsp() + '</div>';
    var main2 = document.querySelector('[data-view]');
    if (main2) main2.scrollTop = st;
    if (state.view === 'theme') ensureFontPreview();
  }

  // Примитивы разметки для отдельных файлов админки (collections.js)
  App.kit = { colorInput: colorInput, secHead: secHead, esc: esc, escAttr: escAttr, jsArg: jsArg, ico: ico, ib: ib, call: call, segm: segm, UI: UI, toggle: toggleHTML, popover: popoverHTML, trLang: trLang, tv: tv, uid: uid };

  // Инициализация — в server-bridge.js (загрузка /api/data → App.render()).
})();

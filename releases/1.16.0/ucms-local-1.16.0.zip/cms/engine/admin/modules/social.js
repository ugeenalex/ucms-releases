'use strict';
// Соцсети и контакты: сеть + адрес.
CMS.editor('social', function (mod, ctx) {
  var ui = ctx.ui, J = ctx.jsArg;
  var NET = [['telegram', 'Telegram'], ['vk', _t('ВКонтакте')], ['whatsapp', 'WhatsApp'], ['youtube', 'YouTube'], ['instagram', 'Instagram'],
    ['facebook', 'Facebook'], ['x', 'X'], ['github', 'GitHub'], ['email', 'Email'], ['phone', _t('Телефон')], ['site', _t('Другой сайт')]];
  var PH = { email: 'name@example.com', phone: '+7 700 000 00 00', telegram: _t('t.me/имя') };
  return ui.field(_t('Вид'), ui.segm([['icons', _t('Значки')], ['text', _t('С названием')]], mod.style || 'icons', function (k) { return ctx.set('style', J(k)); })) +
    ui.list(ctx, mod.items, _t('Ссылки'), _t('Ссылка'), function (it, set) {
      return _t('<div class="ad-li__row"><select class="ad-in ad-select" aria-label="Сеть" onchange="') + set('network') + ';' + ctx.call('renderModule') + '">' +
        NET.map(function (n) { return '<option value="' + n[0] + '"' + (n[0] === it.network ? ' selected' : '') + '>' + n[1] + '</option>'; }).join('') + '</select></div>' +
        ui.input({ value: it.url, mono: true, placeholder: PH[it.network] || 'https://…', oninput: set('url') });
    });
});

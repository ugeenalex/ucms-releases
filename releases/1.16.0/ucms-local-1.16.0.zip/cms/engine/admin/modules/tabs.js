'use strict';
// «Вкладки»: горизонтальные или вертикальные. Содержимое вкладок — обычные блоки,
// они редактируются прямо на холсте внутри карточки модуля (переключатель вкладок
// сверху, под ним — конструктор блоков выбранной вкладки). Здесь — вид и список вкладок.
CMS.editor('tabs', function (mod, ctx) {
  var ui = ctx.ui, J = ctx.jsArg;
  return ui.field(_t('Расположение'), ui.segm([['h', _t('Горизонтальные'), 'tabsH'], ['v', _t('Вертикальные'), 'tabsV']], mod.orient === 'v' ? 'v' : 'h', function (k) { return ctx.set('orient', J(k)); }),
      mod.orient === 'v' ? _t('На телефоне вертикальные вкладки становятся лентой сверху.') : '') +
    ui.field(_t('Вид вкладок'), ui.segm([['line', _t('Подчёркивание'), 'tabLine'], ['pills', _t('Плашки'), 'tabPills']], mod.tabStyle === 'pills' ? 'pills' : 'line', function (k) { return ctx.set('tabStyle', J(k)); })) +
    ui.list(ctx, mod.items || [], _t('Вкладки'), _t('Вкладка'), function (it, set) {
      return ui.input({ value: it.title, placeholder: _t('Название вкладки'), oninput: set('title') });
    }, _t('Содержимое вкладки редактируется на холсте: выберите вкладку в карточке модуля и добавляйте блоки и модули как на странице.'));
});

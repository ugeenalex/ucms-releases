'use strict';
// Таймер обратного отсчёта до даты и времени.
CMS.editor('countdown', function (mod, ctx) {
  var ui = ctx.ui;
  return ui.field(_t('Дата и время'), _t('<input class="ad-in" type="datetime-local" aria-label="Дата и время" value="') + ctx.escAttr(mod.until) + '" onchange="' + ctx.set('until', 'this.value') + '">',
      _t('Время — по часам посетителя сайта.')) +
    ui.field(_t('Заголовок'), ui.input({ value: mod.title, placeholder: _t('До старта продаж'), oninput: ctx.set('title', 'this.value', true) })) +
    ui.field(_t('Текст после окончания'), ui.input({ value: mod.doneText, placeholder: _t('Продажи открыты!'), oninput: ctx.set('doneText', 'this.value', true) }), _t('Пусто — таймер просто остановится на нулях.'));
});

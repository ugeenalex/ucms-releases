'use strict';
// Вопросы и ответы: список «вопрос — ответ», на сайте раскрывающийся (<details>).
CMS.editor('faq', function (mod, ctx) {
  var ui = ctx.ui;
  return ui.sw(_t('Первый вопрос раскрыт'), !!mod.openFirst, ctx.act('m.openFirst=!m.openFirst;')) +
    ui.list(ctx, mod.items, _t('Вопросы'), _t('Вопрос'), function (it, set) {
      return ui.input({ value: it.q, placeholder: _t('Вопрос'), oninput: set('q') }) +
        _t('<textarea class="ad-in ad-tr__ta" rows="3" aria-label="Ответ" placeholder="Ответ" oninput="') + set('a') + '">' + ctx.esc(it.a) + '</textarea>';
    });
});

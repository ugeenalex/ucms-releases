'use strict';
// Цифры: значение + суффикс + подпись. Числа на сайте досчитываются анимацией.
CMS.editor('counters', function (mod, ctx) {
  var ui = ctx.ui;
  return ui.list(ctx, mod.items, _t('Цифры'), _t('Цифра'), function (it, set) {
    return '<div class="ad-li__row">' + ui.input({ value: it.value, placeholder: '500', oninput: set('value') }) +
      _t('<input class="ad-in ad-li__icon" aria-label="Суффикс" maxlength="6" placeholder="+" value="') + ctx.escAttr(it.suffix) + '" oninput="' + set('suffix') + '"></div>' +
      ui.input({ value: it.label, placeholder: _t('Подпись: «клиентов»'), oninput: set('label') });
  }, _t('Анимируется только число без пробелов: 500, 12.5. Иначе значение выводится как есть.'));
});

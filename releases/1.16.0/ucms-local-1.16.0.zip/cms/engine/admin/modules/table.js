'use strict';
// Таблица из текста: строка — ряд, ячейки через «|».
CMS.editor('table', function (mod, ctx) {
  var ui = ctx.ui;
  return ui.sw(_t('Первая строка — заголовок'), mod.header !== false, ctx.act('m.header = m.header === false;')) +
    ui.field(_t('Данные'), _t('<textarea class="ad-in ad-in--mono ad-tr__ta" rows="7" spellcheck="false" aria-label="Данные таблицы" oninput="') + ctx.set('data', 'this.value', true) + '">' + ctx.esc(mod.data) + '</textarea>',
      _t('Каждая строка — ряд таблицы, ячейки разделяйте вертикальной чертой: <code>Услуга | Срок | Цена</code>.'));
});

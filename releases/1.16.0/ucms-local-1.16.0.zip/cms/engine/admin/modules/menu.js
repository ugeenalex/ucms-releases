'use strict';
// Меню сайта: списком / бургер; все страницы или выбранные.
// Значки кнопок «Меню» и «Закрыть»: стандартные (☰ / ✕) или свои картинки.
// Кнопки загрузки — .ad-mod-up с data-field (обработчик в server-bridge.js).
function burgerIcons(mod, ctx) {
  var ui = ctx.ui, J = ctx.jsArg, custom = mod.burgerIcons === 'custom';
  var size = parseInt(mod.iconSize, 10) || 24;
  var img = function (field, label) {
    var v = mod[field];
    return '<div class="ad-f" style="gap:4px;align-items:center"><button type="button" class="ad-gi__thumb ad-mod-up ad-arrow-up" data-field="' + field + '" aria-label="' + ctx.escAttr(label) + '">' +
      (v ? '<img src="' + ctx.escAttr(v) + '" alt="">' : ui.ico('upload', 18)) + '</button><span class="ad-f__hint">' + ctx.esc(label) + '</span>' +
      (v ? '<button type="button" class="ad-b ad-b--sm" onclick="' + ctx.set(field, "''") + '">' + _t('Убрать') + '</button>' : '') + '</div>';
  };
  var html = ui.field(_t('Кнопка ☰'), ui.segm([['', _t('Стандартная'), 'vBurger'], ['custom', _t('Свои значки'), 'imgFill']], custom ? 'custom' : '', function (k) { return ctx.set('burgerIcons', J(k)); }));
  if (!custom) return html;
  return html + '<div class="ad-arrows">' + img('iconMenu', _t('Меню')) + img('iconClose', _t('Закрыть')) + '</div>' +
    '<span class="ad-f__hint" style="margin-top:-10px">' + _t('SVG или PNG. Без значка «Закрыть» — стандартный крестик. Меню в шапке — значки на всём сайте.') + '</span>' +
    ui.field(_t('Размер значков'), ui.stepper(size, ctx.set('iconSize', Math.max(12, size - 4)), ctx.set('iconSize', Math.min(96, size + 4)), ' px')) +
    ui.sw(_t('Рамка вокруг кнопки'), mod.iconFrame !== false, ctx.act('m.iconFrame = m.iconFrame === false;'));
}

CMS.editor('menu', function (mod, ctx) {
  var ui = ctx.ui, J = ctx.jsArg;
  var html = ui.field(_t('Вид на сайте'), ui.segm([['list', _t('Списком'), 'vRow'], ['drop', _t('Бургер'), 'vBurger']], mod.menuType || 'list', function (k) { return ctx.set('menuType', J(k)); }),
      '') +
    ui.field(_t('Меню по кнопке ☰'), ui.segm([['full', _t('На весь экран'), 'vFullscreen'], ['dropdown', _t('Выпадающее'), 'vDropdown']], mod.burgerView || 'full', function (k) { return ctx.set('burgerView', J(k)); }),
      _t('Кнопка ☰ есть всегда в режиме «Бургер» и на телефоне — в режиме «Списком».')) +
    (mod.burgerView === 'dropdown' ? '' :
      ui.sw(_t('Название сайта в меню'), mod.showName !== false, ctx.act('m.showName = m.showName === false;')) +
      ui.sw(_t('Соцсети в меню'), mod.showSocial !== false, ctx.act('m.showSocial = m.showSocial === false;')) +
      (mod.showSocial !== false ? _t('<span class="ad-f__hint" style="margin-top:-10px">Берутся из модуля «Соцсети» в шапке, подвале или на странице.</span>') : '')) +
    burgerIcons(mod, ctx) +
    ui.field(_t('Страницы'), ui.segm([['all', _t('Все')], ['selected', _t('Выбранные')]], mod.pagesMode || 'all', function (k) { return ctx.set('pagesMode', J(k)); }));
  if (mod.pagesMode === 'selected') {
    html += '<div class="ad-checks">' + ctx.menuTree.map(function (pg) {
      var on = !!(mod.selected && mod.selected[pg.title]);
      return '<button type="button" role="checkbox" aria-checked="' + on + '" class="ad-check' + (on ? ' is-on' : '') + '" style="padding-left:' + (pg.child ? 30 : 10) + 'px" ' +
        'onclick="' + ctx.act('var k=' + J(pg.title) + '; m.selected[k]=!m.selected[k];') + '"><span class="ad-check__box">' + (on ? ui.ico('check', 12) : '') + '</span>' + ctx.esc(pg.title) + '</button>';
    }).join('') + '</div>';
  }
  return html;
});

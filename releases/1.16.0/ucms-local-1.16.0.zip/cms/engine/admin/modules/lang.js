'use strict';
// Переключатель языков: списком / выпадающий.
CMS.editor('lang', function (mod, ctx) {
  var ui = ctx.ui;
  return ui.field(_t('Вид на сайте'), ui.segm([['list', _t('Списком'), 'vRow'], ['drop', _t('Выпадающий'), 'vSelect']], mod.langMode || 'list', function (k) { return ctx.set('langMode', ctx.jsArg(k)); }),
    _t('На сайте появляется, только когда языков два или больше.'));
});

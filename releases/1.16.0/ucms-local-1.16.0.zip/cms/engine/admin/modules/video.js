'use strict';
// Видео: ссылка (YouTube/Vimeo), режим «в окне по клику», обложка, проверка в модалке.
// .ad-vcover__btn обрабатывает server-bridge.js (загрузка обложки).
CMS.editor('video', function (mod, ctx) {
  var ui = ctx.ui;
  function ytId(u) { var m = String(u || '').match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/); return m ? m[1] : null; }
  var yid = ytId(mod.url);
  var cover = mod.cover
    ? '<img src="' + ctx.escAttr(mod.cover) + '" alt="">'
    : yid ? '<img src="https://img.youtube.com/vi/' + yid + '/hqdefault.jpg" alt="">' : '';

  var html = ui.field(_t('Ссылка на видео'), ui.input({ value: mod.url, mono: true, placeholder: 'https://youtube.com/watch?v=…', oninput: ctx.set('url', 'this.value', true) }), _t('YouTube, Vimeo или прямая ссылка для встраивания.')) +
    ui.sw(_t('Открывать в окне по клику'), mod.preview, ctx.act('m.preview=!m.preview;'));
  if (mod.preview) {
    html += ui.field(_t('Обложка'), '<div class="ad-f__row">' +
      ui.btn(mod.cover ? _t('Заменить') : _t('Загрузить'), '', { sm: true, variant: 'line', icon: 'upload', cls: 'ad-vcover__btn' }) +
      (mod.cover ? ui.btn(_t('Убрать'), ctx.call('videoClearCover'), { sm: true }) : '') + '</div>',
      mod.cover ? '' : (yid ? _t('Без своей обложки берётся кадр из YouTube.') : _t('Для этого видео обложку нужно загрузить.')));
  }
  html += '<button type="button" class="ad-vprev"' + (mod.url ? ' onclick="' + ctx.call('videoOpenModal') + '"' : ' disabled') + _t(' aria-label="Проверить видео">') + cover +
    '<span class="ad-vprev__play">' + ui.ico('play', 18) + '</span><span class="ad-vprev__tag">' + (mod.preview ? _t('В окне по клику') : _t('Встроено в страницу')) + '</span></button>';
  if (mod._modal && mod.url) {
    html += '<div class="ad-vmodal" onclick="' + ctx.call('videoCloseModal') + '"><div class="ad-vmodal__box" onclick="event.stopPropagation()">' +
      '<iframe src="' + ctx.escAttr(ctx.embedUrl(mod.url)) + _t('" title="Видео" allow="autoplay;fullscreen;picture-in-picture" allowfullscreen></iframe>') +
      _t('<button type="button" class="ad-vmodal__x" aria-label="Закрыть" onclick="') + ctx.call('videoCloseModal') + '">' + ui.ico('close', 16) + '</button></div></div>';
  }
  return html;
});

'use strict';
// Галерея: сетка / лента / слайдер, список изображений с перетаскиванием,
// подписью, alt и ссылкой. Классы .ad-gal-grid / .ad-gal-card / .ad-gal-up__btn
// использует server-bridge.js для загрузки файла в нужный элемент.
CMS.editor('gallery', function (mod, ctx) {
  var ui = ctx.ui, t = ctx.tree, id = mod.id, J = ctx.jsArg;
  var mode = mod.mode || 'grid';
  var size = mode === 'grid'
    ? ui.field(_t('Колонок'), ui.stepper(mod.cols, ctx.set('cols', 'Math.max(1,' + mod.cols + '-1)'), ctx.set('cols', 'Math.min(6,' + mod.cols + '+1)')))
    : ui.field(_t('Высота'), ui.stepper(mod.height, ctx.set('height', 'Math.max(100,' + mod.height + '-50)'), ctx.set('height', mod.height + '+50'), ' px'));
  // Слайдер и лента: индикатор, автоперелистывание, стрелки
  var nav = '';
  if (mode === 'slider' || mode === 'scroll') {
    var auto = parseInt(mod.autoplay, 10) || 0, arrows = mod.arrows || 'default', asz = parseInt(mod.arrowSize, 10) || 40;
    var arrowImg = function (field, label) {
      var v = mod[field];
      return '<div class="ad-f" style="gap:4px;align-items:center"><button type="button" class="ad-gi__thumb ad-mod-up ad-arrow-up" data-field="' + field + '" aria-label="' + label + '">' +
        (v ? '<img src="' + ctx.escAttr(v) + '" alt="">' : ui.ico('upload', 18)) + '</button><span class="ad-f__hint">' + label + '</span>' +
        (v ? '<button type="button" class="ad-b ad-b--sm" onclick="' + ctx.set(field, "''") + _t('">Убрать</button>') : '') + '</div>';
    };
    if (mode === 'slider') {
      nav += ui.field(_t('Индикатор слайдов'), ui.segm([['dots', _t('Точки'), 'indDots'], ['thumbs', _t('Превью'), 'indThumbs'], ['none', _t('Нет'), 'none']], mod.indicator || 'dots', function (k) { return ctx.set('indicator', J(k)); }));
    }
    nav += ui.field(_t('Автоперелистывание'), ui.stepper(auto ? auto + _t(' с') : _t('выкл'), ctx.set('autoplay', Math.max(0, auto - 1)), ctx.set('autoplay', Math.min(60, auto + 1))),
        auto ? _t('Пауза, пока курсор над галереей.') : _t('0 — выключено.')) +
      ui.field(_t('Стрелки'), ui.segm([['default', _t('Стандартные')], ['custom', _t('Свои')], ['none', _t('Нет')]], arrows, function (k) { return ctx.set('arrows', J(k)); }));
    if (arrows === 'custom') {
      nav += '<div class="ad-arrows">' + arrowImg('arrowPrev', _t('Назад')) + arrowImg('arrowNext', _t('Вперёд')) + '</div>' +
        _t('<span class="ad-f__hint" style="margin-top:-10px">PNG, SVG, GIF. Можно загрузить только «Вперёд» — «Назад» будет её зеркальной копией.</span>');
    }
    if (arrows !== 'none') {
      nav += ui.field(_t('Расположение стрелок'), ui.segm([['sides', _t('По краям'), 'arrSides'], ['bottom', _t('Снизу'), 'arrBottom']], mod.arrowPos || 'sides', function (k) { return ctx.set('arrowPos', J(k)); })) +
        ui.field(_t('Размер стрелок'), ui.stepper(asz, ctx.set('arrowSize', Math.max(20, asz - 4)), ctx.set('arrowSize', Math.min(120, asz + 4)), ' px'));
    }
  }
  var items = mod.items.map(function (img, i) {
    var thumb = img.src
      ? _t('<div class="ad-gi__thumb ad-gal-up__btn" title="Заменить"><img src="') + ctx.escAttr(img.src) + '" alt=""></div>'
      : _t('<button type="button" class="ad-gi__thumb ad-gal-up__btn" aria-label="Загрузить изображение">') + ui.ico('upload', 18) + '</button>';
    return '<div class="ad-gal-card ad-gi" draggable="true" ondragstart="event.stopPropagation();App.galDragStart(' + J(t) + ',' + J(id) + ',' + i + ')" ondragover="event.preventDefault();event.stopPropagation()" ondrop="event.preventDefault();event.stopPropagation();App.galDrop(' + J(t) + ',' + J(id) + ',' + i + ')">' +
      '<div class="ad-gi__row">' + thumb + '<div class="ad-gi__fields">' +
      ui.input({ value: img.caption, placeholder: _t('Подпись'), oninput: 'App.galSetItemField(' + J(t) + ',' + J(id) + ',' + J(img.id) + ',\'caption\',this.value)' }) +
      ui.input({ value: img.alt, placeholder: _t('Alt-текст'), oninput: 'App.galSetItemField(' + J(t) + ',' + J(id) + ',' + J(img.id) + ',\'alt\',this.value)' }) +
      '</div><div class="ad-gi__tools"><span class="ad-gi__n">' + (i + 1) + '</span>' +
      ui.ib('del', _t('Удалить изображение'), 'App.galDelItem(' + J(t) + ',' + J(id) + ',' + J(img.id) + ')', { danger: true }) + '</div></div>' +
      (mod.preview ? '' : ctx.linkField(t, id, img.link, ctx.pages, ctx.itemPath(img.id))) + '</div>';
  }).join('');
  return ui.field(_t('Вид'), ui.segm([['grid', _t('Сетка'), 'vGrid'], ['scroll', _t('Лента'), 'vScroll'], ['slider', _t('Слайдер'), 'vSlider']], mode, function (k) { return ctx.set('mode', J(k)); })) +
    size + nav +
    ui.sw(_t('Открывать фото по клику'), mod.preview, ctx.act('m.preview=!m.preview;')) +
    _t('<div class="ad-f"><div class="ad-f__row"><span class="ad-f__l">Изображения · ') + mod.items.length + '</span>' +
    ui.btn(_t('Добавить'), 'App.galAddItem(' + J(t) + ',' + J(id) + ')', { sm: true, variant: 'accent', icon: 'plus' }) + '</div>' +
    '<div class="ad-gal-grid ad-gi-list">' + (items || _t('<div class="ad-empty2">Нет изображений</div>')) + '</div>' +
    (mod.items.length > 1 ? _t('<span class="ad-f__hint">Порядок меняется перетаскиванием.</span>') : '') + '</div>';
});

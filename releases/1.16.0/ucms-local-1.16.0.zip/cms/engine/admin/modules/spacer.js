'use strict';
// Отступ: пустое место, высота отдельно для компьютера и телефона.
CMS.editor('spacer', function (mod, ctx) {
  var ui = ctx.ui, h = parseInt(mod.height, 10) || 0, hm = mod.heightMobile == null || mod.heightMobile === '' ? Math.round(h * 0.6) : parseInt(mod.heightMobile, 10) || 0;
  return ui.field(_t('Высота на компьютере'), ui.stepper(h, ctx.set('height', Math.max(0, h - 8)), ctx.set('height', Math.min(400, h + 8)), ' px')) +
    ui.field(_t('Высота на телефоне'), ui.stepper(hm, ctx.set('heightMobile', Math.max(0, hm - 8)), ctx.set('heightMobile', Math.min(400, hm + 8)), ' px'),
      _t('По умолчанию — 60% от высоты на компьютере.'));
});

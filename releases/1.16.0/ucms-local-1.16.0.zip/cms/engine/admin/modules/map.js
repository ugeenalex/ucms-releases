'use strict';
// Карта: ссылка встраивания или код <iframe> из Яндекс/Google Карт.
CMS.editor('map', function (mod, ctx) {
  var ui = ctx.ui, h = parseInt(mod.height, 10) || 400;
  var m = String(mod.url || '').match(/src\s*=\s*["']([^"']+)["']/i), src = m ? m[1] : String(mod.url || '').trim();
  var bad = mod.url && !/^https:\/\//i.test(src);
  return ui.field(_t('Код или ссылка карты'), _t('<textarea class="ad-in ad-in--mono ad-tr__ta" rows="4" spellcheck="false" aria-label="Код карты" placeholder="&lt;iframe src=&quot;https://yandex.ru/map-widget/v1/?…&quot;&gt;&lt;/iframe&gt;" oninput="') + ctx.set('url', 'this.value', true) + '">' + ctx.esc(mod.url) + '</textarea>',
      bad ? _t('<span style="color:var(--danger)">Не нашёл ссылку https:// — вставьте код встраивания целиком.</span>')
          : _t('Яндекс: «Поделиться» → «Виджет с картой» → «Скопировать код». Google: «Поделиться» → «Встраивание карт» → «Копировать HTML».')) +
    ui.field(_t('Высота'), ui.stepper(h, ctx.set('height', Math.max(200, h - 50)), ctx.set('height', Math.min(900, h + 50)), ' px'));
});

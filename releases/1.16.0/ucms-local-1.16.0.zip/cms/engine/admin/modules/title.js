'use strict';
// Заголовок H1–H4 с необязательной ссылкой.
CMS.editor('title', function (mod, ctx) {
  var ui = ctx.ui;
  return ui.field(_t('Уровень'), ui.segm([['H1', 'H1'], ['H2', 'H2'], ['H3', 'H3'], ['H4', 'H4']], mod.level || 'H2',
      function (v) { return ctx.set('level', ctx.jsArg(v)); })) +
    ui.field(_t('Текст заголовка'), ui.input({ value: mod.text, placeholder: _t('Текст заголовка'), oninput: ctx.set('text', 'this.value', true) })) +
    ctx.linkField(ctx.tree, mod.id, mod.link, ctx.pages, ctx.path);
});

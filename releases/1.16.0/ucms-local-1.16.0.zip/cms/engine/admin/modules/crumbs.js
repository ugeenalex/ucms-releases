'use strict';
// Хлебные крошки: строятся автоматически из дерева страниц.
CMS.editor('crumbs', function (mod, ctx) {
  var ui = ctx.ui;
  return ui.note(_t('Путь «Главная / Раздел / Страница» строится из вложенности страниц в меню (параметр «Родитель» у страницы). Удобно ставить в шапку.')) +
    ui.sw(_t('Показывать на главной странице'), !!mod.showOnHome, ctx.act('m.showOnHome=!m.showOnHome;'));
});

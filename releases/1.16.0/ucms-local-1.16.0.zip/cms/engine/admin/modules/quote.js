'use strict';
// Цитата или отзыв: текст, автор, подпись, фото (.ad-upload__btn → server-bridge.js пишет в src).
CMS.editor('quote', function (mod, ctx) {
  var ui = ctx.ui;
  var photo = mod.src
    ? '<div class="ad-f__row" style="justify-content:flex-start"><img class="ad-avatar" src="' + ctx.escAttr(mod.src) + '" alt="">' +
      ui.btn(_t('Заменить'), '', { sm: true, variant: 'line', cls: 'ad-upload__btn' }) + ui.btn(_t('Убрать'), ctx.set('src', "''"), { sm: true }) + '</div>'
    : ui.btn(_t('Загрузить фото'), '', { sm: true, variant: 'line', icon: 'upload', cls: 'ad-upload__btn' });
  return ui.field(_t('Текст'), _t('<textarea class="ad-in ad-tr__ta" rows="4" aria-label="Текст цитаты" oninput="') + ctx.set('text', 'this.value', true) + '">' + ctx.esc(mod.text) + '</textarea>') +
    ui.field(_t('Автор'), ui.input({ value: mod.author, placeholder: _t('Анна Иванова'), oninput: ctx.set('author', 'this.value', true) })) +
    ui.field(_t('Подпись'), ui.input({ value: mod.role, placeholder: _t('Клиент, Алматы'), oninput: ctx.set('role', 'this.value', true) })) +
    ui.field(_t('Фото автора'), '<div>' + photo + '</div>');
});

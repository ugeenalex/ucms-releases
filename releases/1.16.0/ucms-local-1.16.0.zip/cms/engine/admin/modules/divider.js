'use strict';
// Разделитель: толщина линии в px.
CMS.editor('divider', function (mod, ctx) {
  var ui = ctx.ui, w = parseInt(mod.width, 10) || 2;
  return ui.field(_t('Толщина линии'), ui.stepper(w, ctx.set('width', Math.max(1, w - 1)), ctx.set('width', Math.min(40, w + 1)), ' px')) +
    '<div class="ad-hrprev" style="height:' + w + 'px"></div>';
});

'use strict';
// «Имя сайта» — выводит название сайта, собственных настроек нет.
CMS.editor('sitename', function (mod, ctx) {
  var ui = ctx.ui;
  return ui.note(_t('Выводит название сайта <b>') + ctx.esc(ctx.siteName || _t('Мой сайт')) + _t('</b> со ссылкой на главную. Своих настроек у модуля нет.')) +
    '<div>' + ui.btn(_t('Изменить название'), "App.setView('site')", { sm: true, variant: 'line' }) + '</div>';
});

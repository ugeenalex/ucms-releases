'use strict';
// Произвольный HTML: код с подсветкой или предпросмотр в iframe со стилями сайта.
CMS.editor('html', function (mod, ctx) {
  var ui = ctx.ui, preview = !!mod._preview;
  var mode = ui.field(_t('Режим'), ui.segm([['code', _t('Код')], ['preview', _t('Предпросмотр')]], preview ? 'preview' : 'code', function (k) {
    return (k === 'preview') === preview ? '' : ctx.call('htmlTogglePreview');
  }));
  if (preview) {
    return mode + '<iframe data-frame="' + mod.id + _t('" title="Предпросмотр HTML" class="ad-frame"></iframe>') +
      _t('<span class="ad-f__hint">Стили берутся из CSS сайта (последняя генерация), а не админки.</span>');
  }
  return mode + '<div class="ad-code-wrap"><pre class="ad-code-hl">' + SyntaxHL.html(mod.code) + '</pre>' +
    _t('<textarea class="ad-code-ta" spellcheck="false" aria-label="HTML-код" oninput="App.paintCode(this,') + ctx.jsArg(ctx.tree) + ',' + ctx.jsArg(mod.id) + ',\'code\')" onscroll="App.syncCodeScroll(this)">' + ctx.esc(mod.code) + '</textarea></div>';
});

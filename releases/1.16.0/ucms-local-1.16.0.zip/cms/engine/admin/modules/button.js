'use strict';
// Кнопка-ссылка: текст на кнопке + ссылка.
CMS.editor('button', function (mod, ctx) {
  var ui = ctx.ui;
  return ui.field(_t('Текст кнопки'), ui.input({ value: mod.text, placeholder: _t('Например, «Записаться»'), oninput: ctx.set('text', 'this.value', true) })) +
    ctx.linkField(ctx.tree, mod.id, mod.link, ctx.pages, ctx.path, _t('Куда ведёт'));
});

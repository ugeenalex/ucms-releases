'use strict';
// Преимущества: «иконка + заголовок + текст» сеткой в 1–4 колонки.
// Иконка — своя картинка (png/jpg/svg/gif): кнопки .ad-li-up загружает server-bridge.js.
CMS.editor('features', function (mod, ctx) {
  var ui = ctx.ui, J = ctx.jsArg, size = parseInt(mod.iconSize, 10) || 48;
  return ui.field(_t('Колонок'), ui.segm([['1', '1'], ['2', '2'], ['3', '3'], ['4', '4']], String(mod.cols || 3), function (k) { return ctx.set('cols', k); }), _t('На телефоне — всегда одна.')) +
    ui.field(_t('Иконка'), ui.segm([['top', _t('Сверху'), 'iconTop'], ['left', _t('Слева'), 'iconLeft']], mod.iconSide || 'top', function (k) { return ctx.set('iconSide', J(k)); })) +
    ui.field(_t('Размер иконки'), ui.stepper(size, ctx.set('iconSize', Math.max(16, size - 8)), ctx.set('iconSize', Math.min(160, size + 8)), ' px')) +
    ui.list(ctx, mod.items, _t('Пункты'), _t('Пункт'), function (it, set) {
      // Своя картинка; у пунктов из старых версий вместо неё может быть эмодзи (it.icon)
      var thumb = it.image
        ? '<button type="button" class="ad-gi__thumb ad-li-up ad-feat-ico" data-item="' + it.id + _t('" data-field="image" title="Заменить иконку"><img src="') + ctx.escAttr(it.image) + '" alt=""></button>'
        : '<button type="button" class="ad-gi__thumb ad-li-up ad-feat-ico" data-item="' + it.id + _t('" data-field="image" aria-label="Загрузить иконку">') +
          (it.icon ? '<span class="ad-feat-emoji">' + ctx.esc(it.icon) + '</span>' : ui.ico('upload', 18)) + '</button>';
      var clear = it.image || it.icon
        ? ui.btn(_t('Убрать иконку'), 'App.listSet(' + [ctx.tree, mod.id, it.id, 'image'].map(J).join(',') + ',\'\');App.listSet(' + [ctx.tree, mod.id, it.id, 'icon'].map(J).join(',') + ',\'\');' + ctx.call('renderModule'), { sm: true })
        : '';
      return '<div class="ad-gi__row">' + thumb + '<div class="ad-gi__fields">' +
        ui.input({ value: it.title, placeholder: _t('Заголовок'), oninput: set('title') }) + clear + '</div></div>' +
        _t('<textarea class="ad-in ad-tr__ta" rows="2" aria-label="Текст" placeholder="Короткое описание" oninput="') + set('text') + '">' + ctx.esc(it.text) + '</textarea>';
    }, _t('Иконка — картинка PNG, JPG, SVG или GIF. Нажмите на квадрат, чтобы загрузить.'));
});

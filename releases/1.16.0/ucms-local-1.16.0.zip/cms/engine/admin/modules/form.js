'use strict';
// Обратная связь: простая форма (поля + адрес приёма) или встроенная (embed-URL).
CMS.editor('form', function (mod, ctx) {
  var ui = ctx.ui, J = ctx.jsArg;
  var FIELDS = [['name', _t('Имя')], ['email', 'Email'], ['phone', _t('Телефон')], ['message', _t('Сообщение')]];
  var html = ui.field(_t('Тип'), ui.segm([['simple', _t('Простая')], ['embed', _t('Встроенная')]], mod.formType || 'simple', function (k) { return ctx.set('formType', J(k)); }));
  if (mod.formType === 'embed') {
    return html +
      ui.field(_t('Ссылка на форму'), ui.input({ value: mod.embedUrl, mono: true, placeholder: 'https://docs.google.com/forms/d/e/…/viewform?embedded=true', oninput: ctx.set('embedUrl', 'this.value', true) }),
        _t('Google Forms: «Отправить» → «&lt;&gt;» → адрес из атрибута src (обычно заканчивается на ?embedded=true).')) +
      ui.field(_t('Высота окна, px'), ui.input({ value: mod.embedHeight, mono: true, type: 'number', oninput: ctx.set('embedHeight', 'this.value', true) }));
  }
  return html +
    ui.field(_t('Заголовок формы'), ui.input({ value: mod.title, placeholder: _t('Обратная связь'), oninput: ctx.set('title', 'this.value', true) })) +
    _t('<div class="ad-f" style="gap:0"><span class="ad-f__l" style="margin-bottom:4px">Поля</span>') + FIELDS.map(function (f) {
      return ui.sw(f[1], !!(mod.fields && mod.fields[f[0]]), ctx.act('m.fields[' + J(f[0]) + ']=!m.fields[' + J(f[0]) + '];'));
    }).join('') + '</div>' +
    ui.field(_t('Куда отправлять'), ui.input({ value: mod.endpoint, mono: true, placeholder: _t('https://formspree.io/f/ваш-id'), oninput: ctx.set('endpoint', 'this.value', true) }),
      _t('Адрес сервиса приёма форм без бэкенда (Formspree, Getform и т. п.), метод POST. Без адреса форма никуда не отправится.'));
});

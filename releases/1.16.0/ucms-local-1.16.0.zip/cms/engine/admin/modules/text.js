'use strict';
// Текст: визуальный редактор (contenteditable) или HTML-код с подсветкой.
// onmousedown=preventDefault на панели сохраняет выделение при клике по кнопке.
// Вставка из Word/Google Docs/сайтов очищается от стилей (Clean в app.js).
CMS.editor('text', function (mod, ctx) {
  var ui = ctx.ui, code = !!mod._codeMode;
  var mode = ui.segm([['visual', _t('Визуально')], ['code', 'HTML']], code ? 'code' : 'visual', function (k) {
    return (k === 'code') === code ? '' : ctx.call('textToggleMode');
  });
  if (code) {
    return ui.field(_t('Режим'), mode) +
      '<div class="ad-code-wrap"><pre class="ad-code-hl" style="min-height:160px">' + SyntaxHL.html(mod.html) + '</pre>' +
      _t('<textarea class="ad-code-ta" spellcheck="false" aria-label="HTML текста" oninput="App.paintCode(this,') + ctx.jsArg(ctx.tree) + ',' + ctx.jsArg(mod.id) + ',\'html\')" onscroll="App.syncCodeScroll(this)">' + ctx.esc(mod.html) + '</textarea></div>';
  }
  var B = function (label, title, cmd, val, style) {
    return '<button type="button" class="ad-tb" title="' + title + '" aria-label="' + title + '"' + (style ? ' style="' + style + '"' : '') +
      ' onclick="' + (val ? ctx.call('textExec', cmd, val) : ctx.call('textExec', cmd)) + '">' + label + '</button>';
  };
  return ui.field(_t('Режим'), mode) +
    '<div class="ad-f"><div class="ad-tbar" onmousedown="event.preventDefault()">' +
    B('B', _t('Жирный'), 'bold', '', 'font-weight:700') +
    B('I', _t('Курсив'), 'italic', '', 'font-style:italic;font-weight:600') +
    B('H3', _t('Подзаголовок'), 'formatBlock', '<h3>', 'font-weight:700;font-size:12px') +
    B('¶', _t('Абзац'), 'formatBlock', '<p>', 'font-weight:700') +
    B(Icons.svg('list', 16), _t('Список'), 'insertUnorderedList') +
    B(Icons.svg('quote', 16), _t('Цитата'), 'formatBlock', '<blockquote>') +
    '<button type="button" class="ad-tb" title="' + _t('Ссылка') + '" aria-label="' + _t('Ссылка') + '" onclick="' + ctx.call('textLinkOpen') + '">' + Icons.svg('link', 16) + '</button>' +
    _t('<span class="ad-tbar__sep"></span><button type="button" class="ad-tb ad-tb--wide" title="Убрать всё оформление: у выделенного фрагмента или, без выделения, у всего текста" onclick="') + ctx.call('textClean') + '">' + Icons.svg('eraser', 15) + _t('Очистить стили</button>') +
    '</div><div class="ad-tlink" data-tlink="' + mod.id + '" hidden></div>' +
    _t('<div class="ad-rich" contenteditable="true" role="textbox" aria-multiline="true" aria-label="Текст" data-visual="') + mod.id + '" oninput="' + ctx.set('html', 'this.innerHTML', true) + '">' + mod.html + '</div></div>';
});

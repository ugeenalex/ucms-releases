'use strict';
// Карточки: картинка + заголовок + текст + кнопка-ссылка; опционально — фильтр по ключевым словам.
// Кнопку .ad-li-up (картинка элемента) обрабатывает server-bridge.js.
CMS.editor('cards', function (mod, ctx) {
  var ui = ctx.ui, J = ctx.jsArg, t = ctx.tree, id = mod.id;
  var tags = mod.tags || [];
  var A = function (fn) { return 'App.' + fn + '(' + Array.prototype.slice.call(arguments, 1).map(J).join(',') + ')'; };

  var filter = ui.sw(_t('Фильтр по ключевым словам'), !!mod.filter, ctx.act('m.filter=!m.filter;'));
  if (mod.filter) {
    filter += '<div class="ad-pxbox">' +
      _t('<div class="ad-f"><div class="ad-f__row"><span class="ad-f__l">Ключевые слова · ') + tags.length + '</span>' +
      ui.btn(_t('Слово'), A('tagAdd', t, id), { sm: true, variant: 'accent', icon: 'plus' }) + '</div>' +
      (tags.length ? tags.map(function (tg) {
        return _t('<div class="ad-colrow"><input class="ad-in ad-in--sm" aria-label="Ключевое слово" placeholder="Например, «Дизайн»" value="') + ctx.escAttr(tg.name) + '" ' +
          'oninput="App.tagSet(' + [t, id, tg.id].map(J).join(',') + ',this.value)">' +
          ui.ib('del', _t('Удалить слово'), A('tagDel', t, id, tg.id), { danger: true }) + '</div>';
      }).join('') : _t('<div class="ad-empty2">Добавьте слова — по ним посетитель сможет отфильтровать карточки</div>')) + '</div>' +
      ui.field(_t('Кнопка «показать всё»'), ui.input({ value: mod.allLabel, placeholder: _t('Все'), oninput: ctx.set('allLabel', 'this.value', true) })) +
      _t('<span class="ad-f__hint">На сайте показываются только слова, отмеченные хотя бы у одной карточки.</span></div>');
  }

  var whole = mod.clickMode === 'card';
  return ui.field(_t('Клик по карточке'), ui.segm([['button', _t('Кнопка «Подробнее»')], ['card', _t('Вся карточка')]], whole ? 'card' : 'button', function (k) { return ctx.set('clickMode', J(k)); }),
      whole ? _t('Ссылкой становится вся карточка. Текст кнопки — необязательная подпись внизу.') : '') +
    ui.field(_t('Колонок'), ui.segm([['1', '1'], ['2', '2'], ['3', '3'], ['4', '4']], String(mod.cols || 3), function (k) { return ctx.set('cols', k); }), _t('На телефоне — всегда одна.')) +
    filter +
    ui.list(ctx, mod.items, _t('Карточки'), _t('Карточка'), function (it, set) {
      var thumb = it.image
        ? '<button type="button" class="ad-gi__thumb ad-li-up" data-item="' + it.id + _t('" data-field="image" title="Заменить картинку"><img src="') + ctx.escAttr(it.image) + '" alt=""></button>'
        : '<button type="button" class="ad-gi__thumb ad-li-up" data-item="' + it.id + _t('" data-field="image" aria-label="Загрузить картинку">') + ui.ico('upload', 18) + '</button>';
      var hasLink = it.link && it.link.linkType && it.link.linkType !== 'none';
      var chips = mod.filter && tags.length
        ? _t('<div class="ad-f"><span class="ad-f__l">Ключевые слова карточки</span><div class="ad-tagchips">') + tags.map(function (tg) {
            var on = (it.tags || []).indexOf(tg.id) >= 0;
            return '<button type="button" class="ad-tagchip' + (on ? ' is-on' : '') + '" aria-pressed="' + on + '" onclick="' + A('cardTagToggle', t, id, it.id, tg.id) + '">' +
              (on ? ui.ico('check', 12) : '') + ctx.esc(tg.name || _t('без названия')) + '</button>';
          }).join('') + '</div></div>'
        : '';
      return '<div class="ad-gi__row">' + thumb + '<div class="ad-gi__fields">' +
        ui.input({ value: it.title, placeholder: _t('Заголовок'), oninput: set('title') }) +
        ui.input({ value: it.btnText, placeholder: whole ? _t('Подпись: «Смотреть →» (необязательно)') : _t('Текст кнопки: «Подробнее»'), oninput: set('btnText') }) + '</div></div>' +
        _t('<textarea class="ad-in ad-tr__ta" rows="2" aria-label="Текст" placeholder="Описание" oninput="') + set('text') + '">' + ctx.esc(it.text) + '</textarea>' +
        ctx.linkField(t, id, it.link, ctx.pages, ctx.itemPath(it.id), whole ? _t('Куда ведёт карточка') : _t('Куда ведёт кнопка')) +
        (hasLink ? '' : '<span class="ad-f__hint ad-warn">' + (whole ? _t('Карточка станет кликабельной, когда выбрана ссылка.') : _t('Кнопка появится, когда выбрана ссылка.')) + '</span>') + chips;
    });
});

'use strict';
// Изображение: загрузка, подпись, alt, ссылка или «открывать по клику».
// Кнопки с классом .ad-upload__btn обрабатывает server-bridge.js (загрузка файла).
CMS.editor('image', function (mod, ctx) {
  var ui = ctx.ui;
  var media = mod.src
    ? '<div class="ad-media"><img src="' + ctx.escAttr(mod.src) + '" alt=""><div class="ad-media__bar">' +
      ui.btn(_t('Заменить'), '', { sm: true, icon: 'upload', cls: 'ad-upload__btn ad-b--glass' }) +
      ui.btn(_t('Убрать'), ctx.set('src', "''"), { sm: true, cls: 'ad-b--glass' }) + '</div></div>'
    : '<button type="button" class="ad-drop ad-upload__btn">' + ui.ico('upload', 20) + _t('<b>Загрузить изображение</b><small>JPG, PNG, WebP, SVG</small></button>');
  return media +
    ui.field(_t('Размер'), ui.segm([['fill', _t('По ширине колонки'), 'imgFill'], ['natural', _t('Исходный'), 'imgNatural']], mod.size === 'natural' ? 'natural' : 'fill', function (k) { return ctx.set('size', ctx.jsArg(k)); }),
      mod.size === 'natural' ? _t('Картинка не растягивается больше своего размера.') : '') +
    ui.field(_t('Подпись'), ui.input({ value: mod.caption, placeholder: _t('Подпись под фото'), oninput: ctx.set('caption', 'this.value', true) })) +
    ui.field(_t('Alt-текст'), ui.input({ value: mod.alt, placeholder: _t('Что на фото — для поиска и незрячих'), oninput: ctx.set('alt', 'this.value', true) })) +
    ui.sw(_t('Открывать на весь экран по клику'), mod.preview, ctx.act("m.preview=!m.preview; if(m.preview) m.link={linkType:'none'};")) +
    (mod.preview ? ui.note(_t('Ссылка недоступна: по клику фото открывается в лайтбоксе.')) : ctx.linkField(ctx.tree, mod.id, mod.link, ctx.pages, ctx.path));
});

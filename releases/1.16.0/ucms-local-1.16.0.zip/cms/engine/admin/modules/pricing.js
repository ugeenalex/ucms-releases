'use strict';
// Тарифы: название, цена, период, список возможностей, кнопка; один тариф можно выделить.
CMS.editor('pricing', function (mod, ctx) {
  var ui = ctx.ui, J = ctx.jsArg;
  return ui.list(ctx, mod.items, _t('Тарифы'), _t('Тариф'), function (it, set) {
    return ui.input({ value: it.name, placeholder: _t('Название тарифа'), oninput: set('name') }) +
      '<div class="ad-li__row">' + ui.input({ value: it.price, placeholder: _t('Цена: 990 ₽'), oninput: set('price') }) + ui.input({ value: it.period, placeholder: _t('/ мес'), oninput: set('period') }) + '</div>' +
      _t('<textarea class="ad-in ad-tr__ta" rows="3" aria-label="Возможности" placeholder="Каждая возможность — с новой строки" oninput="') + set('features') + '">' + ctx.esc(it.features) + '</textarea>' +
      ui.input({ value: it.btnText, placeholder: _t('Текст кнопки: «Выбрать»'), oninput: set('btnText') }) +
      ctx.linkField(ctx.tree, mod.id, it.link, ctx.pages, ctx.itemPath(it.id), _t('Куда ведёт кнопка')) +
      ui.sw(_t('Выделить тариф'), !!it.highlight, 'App.listFlip(' + [ctx.tree, mod.id, it.id, 'highlight'].map(J).join(',') + ')');
  }, _t('Без ссылки кнопка не показывается.'));
});

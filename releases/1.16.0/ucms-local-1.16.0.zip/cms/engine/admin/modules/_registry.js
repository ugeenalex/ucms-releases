'use strict';
/*
 * Реестр редакторов админки. Вариант Б: один тип блока = один файл.
 *
 * Каждый файл engine/admin/modules/<type>.js регистрирует свой редактор:
 *     CMS.editor('<type>', function (mod, ctx) { return '<html-строка полей>'; });
 *
 * mod  — объект блока из db (его поля правим через App.* обработчики в onclick).
 * ctx  — всё, что нужно редактору, чтобы файл не лез во внутренности app.js:
 *   ctx.tree        имя дерева ('page' | 'header' | 'footer')
 *   ctx.pages       список названий страниц (для поля ссылки)
 *   ctx.menuTree    дерево страниц (title/child) — для модуля «меню»
 *   ctx.path        уникальный путь блока ('mod:'+id) — для поповеров ссылки
 *   ctx.openPopover какой поповер сейчас открыт (state.openPopover)
 *   ctx.esc/escAttr экранирование текста/значений атрибутов
 *   ctx.linkField(tree,id,link,pages,path)  поле выбора ссылки
 *   ctx.popover(innerHtml,opts)             обёртка выпадающего поповера
 *   ctx.toggle(on,dataToggle,onclick)       тумблер
 *   ctx.embedUrl(url)                        URL для встраивания видео
 *   ctx.ui        UI-кит полей: field(label, inner, hint), input({value, oninput, placeholder, mono, type}),
 *                 segm(options, active, onclickOf), sw(label, on, onclick), btn(label, onclick, {icon, variant, sm}),
 *                 stepper(value, onMinus, onPlus, suffix), note(html), ico(name, size), ib(icon, label, onclick, {danger})
 *   ctx.set(field, valueExpr, noRender)      строка-вызов App.setModuleField для этого модуля
 *   ctx.act(body)                            строка-вызов App.moduleAction(…, function(m){ body })
 *   ctx.call(fn, ...args)                    строка-вызов App.fn(tree, id, ...args) с экранированием
 *   ctx.linkField(tree, id, link, pages, path, label?)  поле ссылки «Нет / URL / Страница»
 * Редактор возвращает плоский набор полей — инспектор раскладывает их столбцом.
 * Глобальные Icons, SyntaxHL, moduleIconHTML доступны напрямую (отдельные скрипты).
 */
(function () {
  window.CMS = window.CMS || {};
  CMS.editors = {};
  CMS.editor = function (type, render) { CMS.editors[type] = render; };
  CMS.hasEditor = function (type) { return typeof CMS.editors[type] === 'function'; };
})();

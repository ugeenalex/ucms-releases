'use strict';
// «Список записей» коллекции: карточки или список, дата/анонс/обложка, фильтр по тегам, «Показать ещё».
// Записи и сами коллекции — в сайдбаре «Коллекции» (collections.js / server-bridge.js).
CMS.editor('collection', function (mod, ctx) {
  var ui = ctx.ui, J = ctx.jsArg;
  var colls = (App._state.collections || []);
  if (!colls.length) {
    return ui.note(_t('Коллекций пока нет. Коллекция — это набор записей с датой: блог, новости, портфолио, каталог.')) +
      ui.btn(_t('Создать коллекцию'), 'App.addCollection()', { variant: 'accent', icon: 'plus' });
  }
  var c = App.collById(mod.collection);
  var sel = '<select class="ad-in" aria-label="' + ctx.escAttr(_t('Коллекция')) + '" onchange="' + ctx.set('collection', 'this.value') + '">' +
    (c ? '' : '<option value="" selected>' + _t('— выберите —') + '</option>') +
    colls.map(function (x) { return '<option value="' + ctx.escAttr(x.id) + '"' + (c && x.id === c.id ? ' selected' : '') + '>' + ctx.esc(x.name) + '</option>'; }).join('') + '</select>';
  var sw = function (label, f) { return ui.sw(label, mod[f] !== false, ctx.act('m.' + f + '=m.' + f + '===false;')); };
  var num = function (f, ph) {
    return '<input class="ad-in" type="number" min="0" step="1" placeholder="' + ph + '" value="' + ctx.escAttr(parseInt(mod[f], 10) || '') + '" oninput="' + ctx.set(f, 'Math.max(0,parseInt(this.value,10)||0)', true) + '">';
  };

  var html = ui.field(_t('Коллекция'), sel, c ? '<button type="button" class="ad-linkbtn" onclick="App.openCollDrawer(' + J(c.id) + ')">' + _t('Настройки коллекции') + '</button> · ' +
    '<button type="button" class="ad-linkbtn" onclick="App.addEntry(' + J(c.id) + ')">' + _t('Новая запись') + '</button>' : '');
  if (!c) return html;

  var list = mod.layout === 'list';
  html += ui.field(_t('Вид'), ui.segm([['grid', _t('Карточки'), 'vGrid'], ['list', _t('Список'), 'vList']], list ? 'list' : 'grid', function (k) { return ctx.set('layout', J(k)); })) +
    (list ? '' : ui.field(_t('Колонок'), ui.segm([['1', '1'], ['2', '2'], ['3', '3'], ['4', '4']], String(mod.cols || 3), function (k) { return ctx.set('cols', k); }), _t('На телефоне — всегда одна.'))) +
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">' +
    ui.field(_t('Показывать по'), num('perPage', _t('все'))) + ui.field(_t('Всего не больше'), num('limit', _t('без ограничения'))) + '</div>' +
    '<span class="ad-f__hint">' + _t('«Показывать по» — сколько записей видно сразу, остальные по кнопке «Показать ещё».') + '</span>' +
    '<div class="ad-f" style="gap:4px"><span class="ad-eyebrow2">' + _t('В карточке записи') + '</span>' +
    sw(_t('Обложка'), 'showCover') + sw(_t('Дата'), 'showDate') + sw(_t('Анонс'), 'showExcerpt') + '</div>' +
    ui.field(_t('Подпись-ссылка'), ui.input({ value: mod.readLabel, placeholder: _t('Например, «Читать»'), oninput: ctx.set('readLabel', 'this.value', true) }), _t('Кликабельна вся карточка; подпись — необязательная подсказка внизу.'));

  // Фильтр по тегам и «только с тегами»
  var tags = App.collTags(c.id);
  var only = Array.isArray(mod.onlyTags) ? mod.onlyTags : [];
  html += ui.sw(_t('Фильтр по тегам'), !!mod.filter, ctx.act('m.filter=!m.filter;')) +
    (mod.filter ? ui.field(_t('Кнопка «показать всё»'), ui.input({ value: mod.allLabel, placeholder: _t('Все'), oninput: ctx.set('allLabel', 'this.value', true) }), _t('Кнопки фильтра — теги записей; появятся, когда тегов хотя бы два.')) : '');
  if (tags.length) {
    html += '<div class="ad-f"><span class="ad-f__l">' + _t('Только записи с тегами') + '</span><div class="ad-tagchips">' + tags.map(function (t) {
      var on = only.indexOf(t) >= 0;
      var body = 'var a=Array.isArray(m.onlyTags)?m.onlyTags:[],t=' + J(t) + ',i=a.indexOf(t);if(i>=0)a.splice(i,1);else a.push(t);m.onlyTags=a;';
      return '<button type="button" class="ad-tagchip' + (on ? ' is-on' : '') + '" aria-pressed="' + on + '" onclick="' + ctx.act(body) + '">' + (on ? ui.ico('check', 12) : '') + ctx.esc(t) + '</button>';
    }).join('') + '</div><span class="ad-f__hint">' + _t('Ничего не отмечено — все записи коллекции. Удобно для блока «Похожие записи».') + '</span></div>';
  }
  html += ui.field(_t('Кнопка «Показать ещё»'), ui.input({ value: mod.moreLabel, placeholder: _t('Показать ещё'), oninput: ctx.set('moreLabel', 'this.value', true) })) +
    ui.field(_t('Если записей нет'), ui.input({ value: mod.emptyText, placeholder: _t('Ничего не выводить'), oninput: ctx.set('emptyText', 'this.value', true) }));
  return html;
});

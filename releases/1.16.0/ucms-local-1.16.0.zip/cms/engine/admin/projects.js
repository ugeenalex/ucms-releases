/* Стартовая страница UCMS: список проектов (сайтов), создание, добавление,
   копирование, перенос. Один движок — много проектов, у каждого своя папка. */
(function () {
  'use strict';
  var app = document.getElementById('app');
  var ADMIN_WIN = 'ucms-admin';
  window.name = 'ucms-projects';   // чтобы «Все проекты» в админке возвращали в эту же вкладку
  // Вернулись на вкладку (например, после правок в админке) — обновить список
  document.addEventListener('visibilitychange', function () { if (!document.hidden && !S.dialog) load(); });
  var S = { projects: [], active: null, defaultRoot: '', registry: '', version: '', dialog: null, browse: null, error: '', upd: null, updBusy: '', notesOpen: false };

  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function sepOf(p) { return /\\/.test(p) ? '\\' : '/'; }
  function join(dir, name) { var sp = sepOf(dir); return dir.replace(/[\\/]+$/, '') + sp + name; }
  function folderName(name) { return String(name || '').trim().replace(/[<>:"/\\|?*\u0000-\u001f]+/g, '-').replace(/\s+/g, ' ').slice(0, 60) || 'site'; }
  function fmtDate(iso) {
    if (!iso) return _t('ещё не открывался');
    var d = new Date(iso), p = function (n) { return String(n).padStart(2, '0'); };
    return p(d.getDate()) + '.' + p(d.getMonth() + 1) + '.' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }
  function ico(name, size) { return window.Icons && Icons.svg ? Icons.svg(name, size || 16) : ''; }

  function api(path, body) {
    return fetch(path, body === undefined ? undefined : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().then(function (d) { if (!r.ok || d.ok === false) throw new Error(d.error || ('HTTP ' + r.status)); return d; }); });
  }
  function load() {
    return api('/api/projects').then(function (d) {
      S.projects = d.projects; S.active = d.active; S.defaultRoot = d.defaultRoot; S.registry = d.registry; S.version = d.version;
      render();
      return loadUpd();
    }).catch(function (e) { S.error = e.message; render(); });
  }
  function loadUpd() { return api('/api/update').then(function (d) { S.upd = d; render(); }).catch(function () {}); }

  /* ── Обновление движка: проверка, установка, откат, перезапуск ── */
  // Описание релиза (markdown из CHANGELOG) → простой безопасный HTML: списки, **жирный**, `код`
  function notesHTML(md) {
    var inline = function (s) { return esc(s).replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/`([^`]+)`/g, '<code>$1</code>'); };
    var out = [], list = null, item = null;
    String(md || '').replace(/\r/g, '').split('\n').forEach(function (line) {
      var li = /^\s*[-*]\s+(.*)$/.exec(line);
      if (li) { if (!list) { list = []; out.push(list); } item = [li[1]]; list.push(item); return; }
      if (/^\s+\S/.test(line) && item) { item.push(line.trim()); return; }   // продолжение пункта
      list = null; item = null;
      if (line.trim()) out.push(line.replace(/^#+\s*/, ''));
    });
    return out.map(function (b) {
      return Array.isArray(b) ? '<ul>' + b.map(function (it) { return '<li>' + inline(it.join(' ')) + '</li>'; }).join('') + '</ul>' : '<p>' + inline(b) + '</p>';
    }).join('');
  }
  function waitRestart(version) {
    var t0 = Date.now();
    S.updBusy = _t('Перезапуск UCMS…'); render();
    (function poll() {
      fetch('/api/ping', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (d) {
        if (d.version === version) { location.reload(); return; }
        throw new Error('old');
      }).catch(function () {
        if (Date.now() - t0 > 60000) { S.updBusy = ''; S.error = _t('Сервер не запустился сам. Закройте окно UCMS и запустите его снова.'); render(); return; }
        setTimeout(poll, 1000);
      });
    })();
  }
  function afterInstall(d) {
    if (d.restarting) return waitRestart(d.version);
    S.updBusy = '';
    S.error = '';
    S.updDone = _t('Версия') + ' ' + d.version + ' ' + _t('установлена. Закройте окно сервера UCMS и запустите его снова — тогда она заработает.');
    render();
  }
  window.UPD = {
    check: function () {
      S.updBusy = _t('Проверяю…'); render();
      api('/api/update/check', {}).then(function (d) { S.upd = d; S.updBusy = ''; render(); })
        .catch(function (e) { S.updBusy = ''; S.error = e.message; render(); });
    },
    set: function (k, v) { var b = {}; b[k] = v; api('/api/update/settings', b).then(function (d) { S.upd = d; render(); if (k === 'prerelease') UPD.check(); }); },
    notes: function () { S.notesOpen = !S.notesOpen; render(); },
    apply: function () {
      var a = S.upd && S.upd.available; if (!a) return;
      if (!confirm(_t('Обновить UCMS до версии') + ' ' + a.version + '?\n' + _t('Сайты и проекты не изменятся. Текущая версия сохранится — к ней можно будет вернуться.'))) return;
      S.updBusy = _t('Скачиваю и проверяю обновление…'); render();
      api('/api/update/apply', {}).then(afterInstall).catch(function (e) { S.updBusy = ''; S.error = _t('Обновление не установлено:') + ' ' + e.message; loadUpd(); render(); });
    },
    rollback: function (id, ver) {
      if (!confirm(_t('Вернуть UCMS версии') + ' ' + ver + '?')) return;
      S.updBusy = _t('Возвращаю прежнюю версию…'); render();
      api('/api/update/rollback', { id: id }).then(afterInstall).catch(function (e) { S.updBusy = ''; S.error = e.message; render(); });
    },
  };
  function sw(label, on, onclick) {
    return '<label class="pj-sw"><button type="button" role="switch" aria-checked="' + !!on + '" class="ad-toggle' + (on ? ' is-on' : '') + '" onclick="' + onclick + '"><span class="ad-toggle__knob"></span></button>' + esc(label) + '</label>';
  }
  function updBanner() {
    var u = S.upd, a = u && u.available;
    if (!a) return '';
    return '<section class="pj-upd" aria-live="polite"><div class="pj-upd__h">' + ico('download', 18) +
      '<div><b>' + _t('Доступна новая версия UCMS') + ' ' + esc(a.version) + (a.prerelease ? ' <span class="pj-badge">' + _t('тестовая') + '</span>' : '') + '</b>' +
      '<small>' + _t('у вас') + ' ' + esc(u.version) + (a.publishedAt ? ' · ' + _t('выпущена') + ' ' + fmtDate(a.publishedAt).split(' ')[0] : '') + '</small></div>' +
      '<div class="pj-upd__act"><button type="button" class="ad-b ad-b--line ad-b--sm" aria-expanded="' + S.notesOpen + '" onclick="UPD.notes()">' + _t('Что нового') + '</button>' +
      '<button type="button" class="ad-b ad-b--primary ad-b--sm"' + (S.updBusy ? ' disabled' : '') + ' onclick="UPD.apply()">' + _t('Обновить') + '</button></div></div>' +
      (S.notesOpen ? '<div class="pj-upd__notes">' + (notesHTML(a.notes) || esc(a.name)) + '</div>' : '') + '</section>';
  }
  function updPanel() {
    var u = S.upd; if (!u) return '';
    var when = u.checkedAt ? fmtDate(new Date(u.checkedAt).toISOString()) : _t('ещё не проверялось');
    var b = (u.backups || [])[0];
    return '<section class="pj-updp"><div class="pj-updp__row"><b>' + _t('Обновления') + '</b>' +
      '<span class="ad-f__hint">UCMS ' + esc(u.version) + ' · ' + _t('проверено') + ': ' + when +
      (!u.available && u.checkedAt && !u.error ? ' · ' + _t('установлена последняя версия') : '') + '</span>' +
      '<button type="button" class="ad-b ad-b--line ad-b--sm" style="margin-left:auto"' + (S.updBusy ? ' disabled' : '') + ' onclick="UPD.check()">' + _t('Проверить сейчас') + '</button></div>' +
      (u.error ? '<div class="ad-pub__msg is-err">' + esc(u.error) + '</div>' : '') +
      '<div class="pj-updp__row">' + sw(_t('Проверять автоматически'), u.auto, 'UPD.set(\'auto\',' + !u.auto + ')') +
      sw(_t('Тестовые версии'), u.prerelease, 'UPD.set(\'prerelease\',' + !u.prerelease + ')') +
      (b ? '<button type="button" class="ad-b ad-b--sm" style="margin-left:auto"' + (S.updBusy ? ' disabled' : '') + ' onclick="UPD.rollback(' + esc(JSON.stringify(b.id)) + ',' + esc(JSON.stringify(b.version)) + ')">' + ico('undo', 14) + _t('Вернуть версию') + ' ' + esc(b.version) + '</button>' : '') + '</div>' +
      (!u.launcher ? '<span class="ad-f__hint">' + _t('UCMS запущена не через start.bat / ярлык — после обновления её нужно будет перезапустить вручную.') + '</span>' : '') +
      '</section>';
  }
  function updOverlay() {
    return S.updBusy ? '<div class="pj-modal"><div class="pj-modal__box pj-busy"><span class="pj-spin" aria-hidden="true"></span><b>' + esc(S.updBusy) + '</b><small>' + _t('Не закрывайте окно сервера UCMS.') + '</small></div></div>' : '';
  }

  /* ── действия ── */
  window.PJ = {
    // Проект открывается в отдельной вкладке «ucms-admin» (одна на все проекты),
    // список проектов остаётся открытым. Вкладку берём синхронно в клике —
    // иначе браузер сочтёт её всплывающим окном и заблокирует.
    open: function (id) {
      var w = window.open('', ADMIN_WIN);
      api('/api/projects/open', { id: id }).then(function () {
        var url = '/admin/?p=' + encodeURIComponent(id);
        if (w && !w.closed) { w.location.href = url; w.focus(); } else location.href = url;
        load();   // отметка «открыт сейчас»
      }).catch(function (e) { if (w && !w.closed && w.location.href === 'about:blank') w.close(); alert(e.message); });
    },
    reveal: function (id) { api('/api/projects/reveal', { id: id }); },
    remove: function (id) {
      var p = S.projects.filter(function (x) { return x.id === id; })[0];
      if (!p || !confirm(p.remote
        ? _t('Отключить сайт? Данные на сервере не изменятся. Ключ доступа удалится с этого компьютера — отзовите его и в веб-админке.') + '\n' + p.url
        : _t('Убрать проект из списка? Папка с файлами останется на диске:') + '\n' + p.path)) return;
      api('/api/projects/remove', { id: id }).then(load).catch(function (e) { alert(e.message); });
    },
    dialog: function (kind, id) {
      var p = id ? S.projects.filter(function (x) { return x.id === id; })[0] : null;
      var name = kind === 'create' ? '' : kind === 'duplicate' ? (p.siteTitle || p.name) + ' ' + _t('(копия)') : '';
      S.dialog = { kind: kind, id: id || null, name: name, parent: S.defaultRoot, path: '', pathTouched: false, error: '', busy: false,
        src: 'folder', site: { url: '', token: '' }, remote: { protocol: 'ftps', host: '', port: 21, user: '', password: '', dir: '/public_html', projectDir: '', allowSelfSigned: false }, found: null, rpass: '' };
      if (kind === 'create' || kind === 'duplicate') S.dialog.path = join(S.defaultRoot, folderName(name || _t('Новый сайт')));
      S.browse = null;
      render();
      var f = app.querySelector('[data-focus]'); if (f) f.focus();
    },
    close: function () { S.dialog = null; S.browse = null; render(); },
    setName: function (v) {
      var D = S.dialog; D.name = v;
      if (!D.pathTouched) { D.path = join(D.parent, folderName(v || _t('Новый сайт'))); var el = app.querySelector('#pj-path'); if (el) el.value = D.path; }
    },
    setPath: function (v) { S.dialog.path = v; S.dialog.pathTouched = true; },
    browse: function (dir) {
      var D = S.dialog;
      var start = dir != null ? dir : ((D.kind === 'add' && D.src !== 'server') || D.kind === 'relocate' ? (D.path || '') : D.parent);
      fetch('/api/fs/dirs?path=' + encodeURIComponent(start)).then(function (r) { return r.json(); }).then(function (d) {
        if (!d.ok) throw new Error(d.error);
        S.browse = d; render();
      }).catch(function (e) { D.error = e.message; render(); });
    },
    pick: function () {   // выбрать папку, открытую в обзоре
      var D = S.dialog, B = S.browse;
      if (D.kind === 'create' || D.kind === 'duplicate' || D.src === 'server') { D.parent = B.path; D.path = join(B.path, folderName(D.name || _t('Новый сайт'))); D.pathTouched = false; }
      else D.path = B.path;
      S.browse = null; render();
    },
    // «Добавить существующий → Сайт UCMS»: адрес веб-UCMS и ключ доступа
    setSite: function (k, v) { S.dialog.site[k] = v; },
    connect: function () {
      var D = S.dialog; D.error = ''; D.busy = true; render();
      api('/api/projects/connect', { url: D.site.url, token: D.site.token }).then(function (d) {
        S.dialog = null; S.projects = d.projects; S.active = d.active; S.fresh = d.connected;
        S.notice = _t('Сайт подключён — откройте его в списке. Правки будут сохраняться сразу на сервере.');
        render();
      }).catch(function (e) { D.busy = false; D.error = e.message; render(); });
    },
    copy: function (id) {
      S.updBusy = _t('Скачиваю копию сайта с сервера…'); render();
      api('/api/projects/remote-copy', { id: id }).then(function (d) {
        S.updBusy = ''; S.error = '';
        S.notice = _t('Копия сайта сохранена на компьютере:') + ' ' + d.dir;
        load();
      }).catch(function (e) { S.updBusy = ''; S.error = e.message; render(); });
    },
    rekey: function (id) {
      var p = S.projects.filter(function (x) { return x.id === id; })[0]; if (!p) return;
      PJ.dialog('add'); var D = S.dialog; D.src = 'ucms'; D.site.url = p.url; D.rekey = true; render();
    },
    // «Добавить существующий → С сервера»
    setSrc: function (v) { var D = S.dialog; D.src = v; D.error = ''; S.browse = null; render(); },
    setR: function (k, v) {
      var D = S.dialog; D.remote[k] = v;
      if (k === 'protocol') { if (v === 'ftps' && +D.remote.port === 990) D.remote.port = 21; D.found = null; render(); return; }
      // правка подключения после «Найти» — найденное больше не актуально; фокус и курсор остаются в поле
      if (D.found && k !== 'password') {
        var el = document.activeElement, id = el && el.id, pos = el && el.selectionStart;
        D.found = null; render();
        var again = id && document.getElementById(id);
        if (again) { again.focus(); try { again.setSelectionRange(pos, pos); } catch (e) { /* number */ } }
      }
    },
    find: function () {
      var D = S.dialog; D.error = ''; D.busy = true; render();
      api('/api/remote/inspect', { config: D.remote, password: D.rpass || '' }).then(function (d) {
        D.busy = false;
        if (!d.found) { D.found = null; D.error = _t('На сервере нет проекта UCMS для папки сайта') + ' ' + d.site + '. ' + _t('Опубликуйте сайт из UCMS 1.10 или новее — проект сохранится рядом с ним.'); render(); return; }
        D.found = d;
        D.name = d.title || D.remote.host;
        D.path = join(D.parent, folderName(D.name)); D.pathTouched = false;
        render();
      }).catch(function (e) { D.busy = false; D.error = e.message; render(); });
    },
    clone: function () {
      var D = S.dialog; D.error = ''; D.busy = true; render();
      api('/api/remote/clone', { config: D.remote, password: D.rpass || '', path: D.path }).then(function () {
        S.updBusy = _t('Скачиваю проект с сервера…'); render();
        (function poll() {
          api('/api/remote/job').then(function (d) {
            var j = d.job;
            if (j.running) {
              S.updBusy = j.phase === 'files' && j.total ? _t('Скачиваю файлы') + ' ' + j.done + ' / ' + j.total : j.phase === 'connect' ? _t('Подключаюсь к серверу…') : _t('Скачиваю проект с сервера…');
              var el = document.querySelector('.pj-busy b'); if (el) el.textContent = S.updBusy; else render();
              setTimeout(poll, 600); return;
            }
            S.updBusy = '';
            if (j.phase === 'error') { D.busy = false; D.error = j.code === 'BAD_PASSWORD' || j.code === 'NEED_PASSWORD' ? _t('Неверный пароль проекта') : j.error; render(); return; }
            var miss = (j.result.missing || []).length;
            S.dialog = null; S.browse = null;
            S.notice = _t('Проект «') + (j.result.title || '') + _t('» скачан с сервера — откройте его в списке.') + (miss ? ' ' + _t('Не найдено на сервере файлов:') + ' ' + miss : '');
            S.fresh = j.result.id;
            load();
          }).catch(function (e) { S.updBusy = ''; D.busy = false; D.error = e.message; render(); });
        })();
      }).catch(function (e) { D.busy = false; D.error = e.message; render(); });
    },
    submit: function () {
      var D = S.dialog;
      if (D.kind === 'add' && D.src === 'server') return D.found ? PJ.clone() : PJ.find();
      if (D.kind === 'add' && D.src === 'ucms') return PJ.connect();
      D.error = ''; D.busy = true; render();
      var req = D.kind === 'create' ? api('/api/projects/create', { name: D.name, path: D.path })
        : D.kind === 'duplicate' ? api('/api/projects/duplicate', { id: D.id, name: D.name, path: D.path })
        : D.kind === 'relocate' ? api('/api/projects/relocate', { id: D.id, path: D.path })
        : api('/api/projects/add', { path: D.path });
      req.then(function (d) {
        if (D.kind === 'create') {
          S.dialog = null; S.projects = d.projects; S.active = d.active; render();
          var w = window.open('/admin/?p=' + encodeURIComponent(d.active), ADMIN_WIN);
          if (!w) location.href = '/admin/?p=' + encodeURIComponent(d.active);   // вкладку заблокировали — открываем здесь
          return;
        }
        S.dialog = null; S.browse = null; S.projects = d.projects; S.active = d.active; render();
      }).catch(function (e) { D.busy = false; D.error = e.message; render(); });
    },
  };

  /* ── разметка ── */
  function remoteCard(p) {
    var on = p.id === S.active, title = p.siteTitle || p.name;
    return '<article class="pj-card pj-card--remote' + (on ? ' is-active' : '') + (p.id === S.fresh ? ' is-fresh' : '') + '">' +
      '<div class="pj-card__top"><div class="pj-card__mark">' + ico('cloud', 18) + '</div>' +
      '<div class="pj-card__head"><div class="pj-card__t">' + esc(title) + '</div>' + (on ? '<span class="pj-badge">' + _t('открыт сейчас') + '</span>' : '<span class="pj-badge pj-badge--srv">' + _t('на сервере') + '</span>') + '</div></div>' +
      '<div class="pj-card__path" title="' + esc(p.url) + '">' + esc(p.url) + '</div>' +
      '<div class="pj-card__meta">' + esc(p.user || '') + (p.role ? ' · ' + (p.role === 'owner' ? _t('владелец') : _t('редактор')) : '') + ' · ' + (p.openedAt ? _t('открыт') + ' ' + fmtDate(p.openedAt) : _t('ещё не открывался')) +
        '<br>' + (p.copy ? _t('копия на компьютере:') + ' ' + fmtDate(new Date(p.copy.at).toISOString()) : '<span class="pj-warn">' + _t('копии на компьютере ещё нет') + '</span>') + '</div>' +
      '<div class="pj-card__actions"><button type="button" class="ad-b ad-b--primary" onclick="PJ.open(\'' + p.id + '\')">' + _t('Открыть') + '</button>' +
      '<button type="button" class="ad-ib" title="' + esc(_t('Сделать копию на компьютер')) + '" aria-label="' + esc(_t('Сделать копию на компьютер')) + '" onclick="PJ.copy(\'' + p.id + '\')">' + ico('download', 16) + '</button>' +
      '<button type="button" class="ad-ib" title="' + esc(_t('Папка с копиями')) + '" aria-label="' + esc(_t('Папка с копиями')) + '" onclick="PJ.reveal(\'' + p.id + '\')">' + ico('folder', 16) + '</button>' +
      '<button type="button" class="ad-ib" title="' + esc(_t('Новый ключ доступа')) + '" aria-label="' + esc(_t('Новый ключ доступа')) + '" onclick="PJ.rekey(\'' + p.id + '\')">' + ico('key', 16) + '</button>' +
      '<button type="button" class="ad-ib ad-ib--danger" style="margin-left:auto" title="' + esc(_t('Отключить сайт')) + '" aria-label="' + esc(_t('Отключить сайт')) + '" onclick="PJ.remove(\'' + p.id + '\')">' + ico('close', 15) + '</button>' +
      '</div></article>';
  }
  function card(p) {
    if (p.remote) return remoteCard(p);
    var on = p.id === S.active, title = p.siteTitle || p.name;
    var meta = p.exists
      ? _t('страниц:') + ' ' + p.pages + (p.languages.length > 1 ? ' · ' + p.languages.join(', ').toUpperCase() : '') + ' · ' + (p.openedAt ? _t('открыт') + ' ' + fmtDate(p.openedAt) : _t('ещё не открывался'))
      : '<span class="pj-warn">' + _t('Папка не найдена или в ней нет db.json') + '</span>';
    return '<article class="pj-card' + (on ? ' is-active' : '') + (p.exists ? '' : ' is-missing') + (p.id === S.fresh ? ' is-fresh' : '') + '">' +
      '<div class="pj-card__top"><div class="pj-card__mark">' + esc((title || '?').trim().charAt(0).toUpperCase()) + '</div>' +
      '<div class="pj-card__head"><div class="pj-card__t">' + esc(title) + '</div>' + (on ? '<span class="pj-badge">' + _t('открыт сейчас') + '</span>' : '') + '</div></div>' +
      '<div class="pj-card__path" title="' + esc(p.path) + '">' + esc(p.path) + '</div>' +
      '<div class="pj-card__meta">' + meta + '</div>' +
      '<div class="pj-card__actions">' +
      (p.exists
        ? '<button type="button" class="ad-b ad-b--primary" onclick="PJ.open(\'' + p.id + '\')">' + _t('Открыть') + '</button>' +
          '<button type="button" class="ad-ib" title="' + esc(_t('Показать папку')) + '" aria-label="' + esc(_t('Показать папку')) + '" onclick="PJ.reveal(\'' + p.id + '\')">' + ico('folder', 16) + '</button>' +
          '<button type="button" class="ad-ib" title="' + esc(_t('Сделать копию')) + '" aria-label="' + esc(_t('Сделать копию')) + '" onclick="PJ.dialog(\'duplicate\',\'' + p.id + '\')">' + ico('copy', 16) + '</button>'
        : '<button type="button" class="ad-b ad-b--line" onclick="PJ.dialog(\'relocate\',\'' + p.id + '\')">' + _t('Указать папку') + '</button>') +
      '<button type="button" class="ad-ib ad-ib--danger" style="margin-left:auto" title="' + esc(_t('Убрать из списка')) + '" aria-label="' + esc(_t('Убрать из списка')) + '" onclick="PJ.remove(\'' + p.id + '\')">' + ico('close', 15) + '</button>' +
      '</div></article>';
  }

  function browser() {
    var B = S.browse, D = S.dialog; if (!B) return '';
    var pickLabel = D.kind === 'create' || D.kind === 'duplicate' ? _t('Создать проект внутри этой папки') : _t('Выбрать эту папку');
    return '<div class="pj-browse">' +
      '<div class="pj-browse__bar">' +
      (B.parent ? '<button type="button" class="ad-ib" aria-label="' + esc(_t('Вверх')) + '" onclick="PJ.browse(' + esc(JSON.stringify(B.parent)) + ')">' + ico('up', 15) + '</button>' : '') +
      '<span class="pj-browse__path">' + esc(B.path) + '</span>' +
      (B.isProject ? '<span class="pj-badge">' + _t('проект UCMS') + '</span>' : '') + '</div>' +
      '<div class="pj-browse__roots">' + B.roots.concat([B.home]).map(function (r) {
        return '<button type="button" class="pj-chip" onclick="PJ.browse(' + esc(JSON.stringify(r)) + ')">' + esc(r === B.home ? _t('Домашняя папка') : r) + '</button>';
      }).join('') + '</div>' +
      '<div class="pj-browse__list">' + (B.dirs.length ? B.dirs.map(function (d) {
        return '<button type="button" class="pj-dir" onclick="PJ.browse(' + esc(JSON.stringify(join(B.path, d))) + ')">' + ico('folder', 15) + '<span>' + esc(d) + '</span></button>';
      }).join('') : '<div class="pj-empty">' + _t('Вложенных папок нет') + '</div>') + '</div>' +
      '<div class="ad-btnrow"><button type="button" class="ad-b ad-b--dark ad-b--sm" onclick="PJ.pick()">' + pickLabel + '</button>' +
      '<button type="button" class="ad-b ad-b--sm" onclick="S_closeBrowse()">' + _t('Закрыть обзор') + '</button></div></div>';
  }
  window.S_closeBrowse = function () { S.browse = null; render(); };

  function dialog() {
    var D = S.dialog; if (!D) return '';
    var titles = { create: _t('Новый проект'), add: _t('Добавить существующий проект'), duplicate: _t('Копия проекта'), relocate: _t('Где теперь лежит проект') };
    var needName = D.kind === 'create' || D.kind === 'duplicate';
    var tabs = D.kind === 'add' ? '<div class="pj-tabs" role="tablist">' + [['folder', _t('Папка на компьютере')], ['server', _t('С сервера (FTP)')], ['ucms', _t('Сайт UCMS (веб)')]].map(function (t) {
      return '<button type="button" role="tab" aria-selected="' + (D.src === t[0]) + '" class="pj-tab' + (D.src === t[0] ? ' is-on' : '') + '" onclick="PJ.setSrc(\'' + t[0] + '\')">' + t[1] + '</button>';
    }).join('') + '</div>' : '';
    if (D.kind === 'add' && D.src === 'server') return serverDialog(D, tabs);
    if (D.kind === 'add' && D.src === 'ucms') return siteDialog(D, tabs);
    var hint = {
      create: _t('Будет создана папка с данными сайта: страницы, картинки, тема, собранный сайт. Подойдёт любое место: «Документы», облачный диск, другой диск.'),
      duplicate: _t('Копируются страницы, картинки и темы. Собранный сайт, резервные копии и настройки FTP не копируются.'),
      add: _t('Укажите папку проекта — в ней лежит db.json. Например, проект с другого компьютера или из архива.'),
      relocate: _t('Если папку проекта перенесли или переименовали — укажите, где она теперь.'),
    }[D.kind];
    return '<div class="pj-modal" role="dialog" aria-modal="true" aria-label="' + esc(titles[D.kind]) + '" onclick="if(event.target===this)PJ.close()">' +
      '<div class="pj-modal__box"><div class="pj-modal__h">' + titles[D.kind] +
      '<button type="button" class="ad-ib" aria-label="' + esc(_t('Закрыть')) + '" onclick="PJ.close()">' + ico('close', 15) + '</button></div>' +
      tabs + '<p class="pj-modal__hint">' + hint + '</p>' +
      (needName ? '<div class="ad-f"><label class="ad-f__l" for="pj-name">' + _t('Название сайта') + '</label>' +
        '<input id="pj-name" class="ad-in" data-focus value="' + esc(D.name) + '" placeholder="' + esc(_t('Например, «Студия Лето»')) + '" oninput="PJ.setName(this.value)"></div>' : '') +
      '<div class="ad-f"><label class="ad-f__l" for="pj-path">' + (needName ? _t('Папка проекта') : _t('Папка')) + '</label>' +
      '<div class="pj-pathrow"><input id="pj-path" class="ad-in ad-in--mono"' + (needName ? '' : ' data-focus') + ' value="' + esc(D.path) + '" placeholder="' + esc(S.defaultRoot) + '" oninput="PJ.setPath(this.value)">' +
      '<button type="button" class="ad-b ad-b--line" onclick="PJ.browse()">' + _t('Обзор…') + '</button></div>' +
      (needName ? '<span class="ad-f__hint">' + _t('Папка должна быть новой или пустой.') + '</span>' : '') + '</div>' +
      browser() +
      (D.error ? '<div class="ad-pub__msg is-err">' + esc(D.error) + '</div>' : '') +
      '<div class="ad-btnrow pj-modal__f"><button type="button" class="ad-b ad-b--primary"' + (D.busy ? ' disabled' : '') + ' onclick="PJ.submit()">' +
      ({ create: _t('Создать и открыть'), add: _t('Добавить'), duplicate: _t('Сделать копию'), relocate: _t('Сохранить') })[D.kind] + '</button>' +
      '<button type="button" class="ad-b" onclick="PJ.close()">' + _t('Отмена') + '</button></div></div></div>';
  }

  // «С сервера»: подключение → найти проект → (пароль проекта) → папка на компьютере → скачать
  function serverDialog(D, tabs) {
    var R = D.remote, F = D.found;
    var inp = function (id, label, k, o) {
      o = o || {};
      return '<div class="ad-f"><label class="ad-f__l" for="' + id + '">' + label + '</label><input id="' + id + '" class="ad-in' + (o.mono ? ' ad-in--mono' : '') + '"' + (o.type ? ' type="' + o.type + '"' : '') +
        ' value="' + esc(R[k] == null ? '' : R[k]) + '" placeholder="' + esc(o.ph || '') + '" autocomplete="' + (o.ac || 'off') + '" oninput="PJ.setR(\'' + k + '\',this.value)"' + (o.focus ? ' data-focus' : '') + '></div>';
    };
    var html = '<div class="pj-modal" role="dialog" aria-modal="true" aria-label="' + esc(_t('Добавить существующий проект')) + '" onclick="if(event.target===this)PJ.close()">' +
      '<div class="pj-modal__box"><div class="pj-modal__h">' + _t('Добавить существующий проект') +
      '<button type="button" class="ad-ib" aria-label="' + esc(_t('Закрыть')) + '" onclick="PJ.close()">' + ico('close', 15) + '</button></div>' + tabs +
      '<p class="pj-modal__hint">' + _t('Проект, который публиковался из UCMS на этот хостинг: подключение то же, что в «Публикации». Данные для входа сохранятся в проекте — следующие публикации пойдут туда же.') + '</p>' +
      '<div class="pj-row2"><div class="ad-f"><span class="ad-f__l">' + _t('Протокол') + '</span><div class="pj-seg">' + [['ftps', _t('FTPS (защищённый)')], ['ftp', 'FTP']].map(function (p) {
        return '<button type="button" class="pj-chip' + (R.protocol === p[0] ? ' is-on' : '') + '" onclick="PJ.setR(\'protocol\',\'' + p[0] + '\')">' + p[1] + '</button>';
      }).join('') + '</div></div></div>' +
      '<div class="pj-row2">' + inp('pr-host', _t('Сервер'), 'host', { mono: true, ph: 'ftp.example.com', focus: true }) + inp('pr-port', _t('Порт'), 'port', { mono: true, ph: '21', type: 'number' }) + '</div>' +
      '<div class="pj-row2">' + inp('pr-user', _t('Логин'), 'user', { ac: 'username' }) + inp('pr-pass', _t('Пароль'), 'password', { type: 'password', ac: 'current-password' }) + '</div>' +
      inp('pr-dir', _t('Папка сайта на сервере'), 'dir', { mono: true, ph: '/public_html' }) +
      inp('pr-pdir', _t('Папка проекта на сервере'), 'projectDir', { mono: true, ph: _t('найдётся сама') });
    if (F) {
      html += '<div class="pj-found">' + ico('check', 16) + '<div><b>' + esc(F.title || _t('Проект найден')) + '</b><small>' +
        [F.pages != null ? _t('страниц:') + ' ' + F.pages : '', F.updatedAt ? _t('обновлён') + ' ' + fmtDate(F.updatedAt) : '', F.computer ? _t('компьютер') + ' ' + esc(F.computer) : '', F.encrypted ? _t('зашифрован') : '']
          .filter(Boolean).join(' · ') + '</small></div></div>';
      if (F.encrypted && !F.passwordOk) {
        html += '<div class="ad-f"><label class="ad-f__l" for="pr-ppass">' + _t('Пароль проекта') + '</label><div class="pj-pathrow"><input id="pr-ppass" class="ad-in" type="password" data-focus value="' + esc(D.rpass) + '" oninput="S_rpass(this.value)">' +
          '<button type="button" class="ad-b ad-b--line" onclick="PJ.find()">' + _t('Проверить') + '</button></div>' +
          '<span class="ad-f__hint">' + _t('Проект хранится на сервере зашифрованным. Пароль задавался в «Публикации» на том компьютере.') + '</span></div>';
      } else {
        html += '<div class="ad-f"><label class="ad-f__l" for="pj-path">' + _t('Папка на этом компьютере') + '</label>' +
          '<div class="pj-pathrow"><input id="pj-path" class="ad-in ad-in--mono" value="' + esc(D.path) + '" oninput="PJ.setPath(this.value)">' +
          '<button type="button" class="ad-b ad-b--line" onclick="PJ.browse()">' + _t('Обзор…') + '</button></div>' +
          '<span class="ad-f__hint">' + _t('Папка должна быть новой или пустой.') + '</span></div>' + browser();
      }
    }
    var ready = F && (!F.encrypted || F.passwordOk);
    return html + (D.error ? '<div class="ad-pub__msg is-err">' + esc(D.error) + '</div>' : '') +
      '<div class="ad-btnrow pj-modal__f"><button type="button" class="ad-b ad-b--primary"' + (D.busy ? ' disabled' : '') + ' onclick="' + (ready ? 'PJ.clone()' : 'PJ.find()') + '">' +
      (D.busy ? _t('Подключаюсь…') : ready ? _t('Скачать проект') : _t('Найти проект')) + '</button>' +
      '<button type="button" class="ad-b" onclick="PJ.close()">' + _t('Отмена') + '</button></div></div></div>';
  }
  window.S_rpass = function (v) { S.dialog.rpass = v; };

  // «Сайт UCMS»: подключение к веб-версии по ключу доступа
  function siteDialog(D, tabs) {
    var title = D.rekey ? _t('Новый ключ доступа') : _t('Добавить существующий проект');
    return '<div class="pj-modal" role="dialog" aria-modal="true" aria-label="' + esc(title) + '" onclick="if(event.target===this)PJ.close()">' +
      '<div class="pj-modal__box"><div class="pj-modal__h">' + title +
      '<button type="button" class="ad-ib" aria-label="' + esc(_t('Закрыть')) + '" onclick="PJ.close()">' + ico('close', 15) + '</button></div>' + (D.rekey ? '' : tabs) +
      '<p class="pj-modal__hint">' + _t('Сайт, который работает в веб-версии UCMS на хостинге. Данные остаются на сервере: правки отсюда сохраняются сразу туда, а «Опубликовать» собирает сайт на сервере. Ключ доступа создаётся в веб-админке: «Настройки сайта → UCMS → Ключи доступа».') + '</p>' +
      '<div class="ad-f"><label class="ad-f__l" for="ps-url">' + _t('Адрес админки') + '</label><input id="ps-url" class="ad-in ad-in--mono"' + (D.rekey ? ' readonly' : ' data-focus') + ' value="' + esc(D.site.url) + '" placeholder="https://admin.example.kz" spellcheck="false" oninput="PJ.setSite(\'url\',this.value)"></div>' +
      '<div class="ad-f"><label class="ad-f__l" for="ps-key">' + _t('Ключ доступа') + '</label><input id="ps-key" class="ad-in ad-in--mono" type="password"' + (D.rekey ? ' data-focus' : '') + ' value="' + esc(D.site.token) + '" placeholder="ucms_…" autocomplete="off" spellcheck="false" oninput="PJ.setSite(\'token\',this.value)">' +
      '<span class="ad-f__hint">' + _t('Ключ хранится только на этом компьютере. Действует с ролью пользователя, который его создал.') + '</span></div>' +
      (D.error ? '<div class="ad-pub__msg is-err">' + esc(D.error) + '</div>' : '') +
      '<div class="ad-btnrow pj-modal__f"><button type="button" class="ad-b ad-b--primary"' + (D.busy ? ' disabled' : '') + ' onclick="PJ.connect()">' +
      (D.busy ? _t('Подключаюсь…') : D.rekey ? _t('Сохранить ключ') : _t('Подключить')) + '</button>' +
      '<button type="button" class="ad-b" onclick="PJ.close()">' + _t('Отмена') + '</button></div></div></div>';
  }

  function render() {
    app.innerHTML =
      '<header class="pj-top"><div class="ad-brand__mark">U</div><div><div class="pj-top__name">UCMS</div><div class="pj-top__ver">' + esc(S.version ? 'v' + S.version : '') + '</div></div>' +
      (window.adminLangMenu ? window.adminLangMenu('pj-lang') : '') + '</header>' +
      '<main class="pj-main">' + updBanner() + '<div class="ad-sec-h"><h1>' + _t('Проекты') + '</h1></div>' +
      (S.updDone ? '<div class="ad-pub__msg is-ok">' + esc(S.updDone) + '</div>' : '') +
      (S.notice ? '<div class="ad-pub__msg is-ok">' + esc(S.notice) + '</div>' : '') +
      (S.error ? '<div class="ad-pub__msg is-err">' + esc(S.error) + '</div>' : '') +
      '<div class="pj-grid">' + S.projects.map(card).join('') +
      '<button type="button" class="pj-new" onclick="PJ.dialog(\'create\')">' + ico('plus', 22) + '<b>' + _t('Новый проект') + '</b><small>' + _t('пустой сайт в своей папке') + '</small></button></div>' +
      '<div class="pj-foot"><button type="button" class="ad-b ad-b--line" onclick="PJ.dialog(\'add\')">' + ico('folder', 15) + _t('Добавить существующий…') + '</button>' +
      '<span class="ad-f__hint">' + _t('Список проектов хранится в') + ' <code>' + esc(S.registry) + '</code></span></div>' + updPanel() + '</main>' +
      dialog() + updOverlay();
    document.title = 'UCMS — ' + _t('Проекты');
  }

  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && S.dialog) PJ.close(); });
  load();
})();

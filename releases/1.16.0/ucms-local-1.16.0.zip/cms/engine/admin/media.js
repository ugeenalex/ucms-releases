/* ============================================================
   МЕДИАТЕКА: оптимизация картинок при загрузке, выбор из уже
   загруженного, раздел «Медиа» (список, использование, удаление,
   оптимизация старых файлов).

   Оптимизация делается в браузере (canvas → WebP): у движка нет
   npm-зависимостей, а браузер умеет декодировать и кодировать картинки.
   Основной файл — не шире maxWidth; рядом уменьшенные копии
   <имя>-w480/960/1600.webp для srcset (генератор подставит их сам).
   GIF, SVG, ICO и анимированный WebP не трогаем.
   ============================================================ */
(function () {
  'use strict';
  var App = window.App;
  var VARIANT_WIDTHS = [480, 960, 1600];
  var OPTIMIZABLE = /^image\/(jpeg|png|webp)$/;
  var IMG_EXT = /\.(png|jpe?g|webp|gif|svg|avif|ico)$/i;
  // folder: '' — все, '_none' — без папки, иначе id; sel — выделенные пути; editing — id папки в правке ('_new')
  var M = { items: null, folders: [], folder: '', tag: '', filter: 'all', busy: '', query: '', sel: {}, editing: null, dragging: null };

  function S() { return App._state; }
  function cfg() { return S().mediaCfg || { optimize: true, maxWidth: 2400, quality: 82 }; }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function ico(n, sz) { return window.Icons && Icons.svg ? Icons.svg(n, sz || 16) : ''; }
  function kb(n) { return n >= 1048576 ? (n / 1048576).toFixed(1) + ' ' + _t('МБ') : Math.max(1, Math.round(n / 1024)) + ' ' + _t('КБ'); }
  function toast(t, bad) { if (App.toast) App.toast(t, bad); }

  /* ── кодирование ── */
  function blobToBase64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1]); };
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  }
  function encodeWebp(bitmap, w, q) {
    var h = Math.round(bitmap.height * w / bitmap.width);
    var c = document.createElement('canvas');
    c.width = w; c.height = h;
    var g = c.getContext('2d');
    g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high';
    g.drawImage(bitmap, 0, 0, w, h);
    return new Promise(function (res) { c.toBlob(function (b) { c.width = c.height = 0; res(b); }, 'image/webp', q / 100); });
  }
  // Анимированный WebP: в заголовке есть чанк ANIM — такой файл не перекодируем
  function isAnimatedWebp(file) {
    return file.slice(0, 4096).arrayBuffer().then(function (buf) {
      var s = String.fromCharCode.apply(null, new Uint8Array(buf));
      return s.indexOf('ANIM') >= 0;
    });
  }
  function baseName(name) { return String(name || 'image').replace(/\.[^.]+$/, ''); }

  // file → { name, data, variants, note } для /api/upload
  App.optimizeImage = function (file, force) {
    var c = cfg();
    var plain = function (note) { return blobToBase64(file).then(function (d) { return { name: file.name, data: d, variants: [], note: note || '' }; }); };
    if ((!c.optimize && !force) || !OPTIMIZABLE.test(file.type) || !window.createImageBitmap) return plain();
    return (file.type === 'image/webp' ? isAnimatedWebp(file) : Promise.resolve(false)).then(function (anim) {
      if (anim) return plain();
      return createImageBitmap(file).then(function (bmp) {
        var srcW = bmp.width, target = Math.min(srcW, c.maxWidth);
        // Маленький PNG (логотип, иконка) без уменьшения — оставляем как есть: чёткость важнее
        if (file.type === 'image/png' && target === srcW && file.size < 150 * 1024 && !force) { bmp.close(); return plain(); }
        return encodeWebp(bmp, target, c.quality).then(function (main) {
          if (!main || main.type !== 'image/webp') { bmp.close(); return plain(_t('браузер не умеет WebP')); }
          if (main.size >= file.size && target === srcW) { bmp.close(); return plain(); }   // выигрыша нет
          var widths = VARIANT_WIDTHS.filter(function (w) { return w < target * 0.9; });
          return Promise.all(widths.map(function (w) {
            return encodeWebp(bmp, w, c.quality).then(function (b) { return blobToBase64(b).then(function (d) { return { w: w, data: d }; }); });
          })).then(function (variants) {
            bmp.close();   // освобождаем декодированную картинку сразу, не дожидаясь сборщика мусора
            return blobToBase64(main).then(function (d) {
              return { name: baseName(file.name) + '.webp', data: d, variants: variants,
                note: kb(file.size) + ' → ' + kb(main.size) + (target < srcW ? ', ' + srcW + '→' + target + ' px' : '') };
            });
          });
        });
      }).catch(function () { return plain(); });
    });
  };

  // Загрузка одного файла (с оптимизацией) → '/uploads/…'
  function uploadFile(file, kind, opts) {
    opts = opts || {};
    var prep = opts.noOptimize ? blobToBase64(file).then(function (d) { return { name: file.name, data: d, variants: [] }; }) : App.optimizeImage(file, opts.force);
    return prep.then(function (p) {
      return App.api.post('/api/upload', { name: p.name, data: p.data, variants: p.variants, kind: kind || 'images', folder: opts.folder || '' })
        .then(function (d) { return { path: '/' + d.path, note: p.note }; });
    });
  }
  App.uploadFile = uploadFile;

  /* ── выбор картинки: загрузить или взять из медиатеки ──
     Заменяет App.uploadImageAt — все кнопки загрузки в админке проходят здесь. */
  var pick = null;
  App.uploadImageAt = function (onSuccess, kind) {
    pick = { cb: onSuccess, kind: kind || 'images', items: null, folders: [], q: '', folder: M.pickFolder || '' };
    renderPicker();
    App.api.get('/api/media').then(function (d) {
      if (!pick) return;
      pick.items = pick.kind === 'files' ? d.items : d.items.filter(function (it) { return IMG_EXT.test(it.path); });
      pick.folders = d.folders || [];
      if (pick.folder && !pick.folders.some(function (f) { return f.id === pick.folder; })) pick.folder = '';
      renderPicker();
    }).catch(function () { if (pick) { pick.items = []; renderPicker(); } });
  };
  // Выбор любого файла медиатеки для ссылки «Файл» (PDF, DOCX, архив…); загрузка — без сжатия
  App.pickFile = function (onSuccess) { App.uploadImageAt(onSuccess, 'files'); };
  function closePicker() { pick = null; var el = document.getElementById('md-pick'); if (el) el.remove(); }
  App.pickClose = closePicker;
  App.pickChoose = function (path) { var p = pick; closePicker(); if (p) p.cb(path); };
  App.pickSearch = function (v) { if (pick) { pick.q = v; renderPickerGrid(); } };
  App.pickFolder = function (id) { if (pick) { pick.folder = M.pickFolder = id; renderPicker(); } };
  App.pickUpload = function (input) {
    var p = pick, file = input.files && input.files[0]; if (!p || !file) return;
    var noOpt = p.kind === 'favicon' || p.kind === 'files';
    setPickBusy(_t('Загружаю…'));
    uploadFile(file, p.kind === 'favicon' ? 'images' : p.kind, { noOptimize: noOpt, folder: p.folder }).then(function (r) {
      closePicker(); p.cb(r.path);
      toast(r.note ? _t('Загружено') + ': ' + r.note : _t('Загружено'));
    }).catch(function (e) { setPickBusy(''); toast(_t('Ошибка загрузки: ') + e.message, true); });
  };
  function setPickBusy(t) { var b = document.querySelector('#md-pick [data-busy]'); if (b) b.textContent = t; }
  function pickGridHTML() {
    if (!pick.items) return '<div class="md-empty">' + _t('Загрузка…') + '</div>';
    var list = pick.items.filter(function (it) { return (!pick.folder || it.folder === pick.folder) && matches(it, pick.q); });
    if (!list.length) return '<div class="md-empty">' + (pick.items.length ? _t('Ничего не найдено') : pick.kind === 'files' ? _t('В медиатеке пока пусто — загрузите первый файл') : _t('В медиатеке пока пусто — загрузите первую картинку')) + '</div>';
    return list.map(function (it) {
      var img = IMG_EXT.test(it.path);
      return '<button type="button" class="md-pick__i" title="' + esc(it.name) + '" onclick="App.pickChoose(' + esc(JSON.stringify(it.path)) + ')">' +
        '<span class="md-thumb">' + (img ? '<img src="' + esc(it.thumb) + '" alt="" loading="lazy">' : '<span class="md-file">' + esc((it.path.split('.').pop() || '').toUpperCase()) + '</span>') + '</span>' +
        '<span class="md-pick__n">' + esc(it.name) + (img ? '' : ' · ' + kb(it.size)) + '</span></button>';
    }).join('');
  }
  function renderPickerGrid() { var g = document.querySelector('#md-pick [data-grid]'); if (g) g.innerHTML = pickGridHTML(); }
  function renderPicker() {
    if (!pick) return;
    var el = document.getElementById('md-pick');
    if (!el) { el = document.createElement('div'); el.id = 'md-pick'; el.className = 'md-modal'; document.body.appendChild(el); }
    var files = pick.kind === 'files';
    var accept = pick.kind === 'favicon' ? 'image/*,.ico' : files ? '' : 'image/*';
    var title = files ? _t('Файл') : _t('Изображение');
    el.innerHTML = '<div class="md-modal__box" role="dialog" aria-modal="true" aria-label="' + esc(title) + '">' +
      '<div class="md-modal__h"><b>' + title + '</b><button type="button" class="ad-ib" aria-label="' + esc(_t('Закрыть')) + '" onclick="App.pickClose()">' + ico('close', 15) + '</button></div>' +
      '<div class="md-modal__bar"><label class="ad-b ad-b--primary">' + ico('upload', 15) + _t('Загрузить с компьютера') +
      '<input type="file"' + (accept ? ' accept="' + accept + '"' : '') + ' hidden onchange="App.pickUpload(this)"></label>' +
      '<span class="ad-f__hint" data-busy>' + (files ? _t('PDF, DOCX, архивы — любой файл, без сжатия') : cfg().optimize && pick.kind !== 'favicon' ? _t('JPG и PNG сожмутся в WebP') : '') + '</span>' +
      '<input class="ad-in md-search" placeholder="' + esc(_t('Поиск по имени и тегам')) + '" value="' + esc(pick.q) + '" oninput="App.pickSearch(this.value)"></div>' +
      (pick.folders.length ? '<div class="md-tags">' + [['', _t('Все')]].concat(pick.folders.map(function (f) { return [f.id, f.name]; })).map(function (f) {
        return '<button type="button" class="md-chip' + (pick.folder === f[0] ? ' is-on' : '') + '" onclick="App.pickFolder(' + J(f[0]) + ')">' + (f[0] ? ico('folder', 12) + ' ' : '') + esc(f[1]) + '</button>';
      }).join('') + '</div>' : '') +
      '<div class="md-pick__grid" data-grid>' + pickGridHTML() + '</div></div>';
    el.onclick = function (e) { if (e.target === el) closePicker(); };
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && pick) closePicker(); });

  /* ── раздел «Медиа» ── */
  function needsOptimize(it) {
    if (!/\.(jpe?g|png|webp)$/i.test(it.path)) return false;
    if (/\.webp$/i.test(it.path) && it.variants.length) return false;
    if (/\.png$/i.test(it.path) && it.size < 150 * 1024 && (!it.width || it.width <= cfg().maxWidth)) return false;
    return it.size > 120 * 1024 || (it.width && it.width > cfg().maxWidth);
  }
  // quiet — без сохранения и экрана «Загрузка…» (после действий с папками и тегами)
  App.loadMedia = function (quiet) {
    if (!quiet) { M.items = null; App.renderView(); }
    // Сначала сохраняем: «используется» считается по db.json на диске
    return (quiet ? Promise.resolve() : App.persistNow().catch(function () {})).then(function () { return App.api.get('/api/media'); })
      .then(function (d) {
        M.items = d.items; M.folders = d.folders || [];
        if (M.folder && M.folder !== '_none' && !M.folders.some(function (f) { return f.id === M.folder; })) M.folder = '';
        var exists = {}; M.items.forEach(function (it) { exists[it.path] = 1; });
        Object.keys(M.sel).forEach(function (p) { if (!exists[p]) delete M.sel[p]; });
        if (S().view === 'media') App.renderView();
      })
      .catch(function (e) { M.items = []; toast(e.message, true); App.renderView(); });
  };
  App.mediaFilter = function (f) { M.filter = f; M.sel = {}; App.renderView(); };
  App.mediaSearch = function (v) { M.query = v; var g = document.querySelector('[data-media-grid]'); if (g) g.innerHTML = gridHTML(); };
  App.mediaCfg = function (key, val) {
    var c = Object.assign({}, cfg()); c[key] = val; S().mediaCfg = c; App.renderView();
  };
  App.mediaUpload = function (input) {
    var files = Array.prototype.slice.call(input.files || []); if (!files.length) return;
    M.busy = _t('Загружаю…'); App.renderView();
    var done = 0, notes = [];
    files.reduce(function (pr, f) {
      return pr.then(function () {
        return uploadFile(f, 'images', { noOptimize: !IMG_EXT.test(f.name), folder: M.folder !== '_none' ? M.folder : '' }).then(function (r) { done++; if (r.note) notes.push(r.note); M.busy = _t('Загружено') + ' ' + done + ' / ' + files.length; App.renderView(); });
      });
    }, Promise.resolve()).catch(function (e) { toast(_t('Ошибка загрузки: ') + e.message, true); })
      .then(function () { M.busy = ''; toast(_t('Загружено файлов:') + ' ' + done); App.loadMedia(); });
  };
  App.mediaDelete = function (paths, warnUsed) {
    if (!paths.length) return;
    var msg = paths.length === 1 ? _t('Удалить файл?') : _t('Удалить файлы:') + ' ' + paths.length + '?';
    if (warnUsed) msg += '\n' + _t('Файл используется на сайте — на его месте будет пусто.');
    if (!confirm(msg)) return;
    M.sel = {};
    App.api.post('/api/media/delete', { paths: paths }).then(function (d) { toast(_t('Удалено:') + ' ' + d.deleted); App.loadMedia(); })
      .catch(function (e) { toast(e.message, true); });
  };
  App.mediaDeleteUnused = function () {
    App.mediaDelete((M.items || []).filter(function (it) { return !it.used && inFolder(it); }).map(function (it) { return it.path; }), false);
  };
  // Оптимизировать уже загруженные: новый WebP + замена всех ссылок в db.json + удаление старого.
  // db.json меняется на сервере, поэтому после — перечитываем данные в админку.
  App.mediaOptimize = function (paths) {
    if (!paths.length) return;
    if (!confirm(_t('Сжать в WebP и уменьшить до') + ' ' + cfg().maxWidth + ' px: ' + paths.length + ' ' + _t('файл(ов)? Ссылки на сайте обновятся автоматически, исходники будут удалены.'))) return;
    var saved = 0, n = 0;
    M.busy = _t('Оптимизирую…'); App.renderView();
    App.persistNow().then(function () {
      return paths.reduce(function (pr, path) {
        return pr.then(function () {
          var it = (M.items || []).filter(function (x) { return x.path === path; })[0];
          return fetch(path, { cache: 'no-store' }).then(function (r) { return r.blob(); }).then(function (blob) {
            var file = new File([blob], it ? it.name : path.split('/').pop(), { type: blob.type });
            return App.optimizeImage(file, true).then(function (p) {
              if (!p.variants.length && !/\.webp$/i.test(p.name)) return null;   // не удалось сжать — оставляем
              var folder = path.split('/')[2] || 'images';
              return App.api.post('/api/upload', { name: p.name, data: p.data, variants: p.variants, kind: folder }).then(function (d) {
                return App.api.post('/api/media/replace', { from: path, to: '/' + d.path }).then(function () {
                  n++; saved += (it ? it.size : 0) - Math.round(p.data.length * 0.75);
                  M.busy = _t('Оптимизировано') + ' ' + n + ' / ' + paths.length; App.renderView();
                });
              });
            });
          });
        });
      }, Promise.resolve());
    }).catch(function (e) { toast(_t('Ошибка:') + ' ' + e.message, true); })
      .then(function () { return App.reloadData(); })
      .then(function () { M.busy = ''; toast(_t('Оптимизировано файлов:') + ' ' + n + (saved > 0 ? ', ' + _t('сэкономлено') + ' ' + kb(saved) : '')); App.loadMedia(); });
  };

  /* ── фильтрация: папка, тег, «не используются / можно сжать», поиск по имени и тегам ── */
  function inFolder(it) {
    if (M.folder === '') return true;
    if (M.folder === '_none') return !it.folder;
    return it.folder === M.folder;
  }
  function matches(it, q) {
    q = (q || '').trim().toLowerCase();
    return !q || it.name.toLowerCase().indexOf(q) >= 0 || (it.tags || []).some(function (t) { return t.toLowerCase().indexOf(q) >= 0; });
  }
  function visible() {
    return (M.items || []).filter(function (it) {
      if (!inFolder(it)) return false;
      if (M.tag && (it.tags || []).indexOf(M.tag) < 0) return false;
      if (M.filter === 'unused' && it.used) return false;
      if (M.filter === 'heavy' && !needsOptimize(it)) return false;
      return matches(it, M.query);
    });
  }
  function allTags(list) {
    var c = {};
    list.forEach(function (it) { (it.tags || []).forEach(function (t) { c[t] = (c[t] || 0) + 1; }); });
    return Object.keys(c).sort(function (a, b) { return a.localeCompare(b); }).map(function (t) { return [t, c[t]]; });
  }
  function folderName(id) { var f = (M.folders || []).filter(function (x) { return x.id === id; })[0]; return f ? f.name : ''; }
  function J(v) { return esc(JSON.stringify(v)); }

  /* ── папки и теги: запросы ── */
  function metaOp(body) {
    return App.api.post('/api/media/meta', body).then(function (d) { M.folders = d.folders; return App.loadMedia(true).then(function () { return d; }); })
      .catch(function (e) { toast(e.message, true); });
  }
  function selected() { return Object.keys(M.sel); }
  App.mediaFolder = function (id) { M.folder = id; M.sel = {}; App.renderView(); };
  App.mediaTag = function (t) { M.tag = M.tag === t ? '' : t; M.sel = {}; App.renderView(); };
  App.mediaFolderNew = function () { M.editing = '_new'; App.renderView(); focusEdit(); };
  App.mediaFolderEdit = function (id) { M.editing = id; App.renderView(); focusEdit(); };
  function focusEdit() { var i = document.querySelector('[data-folder-edit]'); if (i) { i.focus(); i.select(); } }
  App.mediaFolderKey = function (e, input) {
    if (e.key === 'Escape') { M.editing = null; App.renderView(); return; }
    if (e.key !== 'Enter') return;
    var name = input.value.trim(), id = M.editing;
    M.editing = null;
    if (!name) { App.renderView(); return; }
    if (id === '_new') metaOp({ op: 'folderAdd', name: name }).then(function (d) { if (d && d.created) { M.folder = d.created.id; App.renderView(); } });
    else metaOp({ op: 'folderRename', id: id, name: name });
  };
  App.mediaFolderDelete = function (id) {
    if (!confirm(_t('Удалить папку «') + folderName(id) + _t('»? Файлы останутся в медиатеке без папки.'))) return;
    if (M.folder === id) M.folder = '';
    metaOp({ op: 'folderDelete', id: id });
  };
  App.mediaSel = function (path) {
    if (M.sel[path]) delete M.sel[path]; else M.sel[path] = 1;
    App.renderView();
  };
  App.mediaSelAll = function (on) {
    M.sel = {};
    if (on) visible().forEach(function (it) { M.sel[it.path] = 1; });
    App.renderView();
  };
  App.mediaMove = function (folder, paths) {
    paths = paths || selected(); if (!paths.length) return;
    metaOp({ op: 'move', paths: paths, folder: folder }).then(function () {
      toast(_t('Перемещено:') + ' ' + paths.length + ' → ' + (folder ? folderName(folder) : _t('Без папки')));
    });
    M.sel = {};
  };
  App.mediaTagAdd = function (input) {
    var tag = String(input.value || '').trim(), paths = selected();
    if (!tag || !paths.length) return;
    metaOp({ op: 'tagAdd', paths: paths, tag: tag });
  };
  App.mediaTagKey = function (e, input) { if (e.key === 'Enter') App.mediaTagAdd(input); };
  App.mediaTagRemove = function (path, tag) { metaOp({ op: 'tagRemove', paths: [path], tag: tag }); };
  App.mediaTagRename = function (tag) {
    var to = prompt(_t('Новое название тега'), tag);
    if (to && to.trim() && to.trim() !== tag) metaOp({ op: 'tagRename', tag: tag, to: to.trim() }).then(function () { if (M.tag === tag) { M.tag = to.trim(); App.renderView(); } });
  };
  // Перетаскивание карточек на папку: тянем выделенные (если карточка среди них) или одну
  App.mediaDragStart = function (e, path) {
    var paths = M.sel[path] ? selected() : [path];
    e.dataTransfer.setData('text/plain', JSON.stringify(paths));
    e.dataTransfer.effectAllowed = 'move';
    M.dragging = paths;
  };
  App.mediaDragOver = function (e, el) { if (!M.dragging) return; e.preventDefault(); el.classList.add('is-drop'); };
  App.mediaDragLeave = function (el) { el.classList.remove('is-drop'); };
  App.mediaDrop = function (e, folder) {
    e.preventDefault();
    var paths = M.dragging; M.dragging = null;
    if (paths && paths.length) App.mediaMove(folder, paths);
  };
  document.addEventListener('dragend', function () { M.dragging = null; });

  /* ── разметка раздела ── */
  function folderRow(id, name, count, editable) {
    var on = M.folder === id;
    if (M.editing === id) {
      return '<div class="md-fold is-edit"><input class="ad-in" data-folder-edit value="' + esc(name) + '" onkeydown="App.mediaFolderKey(event,this)" onblur="App.mediaFolderKey({key:\'Enter\'},this)"></div>';
    }
    return '<div class="md-fold' + (on ? ' is-on' : '') + (editable ? ' md-fold--edit' : '') + '" ondragover="App.mediaDragOver(event,this)" ondragleave="App.mediaDragLeave(this)" ondrop="App.mediaDragLeave(this);App.mediaDrop(event,' + J(id === '_none' ? '' : id) + ')">' +
      '<button type="button" class="md-fold__b" onclick="App.mediaFolder(' + J(id) + ')">' + ico(id === '' ? 'grid' : 'folder', 15) + '<span>' + esc(name) + '</span><small>' + count + '</small></button>' +
      (editable ? '<button type="button" class="ad-ib md-fold__a" title="' + esc(_t('Переименовать')) + '" aria-label="' + esc(_t('Переименовать')) + '" onclick="App.mediaFolderEdit(' + J(id) + ')">' + ico('pencil', 13) + '</button>' +
        '<button type="button" class="ad-ib ad-ib--danger md-fold__a" title="' + esc(_t('Удалить папку')) + '" aria-label="' + esc(_t('Удалить папку')) + '" onclick="App.mediaFolderDelete(' + J(id) + ')">' + ico('trash', 13) + '</button>' : '') + '</div>';
  }
  function foldersHTML() {
    var items = M.items || [];
    var count = function (id) { return items.filter(function (it) { return it.folder === id; }).length; };
    return '<aside class="md-side"><div class="md-side__h">' + _t('Папки') + '</div>' +
      folderRow('', _t('Все файлы'), items.length, false) +
      folderRow('_none', _t('Без папки'), count(''), false) +
      (M.folders || []).map(function (f) { return folderRow(f.id, f.name, count(f.id), true); }).join('') +
      (M.editing === '_new' ? folderRow('_new', '', 0, false)
        : '<button type="button" class="md-fold__new" onclick="App.mediaFolderNew()">' + ico('plus', 14) + _t('Новая папка') + '</button>') +
      '<div class="md-side__hint">' + _t('Перетащите карточки на папку, чтобы переместить. Папка — только метка в медиатеке: адреса файлов и ссылки на сайте не меняются.') + '</div></aside>';
  }
  function tagsHTML() {
    var tags = allTags((M.items || []).filter(inFolder));
    if (!tags.length && !M.tag) return '';
    return '<div class="md-tags"><span class="md-tags__l">' + _t('Теги:') + '</span>' + tags.map(function (t) {
      return '<button type="button" class="md-chip' + (M.tag === t[0] ? ' is-on' : '') + '" onclick="App.mediaTag(' + J(t[0]) + ')" ondblclick="App.mediaTagRename(' + J(t[0]) + ')" title="' + esc(_t('Двойной клик — переименовать')) + '">#' + esc(t[0]) + ' <small>' + t[1] + '</small></button>';
    }).join('') + '</div>';
  }
  function selBarHTML() {
    var n = selected().length;
    if (!n) return '';
    return '<div class="md-selbar"><b>' + _t('Выбрано:') + ' ' + n + '</b>' +
      '<select class="ad-in ad-select" aria-label="' + esc(_t('Переместить в папку')) + '" onchange="if(this.value!==\'-\')App.mediaMove(this.value===\'_none\'?\'\':this.value)">' +
      '<option value="-">' + _t('Переместить в…') + '</option><option value="_none">' + _t('Без папки') + '</option>' +
      (M.folders || []).map(function (f) { return '<option value="' + esc(f.id) + '">' + esc(f.name) + '</option>'; }).join('') + '</select>' +
      '<input class="ad-in md-taginp" placeholder="' + esc(_t('Добавить тег и Enter')) + '" list="md-taglist" onkeydown="App.mediaTagKey(event,this)">' +
      '<datalist id="md-taglist">' + allTags(M.items || []).map(function (t) { return '<option value="' + esc(t[0]) + '">'; }).join('') + '</datalist>' +
      '<button type="button" class="ad-b ad-b--danger ad-b--sm" onclick="App.mediaDelete(' + J(selected()) + ',' + (M.items.some(function (it) { return M.sel[it.path] && it.used; })) + ')">' + ico('trash', 13) + _t('Удалить') + '</button>' +
      '<button type="button" class="ad-b ad-b--sm" onclick="App.mediaSelAll(false)">' + _t('Снять выделение') + '</button></div>';
  }

  function gridHTML() {
    var list = visible();
    if (!list.length) return '<div class="md-empty">' + ((M.items || []).length ? _t('Ничего не найдено') : _t('Пока пусто. Загрузите файлы кнопкой выше или из любого модуля.')) + '</div>';
    return list.map(function (it) {
      var img = IMG_EXT.test(it.path), P = J(it.path), on = !!M.sel[it.path];
      var meta = (it.width ? it.width + '×' + it.height + ' · ' : '') + kb(it.size) + (it.variants.length ? ' · +' + it.variants.length : '');
      return '<div class="md-card' + (on ? ' is-sel' : '') + '" draggable="true" ondragstart="App.mediaDragStart(event,' + P + ')">' +
        '<button type="button" class="md-thumb" aria-pressed="' + on + '" title="' + esc(_t('Выбрать')) + '" onclick="App.mediaSel(' + P + ')">' +
        (img ? '<img src="' + esc(it.thumb) + '" alt="" loading="lazy" draggable="false">' : '<span class="md-file">' + esc((it.path.split('.').pop() || '').toUpperCase()) + '</span>') +
        '<span class="md-check">' + (on ? ico('check', 13) : '') + '</span></button>' +
        '<div class="md-card__b"><div class="md-card__n" title="' + esc(it.name) + '">' + esc(it.name) + '</div><div class="md-card__m">' + meta +
        (it.folder && M.folder === '' ? ' · ' + ico('folder', 11) + ' ' + esc(folderName(it.folder)) : '') + '</div>' +
        ((it.tags || []).length ? '<div class="md-card__tags">' + it.tags.map(function (t) {
          return '<span class="md-chip md-chip--sm">#' + esc(t) + '<button type="button" aria-label="' + esc(_t('Убрать тег')) + '" onclick="App.mediaTagRemove(' + P + ',' + J(t) + ')">×</button></span>';
        }).join('') + '</div>' : '') +
        '<div class="md-card__f">' + (it.used ? '<span class="md-tag">' + _t('используется') + (it.used > 1 ? ' ×' + it.used : '') + '</span>' : '<span class="md-tag md-tag--free">' + _t('не используется') + '</span>') +
        '<a class="ad-ib" href="' + esc(it.path) + '" target="_blank" rel="noopener" title="' + esc(_t('Открыть')) + '" aria-label="' + esc(_t('Открыть')) + '">' + ico('eye', 15) + '</a>' +
        (needsOptimize(it) ? '<button type="button" class="ad-ib" title="' + esc(_t('Сжать в WebP')) + '" aria-label="' + esc(_t('Сжать в WebP')) + '" onclick="App.mediaOptimize([' + P + '])">' + ico('fit-stretch', 15) + '</button>' : '') +
        '<button type="button" class="ad-ib ad-ib--danger" title="' + esc(_t('Удалить')) + '" aria-label="' + esc(_t('Удалить')) + '" onclick="App.mediaDelete([' + P + '],' + (it.used ? 'true' : 'false') + ')">' + ico('trash', 15) + '</button></div></div></div>';
    }).join('');
  }

  App.renderMediaView = function () {
    var head = '<div class="ad-sec-h"><h1>' + _t('Медиа') + '</h1><p>' + _t('Все загруженные файлы проекта: где используются, сколько весят. Картинки при загрузке сжимаются в WebP, а для разных экранов готовятся уменьшенные копии.') + '</p></div>';
    if (!M.items) return head + '<div class="md-empty">' + _t('Загрузка…') + '</div>';
    var scope = M.items.filter(inFolder), unused = scope.filter(function (it) { return !it.used; }), heavy = scope.filter(needsOptimize), c = cfg();
    var total = M.items.reduce(function (a, it) { return a + it.total; }, 0);
    var shown = visible();
    var step = function (key, val, d, lo, hi, suf) {
      return UI_stepper(val + suf, 'App.mediaCfg(\'' + key + '\',' + Math.max(lo, val - d) + ')', 'App.mediaCfg(\'' + key + '\',' + Math.min(hi, val + d) + ')');
    };
    var where = M.folder === '' ? '' : M.folder === '_none' ? _t('Без папки') : folderName(M.folder);
    return head + '<div class="md-layout">' + foldersHTML() + '<div class="md-main">' +
      '<section class="ad-panel md-tools">' +
      '<div class="md-tools__row"><label class="ad-b ad-b--primary">' + ico('upload', 15) + (where && M.folder !== '_none' ? _t('Загрузить в') + ' «' + esc(where) + '»' : _t('Загрузить файлы')) + '<input type="file" multiple hidden onchange="App.mediaUpload(this)"></label>' +
      '<span class="md-sum">' + M.items.length + ' ' + _t('файлов') + ' · ' + kb(total) + '</span>' + (M.busy ? '<span class="md-busy">' + esc(M.busy) + '</span>' : '') +
      '<input class="ad-in md-search" placeholder="' + esc(_t('Поиск по имени и тегам')) + '" value="' + esc(M.query) + '" oninput="App.mediaSearch(this.value)"></div>' +
      '<div class="md-tools__row">' + segmHTML([['all', _t('Все') + ' · ' + scope.length], ['unused', _t('Не используются') + ' · ' + unused.length], ['heavy', _t('Можно сжать') + ' · ' + heavy.length]], M.filter, 'App.mediaFilter') +
      (M.filter === 'unused' && unused.length ? '<button type="button" class="ad-b ad-b--danger" onclick="App.mediaDeleteUnused()">' + ico('trash', 14) + _t('Удалить неиспользуемые') + '</button>' : '') +
      (M.filter === 'heavy' && heavy.length ? '<button type="button" class="ad-b ad-b--dark" onclick="App.mediaOptimize(' + J(heavy.map(function (it) { return it.path; })) + ')">' + _t('Сжать все') + ' (' + heavy.length + ')</button>' : '') +
      (shown.length ? '<button type="button" class="ad-b ad-b--sm md-selall" onclick="App.mediaSelAll(' + (selected().length < shown.length) + ')">' + (selected().length < shown.length ? _t('Выбрать все') + ' (' + shown.length + ')' : _t('Снять выделение')) + '</button>' : '') + '</div>' +
      tagsHTML() + selBarHTML() + '</section>' +
      '<div class="md-grid" data-media-grid>' + gridHTML() + '</div>' +
      '<section class="ad-panel"><div class="ad-panel__t">' + _t('Оптимизация при загрузке') + '</div>' +
      '<div class="ad-sw"><span>' + _t('Сжимать JPG и PNG в WebP') + '</span>' + toggleHTML(c.optimize, 'App.mediaCfg(\'optimize\',' + (!c.optimize) + ')') + '</div>' +
      (c.optimize ? '<div class="md-cfg"><div class="ad-f"><span class="ad-f__l">' + _t('Наибольшая ширина') + '</span>' + step('maxWidth', c.maxWidth, 200, 1200, 4000, ' px') + '</div>' +
        '<div class="ad-f"><span class="ad-f__l">' + _t('Качество') + '</span>' + step('quality', c.quality, 5, 50, 95, '%') + '</div></div>' +
        '<span class="ad-f__hint">' + _t('Маленькие PNG (логотипы, иконки) остаются как есть. GIF, SVG и анимированный WebP не изменяются. Иконка сайта не сжимается.') + '</span>' : '') +
      '</section></div></div>';
  };

  // Мелкие элементы интерфейса (те же классы, что в app.js)
  function segmHTML(opts, active, fn) {
    return '<div class="ad-segm" role="group">' + opts.map(function (o) {
      return '<button type="button" class="ad-segm__o' + (o[0] === active ? ' is-on' : '') + '" aria-pressed="' + (o[0] === active) + '" onclick="' + fn + '(\'' + o[0] + '\')">' + esc(o[1]) + '</button>';
    }).join('') + '</div>';
  }
  function toggleHTML(on, onclick) {
    return '<button type="button" role="switch" aria-checked="' + !!on + '" class="ad-toggle' + (on ? ' is-on' : '') + '" onclick="' + onclick + '"><span class="ad-toggle__knob"></span></button>';
  }
  function UI_stepper(label, minus, plus) {
    return '<div class="ad-step"><button type="button" class="ad-ib" aria-label="' + esc(_t('Меньше')) + '" onclick="' + minus + '">' + ico('chevron-left', 14) + '</button>' +
      '<span>' + esc(label) + '</span><button type="button" class="ad-ib" aria-label="' + esc(_t('Больше')) + '" onclick="' + plus + '">' + ico('chevron-right', 14) + '</button></div>';
  }
})();

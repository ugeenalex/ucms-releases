// Единый каталог модулей CMS «Витрина» — чистый JS, без библиотек.
// optional:true — модуль подключаемый (engine/packages): в палитре, только если установлен в сайт.
// Редактор, значения и вид на холсте у них остаются здесь (admin/modules/*.js, app.js).
(function () {
  var M = [
    { key:'title',    label:_t('Заголовок'),      glyph:'H' },
    { key:'text',     label:_t('Текст'),          icon:'<path d="M3 5h12M3 9h9M3 13h12"/>' },
    { key:'image',    label:_t('Изображение'),    icon:'<rect x="2.5" y="3.5" width="13" height="11" rx="2"/><circle cx="6.3" cy="7.3" r="1.2"/><path d="m3.5 13 3.3-3 2.8 2.3 2.2-1.7 2.7 2.4"/>' },
    { key:'gallery',  label:_t('Галерея'),        icon:'<rect x="2.5" y="2.5" width="5.6" height="5.6" rx="1.3"/><rect x="9.9" y="2.5" width="5.6" height="5.6" rx="1.3"/><rect x="2.5" y="9.9" width="5.6" height="5.6" rx="1.3"/><rect x="9.9" y="9.9" width="5.6" height="5.6" rx="1.3"/>' },
    { key:'video',    label:_t('Видео'),          icon:'<rect x="2.5" y="4.5" width="9.5" height="9" rx="2"/><path d="m12 8 3.5-2v6L12 10z"/>' },
    { key:'form',     label:_t('Обратная связь'), icon:'<path d="M15 8.7c0 2.6-2.5 4.6-5.6 4.6-.8 0-1.6-.1-2.3-.4L3.8 14l.9-2.8c-.6-.8-1-1.7-1-2.5C3.7 6 6.2 4 9.4 4S15 6 15 8.7Z"/>' },
    { key:'sitename', label:_t('Имя сайта'),      icon:'<path d="M3 8.5 9 3.5l6 5M4.5 7.5V14h9V7.5"/>' },
    { key:'menu',     label:_t('Меню сайта'),     icon:'<path d="M6 5.5h9M6 9h9M6 12.5h9"/><circle cx="3.2" cy="5.5" r=".8" fill="currentColor" stroke="none"/><circle cx="3.2" cy="9" r=".8" fill="currentColor" stroke="none"/><circle cx="3.2" cy="12.5" r=".8" fill="currentColor" stroke="none"/>' },
    { key:'lang',     label:_t('Выбор языка'),    glyph:'A文' },
    { key:'button',   label:_t('Кнопка'),         icon:'<rect x="2.5" y="6" width="13" height="6" rx="3"/>' },
    { key:'divider',  label:_t('Разделитель'),    icon:'<path d="M3 9h12"/>' },
    { key:'html',     label:_t('HTML-код'),       glyph:'&lt;/&gt;' },
    { key:'features', label:_t('Преимущества'),   icon:'<rect x="2.5" y="2.5" width="5" height="5" rx="1.2"/><path d="M10.5 4h5M10.5 6.5h3.5"/><rect x="2.5" y="10.5" width="5" height="5" rx="1.2"/><path d="M10.5 12h5M10.5 14.5h3.5"/>' },
    { key:'faq', optional:true,      label:_t('Вопросы и ответы'), icon:'<circle cx="9" cy="9" r="6.5"/><path d="M7.2 7.2a1.9 1.9 0 1 1 2.6 1.8c-.5.2-.8.6-.8 1.1v.4"/><circle cx="9" cy="12.6" r=".6" fill="currentColor" stroke="none"/>' },
    { key:'spacer',   label:_t('Отступ'),         icon:'<path d="M9 3.5v11M6.5 6 9 3.5 11.5 6M6.5 12 9 14.5l2.5-2.5M3 3h12M3 15h12"/>' },
    { key:'cards',    label:_t('Карточки'),       icon:'<rect x="2.5" y="3" width="5.5" height="12" rx="1.3"/><rect x="10" y="3" width="5.5" height="12" rx="1.3"/><path d="M2.5 7.5h5.5M10 7.5h5.5"/>' },
    { key:'quote', optional:true,    label:_t('Цитата'),         glyph:'❝' },
    { key:'pricing', optional:true,  label:_t('Тарифы'),         icon:'<path d="M3 9.5 9.5 3H15v5.5L8.5 15z"/><circle cx="12" cy="6" r="1"/>' },
    { key:'counters', optional:true, label:_t('Цифры'),          glyph:'123' },
    { key:'table', optional:true,    label:_t('Таблица'),        icon:'<rect x="2.5" y="3" width="13" height="12" rx="1.5"/><path d="M2.5 7h13M2.5 11h13M7 7v8"/>' },
    { key:'map', optional:true,      label:_t('Карта'),          icon:'<path d="M9 15.5s-5-4.6-5-8.5a5 5 0 0 1 10 0c0 3.9-5 8.5-5 8.5z"/><circle cx="9" cy="7" r="1.8"/>' },
    { key:'countdown', optional:true,label:_t('Таймер'),         icon:'<circle cx="9" cy="10" r="5.5"/><path d="M9 7.5V10l1.8 1.2M7 2.5h4"/>' },
    { key:'social', optional:true,   label:_t('Соцсети'),        icon:'<circle cx="5" cy="9" r="2"/><circle cx="13" cy="4.5" r="2"/><circle cx="13" cy="13.5" r="2"/><path d="m6.8 8 4.4-2.5M6.8 10l4.4 2.5"/>' },
    { key:'tabs',     label:_t('Вкладки'),        icon:'<rect x="2.5" y="5.5" width="13" height="10" rx="1.5"/><path d="M2.5 8V3.5h5V5.5M7.5 5.5V3.5h4.5v2"/>' },
    { key:'collection', label:_t('Список записей'), icon:'<rect x="2.5" y="6" width="13" height="9" rx="1.5"/><path d="M4.5 3.8h9M6.5 1.9h5M5 9h5M5 11.8h8"/>' },
    { key:'crumbs',   label:_t('Хлебные крошки'), icon:'<path d="M2.5 9h2.5M13 9h2.5M5 6.5 7.5 9 5 11.5M10.5 6.5 13 9l-2.5 2.5"/>' },
  ];
  var OFF = { video: true, lang: true, html: true };
  window.MODULES = M;
  window.MODULE_OFF_BY_DEFAULT = OFF;
  window.MODULE_LABEL = {};
  M.forEach(function (m) { window.MODULE_LABEL[m.key] = m.label; });

  // Возвращает HTML-разметку иконки модуля (svg или текстовый глиф).
  window.moduleIconHTML = function (key, size) {
    var def = M.filter(function (m) { return m.key === key; })[0];
    if (!def) return '';
    var s = size || 18;
    if (def.glyph) {
      var mono = def.key === 'html';
      return '<span style="font:700 var(--fs-xs) ' + (mono ? 'monospace' : 'var(--font)') + '">' + def.glyph + '</span>';
    }
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 18 18" fill="none" stroke="currentColor" ' +
      'stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' + def.icon + '</svg>';
  };
})();

/**
 * server-bridge.js — связь UI админки с серверным API.
 *
 * Формат движка (db.json): rows → columns → blocks, ссылки { type, url, pageId }.
 * Формат UI (App._state):   blocks → cols/mods,       ссылки { linkType, url, page(title) }.
 * Конвертация — только здесь; app.js о db.json не знает.
 */
(function () {
  'use strict';

  var _db = null;          // последний снимок db с сервера / последнего сохранения
  var _pageTrees = [];     // UI-деревья всех страниц (текущая живёт в state.trees.page)
  var _stTimer = null;
  var _lastSaved = null;   // JSON последнего сохранённого состояния (для автосохранения)
  var _lastSaveAt = Date.now();
  var _importing = false;

  function S() { return App._state; }
  var JSON_HDR = { 'Content-Type': 'application/json' };
  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  /* ── Статусный тост ── */
  function status(msg, err) {
    var el = document.getElementById('_sb_st');
    if (!el) {
      el = document.createElement('div'); el.id = '_sb_st';
      el.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);padding:10px 24px;border-radius:10px;font:600 14px/1.4 Onest,system-ui,sans-serif;color:#fff;z-index:99999;transition:opacity .3s;pointer-events:none';
      document.body.appendChild(el);
    }
    el.textContent = msg; el.style.background = err ? '#c0392b' : '#1f8a5b'; el.style.opacity = '1';
    clearTimeout(_stTimer); _stTimer = setTimeout(function () { el.style.opacity = '0'; }, 2800);
  }

  App.toast = status;   // короткие уведомления из app.js

  /* ── Проект вкладки ──
     Каждый запрос к API несёт id проекта, открытого в этой вкладке (X-UCMS-Project):
     если в другой вкладке переключили проект, сервер ответит 409, и эта вкладка
     ничего не запишет в чужой проект. */
  var PROJECT = null;
  window.name = 'ucms-admin';
  /* Ревизия данных: с какой версии db.json начаты правки этой вкладки. Сервер сообщает ревизию
     до и после каждого запроса; свою запись вкладка узнаёт по совпадению «до» со своей ревизией.
     Сохранение с устаревшей ревизией сервер отклоняет (409 CONFLICT) — правки из другой вкладки
     или с другого устройства не затираются молча. */
  var REV = null, _conflict = false;
  var _fetch = window.fetch.bind(window);
  window.fetch = function (u, o) {
    if (typeof u !== 'string' || u.indexOf('/api/') !== 0) return _fetch(u, o);
    o = Object.assign({}, o);
    var method = (o.method || 'GET').toUpperCase();
    var h = Object.assign({}, o.headers || {});
    if (PROJECT) h['X-UCMS-Project'] = PROJECT.id;
    if (method === 'POST' && u === '/api/data' && REV && !h['X-UCMS-Force']) h['X-UCMS-Base-Rev'] = REV;
    o.headers = h;
    return _fetch(u, o).then(function (r) {
      var was = r.headers.get('X-UCMS-Rev-Was'), now = r.headers.get('X-UCMS-Rev');
      if (now && r.ok) {
        if (method === 'GET' && u === '/api/data') REV = now;
        else if (method !== 'GET' && (was === REV || h['X-UCMS-Force'])) REV = now;
      }
      return r;
    });
  };
  function projectGone(d) {
    _importing = true;   // автосохранение больше ничего не пишет
    var root = document.getElementById('root');
    var other = d && d.active ? '«' + String(d.active.name).replace(/</g, '&lt;') + '»' : '';
    root.innerHTML = '<div class="ad-gone"><div class="ad-gone__box"><b>' + _t('В другой вкладке открыт другой проект') + (other ? ' ' + other : '') + '</b>' +
      '<p>' + _t('Чтобы не записать изменения не туда, эта вкладка больше ничего не сохраняет.') + '</p>' +
      '<div class="ad-btnrow"><a class="ad-b ad-b--dark" href="/admin/projects.html" target="ucms-projects">' + _t('К списку проектов') + '</a>' +
      (PROJECT ? '<button type="button" class="ad-b ad-b--line" onclick="App.reopenProject()">' + _t('Вернуться к') + ' «' + String(PROJECT.name).replace(/</g, '&lt;') + '»</button>' : '') + '</div></div></div>';
  }
  App.reopenProject = function () {
    _fetch('/api/projects/open', { method: 'POST', headers: JSON_HDR, body: JSON.stringify({ id: PROJECT.id }) }).then(function () { location.reload(); });
  };

  function apiFetch(path, opts) {
    return fetch(path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        if (r.status === 409 && d.code === 'NO_PROJECT') { location.href = '/admin/projects.html'; throw new Error(d.error); }
        if (r.status === 409 && d.code === 'PROJECT_SWITCHED') { projectGone(d); throw new Error(d.error); }
        if (r.status === 409 && d.code === 'CONFLICT') { showConflict(); throw new Error(d.error); }
        if (r.status === 401 && d.code === 'AUTH') { location.href = '/admin/login.html?next=' + encodeURIComponent(location.pathname + location.search); throw new Error(d.error); }
        if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status));
        return d;
      });
    });
  }
  // Данные изменили в другом месте: автосохранение останавливаем, решение — за пользователем
  function showConflict() {
    if (_conflict) return;
    _conflict = true;
    App.setStatus(_t('Не сохранено: сайт изменён в другом окне'), true);
    var el = document.createElement('div');
    el.className = 'ad-gone ad-gone--float'; el.setAttribute('role', 'alertdialog');
    el.innerHTML = '<div class="ad-gone__box"><b>' + _t('Сайт изменили в другой вкладке или на другом устройстве') + '</b>' +
      '<p>' + _t('Ваши последние правки не сохранены, чтобы не затереть чужие изменения.') + '</p>' +
      '<div class="ad-btnrow"><button type="button" class="ad-b ad-b--dark" onclick="location.reload()">' + _t('Загрузить актуальную версию') + '</button>' +
      '<button type="button" class="ad-b ad-b--line" onclick="App.conflictForce(this)">' + _t('Сохранить мою версию поверх') + '</button></div></div>';
    document.body.appendChild(el);
  }
  App.conflictForce = function (btn) {
    if (!confirm(_t('Изменения из другого окна будут заменены вашей версией. Продолжить?'))) return;
    btn.disabled = true;
    var db = buildDb(), json = JSON.stringify(db);
    apiFetch('/api/data', { method: 'POST', headers: Object.assign({ 'X-UCMS-Force': '1' }, JSON_HDR), body: json }).then(function () {
      _db = db; _lastSaved = json; _lastSaveAt = Date.now(); _conflict = false;
      var el = document.querySelector('.ad-gone--float'); if (el) el.remove();
      App.setStatus(_t('Сохранено'), false); status(_t('Сохранено'));
    }).catch(function (e) { btn.disabled = false; status(_t('Ошибка сохранения: ') + e.message, true); });
  };
  App.logout = function () {
    App.persistNow().catch(function () {}).then(function () { return _fetch('/api/auth/logout', { method: 'POST' }); })
      .then(function () { location.href = '/admin/login.html'; });
  };

  function postJson(path, body) { return apiFetch(path, { method: 'POST', headers: JSON_HDR, body: JSON.stringify(body) }); }

  /* ══════════════ Ссылки: pageId ↔ название страницы ══════════════ */
  function linkToUi(link, titleById) {
    var lt = link.type === 'internal' ? 'inner' : (link.linkType || link.type || 'none');
    var out = { linkType: lt, url: link.url || '', page: (link.pageId && titleById[link.pageId]) || link.page || null, anchor: link.anchor || '' };
    if (lt === 'file') { out.file = link.file || ''; out.download = link.download !== false; }
    return out;
  }
  function linkToDb(link, idByTitle) {
    var lt = link.linkType === 'inner' ? 'internal' : (link.linkType || 'none');
    var out = { type: lt, url: link.url || '', pageId: (lt === 'internal' && link.page && idByTitle[link.page]) || null };
    if (lt === 'internal' && link.anchor) out.anchor = link.anchor;
    if (lt === 'file') { out.file = link.file || ''; if (link.download === false) out.download = false; }   // файл из медиатеки
    return out;
  }

  /* ══════════════ Блоки движка → модули UI ══════════════ */
  var MOD_DEFAULTS = {
    text:    { html: '' },
    html:    { code: '' },
    divider: { width: 2 },
    button:  { link: { linkType: 'none' } },
    gallery: { items: [], cols: 3, height: 450, mode: 'grid', preview: false },
    lang:    { langMode: 'list' },
    menu:    { menuType: 'list', pagesMode: 'all', selected: {} },
    form:    { formType: 'simple', fields: { name: true, email: true, phone: false, message: true } },
    video:   { preview: false, _modal: false },
    image:   { preview: false },
  };

  function blockToMod(blk, titleById) {
    var m = clone(blk);
    if (m.type === 'title' && typeof m.level === 'number') m.level = 'H' + m.level;
    if (m.link) m.link = linkToUi(m.link, titleById);
    // ссылки элементов любых модулей-списков (галерея, карточки, тарифы…)
    if (Array.isArray(m.items)) {
      m.items = m.items.map(function (it) { return it.link ? Object.assign({}, it, { link: linkToUi(it.link, titleById) }) : it; });
    }
    // Старый формат HTML-блока хранил разметку в 'html' — переносим в 'code'
    if (m.type === 'html' && !m.code && m.html) m.code = m.html;
    if (m.type === 'html') delete m.html;
    var def = MOD_DEFAULTS[m.type] || {};
    Object.keys(def).forEach(function (k) { if (m[k] == null) m[k] = clone(def[k]); });
    // «Вкладки»: у каждой вкладки свои блоки — db-ряды → UI-блоки (рекурсивно)
    if (m.type === 'tabs') m.items = (m.items || []).map(function (it) {
      var o = Object.assign({}, it, { blocks: rowsToBlocks(it.rows, titleById) }); delete o.rows; return o;
    });
    return m;
  }

  // Строка из одной колонки с id *_mc — это «блок без колонок» (mods). Без этого
  // признака после каждого сохранения/загрузки такой блок превращался в колоночный.
  function rowsToBlocks(rows, titleById) {
    return (rows || []).map(function (row) {
      var cols = row.columns || [];
      var toMods = function (list) { return (list || []).map(function (b) { return blockToMod(b, titleById); }); };
      var style = row.style ? clone(row.style) : {};
      if (cols.length === 1 && /_mc$/.test(cols[0].id || '')) {
        return { id: String(row.id).replace(/(_m)+$/, ''), cssClass: row.cssClass || '', style: style, mods: toMods(cols[0].blocks), cols: [] };
      }
      return {
        id: row.id, cssClass: row.cssClass || '', style: style,
        mods: toMods(row.blocks),   // модули блока под колонками
        cols: cols.map(function (col) {
          var w = col.width;
          var has = w && w.value != null && w.value !== '';
          return { id: col.id, width: has ? String(w.value) : '', unit: (has && w.unit) || 'px', align: col.align || '', mods: toMods(col.blocks) };
        }),
      };
    });
  }

  /* ══════════════ Модули UI → блоки движка ══════════════ */
  var TRANSIENT = ['_modal', '_preview', '_codeMode'];   // состояние редактора, в db не пишем

  function modToBlock(m, idByTitle) {
    var blk = clone(m);
    TRANSIENT.forEach(function (k) { delete blk[k]; });
    if (blk.type === 'title' && typeof blk.level === 'string') {
      var n = parseInt(blk.level.replace(/\D/g, ''), 10);
      blk.level = isNaN(n) ? 2 : Math.min(4, Math.max(1, n));
    }
    if (blk.link) blk.link = linkToDb(blk.link, idByTitle);
    if (Array.isArray(blk.items)) {
      blk.items = blk.items.map(function (it) { return it.link ? Object.assign({}, it, { link: linkToDb(it.link, idByTitle) }) : it; });
    }
    if (blk.type === 'tabs') blk.items = (blk.items || []).map(function (it) {
      var o = Object.assign({}, it, { rows: blocksToRows(it.blocks || [], idByTitle) }); delete o.blocks; return o;
    });
    return blk;
  }

  // Настройки блока: только непустые значения (db.json не раздувается дефолтами).
  function cleanStyle(st) {
    var out = {};
    Object.keys(st || {}).forEach(function (k) {
      var v = st[k];
      if (k === 'bg') { if (v && v.type && v.type !== 'none') out.bg = clone(v); return; }
      if (v !== '' && v !== false && v != null) out[k] = v;
    });
    return Object.keys(out).length ? out : undefined;
  }

  // Один блок = одна строка: колонки + модули под ними (row.blocks).
  // Блок без колонок — строка с одной колонкой *_mc (формат, понятный и старым темам).
  function blocksToRows(blocks, idByTitle) {
    var conv = function (mods) { return (mods || []).map(function (m) { return modToBlock(m, idByTitle); }); };
    return (blocks || []).map(function (blk) {
      var row = { id: blk.id, cssClass: blk.cssClass || '' };
      var style = cleanStyle(blk.style); if (style) row.style = style;
      if (blk.cols && blk.cols.length) {
        row.columns = blk.cols.map(function (col) {
          var wv = col.width !== '' ? parseFloat(col.width) : NaN;
          var out = { id: col.id, width: isNaN(wv) ? null : { value: wv, unit: col.unit || 'px' }, blocks: conv(col.mods) };
          if (col.align) out.align = col.align;
          return out;
        });
        if (blk.mods && blk.mods.length) row.blocks = conv(blk.mods);
      } else {
        row.columns = [{ id: blk.id + '_mc', width: null, blocks: conv(blk.mods) }];
      }
      return row;
    });
  }

  // Старые данные могли содержать одинаковые id (прежний счётчик uid начинался с 1
  // на каждой загрузке). Дубликаты получают новые id — иначе правится не тот модуль.
  function dedupeIds(trees) {
    var seen = {};
    function fix(o, pre) { if (!o.id || seen[o.id]) o.id = App.uid(pre); seen[o.id] = 1; }
    function walk(tree) {
      (tree || []).forEach(function (b) {
        fix(b, 'b');
        (b.cols || []).forEach(function (c) { fix(c, 'c'); });
        [b.mods].concat((b.cols || []).map(function (c) { return c.mods; })).forEach(function (mods) {
          (mods || []).forEach(function (m) {
            fix(m, 'm');
            (m.items || []).forEach(function (it) { fix(it, 'g'); if (it.blocks) walk(it.blocks); });   // блоки внутри вкладок
          });
        });
      });
    }
    trees.forEach(walk);
  }

  // Шаблоны секций хранятся в формате движка (row) — переиспользуем конвертеры.
  function titleByIdNow() { var m = {}; (_db ? _db.pages : []).forEach(function (p, i) { m[p.id] = (S().pages[i] || p).title; }); return m; }
  function idByTitleNow() { var m = {}; (_db ? _db.pages : []).forEach(function (p, i) { m[p.title] = p.id; if (S().pages[i]) m[S().pages[i].title] = p.id; }); return m; }
  // Якоря страницы (для полей ссылок): блоки с якорем на странице + в шапке/подвале
  App.pageAnchors = function (title) {
    var s = S(), i = s.pages.findIndex(function (p) { return p.title === title; });
    var out = [], seen = {};
    function walk(tree, where) {
      (tree || []).forEach(function (b, bi) {
        var a = b.style && b.style.anchor;
        if (a && !seen[a]) { seen[a] = 1; out.push({ anchor: a, label: where + ' · ' + _t('Блок') + ' ' + (bi + 1) }); }
      });
    }
    if (i >= 0) walk(i === s.sel ? s.trees.page : _pageTrees[i], _t('страница'));
    walk(s.trees.header, _t('шапка')); walk(s.trees.footer, _t('подвал'));
    return out;
  };
  // Страницы с id — для ссылок в тексте (ucms:page/<id>)
  App.pageRefs = function () {
    var s = S();
    return (_db ? _db.pages : []).map(function (p, i) { return { id: p.id, title: (s.pages[i] || p).title }; });
  };
  App.convert = {
    toRow: function (blk) { return blocksToRows([blk], idByTitleNow())[0]; },
    toBlock: function (row) { return rowsToBlocks([row], titleByIdNow())[0]; },
  };

  /* ══════════════ ЗАГРУЗКА ══════════════ */
  function parentTitle(p) {
    var parent = p.parentId && (_db.pages || []).filter(function (x) { return x.id === p.parentId; })[0];
    return parent ? parent.title : 'root';
  }

  function applyPageMeta(s, p) {
    if (!p) return;
    s.pageTitle = p.title || '';
    s.pageSlug = p.slug || '';
    s.inMenu = p.showInMenu !== false;
    s.headerVisible = p.showHeader !== false;
    s.footerVisible = p.showFooter !== false;
    s.menuOrder = p.order || 0;
    s.menuPos = parentTitle(p);
    App.setBgFromDb(p.background);
    s.pageTr = clone(p.translations || {});
    s.pageSeo = clone(p.seo || {});
    // Запись коллекции: свои поля (дата, обложка, анонс, теги, черновик)
    s.pageEntry = p.collection ? {
      collection: p.collection, date: p.date || '', cover: p.cover || '', excerpt: p.excerpt || '',
      tags: clone(p.tags || []), draft: !!p.draft,
    } : null;
  }
  // Строка списка страниц в UI: у записей — коллекция, дата и черновик (для сайдбара)
  function pageRow(p) {
    var r = { title: p.title, slug: '/' + (p.slug || 'index') + '.html', child: !!p.parentId };
    if (p.collection) { r.coll = p.collection; r.date = p.date || ''; r.draft = !!p.draft; r.order = p.order || 0; r.cover = p.cover || ''; }
    return r;
  }

  // Проект вкладки: ?p=<id> из стартовой страницы, иначе — открытый на сервере.
  function loadFromServer() {
    var want = new URLSearchParams(location.search).get('p');
    _fetch('/api/projects').then(function (r) { return r.json(); }).then(function (pr) {
      if (!pr.active) { location.href = '/admin/projects.html'; throw new Error('no project'); }
      var cur = pr.projects.filter(function (p) { return p.id === pr.active; })[0];
      PROJECT = { id: pr.active, name: (cur && (cur.siteTitle || cur.name)) || '', path: cur && cur.path };
      S().project = PROJECT;
      App.web = pr.mode === 'web';   // веб-версия: без ИИ-перевода, FTP и списка проектов
      App.remote = !App.web && pr.remote ? pr.remote : null;   // локальная UCMS, подключённая к сайту на сервере
      App.hosted = App.web || !!App.remote;   // сайт собирается и публикуется на сервере
      App.webInfo = App.web ? { publishDir: pr.publishDir || '', siteUrl: pr.siteUrl || '', user: pr.user || '', role: pr.role || '', perms: pr.perms || null }
        : App.remote ? { publishDir: App.remote.publishDir || '', siteUrl: App.remote.siteUrl || '', user: App.remote.user || '', role: App.remote.role || '', perms: App.remote.perms || null, server: App.remote.url } : null;
      if (App.hosted) S().user = App.webInfo.user;
      if (App.viewAllowed && !App.viewAllowed(S().view)) S().view = App.firstView();   // раздел по умолчанию недоступен
      if (want && want !== pr.active) {
        var mine = pr.projects.filter(function (p) { return p.id === want; })[0];
        PROJECT = mine ? { id: mine.id, name: mine.siteTitle || mine.name, path: mine.path } : PROJECT;
        projectGone({ active: cur ? { name: cur.siteTitle || cur.name } : null });
        throw new Error('switched');
      }
      // подключаемые модули сайта — до данных: палитра и выключатели модулей строятся с ними
      return apiFetch('/api/modules/packages').then(function (d) { if (App.registerPackages) App.registerPackages(d); }, function () {}).then(function () { return loadData(); });
    }).catch(function (e) { console.warn('[UCMS]', e.message); });
  }
  // Данные db → состояние админки. keep — остаться на той же странице, языке и выделении
  // (перезагрузка после отката версии, отмена/повтор действий).
  function applyDb(db, keep) {
    var s = S();
    var prev = keep ? {
      pageId: _db && _db.pages && _db.pages[s.sel] ? _db.pages[s.sel].id : null,
      plang: s.plang, selected: s.selected, drawer: s.drawer,
    } : null;
    _db = db;
    var pages = db.pages || [];
    var titleById = {};
    pages.forEach(function (p) { titleById[p.id] = p.title; });

    s.pages = pages.map(pageRow);
    s.collections = clone(db.settings.collections || []);
    _pageTrees = pages.map(function (p) { return rowsToBlocks(p.rows, titleById); });
    s.trees.header = rowsToBlocks(db.settings.header && db.settings.header.rows, titleById);
    s.trees.footer = rowsToBlocks(db.settings.footer && db.settings.footer.rows, titleById);
    dedupeIds(_pageTrees.concat([s.trees.header, s.trees.footer]));
    var idx = prev && prev.pageId ? pages.findIndex(function (p) { return p.id === prev.pageId; }) : 0;
    s.sel = idx >= 0 ? idx : 0;
    s.trees.page = _pageTrees[s.sel] || [];
    applyPageMeta(s, pages[s.sel]);

    s.siteName = db.settings.siteTitle || '';
    s.headerSticky = !!(db.settings.header && db.settings.header.sticky);
    s.siteTitleTr = clone(db.settings.siteTitleTranslations || {});
    s.siteUrl = db.settings.siteUrl || '';
    s.siteFavicon = db.settings.favicon || '';
    var md = db.settings.media || {};
    s.mediaCfg = { optimize: md.optimize !== false, maxWidth: parseInt(md.maxWidth, 10) || 2400, quality: parseInt(md.quality, 10) || 82 };
    s.templates = clone(db.settings.sectionTemplates || []);
  s.brand = clone(db.settings.brand || { enabled: true, colors: {} });
  s.brand.colors = s.brand.colors || {};
    s.themeFontName = db.settings.fontFamily || '';
    s.themeFontUrl = db.settings.fontImportUrl || '';
    s.themeCss = db.settings.css || '';
    s.themeName = db.settings.theme || 'default';
    s.langs = (db.settings.languages || [{ code: 'ru', label: _t('Русский'), isDefault: true }]).map(function (l) {
      return { code: String(l.code || 'ru').toUpperCase(), name: l.label || l.code, isDefault: !!l.isDefault };
    });
    var def = s.langs.filter(function (l) { return l.isDefault; })[0] || s.langs[0];
    s.plang = def ? def.code : 'RU';
    s.apiKey = (db.settings.translation && db.settings.translation.apiKey) || '';
    var em = db.settings.enabledModules || [];
    // Модуль, которого не было при прошлом сохранении (новый в движке), — включён.
    var known = db.settings.knownModules || em;
    MODULES.forEach(function (m) { s.moduleSw[m.key] = !em.length || em.indexOf(m.key) >= 0 || known.indexOf(m.key) < 0; });

    if (prev) {
      if (s.langs.some(function (l) { return l.code === prev.plang; })) s.plang = prev.plang;
      var sel = prev.selected;   // выделенный блок/модуль — если он ещё есть
      s.selected = sel && sel.id && s.trees[sel.tree] && JSON.stringify(s.trees[sel.tree]).indexOf('"' + sel.id + '"') >= 0 ? sel : null;
      var dr = prev.drawer;
      s.drawer = dr === 'page' || (/^coll:/.test(dr || '') && (s.collections || []).some(function (c) { return 'coll:' + c.id === dr; })) ? dr : null;
    } else { s.selected = null; s.drawer = null; }
  }

  function loadData(keep) {
    return apiFetch('/api/data').then(function (db) {
      var s = S();
      applyDb(db, keep);
      var built = buildDb();
      _lastSaved = built && JSON.stringify(built);   // исходное состояние не считается «изменением»
      if (App.undoBaseline) App.undoBaseline(keep);

      return apiFetch('/api/themes').then(function (t) {
        if (t.ok) { s.themes = t.themes || []; s.themeName = t.active || s.themeName; }
      }).catch(function () {});
    }).then(function () {
      App.render();
      App.loadPublish();
      document.title = (S().siteName || _t('Сайт без названия')) + ' — UCMS';   // заголовок вкладки
      apiFetch('/api/update').then(function (u) {   // есть новая версия движка — пункт в меню
        var v = u.available ? u.available.version : '';
        if (v !== (S().updateAvailable || '')) { S().updateAvailable = v; App.renderSide(); }
      }).catch(function () {});
    }).catch(function (e) {
      if (document.querySelector('.ad-gone')) return;   // уже показан экран «проект переключён»
      console.error('[UCMS] Load error:', e);
      document.getElementById('root').innerHTML = _t('<div style="padding:40px;font:500 15px Onest,system-ui,sans-serif;color:#c0392b">Не удалось загрузить данные: ') + String(e.message).replace(/</g, '&lt;') + '</div>';
    });
  }

  /* ══════════════ СОХРАНЕНИЕ ══════════════ */
  // Текущая страница: мета из полей формы → s.pages[sel], дерево → _pageTrees[sel].
  function flushCurrentPage() {
    var s = S(), cur = s.pages[s.sel];
    if (!cur) return;
    cur.title = s.pageTitle || cur.title;
    cur.slug = '/' + (s.pageSlug || 'page') + '.html';
    _pageTrees[s.sel] = s.trees.page;
  }

  // Чистая функция от state: ничего не мутирует, кроме синхронизации текущей страницы.
  function buildDb() {
    if (!_db) return null;
    var s = S();
    flushCurrentPage();
    var db = clone(_db);
    db.pages = db.pages || [];

    // Страницы в UI и в db выровнены по индексу; новые — дописываем.
    while (db.pages.length < s.pages.length) {
      var i = db.pages.length;
      db.pages.push({ id: 'pg_' + App.uid(''), title: '', slug: '', parentId: null, order: i, showInMenu: true, showHeader: true, showFooter: true, translations: {}, background: { type: 'none' }, rows: [] });
    }
    db.pages = db.pages.slice(0, s.pages.length);

    // Название → id: сначала текущие названия (переименование в этой сессии),
    // затем прежние — чтобы ссылка, выбранная до переименования, не потерялась.
    var idByTitle = {};
    _db.pages.forEach(function (p, i) { if (db.pages[i]) idByTitle[p.title] = db.pages[i].id; });
    s.pages.forEach(function (sp, i) { idByTitle[sp.title] = db.pages[i].id; });

    s.pages.forEach(function (sp, i) {
      var p = db.pages[i];
      p.title = sp.title;
      p.slug = sp.slug.replace(/^\//, '').replace(/\.html$/, '');
      p.rows = blocksToRows(_pageTrees[i] || [], idByTitle);
      if (sp.coll) p.collection = sp.coll; else delete p.collection;
    });

    var cur = db.pages[s.sel];
    if (cur) {
      cur.showInMenu = !!s.inMenu;
      cur.showHeader = !!s.headerVisible;
      cur.showFooter = !!s.footerVisible;
      cur.order = parseInt(s.menuOrder, 10) || 0;
      cur.parentId = (s.menuPos && s.menuPos !== 'root' && idByTitle[s.menuPos]) || null;
      if (cur.parentId === cur.id) cur.parentId = null;
      cur.background = App.getBgForDb();
      cur.translations = clone(s.pageTr || {});
      var seo = {};
      Object.keys(s.pageSeo || {}).forEach(function (k) { if (s.pageSeo[k]) seo[k] = s.pageSeo[k]; });
      if (Object.keys(seo).length) cur.seo = seo; else delete cur.seo;
      var en = s.pageEntry;
      if (en && cur.collection) {
        cur.date = en.date || ''; cur.excerpt = en.excerpt || ''; cur.cover = en.cover || '';
        cur.tags = (en.tags || []).slice(); cur.draft = !!en.draft;
        cur.showInMenu = false; cur.parentId = null;
        if (!cur.cover) delete cur.cover;
        if (!cur.excerpt) delete cur.excerpt;
        if (!cur.draft) delete cur.draft;
      } else ['date', 'excerpt', 'cover', 'tags', 'draft'].forEach(function (k) { delete cur[k]; });
    }
    // Порядок записей при ручной сортировке хранится в строках UI (меняется стрелками в сайдбаре)
    s.pages.forEach(function (sp, i) { if (sp.coll && db.pages[i] !== cur) db.pages[i].order = sp.order || 0; });
    if (cur && cur.collection) cur.order = (s.pages[s.sel] && s.pages[s.sel].order) || 0;
    db.settings.collections = clone(s.collections || []);

    db.settings.header = Object.assign({ enabled: true }, db.settings.header, { rows: blocksToRows(s.trees.header, idByTitle), sticky: !!s.headerSticky });
    db.settings.footer = Object.assign({ enabled: true }, db.settings.footer, { rows: blocksToRows(s.trees.footer, idByTitle) });
    db.settings.siteTitle = s.siteName || '';
    db.settings.siteTitleTranslations = clone(s.siteTitleTr || {});
    db.settings.siteUrl = s.siteUrl || '';
    db.settings.favicon = s.siteFavicon || '';
    if (s.mediaCfg) db.settings.media = clone(s.mediaCfg);
    db.settings.sectionTemplates = clone(s.templates || []);
    if (s.brand) db.settings.brand = clone(s.brand);
    db.settings.fontFamily = s.themeFontName || '';
    db.settings.fontImportUrl = s.themeFontUrl || '';
    db.settings.css = s.themeCss || '';
    db.settings.theme = s.themeName || 'default';
    db.settings.languages = s.langs.map(function (l) { return { code: l.code.toLowerCase(), label: l.name, isDefault: !!l.isDefault }; });
    db.settings.translation = Object.assign({}, db.settings.translation, { apiKey: s.apiKey || '' });
    db.settings.enabledModules = MODULES.filter(function (m) { return s.moduleSw[m.key] !== false; }).map(function (m) { return m.key; });
    db.settings.knownModules = MODULES.map(function (m) { return m.key; });
    return db;
  }

  // Единая точка сохранения (ручное, автосохранение, перед генерацией).
  function persist(db) {
    var json = JSON.stringify(db);
    return apiFetch('/api/data', { method: 'POST', headers: JSON_HDR, body: json }).then(function (r) {
      _db = db; _lastSaved = json; _lastSaveAt = Date.now();
      var d = new Date();
      // сервер не принял правки в разделах без прав — сообщаем, что именно осталось как было
      if (r && r.kept && r.kept.length) {
        var NAMES = { content: _t('страницы и записи'), layout: _t('шапка и подвал'), design: _t('оформление'), settings: _t('настройки сайта'), media: _t('медиафайлы') };
        App.setStatus(_t('Не сохранено — нет доступа:') + ' ' + r.kept.map(function (k) { return NAMES[k] || k; }).join(', '), true);
        return;
      }
      App.setStatus(_t('Сохранено · ') + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'), false);
    });
  }

  // Для медиатеки (media.js): сохранить сейчас, перечитать данные, запросы к API
  App.persistNow = function () { var db = buildDb(); return db ? persist(db) : Promise.resolve(); };
  App.reloadData = function (keep) { return loadData(keep !== false); };

  /* ── Отмена/повтор (history.js): снимок состояния без темы ──
     Тема (CSS, шрифт, выбор темы) живёт в файлах темы и сохраняется отдельно,
     поэтому в шаги отмены не входит: при отмене остаётся текущей. */
  var THEME_KEYS = ['css', 'theme', 'fontFamily', 'fontImportUrl', 'translation'];
  App.undoSnap = function () {
    var db = buildDb(); if (!db) return null;
    THEME_KEYS.forEach(function (k) { delete db.settings[k]; });
    delete db.settings.knownModules;
    return JSON.stringify(db);
  };
  App.undoApply = function (json) {
    var cur = buildDb(); if (!cur) return;
    var db = JSON.parse(json);
    THEME_KEYS.forEach(function (k) { if (k in cur.settings) db.settings[k] = cur.settings[k]; });
    db.settings.knownModules = cur.settings.knownModules;
    applyDb(db, true);
    App.render();
  };
  App.api = { get: apiFetch, post: postJson };

  App.save = function () {
    var db = buildDb(); if (!db) { status(_t('Данные не загружены'), true); return; }
    persist(db).then(function () { status(_t('Сохранено')); })
      .catch(function (e) { status(_t('Ошибка сохранения: ') + e.message, true); });
  };

  App.generate = function () {
    var db = buildDb(); if (!db) { status(_t('Данные не загружены'), true); return; }
    status(_t('Генерирую…'));
    persist(db)
      .then(function () { return apiFetch('/api/generate', { method: 'POST' }); })
      .then(function (d) {
        if (!App.hosted) { status(_t('Сгенерировано: ') + d.count + _t(' стр. → /output/')); return; }
        var t = new Date();
        S().lastPublished = _t('Опубликовано: ') + d.count + _t(' стр.') +
          (d.published ? ', ' + _t('файлов обновлено:') + ' ' + d.published.copied + (d.published.deleted ? ', ' + _t('удалено:') + ' ' + d.published.deleted : '') : '') +
          ' · ' + String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0');
        status(S().lastPublished);
        if (S().view === 'publish') App.renderView();
      })
      .catch(function (e) { status(_t('Ошибка: ') + e.message, true); });
  };

  App.openPreview = function () { window.open('/output/', '_blank'); };

  /* ══════════════ Страницы ══════════════ */
  App.selectPage = function (idx) {
    var s = S();
    if (idx === s.sel || !s.pages[idx]) return;
    // Мета текущей страницы — в _db, чтобы при возврате поля не откатились
    flushCurrentPage();
    var db = buildDb();
    if (db) _db.pages = db.pages;
    s.sel = idx;
    s.trees.page = _pageTrees[idx] || [];
    s.openPopover = null; s.selected = null;
    applyPageMeta(s, _db.pages[idx]);
    App.render();
  };

  // Уникальные название и адрес новой страницы (ссылки в админке ищут страницу по названию)
  function uniqueTitle(base) {
    var s = S(), t = base, n = 2;
    while (s.pages.some(function (p) { return p.title === t; })) t = base + ' ' + n++;
    return t;
  }
  function uniqueSlug(base, coll) {
    var s = S(), sl = base, n = 2;
    var taken = function (x) { return s.pages.some(function (p) { return (p.coll || '') === (coll || '') && p.slug === '/' + x + '.html'; }); };
    while (taken(sl)) sl = base + '-' + n++;
    return sl;
  }
  // Блок «без колонок» с одним модулем — в формате движка
  function rowWith(mod) { var rid = App.uid('b'); return { id: rid, columns: [{ id: rid + '_mc', width: null, blocks: [mod] }] }; }

  function pushPage(page, openDrawer) {
    var s = S();
    flushCurrentPage();
    var db = buildDb(); if (db) _db.pages = db.pages;
    var titleById = {}; _db.pages.forEach(function (p) { titleById[p.id] = p.title; });
    _db.pages.push(page);
    s.pages.push(pageRow(page));
    _pageTrees.push(rowsToBlocks(page.rows, titleById));
    s.sel = s.pages.length - 1;
    s.trees.page = _pageTrees[s.sel];
    s.selected = null; s.openPopover = null; s.drawer = openDrawer;
    if (s.view !== 'page') s.view = 'page';
    applyPageMeta(s, page);
  }
  function newPage(title, slug) {
    return { id: 'pg_' + App.uid(''), title: title, slug: slug, parentId: null, order: S().pages.length, showInMenu: true, showHeader: true, showFooter: true, translations: {}, background: { type: 'none' }, rows: [] };
  }

  App.addPage = function () {
    var n = S().pages.filter(function (p) { return !p.coll; }).length + 1;
    pushPage(newPage(uniqueTitle(_t('Страница ') + n), uniqueSlug('page-' + n)), 'page');   // новую страницу сразу называем
    App.render();
  };

  /* ══════════════ Коллекции (блог, новости, портфолио, каталог) ══════════════ */
  function today() { var d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  function collById(id) { return (S().collections || []).filter(function (c) { return c.id === id; })[0] || null; }
  App.collById = collById;

  // Новая коллекция сразу с готовой страницей-списком (модуль «Список записей» на ней).
  App.addCollection = function () {
    var s = S();
    var n = (s.collections || []).length;
    var name = uniqueTitle(n ? _t('Коллекция ') + (n + 1) : _t('Блог'));
    var cid = 'col_' + App.uid('');
    var slug = n ? 'items-' + (n + 1) : 'blog';
    while ((s.collections || []).some(function (c) { return c.slug === slug; })) slug += '-2';
    var list = newPage(name, uniqueSlug(slug));
    list.rows = [rowWith({ id: App.uid('m'), type: 'collection', collection: cid, layout: 'grid', cols: 3, perPage: 9, filter: true, showCover: true, showDate: true, showExcerpt: true })];
    s.collections = (s.collections || []).concat([{ id: cid, name: name, slug: slug, listPageId: list.id, sort: 'date', showTitle: true, showDate: true, showCoverTop: false, showTags: false, navTop: true, navBottom: true }]);
    pushPage(list, 'coll:' + cid);
    s.collOpen = s.collOpen || {}; s.collOpen[cid] = true;
    App.render();
  };

  App.addEntry = function (collId) {
    var s = S(), c = collById(collId); if (!c) return;
    var mine = s.pages.filter(function (p) { return p.coll === collId; });
    var page = newPage(uniqueTitle(_t('Новая запись')), uniqueSlug('post-' + (mine.length + 1), collId));
    page.collection = collId; page.date = today(); page.showInMenu = false;
    page.order = mine.reduce(function (m, p) { return Math.max(m, (p.order || 0) + 1); }, 0);
    page.rows = [rowWith({ id: App.uid('m'), type: 'text', html: _t('<p>Текст записи…</p>') })];
    pushPage(page, 'page');
    s.collOpen = s.collOpen || {}; s.collOpen[collId] = true;
    App.render();
  };

  App.setCollField = function (id, field, value, render) {
    var c = collById(id); if (!c) return;
    c[field] = value;
    if (render) App.render(); else { App.renderSide(); }
  };

  // Поле записи (текущая страница): дата, обложка, анонс, теги, черновик, коллекция.
  App.setEntryField = function (field, value, render) {
    var s = S(), en = s.pageEntry, row = s.pages[s.sel]; if (!en || !row) return;
    en[field] = value;
    if (field === 'date') row.date = value;
    if (field === 'draft') row.draft = !!value;
    if (field === 'cover') row.cover = value;
    if (field === 'collection') {
      // в другой папке адрес может совпасть — делаем уникальным
      row.coll = value; row.slug = '/' + uniqueSlug(String(s.pageSlug || 'post'), value) + '.html';
      s.pageSlug = row.slug.replace(/^\//, '').replace(/\.html$/, '');
    }
    if (render) App.render(); else { App.renderSide(); App.renderPageHead(); }
  };
  App.entryTagAdd = function (name) {
    var en = S().pageEntry; name = String(name || '').trim().replace(/\s+/g, ' ').slice(0, 40);
    if (!en || !name || en.tags.indexOf(name) >= 0) return;
    en.tags.push(name); App.renderInsp();
  };
  App.entryTagDel = function (name) {
    var en = S().pageEntry; if (!en) return;
    en.tags = en.tags.filter(function (t) { return t !== name; }); App.renderInsp();
  };
  // Все теги записей коллекции (подсказки в редакторе записи и в «Списке записей»)
  App.collTags = function (collId) {
    var s = S(), seen = {}, out = [];
    var add = function (t) { if (t && !seen[t]) { seen[t] = 1; out.push(t); } };
    (_db ? _db.pages : []).forEach(function (p, i) {
      if (i === s.sel) return;
      if (p.collection === collId) (p.tags || []).forEach(add);
    });
    if (s.pageEntry && s.pageEntry.collection === collId) s.pageEntry.tags.forEach(add);
    return out;
  };

  // Ручной порядок: запись выше/ниже среди записей своей коллекции
  App.moveEntry = function (idx, dir) {
    var s = S(), row = s.pages[idx]; if (!row || !row.coll) return;
    var list = s.pages.map(function (p, i) { return { p: p, i: i }; }).filter(function (x) { return x.p.coll === row.coll; })
      .sort(function (a, b) { return (a.p.order || 0) - (b.p.order || 0); });
    list.forEach(function (x, k) { x.p.order = k; });   // нормализуем
    var k = list.findIndex(function (x) { return x.i === idx; }), j = k + dir;
    if (j < 0 || j >= list.length) return;
    var a = list[k].p, b = list[j].p, t = a.order; a.order = b.order; b.order = t;
    App.renderSide();
  };

  App.deleteCollection = function (id) {
    var s = S(), c = collById(id); if (!c) return;
    var count = s.pages.filter(function (p) { return p.coll === id; }).length;
    if (!confirm(_t('Удалить коллекцию «') + c.name + '»' + (count ? _t(' и её записи (') + count + ')' : '') + _t('? Страница-список останется.'))) return;
    flushCurrentPage();
    var db = buildDb(); if (db) _db.pages = db.pages;
    var curId = _db.pages[s.sel] && _db.pages[s.sel].id;
    for (var i = s.pages.length - 1; i >= 0; i--) {
      if (s.pages[i].coll === id) { s.pages.splice(i, 1); _pageTrees.splice(i, 1); _db.pages.splice(i, 1); }
    }
    s.collections = s.collections.filter(function (x) { return x.id !== id; });
    var keep = _db.pages.findIndex(function (p) { return p.id === curId; });
    s.sel = keep >= 0 ? keep : 0;
    s.trees.page = _pageTrees[s.sel] || [];
    s.selected = null; s.drawer = null;
    applyPageMeta(s, _db.pages[s.sel]);
    App.render();
  };

  App.deletePage = function () {
    var s = S();
    var isEntry = !!s.pages[s.sel].coll;
    if (!isEntry && s.pages.filter(function (p) { return !p.coll; }).length <= 1) { status(_t('Нельзя удалить единственную страницу'), true); return; }
    if (!confirm((isEntry ? _t('Удалить запись «') : _t('Удалить страницу «')) + s.pages[s.sel].title + '»?')) return;
    var db = buildDb(); if (db) _db.pages = db.pages;
    var removedId = _db.pages[s.sel] && _db.pages[s.sel].id;
    s.pages.splice(s.sel, 1); _pageTrees.splice(s.sel, 1); _db.pages.splice(s.sel, 1);
    // Дочерние страницы удалённой поднимаем в корень меню
    _db.pages.forEach(function (p, i) { if (p.parentId === removedId) { p.parentId = null; s.pages[i].child = false; } });
    s.sel = Math.min(s.sel, s.pages.length - 1);
    // после удаления записи остаёмся в её коллекции, страницы — на ближайшей обычной странице
    if (!isEntry && s.pages[s.sel] && s.pages[s.sel].coll) s.sel = Math.max(0, s.pages.findIndex(function (p) { return !p.coll; }));
    s.trees.page = _pageTrees[s.sel] || [];
    s.selected = null; s.drawer = null;
    applyPageMeta(s, _db.pages[s.sel]);
    App.render();
  };

  /* ══════════════ Загрузка файлов ══════════════ */
  App.uploadImageAtPlain = App.uploadImageAt = function (onSuccess, kind) {
    var inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*';
    inp.onchange = function () {
      var file = inp.files[0]; if (!file) return;
      var rd = new FileReader();
      rd.onload = function () {
        postJson('/api/upload', { name: file.name, data: String(rd.result).split(',')[1], kind: kind || 'images' })
          .then(function (d) { onSuccess('/' + d.path); status(_t('Загружено')); })
          .catch(function (e) { status(_t('Ошибка загрузки: ') + e.message, true); });
      };
      rd.readAsDataURL(file);
    };
    inp.click();
  };

  function cardModule(el) {
    var card = el.closest('[data-mid]');
    return card ? { tree: card.getAttribute('data-tree'), id: card.getAttribute('data-mid'), mod: App.getModule(card.getAttribute('data-tree'), card.getAttribute('data-mid')) } : null;
  }

  /* ══════════════ ИИ-перевод ══════════════ */
  function collectTexts(blocks) {
    var items = [];
    function walk(mods) {
      (mods || []).forEach(function (m) {
        (App.TRANSLATABLE[m.type] || []).forEach(function (f) { items.push({ obj: m, field: f[0] }); });
        (App.ITEM_TRANSLATABLE[m.type] || []).forEach(function (f) {
          (m.items || []).forEach(function (it) { items.push({ obj: it, field: f[0] }); });
        });
        if (m.type === 'cards' && m.filter) (m.tags || []).forEach(function (tg) { items.push({ obj: tg, field: 'name' }); });
        if (m.type === 'tabs') (m.items || []).forEach(function (it) { walkBlocks(it.blocks); });   // тексты внутри вкладок
      });
    }
    function walkBlocks(list) { (list || []).forEach(function (blk) { walk(blk.mods); (blk.cols || []).forEach(function (c) { walk(c.mods); }); }); }
    walkBlocks(blocks);
    return items;
  }

  App.aiTranslatePage = function (targetCode) {
    if (App.hosted) return;
    var s = S();
    var src = s.langs.filter(function (l) { return l.isDefault; })[0] || s.langs[0];
    var trg = s.langs.filter(function (l) { return l.code === targetCode; })[0];
    if (!src || !trg || trg.isDefault) return;
    var lc = String(targetCode).toLowerCase();       // на сайте переводы хранятся по коду в нижнем регистре
    var items = collectTexts(s.trees.page);
    // Поля самой страницы (название, описание, анонс записи) — если перевода ещё нет
    var ptr = (s.pageTr && s.pageTr[lc]) || {};
    var pageSrc = { title: s.pageTitle || '', description: (s.pageSeo && s.pageSeo.description) || '', excerpt: (s.pageEntry && s.pageEntry.excerpt) || '' };
    Object.keys(pageSrc).forEach(function (f) { if (pageSrc[f] && !ptr[f]) items.push({ obj: pageSrc, field: f, page: true }); });
    var texts = items.map(function (it) { return it.obj[it.field] || ''; });
    if (!texts.some(Boolean)) { status(_t('Нечего переводить'), true); return; }
    status(_t('Перевожу…'));
    postJson('/api/translate', { sourceLabel: src.name, targetLabel: trg.name, items: texts })
      .then(function (d) {
        d.items.forEach(function (v, i) {
          if (!v || !items[i]) return;
          if (items[i].page) {
            s.pageTr = s.pageTr || {};
            (s.pageTr[lc] = s.pageTr[lc] || {})[items[i].field] = v;
            return;
          }
          var o = items[i].obj;
          o.translations = o.translations || {};
          o.translations[lc] = o.translations[lc] || {};
          o.translations[lc][items[i].field] = v;       // исходник не трогаем
        });
        App.refreshTranslations();
        status(_t('Переведено! Проверьте текст в инспекторе.'));
      }).catch(function (e) { status(_t('Ошибка: ') + e.message, true); });
  };

  /* ══════════════ Публикация (FTP/FTPS) ══════════════ */
  var _pubTimer = null;
  function pubState() { var s = S(); s.publish = s.publish || {}; return s.publish; }
  function pubForm(cfg) {
    return { protocol: cfg.protocol, host: cfg.host, port: cfg.port, user: cfg.user, password: '', dir: cfg.dir, allowSelfSigned: cfg.allowSelfSigned,
      projectSync: cfg.projectSync !== false, projectDir: cfg.projectDir || '', encrypt: !!cfg.encrypt, projectPassword: '' };
  }
  App.loadPublish = function () {
    if (App.hosted) return Promise.resolve();   // сайт на сервере UCMS — FTP не нужен
    return apiFetch('/api/publish/config').then(function (d) {
      var P = pubState(); P.config = d.config; if (!P.form) P.form = pubForm(d.config);
      if (S().view === 'publish') App.renderView();
      App.renderTop();
      if (App.loadSync) App.loadSync();   // проект на сервере: нет ли правок с другого компьютера
    }).catch(function () {});
  };
  // Форма отличается от сохранённых настроек (в т.ч. введён новый пароль FTP или проекта)
  function pubDirty() {
    var P = pubState();
    return !!(P.form && P.config && JSON.stringify(P.form) !== JSON.stringify(pubForm(P.config)));
  }
  function savePub(quiet) {
    var P = pubState();
    return postJson('/api/publish/config', P.form).then(function (d) {
      P.config = d.config; P.form = pubForm(d.config); P.testMsg = '';
      App.renderView(); App.renderTop();
      if (!quiet) status(_t('Настройки публикации сохранены'));
      if (App.loadSync) App.loadSync(true);
    });
  }
  App.savePublish = function () { return savePub(false).catch(function (e) { status(_t('Ошибка: ') + e.message, true); }); };
  function setTestMsg(html) { pubState().testMsg = html; var el = document.querySelector('[data-pub-test]'); if (el) el.innerHTML = html; }
  App.testPublish = function () {
    setTestMsg(_t('<div class="ad-f__hint">Подключаюсь…</div>'));
    App.savePublish().then(function () { return postJson('/api/publish/test', {}); }).then(function (d) {
      var pr = d.ok && d.project;
      setTestMsg(d.ok ? _t('<div class="ad-pub__msg is-ok">Подключение работает, папка на сервере доступна.</div>') +
          (pr && pr.enabled && pr.writable === false ? '<div class="ad-pub__msg is-err">' + _t('Нет записи в папку проекта') + ' ' + String(pr.dir).replace(/</g, '&lt;') + '. ' + _t('Укажите папку проекта внутри папки сайта и задайте пароль проекта — он будет храниться зашифрованным.') + '</div>' : '')
                      : '<div class="ad-pub__msg is-err">' + String(d.error).replace(/</g, '&lt;') + '</div>');
    }).catch(function (e) { setTestMsg('<div class="ad-pub__msg is-err">' + String(e.message).replace(/</g, '&lt;') + '</div>'); });
  };
  // Опрос статуса, пока идёт публикация; интервал снимается сразу по завершении.
  function pollPublish() {
    if (_pubTimer) return;
    _pubTimer = setInterval(function () {
      apiFetch('/api/publish/status').then(function (d) {
        var P = pubState(); P.job = d.job; App.renderPubJob();
        if (!d.job.running) {
          clearInterval(_pubTimer); _pubTimer = null;
          if (d.job.phase === 'error' && d.job.code === 'REMOTE_NEWER') { status(_t('Не опубликовано: на сервере более новая версия'), true); if (App.syncConflict) App.syncConflict(d.job.remote); }
          else if (d.job.phase === 'error') status(_t('Публикация: ') + d.job.error, true);
          else { status(_t('Опубликовано: загружено ') + d.job.result.uploaded + _t(' файл(ов)')); if (App.syncAfterPublish) App.syncAfterPublish(d.job.result); }
          if (S().view === 'publish') App.renderView();
        }
      }).catch(function () { clearInterval(_pubTimer); _pubTimer = null; });
    }, 500);
  }
  App.startPublish = function (force) {
    var db = buildDb(); if (!db) return;
    status(_t('Публикую…'));
    // несохранённые настройки публикации (например, только что введённый пароль проекта) — сначала сохраняем
    (pubDirty() ? savePub(true) : Promise.resolve())
      .then(function () { return persist(db); })
      .then(function () { return postJson('/api/publish/start', { force: force === true }); })
      .then(function (d) {
        if (!d.ok) throw new Error(d.error);
        pubState().job = { running: true, phase: 'connect', done: 0, total: 0, current: (pubState().config || {}).host || '' };
        App.renderPubJob(); pollPublish();
      })
      .catch(function (e) { status(_t('Ошибка: ') + e.message, true); });
  };
  App.resetPublish = function () {
    if (!confirm(_t('Следующая публикация загрузит все файлы сайта заново. Продолжить?'))) return;
    postJson('/api/publish/reset', {}).then(function () { status(_t('Следующая публикация загрузит всё заново')); });
  };

  /* ══════════════ Экспорт / импорт / резервные копии ══════════════ */
  function backupState() { var s = S(); s.backup = s.backup || {}; return s.backup; }
  App.loadBackups = function () {
    return apiFetch('/api/backups').then(function (d) { backupState().list = d.backups; App.renderBackup(); }).catch(function () {});
  };
  // Файл читаем один раз; сначала сервер только разбирает его (dry), потом — заменяет по подтверждению.
  App.importPick = function (file) {
    if (!file) return;
    var B = backupState();
    var rd = new FileReader();
    rd.onload = function () {
      B.pendingData = rd.result;
      fetch('/api/import?dry=1', { method: 'POST', body: rd.result }).then(function (r) { return r.json(); }).then(function (d) {
        if (!d.ok) throw new Error(d.error);
        B.pending = { summary: d.summary, fileName: file.name };
        App.renderBackup();
      }).catch(function (e) { B.pending = null; B.pendingData = null; status(_t('Не удалось прочитать файл: ') + e.message, true); });
    };
    rd.readAsArrayBuffer(file);
  };
  App.importCancel = function () { var B = backupState(); B.pending = null; B.pendingData = null; App.renderBackup(); };
  App.importApply = function () {
    var B = backupState(); if (!B.pendingData || B.busy) return;
    B.busy = true; _importing = true; App.renderBackup();   // автосохранение не должно записать старый сайт поверх нового
    fetch('/api/import', { method: 'POST', body: B.pendingData }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.ok) throw new Error(d.error);
      status(_t('Сайт загружен. Резервная копия: ') + d.backup);
      setTimeout(function () { location.reload(); }, 600);
    }).catch(function (e) { B.busy = false; _importing = false; App.renderBackup(); status(_t('Ошибка импорта: ') + e.message, true); });
  };
  App.backupNow = function () {
    postJson('/api/backups/create', {}).then(function (d) { status(_t('Резервная копия: ') + d.name); App.loadBackups(); })
      .catch(function (e) { status(_t('Ошибка: ') + e.message, true); });
  };

  /* ══════════════ Темы ══════════════ */
  var _cssSaveTimer = null;
  App.saveThemeCss = function (value) {
    S().themeCss = value;
    clearTimeout(_cssSaveTimer);
    _cssSaveTimer = setTimeout(function () {
      _cssSaveTimer = null;
      postJson('/api/theme-css-save', { css: value })
        .then(function () { status(_t('Стили темы сохранены')); })
        .catch(function (e) { status(_t('Ошибка сохранения стилей: ') + e.message, true); });
    }, 600);
  };
  function applyTheme(d, msg) {
    var s = S();
    s.themeCss = d.css; s.themeName = d.active; s.themes = d.themes || s.themes;
    if (d.font) { s.themeFontName = d.font.fontFamily || ''; s.themeFontUrl = d.font.fontImportUrl || ''; }   // шрифт принадлежит теме
    status(msg + d.active); App.renderSettings();
  }
  App.switchTheme = function (name) {
    if (!name || name === S().themeName) return;
    status(_t('Переключаю тему…'));
    postJson('/api/theme-switch', { name: name })
      .then(function (d) { applyTheme(d, _t('Тема: ')); })
      .catch(function (e) { status(_t('Ошибка: ') + e.message, true); });
  };
  App.createTheme = function () {
    var s = S(), name = (s.newThemeName || '').trim();
    if (!name) { status(_t('Введите имя темы'), true); return; }
    postJson('/api/theme-create', { name: name, from: 'current' })
      .then(function (d) { s.newThemeName = ''; applyTheme(d, _t('Тема создана: ')); })
      .catch(function (e) { status(_t('Ошибка: ') + e.message, true); });
  };

  /* ══════════════ Делегирование кликов ══════════════ */
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!(t instanceof Element)) return;

    // Картинка модуля «Изображение»
    var up = t.closest('.ad-upload__btn');
    if (up) {
      var cm = cardModule(up);
      if (cm && cm.mod) App.uploadImageAt(function (url) { cm.mod.src = url; App.renderModule(cm.tree, cm.id); }, 'images');
      return;
    }
    // Картинка элемента галереи (id элемента, а не индекс карточки: порядок мог измениться)
    var galUp = t.closest('.ad-gal-up__btn');
    if (galUp) {
      var gm = cardModule(galUp);
      var cards = gm ? Array.prototype.slice.call(galUp.closest('.ad-gal-grid').children) : [];
      var item = gm && gm.mod && gm.mod.items[cards.indexOf(galUp.closest('.ad-gal-card'))];
      if (item) App.uploadImageAt(function (url) { item.src = url; App.renderModule(gm.tree, gm.id); }, 'gallery');
      return;
    }
    // Картинка элемента списка (карточки): data-item / data-field на кнопке
    var liUp = t.closest('.ad-li-up');
    if (liUp) {
      var lm = cardModule(liUp), itemId = liUp.getAttribute('data-item'), field = liUp.getAttribute('data-field');
      var li = lm && lm.mod && (lm.mod.items || []).filter(function (x) { return x.id === itemId; })[0];
      if (li) App.uploadImageAt(function (url) { li[field] = url; App.renderModule(lm.tree, lm.id); }, 'images');
      return;
    }
    // Картинка в поле самого модуля (стрелки галереи): data-field на кнопке
    var modUp = t.closest('.ad-mod-up');
    if (modUp) {
      var mm = cardModule(modUp), mf = modUp.getAttribute('data-field');
      if (mm && mm.mod) App.uploadImageAt(function (url) { mm.mod[mf] = url; App.renderModule(mm.tree, mm.id); }, 'images');
      return;
    }
    // Иконка сайта (favicon)
    if (t.closest('.ad-site-up')) { App.uploadImageAt(function (url) { App.setFavicon(url); }, 'favicon'); return; }
    // Картинка для соцсетей (SEO страницы)
    if (t.closest('.ad-seo-up')) { App.uploadImageAt(function (url) { App.setPageSeo('image', url, true); }, 'images'); return; }
    // Обложка видео
    var vc = t.closest('.ad-vcover__btn');
    if (vc) {
      var vm = cardModule(vc);
      if (vm && vm.mod) App.uploadImageAt(function (url) { vm.mod.cover = url; App.renderModule(vm.tree, vm.id); }, 'images');
      return;
    }
    // Фон страницы или блока (картинка / узор): цель — в data-bg редактора
    var bgUp = t.closest('.ad-bg-up');
    if (bgUp) {
      var target = bgUp.closest('[data-bg]').getAttribute('data-bg');
      App.uploadImageAt(function (url) { App.bgSet(target, 'image', url); }, 'background');
    }
  });

  /* ══════════════ Статус и автосохранение ══════════════
     Раз в 4 с сравниваем состояние с последним сохранённым (полный JSON):
     есть разница — статус «не сохранено», а через 30 с после прошлого
     сохранения — автосохранение. На скрытой вкладке ничего не делаем. */
  setInterval(function () {
    if (!_db || document.hidden || _importing || _conflict) return;
    var db = buildDb(); if (!db) return;
    if (JSON.stringify(db) === _lastSaved) return;
    App.setStatus(_t('Есть несохранённые изменения'), true);
    if (Date.now() - _lastSaveAt >= 30000) persist(db).catch(function () { /* повторим на следующем тике */ });
  }, 4000);

  /* ══════════════ Внешние правки theme.css ══════════════
     На вкладке «Настройка темы» подтягиваем файл, если его изменили снаружи,
     пользователь не в поле и нет несохранённой правки. */
  setInterval(function () {
    var s = S();
    if (!s || s.view !== 'theme' || _cssSaveTimer || document.hidden) return;
    fetch('/api/theme-css').then(function (r) { return r.text(); }).then(function (txt) {
      if (typeof txt !== 'string' || txt === s.themeCss || _cssSaveTimer) return;
      var ta = document.querySelector('.ad-css-editor');
      if (ta && document.activeElement === ta) return;
      s.themeCss = txt;
      if (ta) ta.value = txt;
      status(_t('Стили обновлены из файла'));
    }).catch(function () {});
  }, 2500);

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', loadFromServer);
  else loadFromServer();
})();

/* ============================================================
   СТИЛЬ ПРОЕКТА (Тема → Стиль проекта): цвета, скругление, размер
   текста и шрифты поверх темы. Хранится в db.settings.brand, на сайте —
   блоком в конце style.css (server.js: brandCss), файл темы не меняется.
   Пустое значение = как в теме. Значения темы по умолчанию читаются из
   :root её CSS и показываются подсказкой.

   Образец справа обновляется без перерисовки панели (фокус в полях и
   открытый пикер не теряются). Шрифты для образца подключаются в админку
   <link>-ом — по одному на адрес, повторно не добавляются.
   ============================================================ */
(function () {
  'use strict';
  var App = window.App;
  function S() { return App._state; }
  function K() { return App.kit; }

  var COLORS = [
    ['accent', _t('Акцент'), _t('ссылки, кнопки, активные пункты')],
    ['paper', _t('Фон страницы'), ''],
    ['panel', _t('Панели'), _t('шапка, подвал, карточки')],
    ['ink', _t('Текст'), ''],
    ['muted', _t('Второстепенный текст'), ''],
    ['line', _t('Линии'), _t('границы и разделители')],
  ];
  // Стандартные палитры — быстрый старт, дальше правится вручную. Свои палитры и
  // скрытые стандартные хранятся на компьютере, общие для всех проектов (/api/palettes).
  var PRESETS = [
    { id: 'light', name: _t('Светлая'), colors: { paper: '#f7f7f5', panel: '#ffffff', ink: '#16181d', muted: '#6b7079', accent: '#2e5bdb', line: '#e4e4e0' } },
    { id: 'warm', name: _t('Тёплая'), colors: { paper: '#f6f1e9', panel: '#fffaf2', ink: '#2b2118', muted: '#7d6f60', accent: '#c8672b', line: '#e8ddcc' } },
    { id: 'nature', name: _t('Природа'), colors: { paper: '#f1f4ef', panel: '#fafcf8', ink: '#1b2a20', muted: '#64746a', accent: '#1f8a5b', line: '#dde5dc' } },
    { id: 'strict', name: _t('Строгая'), colors: { paper: '#ffffff', panel: '#f5f5f5', ink: '#111111', muted: '#666666', accent: '#111111', line: '#e2e2e2' } },
    { id: 'dark', name: _t('Тёмная'), colors: { paper: '#121316', panel: '#1b1d22', ink: '#ececef', muted: '#9a9ca5', accent: '#8b7bff', line: '#2c2f36' } },
  ];
  // Популярные шрифты Google с кириллицей: ссылка с весами, которые у шрифта есть
  var FONTS = [
    ['Inter', '400;500;600;700'], ['Manrope', '400;500;600;700'], ['Onest', '400;500;600;700'], ['Golos Text', '400;500;600;700'],
    ['Montserrat', '400;500;600;700'], ['Roboto', '400;500;700'], ['Rubik', '400;500;600;700'], ['Nunito', '400;600;700'],
    ['Open Sans', '400;600;700'], ['PT Sans', '400;700'], ['Fira Sans', '400;500;600;700'], ['IBM Plex Sans', '400;500;600;700'],
    ['Raleway', '400;500;600;700'], ['Ubuntu', '400;500;700'], ['Unbounded', '400;500;600;700'], ['Oswald', '400;500;600;700'],
    ['Playfair Display', '400;600;700'], ['Lora', '400;600;700'], ['Merriweather', '400;700'], ['PT Serif', '400;700'],
    ['Cormorant Garamond', '400;600;700'], ['Comfortaa', '400;600;700'], ['Caveat', '400;700'], ['Lobster', '400'],
  ];
  function fontUrl(name) {
    var f = FONTS.filter(function (x) { return x[0].toLowerCase() === String(name || '').trim().toLowerCase(); })[0];
    return f ? 'https://fonts.googleapis.com/css2?family=' + f[0].replace(/ /g, '+') + ':wght@' + f[1] + '&display=swap' : '';
  }

  function brand() {
    var s = S();
    s.brand = s.brand || { enabled: true, colors: {} };
    s.brand.colors = s.brand.colors || {};
    return s.brand;
  }
  // Значения токенов темы из её CSS (первый :root)
  function themeTokens() {
    var css = String(S().themeCss || ''), out = {};
    var root = /:root\s*\{([^}]*)\}/.exec(css);
    (root ? root[1] : '').replace(/--([a-z-]+)\s*:\s*([^;]+);/gi, function (m, k, v) { out[k] = v.trim(); return m; });
    var fs = /body\s*\{[^}]*font-size:\s*([\d.]+)px/.exec(css);
    out['font-size'] = fs ? fs[1] : '16';
    return out;
  }
  function value(key) {
    var b = brand(), t = themeTokens();
    var v = b.colors[key];
    return v || t[key] || '';
  }

  /* ── контраст (WCAG): предупреждаем о нечитаемых сочетаниях ── */
  function rgb(c) {
    c = String(c || '').trim();
    var m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(c);
    if (!m) return null;
    var h = m[1].length === 3 ? m[1].replace(/./g, '$&$&') : m[1];
    return [0, 2, 4].map(function (i) { return parseInt(h.substr(i, 2), 16); });
  }
  function lum(c) {
    var v = rgb(c); if (!v) return null;
    v = v.map(function (x) { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); });
    return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
  }
  function contrast(a, b) {
    var la = lum(a), lb = lum(b);
    if (la == null || lb == null) return null;
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }
  function warnings() {
    var out = [], c;
    c = contrast(value('ink'), value('paper'));
    if (c != null && c < 4.5) out.push(_t('Текст плохо читается на фоне страницы') + ' (' + c.toFixed(1) + ' : 1)');
    c = contrast(value('accent'), '#ffffff');
    if (c != null && c < 3) out.push(_t('Белый текст на кнопках акцентного цвета читается плохо') + ' (' + c.toFixed(1) + ' : 1)');
    c = contrast(value('accent'), value('paper'));
    if (c != null && c < 3) out.push(_t('Ссылки акцентного цвета сливаются с фоном') + ' (' + c.toFixed(1) + ' : 1)');
    return out;
  }

  /* ── образец ── */
  var loadedFonts = {};
  function ensureFont(f) {
    if (!f || !f.family || f.local) return;
    var url = f.url || fontUrl(f.family) || 'https://fonts.googleapis.com/css2?family=' + encodeURIComponent(f.family).replace(/%20/g, '+') + '&display=swap';
    if (loadedFonts[url]) return;
    loadedFonts[url] = true;
    var l = document.createElement('link'); l.rel = 'stylesheet'; l.href = url;
    document.head.appendChild(l);
  }
  function fam(f, fallback) { return f && f.family ? '"' + f.family.replace(/["\\<>]/g, '') + '", ' + fallback : fallback; }
  function sampleVars() {
    var b = brand(), t = themeTokens();
    var on = b.enabled !== false;
    var get = function (k) { return (on && b.colors[k]) || t[k] || ''; };
    var themeFont = S().themeFontName ? '"' + S().themeFontName.replace(/["\\<>]/g, '') + '", sans-serif' : 'system-ui, sans-serif';
    var r = on && b.radius !== '' && b.radius != null ? b.radius + 'px' : (t.radius || '10px');
    return {
      '--b-paper': get('paper') || '#f4f2ec', '--b-panel': get('panel') || '#fff', '--b-ink': get('ink') || '#1a1a2e',
      '--b-muted': get('muted') || '#6b7280', '--b-accent': get('accent') || '#5b3fc8', '--b-line': get('line') || '#e5e3dc',
      '--b-radius': r,
      '--b-font': on ? fam(b.fontBody, themeFont) : themeFont,
      '--b-head': on && b.fontHead && b.fontHead.family ? fam(b.fontHead, themeFont) : (on ? fam(b.fontBody, themeFont) : themeFont),
      '--b-size': ((on && b.fontSize) || t['font-size'] || 16) + 'px',
    };
  }
  function refreshSample() {
    var el = document.querySelector('[data-brand-sample]'); if (!el) return;
    var v = sampleVars();
    Object.keys(v).forEach(function (k) { el.style.setProperty(k, v[k]); });
    var b = brand();
    if (b.enabled !== false) { ensureFont(b.fontBody); ensureFont(b.fontHead); }
    var w = document.querySelector('[data-brand-warn]');
    if (w) { var list = warnings(); w.innerHTML = list.map(function (x) { return '<div>⚠ ' + K().esc(x) + '</div>'; }).join(''); w.hidden = !list.length; }
  }

  /* ── действия ── */
  App.brandColor = function (key, v) {
    var b = brand();
    v = String(v || '').trim();
    if (v) b.colors[key] = v; else delete b.colors[key];
    refreshSample();
  };
  App.brandColorReset = function (key) { delete brand().colors[key]; App.renderView(); };
  App.brandSet = function (field, v, render) {
    var b = brand();
    if (field === 'radius' || field === 'fontSize') v = v === '' || v == null ? '' : Math.max(0, parseFloat(v) || 0);
    b[field] = v;
    if (render) App.renderView(); else refreshSample();
  };
  App.brandFont = function (which, field, v) {
    var b = brand(), key = which === 'head' ? 'fontHead' : 'fontBody';
    var f = b[key] = b[key] || { family: '', url: '' };
    f[field] = String(v || '').trim();
    if (field === 'family') {
      // шрифт из списка — подставляем ссылку с его начертаниями; свой — ссылку не трогаем
      var u = fontUrl(f.family);
      if (u) f.url = u;
      else if (/^https:\/\/fonts\.googleapis\.com\//.test(f.url || '')) f.url = '';
      var inp = document.getElementById('brand-' + which + '-url');
      if (inp && inp.value !== (f.url || '')) inp.value = f.url || '';
    }
    if (!f.family && !f.url) delete b[key];
    refreshSample();
  };
  /* ── палитры: стандартные + свои ── */
  var PAL = { custom: [], hidden: [], loaded: false, loading: false, adding: false };
  function loadPalettes() {
    if (PAL.loaded || PAL.loading || !App.api) return;
    PAL.loading = true;
    App.api.get('/api/palettes').then(function (d) {
      PAL.custom = d.custom || []; PAL.hidden = d.hidden || [];
    }).catch(function () { /* без сервера — только стандартные */ }).then(function () {
      PAL.loaded = true; PAL.loading = false; rerenderPresets();
    });
  }
  function savePalettes() {
    return App.api.post('/api/palettes', { custom: PAL.custom, hidden: PAL.hidden })
      .then(function (d) { PAL.custom = d.custom || []; PAL.hidden = d.hidden || []; rerenderPresets(); })
      .catch(function (e) { if (App.toast) App.toast(_t('Ошибка: ') + e.message, true); });
  }
  function palettes() {
    return PRESETS.filter(function (p) { return PAL.hidden.indexOf(p.id) < 0; }).concat(PAL.custom.map(function (p) { return Object.assign({ own: true }, p); }));
  }
  function rerenderPresets() {
    var el = document.querySelector('[data-brand-presets]');
    if (el) el.outerHTML = presetsHTML();
  }
  App.brandPreset = function (id) {
    var p = palettes().filter(function (x) { return x.id === id; })[0]; if (!p) return;
    brand().colors = JSON.parse(JSON.stringify(p.colors));
    App.renderView();
  };
  App.brandPaletteDel = function (id) {
    var own = PAL.custom.some(function (p) { return p.id === id; });
    var p = palettes().filter(function (x) { return x.id === id; })[0]; if (!p) return;
    if (!confirm(_t('Удалить палитру «') + p.name + _t('»? Палитры общие для всех проектов.'))) return;
    if (own) PAL.custom = PAL.custom.filter(function (x) { return x.id !== id; });
    else PAL.hidden.push(id);
    savePalettes();
  };
  App.brandPaletteAdd = function (open) { PAL.adding = !!open; rerenderPresets(); var i = document.getElementById('br-pal-name'); if (i) i.focus(); };
  App.brandPaletteSave = function () {
    var inp = document.getElementById('br-pal-name');
    var name = (inp && inp.value.trim()) || _t('Моя палитра ') + (PAL.custom.length + 1);
    var colors = {};
    COLORS.forEach(function (c) { var v = value(c[0]); if (v) colors[c[0]] = v; });   // текущие цвета: свои или темы
    PAL.custom.push({ id: 'p' + Date.now().toString(36), name: name, colors: colors });
    PAL.adding = false;
    savePalettes().then(function () { if (App.toast) App.toast(_t('Палитра сохранена')); });
  };
  App.brandPalettesRestore = function () { PAL.hidden = []; savePalettes(); };
  function presetsHTML() {
    var k = K();
    loadPalettes();
    var list = palettes().map(function (p) {
      var c = p.colors || {};
      return '<span class="br-preset' + (p.own ? ' is-own' : '') + '"><button type="button" class="br-preset__b" onclick="App.brandPreset(' + k.jsArg(p.id) + ')" title="' + k.escAttr(p.name) + '">' +
        '<span style="background:' + k.escAttr(c.paper || '#fff') + '"><i style="background:' + k.escAttr(c.accent || '#888') + '"></i><i style="background:' + k.escAttr(c.ink || '#111') + '"></i></span>' + k.esc(p.name) + '</button>' +
        '<button type="button" class="br-preset__x" aria-label="' + k.escAttr(_t('Удалить палитру')) + '" title="' + k.escAttr(_t('Удалить палитру')) + '" onclick="App.brandPaletteDel(' + k.jsArg(p.id) + ')">×</button></span>';
    }).join('');
    var add = PAL.adding
      ? '<span class="br-pal-add"><input id="br-pal-name" class="ad-in ad-in--sm" placeholder="' + k.escAttr(_t('Название палитры')) + '" onkeydown="if(event.key===\'Enter\')App.brandPaletteSave();if(event.key===\'Escape\')App.brandPaletteAdd(false)">' +
        '<button type="button" class="ad-b ad-b--sm ad-b--dark" onclick="App.brandPaletteSave()">' + _t('Сохранить') + '</button>' +
        '<button type="button" class="ad-b ad-b--sm" onclick="App.brandPaletteAdd(false)">' + _t('Отмена') + '</button></span>'
      : '<button type="button" class="br-preset br-preset--add" onclick="App.brandPaletteAdd(true)" title="' + k.escAttr(_t('Сохранить текущие цвета как палитру')) + '">+ ' + _t('Сохранить текущие') + '</button>';
    var restore = PAL.hidden.length ? '<button type="button" class="ad-linkbtn br-pal-restore" onclick="App.brandPalettesRestore()">' + _t('Вернуть стандартные') + ' (' + PAL.hidden.length + ')</button>' : '';
    return '<div class="br-presets" data-brand-presets>' + list + add + restore + '</div>';
  }

  /* ── выбор шрифта: поле + свой выпадающий список (у <datalist> список
     фильтруется по введённому и после выбора не открывается снова) ── */
  var FL = { which: null, idx: -1, all: false };
  function fontItems(q) {
    q = String(q || '').trim().toLowerCase();
    return FONTS.map(function (f) { return f[0]; }).filter(function (n) { return !q || n.toLowerCase().indexOf(q) >= 0; });
  }
  function fontListEl(which) { return document.querySelector('[data-brand-font="' + which + '"] .br-font__list'); }
  function renderFontList(which) {
    var k = K(), el = fontListEl(which); if (!el) return;
    var cur = ((brand()[which === 'head' ? 'fontHead' : 'fontBody'] || {}).family || '');
    var items = fontItems(FL.all ? '' : cur);
    var rows = ['<button type="button" class="br-font__i br-font__i--none' + (FL.idx === 0 ? ' is-hl' : '') + '" data-v="">' + (which === 'head' ? _t('как шрифт текста') : _t('как в теме')) + '</button>']
      .concat(items.map(function (n, i) {
        var on = n.toLowerCase() === cur.toLowerCase();
        return '<button type="button" class="br-font__i' + (on ? ' is-on' : '') + (FL.idx === i + 1 ? ' is-hl' : '') + '" data-v="' + k.escAttr(n) + '">' + k.esc(n) + (on ? k.ico('check', 12) : '') + '</button>';
      }));
    el.innerHTML = rows.join('') + (items.length ? '' : '<div class="br-font__empty">' + _t('Нет в списке — будет подключён с Google Fonts по названию') + '</div>');
    el.hidden = false;
    var hl = el.querySelector('.is-hl'); if (hl) hl.scrollIntoView({ block: 'nearest' });
  }
  function closeFontList() {
    if (!FL.which) return;
    var el = fontListEl(FL.which); if (el) el.hidden = true;
    FL.which = null; FL.idx = -1;
  }
  // keep — клик в поле: открыть, но не закрывать уже открытый список
  App.brandFontOpen = function (which, all, keep) {
    if (FL.which && FL.which !== which) closeFontList();
    if (FL.which === which && all) { if (!keep) closeFontList(); return; }   // повторный клик по стрелке — закрыть
    FL.which = which; FL.all = !!all; FL.idx = -1;
    renderFontList(which);
  };
  App.brandFontInput = function (which, v) {
    App.brandFont(which, 'family', v);
    FL.which = which; FL.all = false; FL.idx = -1;
    renderFontList(which);
  };
  function pickFont(which, name) {
    var inp = document.querySelector('[data-brand-font="' + which + '"] input');
    if (inp) inp.value = name;
    App.brandFont(which, 'family', name);
    closeFontList();
  }
  App.brandFontKey = function (e, which) {
    if (e.key === 'Escape') { closeFontList(); return; }
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp' && e.key !== 'Enter') return;
    if (FL.which !== which) { App.brandFontOpen(which, true); e.preventDefault(); return; }
    var btns = fontListEl(which).querySelectorAll('.br-font__i');
    if (e.key === 'Enter') { if (FL.idx >= 0 && btns[FL.idx]) { e.preventDefault(); pickFont(which, btns[FL.idx].getAttribute('data-v')); } else closeFontList(); return; }
    e.preventDefault();
    FL.idx = Math.max(0, Math.min(btns.length - 1, FL.idx + (e.key === 'ArrowDown' ? 1 : -1)));
    renderFontList(which);
  };
  // Клик по пункту списка и клик вне — один слушатель на всё время работы админки
  document.addEventListener('mousedown', function (e) {
    var item = e.target.closest && e.target.closest('.br-font__i');
    if (item) { e.preventDefault(); pickFont(item.closest('[data-brand-font]').getAttribute('data-brand-font'), item.getAttribute('data-v')); return; }
    if (FL.which && !(e.target.closest && e.target.closest('[data-brand-font]'))) closeFontList();
  });
  App.brandReset = function () {
    if (!confirm(_t('Сбросить стиль проекта? Сайт будет выглядеть как в теме.'))) return;
    S().brand = { enabled: brand().enabled !== false, colors: {} };
    App.renderView();
  };

  App.renderBrandPanel = function () {
    var k = K(), UI = k.UI, b = brand(), t = themeTokens(), on = b.enabled !== false;
    var colors = COLORS.map(function (c) {
      var own = b.colors[c[0]] || '', theme = t[c[0]] || '';
      return '<div class="br-color"><div class="br-color__l"><b>' + k.esc(c[1]) + '</b>' + (c[2] ? '<small>' + k.esc(c[2]) + '</small>' : '') + '</div>' +
        '<div class="br-color__in">' + k.colorInput(own, 'App.brandColor(' + k.jsArg(c[0]) + ',this.value)', c[1]) +
        (own ? k.ib('close', _t('Как в теме'), 'App.brandColorReset(' + k.jsArg(c[0]) + ')')
          : '<span class="br-theme" title="' + k.escAttr(_t('Значение темы')) + '"><i style="background:' + k.escAttr(theme) + '"></i>' + k.esc(_t('тема')) + '</span>') + '</div></div>';
    }).join('');
    var presets = presetsHTML();
    var fontRow = function (which, label, hint) {
      var f = b[which === 'head' ? 'fontHead' : 'fontBody'] || {};
      return '<div class="ad-f"><span class="ad-f__l">' + k.esc(label) + '</span>' +
        '<div class="br-font" data-brand-font="' + which + '"><input class="ad-in" role="combobox" aria-autocomplete="list" autocomplete="off" placeholder="' + k.escAttr(hint) + '" value="' + k.escAttr(f.family || '') + '"' +
        ' oninput="App.brandFontInput(' + k.jsArg(which) + ',this.value)" onclick="App.brandFontOpen(' + k.jsArg(which) + ',true,true)" onkeydown="App.brandFontKey(event,' + k.jsArg(which) + ')">' +
        '<button type="button" class="br-font__btn" tabindex="-1" aria-label="' + k.escAttr(_t('Список шрифтов')) + '" onmousedown="event.preventDefault()" onclick="App.brandFontOpen(' + k.jsArg(which) + ',true)">' + k.ico('chevd', 13) + '</button>' +
        '<div class="br-font__list" role="listbox" hidden></div></div>' +
        '<input id="brand-' + which + '-url" class="ad-in ad-in--mono ad-in--sm" placeholder="' + k.escAttr(_t('Ссылка на шрифт (необязательно)')) + '" value="' + k.escAttr(f.url || '') + '" oninput="App.brandFont(' + k.jsArg(which) + ',\'url\',this.value)"></div>';
    };
    var themeSize = t['font-size'] || '16';
    var sample = '<div class="br-sample" data-brand-sample>' +
      '<div class="br-sample__head"><b>' + k.esc(S().siteName || _t('Название сайта')) + '</b><span>' + _t('Главная') + '</span><span class="is-on">' + _t('О нас') + '</span><span>' + _t('Контакты') + '</span></div>' +
      '<div class="br-sample__body"><div class="br-sample__h">' + _t('Заголовок страницы') + '</div>' +
      '<p>' + _t('Обычный текст абзаца. ') + '<a>' + _t('Ссылка в тексте') + '</a>. <span class="br-sample__muted">' + _t('Второстепенный текст.') + '</span></p>' +
      '<div class="br-sample__row"><span class="br-sample__btn">' + _t('Кнопка') + '</span><div class="br-sample__card"><b>' + _t('Карточка') + '</b><span>' + _t('Описание карточки') + '</span></div></div></div></div>';
    var html = '<section class="ad-panel br">' +
      '<div class="br-h"><div><div class="ad-panel__t">' + _t('Стиль проекта') + '</div>' +
      '<span class="ad-f__hint">' + _t('Цвета и шрифты этого сайта поверх темы. Тема не меняется: при смене темы стиль проекта сохраняется. Пустое поле — значение темы.') + '</span></div>' +
      '<div class="br-h__r">' + UI.sw(_t('Включён'), on, 'App.brandSet(\'enabled\',' + (on ? 'false' : 'true') + ',true)') +
      UI.btn(_t('Сбросить'), 'App.brandReset()', { sm: true, variant: 'line' }) + '</div></div>' +
      '<div class="br-grid' + (on ? '' : ' is-off') + '"><div class="br-controls">' +
      '<div class="ad-f"><span class="ad-f__l">' + _t('Палитры') + '</span>' + presets +
      '<span class="ad-f__hint">' + _t('Клик — применить. Свои палитры и удаление стандартных — общие для всех проектов на этом компьютере.') + '</span></div>' +
      '<div class="br-colors">' + colors + '</div>' +
      '<div class="br-row2">' +
      UI.field(_t('Скругление углов'), '<div class="ad-affix"><input type="number" min="0" max="40" placeholder="' + k.escAttr(String(parseFloat(t.radius) || 10)) + '" value="' + k.escAttr(b.radius == null ? '' : b.radius) + '" oninput="App.brandSet(\'radius\',this.value)"><span>px</span></div>') +
      UI.field(_t('Размер текста'), '<div class="ad-affix"><input type="number" min="12" max="24" placeholder="' + k.escAttr(themeSize) + '" value="' + k.escAttr(b.fontSize == null ? '' : b.fontSize) + '" oninput="App.brandSet(\'fontSize\',this.value)"><span>px</span></div>') + '</div>' +
      fontRow('body', _t('Шрифт текста'), _t('как в теме') + (S().themeFontName ? ' — ' + S().themeFontName : '')) +
      fontRow('head', _t('Шрифт заголовков'), _t('как шрифт текста')) +
      '<span class="ad-f__hint">' + _t('Шрифты из списка подключаются с Google Fonts со всеми начертаниями. Для другого шрифта вставьте ссылку «Embed» с fonts.google.com (или свою).') + '</span>' +
      '</div><div class="br-side"><span class="ad-eyebrow2">' + _t('Образец') + '</span>' + sample +
      '<div class="br-warn" data-brand-warn hidden></div></div></div></section>';
    setTimeout(refreshSample, 0);   // после вставки в DOM
    return html;
  };
})();

/* ============================================================
   ПРОЕКТ НА СЕРВЕРЕ (публикация → publish/project.js на сервере UCMS).

   • Блок «Проект на сервере» в «Публикации»: хранить ли исходники рядом с сайтом,
     папка, шифрование, пароль проекта, состояние, «Скачать правки».
   • Плашка вверху админки: проект на сервере изменён с другого компьютера —
     «Скачать правки» (или «Опубликовать поверх», если это всплыло при публикации).
   Статус с сервера проверяется при открытии проекта и после публикации,
   не по таймеру: каждое обращение — это FTP-подключение.
   ============================================================ */
(function () {
  'use strict';
  var App = window.App;
  var PUBLIC_ROOTS = /^(public_html|www|htdocs|httpdocs|html|web|wwwroot|public|site)$/i;

  function S() { return App._state; }
  function K() { return App.kit; }
  function Y() { var s = S(); s.sync = s.sync || { status: null, conflict: null, dismissed: false, busy: '' }; return s.sync; }
  function toast(t, bad) { if (App.toast) App.toast(t, bad); }
  function fmt(iso) {
    if (!iso) return '';
    var d = new Date(iso), p = function (n) { return String(n).padStart(2, '0'); };
    return p(d.getDate()) + '.' + p(d.getMonth() + 1) + '.' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }

  // Та же логика, что в publish/project.js: папка проекта по умолчанию — рядом с публичной папкой
  function norm(p) { var n = ('/' + String(p || '/').replace(/\\/g, '/')).replace(/\/+/g, '/'); return n.length > 1 ? n.replace(/\/$/, '') : '/'; }
  function autoDir(site) {
    var parts = norm(site).split('/').filter(Boolean);
    if (!parts.length) return '/.ucms-project';
    var i = -1; parts.forEach(function (p, k) { if (i < 0 && PUBLIC_ROOTS.test(p)) i = k; });
    var base = i >= 0 ? parts.slice(0, i) : parts.slice(0, -1);
    var rest = (i >= 0 ? parts.slice(i + 1) : parts.slice(-1)).join('-').replace(/[^\w.-]+/g, '-');
    return '/' + base.concat([rest ? 'ucms-project-' + rest : 'ucms-project']).join('/');
  }
  function inside(site, dir) { var s = norm(site), d = norm(dir); return s === '/' || d === s || d.indexOf(s + '/') === 0; }
  function formTarget(f) {
    var dir = f.projectDir ? norm(f.projectDir) : autoDir(f.dir);
    var ins = inside(f.dir, dir);
    return { dir: dir, inside: ins, encrypted: ins || !!f.encrypt, enabled: f.projectSync !== false };
  }

  /* ── статус ── */
  App.loadSync = function (fresh) {
    var P = S().publish || {};
    if (!P.config || !P.config.host) return Promise.resolve();
    var Ys = Y();
    Ys.checking = true;
    if (S().view === 'publish') App.renderView();
    return App.api.get('/api/sync/status' + (fresh ? '?fresh=1' : '')).then(function (d) {
      Ys.checking = false;
      Ys.status = d;
      if (d.state === 'remote-newer') Ys.dismissed = false; else Ys.conflict = null;
      App.renderSyncBar();
      if (S().view === 'publish') App.renderView();
    }).catch(function (e) { Ys.checking = false; Ys.status = { ok: false, error: e.message }; if (S().view === 'publish') App.renderView(); });
  };
  // Публикация остановилась: на сервере проект новее
  App.syncConflict = function (remote) {
    var Ys = Y();
    Ys.conflict = remote || {}; Ys.dismissed = false;
    Ys.status = Object.assign({}, Ys.status || {}, { state: 'remote-newer', remote: remote });
    App.renderSyncBar();
  };
  App.syncAfterPublish = function (result) {
    var Ys = Y();
    Ys.conflict = null;
    App.renderSyncBar();
    if (result && result.project) App.loadSync(true);   // свежий манифест: дата и компьютер
    if (result && result.projectError) toast(_t('Сайт опубликован, но проект на сервер не сохранён:') + ' ' + result.projectError.message, true);
  };

  /* ── «Скачать правки» ── */
  App.syncPull = function () {
    var Ys = Y();
    if (Ys.busy) return;
    if (!confirm(_t('Заменить данные этого проекта версией с сервера?') + '\n' + _t('Правки, сделанные здесь после последней публикации, будут заменены. Перед заменой сохранятся резервная копия и версия в «Истории».'))) return;
    Ys.busy = _t('Скачиваю правки с сервера…'); App.renderSyncBar(); if (S().view === 'publish') App.renderView();
    App.persistNow().catch(function () {}).then(function () { return App.api.post('/api/sync/pull', {}); }).then(function () {
      (function poll() {
        App.api.get('/api/sync/job').then(function (d) {
          var j = d.job;
          if (j.running) {
            Ys.busy = j.phase === 'files' && j.total ? _t('Скачиваю файлы') + ' ' + j.done + ' / ' + j.total : _t('Скачиваю правки с сервера…');
            var el = document.querySelector('[data-sync-busy]'); if (el) el.textContent = Ys.busy;
            setTimeout(poll, 600); return;
          }
          if (j.phase === 'error') throw new Error(j.code === 'NEED_PASSWORD' || j.code === 'BAD_PASSWORD' ? _t('Неверный или не задан пароль проекта — укажите его в «Публикации».') : j.error);
          var miss = (j.result && j.result.missing) || [];
          toast(_t('Правки получены') + (miss.length ? '. ' + _t('Не найдено на сервере файлов:') + ' ' + miss.length : ''));
          setTimeout(function () { location.reload(); }, 500);
        }).catch(function (e) { Ys.busy = ''; toast(_t('Не удалось получить правки:') + ' ' + e.message, true); App.renderSyncBar(); if (S().view === 'publish') App.renderView(); });
      })();
    }).catch(function (e) { Ys.busy = ''; toast(e.message, true); App.renderSyncBar(); });
  };
  App.syncForce = function () {
    if (!confirm(_t('Опубликовать эту версию поверх?') + '\n' + _t('Сайт и проект на сервере заменятся версией с этого компьютера — правки, сделанные на другом компьютере, пропадут.'))) return;
    var Ys = Y(); Ys.conflict = null; Ys.dismissed = true; App.renderSyncBar();
    App.startPublish(true);
  };
  App.syncDismiss = function () { Y().dismissed = true; App.renderSyncBar(); };

  /* ── плашка вверху админки ── */
  App.renderSyncBarHTML = function () {
    var Ys = Y(), st = Ys.status || {};
    var show = !Ys.dismissed && (Ys.conflict || st.state === 'remote-newer');
    if (!show && !(Ys.busy && st.state === 'remote-newer')) return '<div data-syncbar hidden></div>';
    var r = Ys.conflict || st.remote || {}, k = K();
    var who = [r.updatedAt ? fmt(r.updatedAt) : '', r.computer ? _t('компьютер') + ' ' + r.computer : ''].filter(Boolean).join(' · ');
    return '<div data-syncbar class="ad-syncbar" role="alert">' + k.ico('cloud', 18) +
      '<div class="ad-syncbar__t"><b>' + (Ys.conflict ? _t('Публикация остановлена: сайт изменили с другого компьютера') : _t('На сервере есть правки с другого компьютера')) + '</b>' +
      '<span>' + (who ? esc(who) + '. ' : '') + _t('Скачайте их, чтобы продолжить работу с актуальной версией.') + '</span></div>' +
      (Ys.busy ? '<span class="ad-syncbar__busy" data-sync-busy>' + esc(Ys.busy) + '</span>' :
        '<div class="ad-syncbar__a"><button type="button" class="ad-b ad-b--primary ad-b--sm" onclick="App.syncPull()">' + k.ico('down', 14) + _t('Скачать правки') + '</button>' +
        (Ys.conflict ? '<button type="button" class="ad-b ad-b--sm ad-syncbar__force" onclick="App.syncForce()">' + _t('Опубликовать поверх') + '</button>' : '') +
        '<button type="button" class="ad-ib" aria-label="' + K().escAttr(_t('Позже')) + '" title="' + K().escAttr(_t('Позже')) + '" onclick="App.syncDismiss()">' + k.ico('close', 14) + '</button></div>') +
      '</div>';
  };
  App.renderSyncBar = function () {
    var el = document.querySelector('[data-syncbar]');
    if (el) el.outerHTML = App.renderSyncBarHTML();
  };
  function esc(s) { return K().esc(s); }

  /* ── блок «Проект на сервере» в «Публикации» ── */
  App.renderProjectPanel = function () {
    var P = S().publish || {}, f = P.form, c = P.config || {}, k = K(), UI = k.UI, Ys = Y();
    if (!f) return '';
    var t = formTarget(f);
    var html = '<section class="ad-panel ad-proj"><div class="ad-panel__t">' + _t('Проект на сервере') + '</div>' +
      '<span class="ad-f__hint" style="margin-top:-8px">' + _t('Рядом с сайтом хранятся его исходники: страницы, настройки, темы. Так проект можно открыть на другом компьютере («Проекты → Добавить существующий → С сервера») и получать правки. Пароли FTP и ключ ИИ-перевода на сервер не попадают.') + '</span>' +
      UI.sw(_t('Хранить проект на сервере'), t.enabled, 'App.setPub(\'projectSync\',' + !t.enabled + ')');
    if (!t.enabled) return html + '</section>';
    html += '<div class="ad-f"><label class="ad-f__l" for="pub-pdir">' + _t('Папка проекта на сервере') + '</label>' +
      '<input id="pub-pdir" class="ad-in ad-in--mono" placeholder="' + k.escAttr(autoDir(f.dir)) + '" value="' + k.escAttr(f.projectDir || '') + '" oninput="App.setPub(\'projectDir\',this.value)" onchange="App.renderView()">' +
      '<span class="ad-f__hint">' + (t.inside
        ? '<span style="color:var(--warn,#b26b00)">' + _t('Папка внутри папки сайта — её можно открыть из интернета, поэтому проект будет зашифрован паролем проекта.') + '</span>'
        : _t('Выше папки сайта — из интернета не видна. Пусто — папка по умолчанию.')) + '</span></div>' +
      (t.inside ? '' : UI.sw(_t('Шифровать проект паролем'), !!f.encrypt, 'App.setPub(\'encrypt\',' + !f.encrypt + ')'));
    if (t.encrypted) {
      html += '<div class="ad-f"><label class="ad-f__l" for="pub-ppass">' + _t('Пароль проекта') + '</label>' +
        '<input id="pub-ppass" class="ad-in" type="password" autocomplete="new-password" placeholder="' + k.escAttr(c.hasProjectPassword ? _t('сохранён — оставьте пустым') : _t('придумайте пароль')) + '" value="' + k.escAttr(f.projectPassword || '') + '" oninput="App.setPub(\'projectPassword\',this.value)">' +
        '<span class="ad-f__hint">' + _t('Нужен, чтобы открыть проект на другом компьютере. Запишите его: без пароля проект с сервера не восстановить (сайт при этом не пострадает).') + '</span></div>';
    }
    // состояние на сервере
    var st = Ys.status, line;
    if (!c.host) line = _t('Заполните подключение и сохраните — после публикации проект появится на сервере.');
    else if (Ys.checking) line = _t('Проверяю сервер…');
    else if (!st) line = '';
    else if (st.ok === false) line = '<span style="color:var(--danger)">' + esc(st.error) + '</span>';
    else if (!st.enabled) line = '';
    else if (st.state === 'none') line = _t('На сервере проекта ещё нет — он появится после следующей публикации.');
    else {
      var r = st.remote || {};
      var meta = [fmt(r.updatedAt), st.mine ? _t('с этого компьютера') : r.computer ? _t('компьютер') + ' ' + esc(r.computer) : '', r.encrypted ? _t('зашифрован') : ''].filter(Boolean).join(' · ');
      line = st.state === 'same'
        ? k.ico('check', 13) + ' ' + _t('На сервере та же версия, что здесь') + (meta ? ' · ' + meta : '')
        : '<b style="color:var(--warn,#b26b00)">' + _t('На сервере более новая версия') + '</b>' + (meta ? ' · ' + meta : '');
    }
    html += (line ? '<div class="ad-f__hint ad-proj__st">' + line + '</div>' : '') +
      (c.host ? '<div class="ad-btnrow">' + UI.btn(_t('Сохранить'), 'App.savePublish()', { sm: true, variant: 'dark' }) + UI.btn(_t('Проверить сервер'), 'App.loadSync(true)', { sm: true }) +
        (st && st.remote ? UI.btn(Ys.busy ? Ys.busy : _t('Скачать правки с сервера'), 'App.syncPull()', { sm: true, variant: st.state === 'remote-newer' ? 'primary' : 'line' }) : '') + '</div>' : '');
    return html + '</section>';
  };
})();

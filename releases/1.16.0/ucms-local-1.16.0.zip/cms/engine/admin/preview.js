/* ============================================================
   ПРЕДПРОСМОТР САЙТА в админке: ПК / планшет / телефон.

   Страницы собирает сервер на лету из сохранённых данных (/preview/…),
   без генерации в output/. Перед открытием и по «Обновить» текущие правки
   сохраняются. Ширина «устройства» — настоящая ширина iframe (медиазапросы
   сайта срабатывают как на устройстве); если окно меньше — рамка
   масштабируется целиком.

   Память: окно предпросмотра — один элемент в <body>; слушатели resize и
   keydown вешаются при открытии и снимаются при закрытии, iframe удаляется
   вместе с окном.
   ============================================================ */
(function () {
  'use strict';
  var App = window.App;
  var KEY = 'ucms-preview-device';
  var DEVICES = {
    desktop: { w: 1440, h: 900, label: _t('ПК'), icon: '<rect x="1.5" y="2.5" width="13" height="8.5" rx="1"/><path d="M5.5 14h5M8 11v3"/>' },
    tablet: { w: 768, h: 1024, label: _t('Планшет'), icon: '<rect x="3" y="1.5" width="10" height="13" rx="1.5"/><path d="M7 12.5h2"/>' },
    phone: { w: 390, h: 844, label: _t('Телефон'), icon: '<rect x="4.5" y="1.5" width="7" height="13" rx="1.5"/><path d="M7.3 12.5h1.4"/>' },
  };
  var P = { el: null, device: 'desktop', landscape: false, onResize: null, onKey: null };

  function S() { return App._state; }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function svg(path, size) { return '<svg width="' + (size || 16) + '" height="' + (size || 16) + '" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + path + '</svg>'; }
  var ICO = {
    close: '<path d="m4 4 8 8M12 4l-8 8"/>',
    reload: '<path d="M13.5 8a5.5 5.5 0 1 1-1.6-3.9"/><path d="M13.7 2.6v2.6h-2.6"/>',
    ext: '<path d="M9 2h5v5M14 2 7.5 8.5M12 9.5V14H2V4h4.5"/>',
    rotate: '<rect x="2" y="5" width="12" height="7" rx="1.3"/><path d="M5 2.5h4.5a2 2 0 0 1 2 2"/><path d="m10 3.3 1.5 1.2 1.2-1.5"/>',
    edit: '<path d="M11 2.5 13.5 5 6 12.5l-3 .5.5-3z"/>',
  };
  try { var saved = JSON.parse(localStorage.getItem(KEY) || '{}'); if (DEVICES[saved.d]) { P.device = saved.d; P.landscape = !!saved.l; } } catch (e) { /* без localStorage — по умолчанию */ }
  function remember() { try { localStorage.setItem(KEY, JSON.stringify({ d: P.device, l: P.landscape })); } catch (e) { /* не критично */ } }

  function frame() { return P.el && P.el.querySelector('iframe'); }
  function size() {
    var d = DEVICES[P.device];
    return P.device !== 'desktop' && P.landscape ? { w: d.h, h: d.w } : { w: d.w, h: d.h };
  }
  // Размер и масштаб рамки под окно
  function layout() {
    if (!P.el) return;
    var stage = P.el.querySelector('.pv-stage'), box = P.el.querySelector('.pv-frame');
    var sw = stage.clientWidth - 32, sh = stage.clientHeight - 32, sz = size();
    var k, w = sz.w, h;
    if (P.device === 'desktop') { k = Math.min(1, sw / w); h = Math.max(320, sh / k); }
    else { h = sz.h; k = Math.min(1, sw / w, sh / h); }
    box.style.width = w + 'px'; box.style.height = h + 'px';
    box.style.transform = 'scale(' + k + ')';
    box.parentNode.style.width = Math.round(w * k) + 'px';
    box.parentNode.style.height = Math.round(h * k) + 'px';
    var z = P.el.querySelector('[data-pv-size]');
    if (z) z.textContent = w + ' × ' + Math.round(h) + (k < 0.999 ? ' · ' + Math.round(k * 100) + '%' : '');
  }

  function barHTML() {
    var langs = S().langs || [];
    var devs = Object.keys(DEVICES).map(function (k) {
      var on = k === P.device;
      return '<button type="button" class="ad-segm__o' + (on ? ' is-on' : '') + '" aria-pressed="' + on + '" onclick="App.previewDevice(\'' + k + '\')">' + svg(DEVICES[k].icon, 15) + '<span>' + esc(DEVICES[k].label) + '</span></button>';
    }).join('');
    var lang = langs.length > 1 ? '<div class="ad-segm pv-langs" role="group">' + langs.map(function (l) {
      return '<button type="button" class="ad-segm__o" data-pv-lang="' + esc(l.code.toLowerCase()) + '" onclick="App.previewLang(\'' + esc(l.code.toLowerCase()) + '\')">' + esc(l.code) + '</button>';
    }).join('') + '</div>' : '';
    return '<div class="pv-bar">' +
      '<div class="pv-bar__l"><b>' + _t('Предпросмотр') + '</b><span class="pv-addr" data-pv-addr></span></div>' +
      '<div class="pv-bar__c"><div class="ad-segm pv-devs" role="group" aria-label="' + esc(_t('Устройство')) + '">' + devs + '</div>' +
      '<button type="button" class="ad-ib" data-pv-rotate title="' + esc(_t('Повернуть')) + '" aria-label="' + esc(_t('Повернуть')) + '" onclick="App.previewRotate()"' + (P.device === 'desktop' ? ' disabled' : '') + '>' + svg(ICO.rotate) + '</button>' +
      '<span class="pv-size" data-pv-size></span>' + lang + '</div>' +
      '<div class="pv-bar__r">' +
      '<button type="button" class="ad-b ad-b--sm" data-pv-edit onclick="App.previewEdit()" hidden>' + svg(ICO.edit, 14) + _t('Редактировать эту страницу') + '</button>' +
      '<button type="button" class="ad-ib" title="' + esc(_t('Обновить (сохранить правки)')) + '" aria-label="' + esc(_t('Обновить')) + '" onclick="App.previewReload()">' + svg(ICO.reload) + '</button>' +
      '<button type="button" class="ad-ib" title="' + esc(_t('Открыть в новой вкладке')) + '" aria-label="' + esc(_t('Открыть в новой вкладке')) + '" onclick="App.previewNewTab()">' + svg(ICO.ext) + '</button>' +
      '<button type="button" class="ad-ib" title="' + esc(_t('Закрыть (Esc)')) + '" aria-label="' + esc(_t('Закрыть')) + '" onclick="App.closePreview()">' + svg(ICO.close) + '</button></div></div>';
  }

  // Какая страница открыта в предпросмотре: адрес и id (meta ucms-page)
  function onFrameLoad() {
    var f = frame(); if (!f) return;
    var addr = P.el.querySelector('[data-pv-addr]'), edit = P.el.querySelector('[data-pv-edit]');
    var path = '', id = '';
    try {
      path = f.contentWindow.location.pathname.replace(/^\/preview\//, '/');
      var meta = f.contentDocument.querySelector('meta[name="ucms-page"]');
      id = meta ? meta.getAttribute('content') : '';
    } catch (e) { /* внешний сайт по ссылке — адрес недоступен */ }
    P.pageId = id;
    if (addr) addr.textContent = path;
    if (edit) edit.hidden = !id;
    var lang = (/^\/([a-z]{2,3}(?:-[a-z]+)?)\//i.exec(path) || [])[1];
    P.el.querySelectorAll('[data-pv-lang]').forEach(function (b) {
      var on = b.getAttribute('data-pv-lang') === String(lang || '').toLowerCase();
      b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', on);
    });
  }

  function curPageId() {
    var s = S(), refs = App.pageRefs ? App.pageRefs() : [];
    return s.view === 'page' && refs[s.sel] ? refs[s.sel].id : (refs[0] && refs[0].id) || '';
  }

  App.openPreview = function () {
    if (P.el) return;
    var s = S(), lang = String(s.plang || '').toLowerCase();
    var src = '/preview/__page/' + encodeURIComponent(curPageId()) + (lang ? '?lang=' + encodeURIComponent(lang) : '');
    P.el = document.createElement('div');
    P.el.className = 'pv';
    P.el.setAttribute('role', 'dialog');
    P.el.setAttribute('aria-modal', 'true');
    P.el.setAttribute('aria-label', _t('Предпросмотр'));
    P.el.innerHTML = barHTML() + '<div class="pv-stage"><div class="pv-fit"><div class="pv-frame pv-frame--' + P.device + '"><iframe title="' + esc(_t('Предпросмотр сайта')) + '"></iframe></div></div><div class="pv-wait">' + _t('Сохраняю и собираю страницу…') + '</div></div>';
    document.body.appendChild(P.el);
    document.body.classList.add('pv-open');
    var f = frame();
    f.addEventListener('load', function () { P.el && P.el.classList.add('is-ready'); onFrameLoad(); });
    P.onResize = function () { layout(); };
    P.onKey = function (e) { if (e.key === 'Escape') App.closePreview(); };
    window.addEventListener('resize', P.onResize);
    document.addEventListener('keydown', P.onKey);
    layout();
    var go = function () { if (frame()) frame().src = src; };
    (App.persistNow ? App.persistNow() : Promise.resolve()).then(go, go);   // не сохранилось — показываем сохранённое
  };
  App.closePreview = function () {
    if (!P.el) return;
    window.removeEventListener('resize', P.onResize);
    document.removeEventListener('keydown', P.onKey);
    P.onResize = P.onKey = null;
    var f = frame(); if (f) f.src = 'about:blank';   // останавливаем видео, таймеры страницы
    P.el.remove(); P.el = null;
    document.body.classList.remove('pv-open');
  };
  App.previewDevice = function (d) {
    if (!DEVICES[d] || !P.el) return;
    P.device = d; remember();
    P.el.querySelectorAll('.pv-devs .ad-segm__o').forEach(function (b, i) {
      var on = Object.keys(DEVICES)[i] === d; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', on);
    });
    P.el.querySelector('[data-pv-rotate]').disabled = d === 'desktop';
    P.el.querySelector('.pv-frame').className = 'pv-frame pv-frame--' + d + (P.landscape && d !== 'desktop' ? ' is-land' : '');
    layout();
  };
  App.previewRotate = function () {
    if (!P.el || P.device === 'desktop') return;
    P.landscape = !P.landscape; remember();
    App.previewDevice(P.device);
  };
  App.previewReload = function () {
    var f = frame(); if (!f) return;
    P.el.classList.remove('is-ready');
    var go = function () { try { f.contentWindow.location.reload(); } catch (e) { f.src = f.src; } };
    (App.persistNow ? App.persistNow() : Promise.resolve()).then(go, go);
  };
  App.previewLang = function (code) {
    var f = frame(); if (!f) return;
    f.src = '/preview/__page/' + encodeURIComponent(P.pageId || curPageId()) + '?lang=' + encodeURIComponent(code);
  };
  App.previewNewTab = function () {
    var f = frame(), url = '/preview/';
    try { url = f.contentWindow.location.href; } catch (e) { /* внешний адрес */ }
    window.open(url, '_blank');
  };
  // Открыть в редакторе страницу, которая сейчас в предпросмотре
  App.previewEdit = function () {
    var id = P.pageId; if (!id) return;
    var refs = App.pageRefs ? App.pageRefs() : [];
    var i = refs.findIndex(function (p) { return p.id === id; });
    App.closePreview();
    if (i < 0) return;
    if (S().view !== 'page') App.setView('page');
    App.selectPage(i);
  };
})();

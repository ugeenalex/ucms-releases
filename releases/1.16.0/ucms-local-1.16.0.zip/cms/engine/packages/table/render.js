'use strict';
// Таблица из текста: строка = ряд, ячейки через «|». Первая строка — заголовок (опция).
function parse(data) {
  return String(data || '').split(/\r?\n/).map(l => l.trim()).filter(Boolean).map(l => l.split('|').map(c => c.trim()));
}
module.exports = {
  render(block, ctx, h) {
    const rows = parse(h.field(block, 'data'));
    if (!rows.length) return '';
    const head = block.header !== false ? rows.shift() : null;
    const cell = (t, c) => `<${t}>${h.esc(c)}</${t}>`;
    return '<div class="block block-table"><table>' +
      (head ? `<thead><tr>${head.map(c => cell('th', c)).join('')}</tr></thead>` : '') +
      `<tbody>${rows.map(r => `<tr>${r.map(c => cell('td', c)).join('')}</tr>`).join('')}</tbody></table></div>`;
  },
};

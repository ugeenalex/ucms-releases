'use strict';
// Вопросы и ответы: нативный <details> — работает без JavaScript. Оформление — в ucms.css движка.
module.exports = {
  render(block, ctx, h) {
    const items = (block.items || []).filter(it => (it.q || '').trim());
    if (!items.length) return '';
    const html = items.map((it, i) => {
      const q = h.field(it, 'q') || '', a = h.field(it, 'a') || '';
      return `<details class="faq-item"${block.openFirst && i === 0 ? ' open' : ''}><summary>${h.esc(q)}</summary><div class="faq-a">${h.esc(a).replace(/\r?\n/g, '<br>')}</div></details>`;
    }).join('');
    return `<div class="block block-faq">${html}</div>`;
  },
};

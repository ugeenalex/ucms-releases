'use strict';
// Цитата / отзыв: текст, автор, подпись, фото. Оформление — в ucms.css движка.
module.exports = {
  render(block, ctx, h) {
    const text = h.field(block, 'text') || '';
    if (!text.trim()) return '';
    const author = h.field(block, 'author') || '', role = h.field(block, 'role') || '';
    const who = author || role
      ? '<figcaption class="quote-who">' + (block.src ? `<img src="${h.esc(h.src(block.src))}" alt="" loading="lazy">` : '') +
        `<span>${author ? `<b>${h.esc(author)}</b>` : ''}${role ? `<small>${h.esc(role)}</small>` : ''}</span></figcaption>`
      : '';
    return `<figure class="block block-quote"><blockquote>${h.esc(text).replace(/\r?\n/g, '<br>')}</blockquote>${who}</figure>`;
  },
};

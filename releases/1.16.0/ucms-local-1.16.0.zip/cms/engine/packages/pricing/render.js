'use strict';
// Тарифы: колонки с названием, ценой, списком возможностей и кнопкой. Оформление — в ucms.css движка.
module.exports = {
  render(block, ctx, h) {
    const items = (block.items || []).filter(it => it.name || it.price);
    if (!items.length) return '';
    const html = items.map(it => {
      const f = k => h.field(it, k) || '';
      const feats = f('features').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
      const href = h.href(it.link);
      return `<div class="plan${it.highlight ? ' plan--hl' : ''}">` +
        `<div class="plan-name">${h.esc(f('name'))}</div>` +
        `<div class="plan-price">${h.esc(f('price'))}${f('period') ? `<small>${h.esc(f('period'))}</small>` : ''}</div>` +
        (feats.length ? `<ul class="plan-feats">${feats.map(x => `<li>${h.esc(x)}</li>`).join('')}</ul>` : '') +
        (href ? `<a class="plan-btn" href="${h.esc(href)}"${h.linkAttrs(it.link)}>${h.esc(f('btnText') || 'Выбрать')}</a>` : '') + '</div>';
    }).join('');
    return `<div class="block block-pricing" style="--plans:${Math.min(4, items.length)}">${html}</div>`;
  },
};

'use strict';
// Соцсети и контакты: ссылки-кнопки с коротким значком сети. Оформление — в ucms.css движка.
const NETWORKS = {
  telegram: ['Telegram', 'TG'], vk: ['ВКонтакте', 'VK'], whatsapp: ['WhatsApp', 'WA'], youtube: ['YouTube', 'YT'],
  instagram: ['Instagram', 'IG'], facebook: ['Facebook', 'FB'], x: ['X', 'X'], github: ['GitHub', 'GH'],
  email: ['Email', '@'], phone: ['Телефон', '☎'], site: ['Сайт', '↗'],
};
function href(it) {
  const u = String(it.url || '').trim();
  if (!u) return '';
  if (it.network === 'email') return u.startsWith('mailto:') ? u : `mailto:${u}`;
  if (it.network === 'phone') return u.startsWith('tel:') ? u : `tel:${u.replace(/[^\d+]/g, '')}`;
  return /^https?:\/\//i.test(u) ? u : `https://${u}`;
}
module.exports = {
  render(block, ctx, h) {
    const items = (block.items || []).filter(it => href(it));
    if (!items.length) return '';
    const text = block.style === 'text';
    const html = items.map(it => {
      const n = NETWORKS[it.network] || NETWORKS.site;
      const ext = it.network === 'email' || it.network === 'phone' ? '' : ' target="_blank" rel="noopener noreferrer"';
      return `<a class="social-link social-${h.esc(it.network || 'site')}" href="${h.esc(href(it))}"${ext} aria-label="${h.esc(n[0])}" title="${h.esc(n[0])}">` +
        `<span class="social-ico" aria-hidden="true">${h.esc(n[1])}</span>${text ? `<span>${h.esc(n[0])}</span>` : ''}</a>`;
    }).join('');
    return `<div class="block block-social${text ? ' social--text' : ''}">${html}</div>`;
  },
};

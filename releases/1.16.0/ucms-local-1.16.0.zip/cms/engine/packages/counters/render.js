'use strict';
// Цифры: «500+ клиентов». Число досчитывается анимацией при появлении (ucms.js движка);
// без JavaScript сразу видно итоговое значение.
module.exports = {
  render(block, ctx, h) {
    const items = (block.items || []).filter(it => String(it.value || '').trim());
    if (!items.length) return '';
    const html = items.map(it => {
      const value = String(it.value).trim();
      const num = /^\d+([.,]\d+)?$/.test(value) ? ` data-count="${h.esc(value.replace(',', '.'))}"` : '';
      return `<div class="counter"><div class="counter-num"><span${num}>${h.esc(value)}</span>${h.esc(it.suffix || '')}</div>` +
        `<div class="counter-label">${h.esc(h.field(it, 'label') || '')}</div></div>`;
    }).join('');
    return `<div class="block block-counters" style="--counters:${Math.min(4, items.length)}">${html}</div>`;
  },
};

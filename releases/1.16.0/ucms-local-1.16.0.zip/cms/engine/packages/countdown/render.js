'use strict';
// Таймер обратного отсчёта до даты; тикает ucms.js движка. После даты — текст «готово».
const UNITS = { ru: ['дней', 'часов', 'минут', 'секунд'], en: ['days', 'hours', 'minutes', 'seconds'], kk: ['күн', 'сағат', 'минут', 'секунд'] };
module.exports = {
  render(block, ctx, h) {
    const t = Date.parse(block.until || '');
    if (!isFinite(t)) return '';
    const title = h.field(block, 'title') || '', done = h.field(block, 'doneText') || '';
    const names = UNITS[ctx.lang] || UNITS.ru;
    const cells = ['d', 'h', 'm', 's'].map((k, i) => `<div class="cd-cell"><span class="cd-num" data-u="${k}">00</span><span class="cd-lbl">${names[i]}</span></div>`).join('');
    return `<div class="block block-countdown" data-until="${new Date(t).toISOString()}" ${done ? ` data-done="${h.esc(done)}"` : ''}>` +
      (title ? `<div class="cd-title">${h.esc(title)}</div>` : '') + `<div class="cd-grid">${cells}</div></div>`;
  },
};

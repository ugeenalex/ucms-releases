'use strict';
// Карта: встраивание Яндекс/Google Карт по ссылке или коду <iframe>.
// Из вставленного кода iframe берём только src — сам код на сайт не попадает.
function embedSrc(v) {
  const s = String(v || '').trim();
  const m = s.match(/src\s*=\s*["']([^"']+)["']/i);
  const url = m ? m[1] : s;
  return /^https:\/\//i.test(url) ? url : '';
}
module.exports = {
  render(block, ctx, h) {
    const src = embedSrc(block.url);
    if (!src) return '';
    const ht = Math.min(900, Math.max(200, parseInt(block.height, 10) || 400));
    return `<div class="block block-map"><iframe src="${h.esc(src)}" title="${ctx.lang === 'ru' ? 'Карта' : 'Map'}" height="${ht}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe></div>`;
  },
};

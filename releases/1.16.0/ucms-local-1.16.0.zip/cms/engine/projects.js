'use strict';
/**
 * Реестр проектов UCMS. Движок один, проектов (сайтов) много: у каждого своя папка
 * с данными — db.json, uploads/, themes/, output/, backups/, publish.json…
 * Папка может лежать где угодно. Список хранится вне движка, в профиле пользователя
 * (~/.ucms/projects.json; UCMS_HOME — другое место), поэтому обновление или перенос
 * движка проекты не теряет.
 *
 * Подключённый сайт (1.13): { kind: 'remote', url, user, role, … } — данные живут на сервере
 * веб-UCMS, локальная админка работает с ними через ключ доступа. Ключи — отдельно,
 * в ~/.ucms/remote-keys.json (доступ только владельцу файла), не в списке проектов.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const HOME = process.env.UCMS_HOME || path.join(os.homedir(), '.ucms');
const REG = path.join(HOME, 'projects.json');
const KEYS = path.join(HOME, 'remote-keys.json');

function readKeys() { try { return JSON.parse(fs.readFileSync(KEYS, 'utf8')) || {}; } catch (e) { return {}; } }
function writeKeys(k) {
  fs.mkdirSync(HOME, { recursive: true });
  fs.writeFileSync(KEYS + '.tmp', JSON.stringify(k, null, 2), { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(KEYS + '.tmp', KEYS);
}
function getToken(id) { return readKeys()[id] || ''; }
function setToken(id, token) { const k = readKeys(); if (token) k[id] = token; else delete k[id]; writeKeys(k); }

function load() {
  try {
    const r = JSON.parse(fs.readFileSync(REG, 'utf8'));
    return { projects: Array.isArray(r.projects) ? r.projects : [], last: r.last || null };
  } catch (e) { return { projects: [], last: null }; }
}
function save(reg) {
  fs.mkdirSync(HOME, { recursive: true });
  const tmp = REG + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(reg, null, 2), 'utf8');
  fs.renameSync(tmp, REG);
}

// Папка для новых проектов по умолчанию: «Документы/UCMS Projects»
function defaultRoot() {
  const docs = path.join(os.homedir(), 'Documents');
  return path.join(fs.existsSync(docs) ? docs : os.homedir(), 'UCMS Projects');
}

function isProjectDir(dir) { return !!dir && fs.existsSync(path.join(dir, 'db.json')); }
function isEmptyDir(dir) { return !fs.existsSync(dir) || fs.readdirSync(dir).length === 0; }

// Сведения для стартовой страницы: название сайта и число страниц читаем из db.json
function info(p) {
  if (p.kind === 'remote') return { ...p, path: p.url, exists: true, remote: true, siteTitle: p.siteTitle || p.name, pages: p.pages || 0, languages: p.languages || [] };
  const out = { ...p, exists: isProjectDir(p.path), siteTitle: '', pages: 0, languages: [] };
  if (!out.exists) return out;
  try {
    const db = JSON.parse(fs.readFileSync(path.join(p.path, 'db.json'), 'utf8'));
    out.siteTitle = (db.settings && db.settings.siteTitle) || '';
    out.pages = Array.isArray(db.pages) ? db.pages.length : 0;
    out.languages = ((db.settings && db.settings.languages) || []).map(l => l.code);
  } catch (e) { out.broken = true; }
  return out;
}

function list() { const reg = load(); return { projects: reg.projects.map(info), last: reg.last }; }
function get(id) { return load().projects.find(p => p.id === id) || null; }

function add(dir, name) {
  const reg = load();
  const abs = path.resolve(dir);
  const same = reg.projects.find(p => p.path && path.resolve(p.path).toLowerCase() === abs.toLowerCase());
  if (same) return same;
  const p = { id: crypto.randomBytes(6).toString('hex'), name: name || path.basename(abs), path: abs, createdAt: new Date().toISOString(), openedAt: null };
  reg.projects.push(p);
  save(reg);
  return p;
}
// Подключённый сайт веб-UCMS. Тот же адрес уже есть — обновляем его (новый ключ, пользователь).
function addRemote(url, token, meta) {
  const reg = load();
  let p = reg.projects.find(x => x.kind === 'remote' && x.url.toLowerCase() === url.toLowerCase());
  if (p) Object.assign(p, meta);
  else {
    p = { id: crypto.randomBytes(6).toString('hex'), kind: 'remote', url, name: meta.siteTitle || url.replace(/^https?:\/\//, ''), createdAt: new Date().toISOString(), openedAt: null, ...meta };
    reg.projects.push(p);
  }
  save(reg);
  setToken(p.id, token);
  return p;
}
function update(id, patch) {
  const reg = load(); const p = reg.projects.find(x => x.id === id);
  if (!p) return null;
  Object.assign(p, patch);
  if (patch.openedAt) reg.last = id;
  save(reg);
  return p;
}
function remove(id) {
  const reg = load();
  reg.projects = reg.projects.filter(p => p.id !== id);
  if (reg.last === id) reg.last = null;
  save(reg);
  if (getToken(id)) setToken(id, '');
}

module.exports = { HOME, REG, load, list, get, add, addRemote, update, remove, getToken, setToken, defaultRoot, isProjectDir, isEmptyDir };

'use strict';
/**
 * UCMS — сервер на чистом Node.js (без npm-зависимостей).
 * Запуск: node engine/server.js   (из корня проекта)
 *   или:  node server.js          (из папки engine/)
 *
 * Папка engine/ — код движка (заменяется при обновлениях).
 * Данные сайтов — папки проектов (любое место на диске, список — ~/.ucms/projects.json).
 * <папка UCMS>/content/ — данные из версий до 1.1: если там есть db.json, он становится первым проектом.
 */

const http  = require('http');
const https = require('https');
const fs    = require('fs');
const fsp   = fs.promises;
const path  = require('path');
const { exec } = require('child_process');
const os    = require('os');

const ENGINE_DIR   = __dirname;
const PROJECT_ROOT = path.join(ENGINE_DIR, '..');
// Пути активного проекта (папка с данными сайта) — меняются в useProject().
let CONTENT_DIR = null, DB_PATH = null, THEMES_DIR = null, OUTPUT_DIR = null, UPLOADS_DIR = null, BACKUPS_DIR = null;
let ACTIVE = null;   // { id, name, path } — открытый проект
let HISTORY = null;  // история версий активного проекта (lib/history.js)
const LEGACY_CONTENT = path.join(PROJECT_ROOT, 'content');   // папка данных из версий до 1.1
const ADMIN_DIR    = path.join(ENGINE_DIR, 'admin');
const SITE_DIR     = path.join(ENGINE_DIR, 'site');           // runtime сайта: ucms.css / ucms.js
const DEFAULT_THEME_FILE = path.join(ENGINE_DIR, 'themes', 'default.css');
const PORT         = process.env.PORT || 3000;
// Веб-версия (UCMS_MODE=web): один сайт, вход по паролю, сайт открывается с корня адреса.
// Нет ИИ-перевода, FTP, списка проектов и доступа к файлам компьютера. Подробно — docs/WEB.md.
const WEB          = process.env.UCMS_MODE === 'web';
const UPLOAD_MB    = Math.max(1, parseInt(process.env.UCMS_UPLOAD_MB, 10) || 50);   // веб: предел одного файла
const TRUST_PROXY  = process.env.UCMS_TRUST_PROXY === '1';   // за nginx: адрес клиента из X-Real-IP / X-Forwarded-For
// Веб: куда публиковать сайт на этом же сервере (например, httpdocs домена в Plesk) и его адрес.
// Задаются мастером установки (<UCMS_HOME>/config.json) или переменными окружения — они главнее.
// Из админки после установки путь на сервере не меняется.
let PUBLISH_DIR    = '';
let SITE_URL       = '';
const VERSION      = (() => { try { return fs.readFileSync(path.join(PROJECT_ROOT, 'VERSION'), 'utf8').trim(); } catch (e) { return 'dev'; } })();

const DEFAULT_MODEL = 'claude-haiku-4-5-20251001';
const FONT_FALLBACK = '-apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif';

const blockModules = require('./modules/index');
const { createPackages } = require('./lib/packages');
// Подключаемые модули сайта (<сайт>/modules/<id>) — lib/packages.js, docs/MODULES.md
const PKG = createPackages({
  dirOf: () => path.join(CONTENT_DIR, 'modules'), builtinTypes: blockModules.modules.map(m => m.type), version: VERSION,
  bundledDir: path.join(__dirname, 'packages'),   // необязательные модули, идущие с движком
  catalogUrl: process.env.UCMS_MODULES_CATALOG || 'https://raw.githubusercontent.com/ugeenalex/ucms-modules/main/catalog.json',
  httpGet: (url, limit) => httpGetBuf(url, limit),
});
// GET по https с переходами (до 3) и пределом размера — каталог модулей и архивы из него
function httpGetBuf(url, limit, hops = 0) {
  return new Promise((resolve, reject) => {
    const u = new URL(url), local = /^(localhost|127\.0\.0\.1)$/.test(u.hostname);
    if (u.protocol !== 'https:' && !local) return reject(new Error('Только https'));
    const rq = (u.protocol === 'https:' ? https : http).get(u, { headers: { 'User-Agent': 'UCMS/' + VERSION }, timeout: 20000 }, r => {
      if ([301, 302, 303, 307, 308].includes(r.statusCode) && r.headers.location && hops < 3) { r.resume(); return resolve(httpGetBuf(new URL(r.headers.location, u).toString(), limit, hops + 1)); }
      if (r.statusCode !== 200) { r.resume(); return reject(new Error('ответ ' + r.statusCode)); }
      const chunks = []; let n = 0;
      r.on('data', c => { n += c.length; if (n > limit) rq.destroy(new Error('слишком большой ответ')); else chunks.push(c); });
      r.on('end', () => resolve(Buffer.concat(chunks)));
      r.on('error', reject);
    });
    rq.on('timeout', () => rq.destroy(new Error('нет ответа за 20 с')));
    rq.on('error', reject);
  });
}
// Типы модулей, которые есть на сайте (страницы, шапка, подвал, вкладки)
function usedTypes(db) {
  const out = new Map();
  const walk = rows => (rows || []).forEach(r => [r.blocks].concat((r.columns || []).map(c => c.blocks)).forEach(list => (list || []).forEach(b => {
    out.set(b.type, (out.get(b.type) || 0) + 1);
    (b.items || []).forEach(it => walk(it.rows));
  })));
  (db.pages || []).forEach(p => walk(p.rows));
  walk(((db.settings || {}).header || {}).rows); walk(((db.settings || {}).footer || {}).rows);
  return out;
}
// Модули, вынесенные из движка (1.15): если на сайте есть их блоки — поставить из движка.
// Один раз на сайт (метка modules/.from-engine): удалённый потом вручную модуль сам не вернётся.
function ensureSiteModules(force) {
  const mark = path.join(CONTENT_DIR, 'modules', '.from-engine');
  if (!force && fs.existsSync(mark)) return;
  try {
    const got = PKG.ensureUsed([...usedTypes(readDB()).keys()]);
    if (got.length) console.log('  Модули сайта установлены из движка: ' + got.join(', '));
    fs.mkdirSync(path.dirname(mark), { recursive: true });
    fs.writeFileSync(mark, new Date().toISOString() + '\n');
  } catch (e) { console.warn('[modules]', e.message); }
}
const blockShared = require('./modules/_shared');
const { srcPath } = blockShared;
const collLib = require('./modules/_coll');
const { createPublisher, inspectRemote, cloneRemote } = require('./publish');
const { publishToDir } = require('./publish/local');
const remoteProject = require('./publish/project');
const { createZip, readZip } = require('./lib/zip');
const projects = require('./projects');
const { createHistory, diffDb, applyPart } = require('./lib/history');
const { imageSize } = require('./lib/imgsize');
const { createUpdater } = require('./lib/update');
const { createAuth, passwdCli } = require('./lib/auth');
const auth = WEB || process.argv[2] === 'passwd' ? createAuth(projects.HOME) : null;
const { createSetup } = require('./lib/setup');
// Веб: папка данных сайта (страницы, медиа, история) — вне публичных папок
const WEB_SITE_DIR = WEB ? path.resolve(process.env.UCMS_SITE || path.join(projects.HOME, 'site')) : '';
const setup = WEB ? createSetup({ appRoot: PROJECT_ROOT, home: projects.HOME, siteDir: WEB_SITE_DIR }) : null;
function loadWebConfig() {
  if (!WEB) return;
  const cfg = setup.readConfig();
  const dir = process.env.UCMS_PUBLISH_DIR !== undefined ? process.env.UCMS_PUBLISH_DIR : cfg.publishDir;
  PUBLISH_DIR = dir ? path.resolve(dir) : '';
  SITE_URL = String((process.env.UCMS_SITE_URL !== undefined ? process.env.UCMS_SITE_URL : cfg.siteUrl) || '').replace(/\/+$/, '');
}
loadWebConfig();
// Веб: установка не завершена, пока нет ни одного пользователя. Когда пользователь появился,
// обратно в мастер не возвращаемся (флаг, чтобы не читать auth.json на каждый запрос).
let _installed = false;
function needSetup() { if (!WEB || _installed) return false; if (auth.configured()) { _installed = true; return false; } return true; }

// ────────────────────────────── Дефолтная тема ──────────────────────────────
// Тема по умолчанию — обычный CSS-файл движка, а не строка внутри server.js.
let _defaultCss = null;
function defaultCss() {
  if (_defaultCss == null) _defaultCss = fs.readFileSync(DEFAULT_THEME_FILE, 'utf8');
  return _defaultCss;
}

// ────────────────────────────── ID ──────────────────────────────
let _seq = 0;
function genId(p) { return `${p}_${Date.now().toString(36)}${(++_seq).toString(36)}`; }

// ────────────────────────────── БД ──────────────────────────────
function defaultDB() {
  return {
    settings: {
      siteTitle: 'Мой сайт', css: defaultCss(),
      fontFamily: '',   // пусто = шрифт берётся из темы (--font-body / --font-head)
      fontImportUrl: 'https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500;700&display=swap',
      languages: [{ code: 'ru', label: 'Русский', isDefault: true }],
      siteTitleTranslations: {},
      enabledModules: blockModules.modules.map(m => m.type),
      translation: { apiKey: '', model: DEFAULT_MODEL },
      header: { enabled: true, rows: [{ id: genId('row'), columns: [
        { id: genId('col'), width: null, blocks: [{ id: genId('blk'), type: 'sitename' }] },
        { id: genId('col'), width: null, align: 'right', blocks: [{ id: genId('blk'), type: 'menu', menuType: 'list', pagesMode: 'all', selected: {} }] },
      ]}]},
      footer: { enabled: true, rows: [{ id: genId('row'), columns: [
        { id: genId('col'), width: { value: 50, unit: '%' }, blocks: [
          { id: genId('blk'), type: 'title', level: 4, text: 'О сайте' },
          { id: genId('blk'), type: 'html', code: '<p>Описание сайта.</p>' },
        ]},
        { id: genId('col'), width: { value: 50, unit: '%' }, blocks: [
          { id: genId('blk'), type: 'title', level: 4, text: 'Контакты' },
          { id: genId('blk'), type: 'html', code: '<p>email@example.com</p>' },
        ]},
      ]}]},
    },
    pages: [{
      id: 'home', title: 'Главная', slug: 'index',
      parentId: null, order: 0, showInMenu: true,
      showHeader: true, showFooter: true,
      translations: {}, background: { type: 'none' },
      rows: [{ id: genId('row'), columns: [{
        id: genId('col'), width: null,
        blocks: [
          { id: genId('blk'), type: 'title', level: 1, text: 'Добро пожаловать' },
          { id: genId('blk'), type: 'text', html: '<p>Это стартовая страница вашей CMS.</p>' },
        ],
      }]}],
    }],
  };
}

// Однократные миграции старых форматов. Идемпотентна: повторный прогон ничего не меняет.
const TYPE_RENAME = { heading: 'title', feedback: 'form', siteTitle: 'sitename', langSwitch: 'lang' };

function forEachBlock(rows, fn) {
  (rows || []).forEach(row => (row.columns || []).forEach(col => (col.blocks || []).forEach(fn)));
}

function migrateDB(db) {
  const st = db.settings || (db.settings = {});
  if (!st.css) st.css = defaultCss();
  if (typeof st.fontFamily !== 'string') st.fontFamily = '';
  if (typeof st.fontImportUrl !== 'string') st.fontImportUrl = '';
  if (!Array.isArray(st.languages) || !st.languages.length) st.languages = [{ code: 'ru', label: 'Русский', isDefault: true }];
  if (!st.siteTitleTranslations) st.siteTitleTranslations = {};
  if (!st.translation) st.translation = { apiKey: '', model: DEFAULT_MODEL };
  if (!Array.isArray(st.enabledModules)) st.enabledModules = blockModules.modules.map(m => m.type);
  if (!Array.isArray(st.collections)) st.collections = [];

  // footer.columns (очень старый формат) → rows. Проверка ДО нормализации rows.
  if (st.footer && Array.isArray(st.footer.columns) && !Array.isArray(st.footer.rows)) {
    st.footer.rows = [{ id: genId('row'), columns: st.footer.columns.map(c => ({
      id: c.id || genId('col'), width: null,
      blocks: [...(c.title ? [{ id: genId('blk'), type: 'title', level: 4, text: c.title }] : []), { id: genId('blk'), type: 'html', code: c.html || '' }],
    }))}];
    delete st.footer.columns;
  }
  if (!st.header || !Array.isArray(st.header.rows)) st.header = { enabled: true, rows: [] };
  if (!st.footer || !Array.isArray(st.footer.rows)) st.footer = { enabled: true, rows: [] };

  if (!Array.isArray(db.pages)) db.pages = [];
  db.pages.forEach(p => {
    if (Array.isArray(p.blocks) && !Array.isArray(p.rows)) {
      p.rows = [{ id: genId('row'), columns: [{ id: genId('col'), width: null, blocks: p.blocks }] }];
      delete p.blocks;
    }
    if (!Array.isArray(p.rows)) p.rows = [];
    if (!p.translations) p.translations = {};
    if (!p.background) p.background = { type: 'none' };
  });

  // Однократно: колонку с меню в шапке прижимаем вправо (раньше это делала тема,
  // теперь выравнивание — настройка колонки в админке).
  st.migrated = st.migrated || {};
  if (!st.migrated.headerMenuRight) {
    st.header.rows.forEach(row => {
      const cols = row.columns || [];
      const last = cols[cols.length - 1];
      if (cols.length > 1 && last && !last.align && (last.blocks || []).some(b => b.type === 'menu' || b.type === 'lang')) last.align = 'right';
    });
    st.migrated.headerMenuRight = true;
  }
  // 1.3: новый модуль «Список записей» — включаем в палитру существующих проектов
  if (!st.migrated.collectionModule) {
    if (!st.enabledModules.includes('collection')) st.enabledModules.push('collection');
    st.migrated.collectionModule = true;
  }

  const rename = b => { if (TYPE_RENAME[b.type]) b.type = TYPE_RENAME[b.type]; };
  db.pages.forEach(p => forEachBlock(p.rows, rename));
  forEachBlock(st.header.rows, rename);
  forEachBlock(st.footer.rows, rename);

  ensureThemes(db);
  return db;
}

// ─────────────────────────── Темы ───────────────────────────
// Темы — папки themes/<Имя>/theme.css. Активная — db.settings.theme;
// db.settings.css — рабочая копия, но источник истины — файл темы.
function cleanThemeName(name) { return String(name || '').replace(/[^a-zA-Z0-9_\- ]/g, '').trim().replace(/\s+/g, '-'); }
function themeDir(name) { return path.join(THEMES_DIR, cleanThemeName(name) || 'default'); }
function themeCssFile(name) { return path.join(themeDir(name), 'theme.css'); }
// Шрифт принадлежит теме: themes/<Имя>/theme.json { fontFamily, fontImportUrl }.
const DEFAULT_FONT = { fontFamily: '', fontImportUrl: 'https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500;700&display=swap' };
function themeMetaFile(name) { return path.join(themeDir(name), 'theme.json'); }
function readThemeFont(name) {
  try {
    const m = JSON.parse(fs.readFileSync(themeMetaFile(name), 'utf8'));
    return { fontFamily: String(m.fontFamily || ''), fontImportUrl: String(m.fontImportUrl || '') };
  } catch (e) { return null; }
}
function writeThemeFont(name, font) {
  const f = themeMetaFile(name);
  let meta = {};
  try { meta = JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { /* файла ещё нет */ }
  meta.fontFamily = String(font.fontFamily || '');
  meta.fontImportUrl = String(font.fontImportUrl || '');
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f, JSON.stringify(meta, null, 2), 'utf8');
}
function listThemes() {
  if (!fs.existsSync(THEMES_DIR)) return [];
  return fs.readdirSync(THEMES_DIR, { withFileTypes: true }).filter(d => d.isDirectory()).map(d => d.name);
}
function ensureThemes(db) {
  try {
    fs.mkdirSync(THEMES_DIR, { recursive: true });
    if (listThemes().length === 0) {
      fs.mkdirSync(path.join(THEMES_DIR, 'default'), { recursive: true });
      fs.writeFileSync(path.join(THEMES_DIR, 'default', 'theme.css'), db.settings.css || defaultCss(), 'utf8');
    }
    const themes = listThemes();
    if (!db.settings.theme || !themes.includes(db.settings.theme)) db.settings.theme = themes[0] || 'default';
    // Файл активной темы — источник истины, если он непустой. Пустой/отсутствующий
    // файл восстанавливаем из рабочей копии (самолечение рассинхрона).
    const cf = themeCssFile(db.settings.theme);
    const fileCss = fs.existsSync(cf) ? fs.readFileSync(cf, 'utf8') : '';
    if (fileCss.trim()) db.settings.css = fileCss;
    else if (typeof db.settings.css === 'string' && db.settings.css.trim()) {
      fs.mkdirSync(path.dirname(cf), { recursive: true });
      fs.writeFileSync(cf, db.settings.css, 'utf8');
    }
    // Шрифт: из theme.json активной темы. Нет файла (старая тема) — переносим
    // в неё текущий шрифт из настроек, чтобы при обновлении ничего не сменилось.
    const legacy = { fontFamily: db.settings.fontFamily, fontImportUrl: db.settings.fontImportUrl };
    themes.forEach(t => { if (!fs.existsSync(themeMetaFile(t))) writeThemeFont(t, legacy); });
    // До 1.6 в поставке у темы default оставалась тестовая ссылка (Great Vibes) при семействе Ubuntu — чиним
    themes.forEach(t => {
      const f = readThemeFont(t);
      if (f && /family=Great\+Vibes/.test(f.fontImportUrl) && /^ubuntu$/i.test(f.fontFamily.trim())) writeThemeFont(t, { fontFamily: 'Ubuntu', fontImportUrl: DEFAULT_FONT.fontImportUrl });
    });
    Object.assign(db.settings, readThemeFont(db.settings.theme) || legacy);
  } catch (e) { console.warn('[themes]', e.message); }
}

function readDB() {
  if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, JSON.stringify(defaultDB(), null, 2), 'utf8');
  return migrateDB(JSON.parse(fs.readFileSync(DB_PATH, 'utf8')));
}
// ─────────────── Запись db.json ───────────────
// Атомарно: пишем во временный файл и переименовываем поверх db.json — обрыв
// посреди записи не оставит битый JSON.
//
// Windows: rename поверх файла падает с EPERM/EACCES/EBUSY, пока кто-то держит
// на нём дескриптор без FILE_SHARE_DELETE — Defender проверяет только что
// записанный файл, индексатор поиска, синхронизация облака. Блокировка живёт
// десятки миллисекунд, поэтому повторяем с нарастающей паузой. Все записи идут
// через одну очередь, чтобы автосохранение и ручное сохранение не пересекались.
const RENAME_RETRY_CODES = new Set(['EPERM', 'EACCES', 'EBUSY']);
const RENAME_DELAYS_MS = [20, 40, 80, 160, 320, 640, 1000];   // ≈2.3 с суммарно
const sleep = ms => new Promise(r => setTimeout(r, ms));
let _tmpSeq = 0;
let _writeQueue = Promise.resolve();

async function renameWithRetry(from, to) {
  for (let attempt = 0; ; attempt++) {
    try { return await fsp.rename(from, to); }
    catch (e) {
      if (!RENAME_RETRY_CODES.has(e.code) || attempt >= RENAME_DELAYS_MS.length) throw e;
      await sleep(RENAME_DELAYS_MS[attempt]);
    }
  }
}

async function writeFileAtomic(file, data) {
  const tmp = `${file}.${process.pid}.${++_tmpSeq}.tmp`;   // уникальное имя на каждую запись
  await fsp.writeFile(tmp, data, 'utf8');
  try {
    await renameWithRetry(tmp, file);
  } catch (e) {
    if (!RENAME_RETRY_CODES.has(e.code)) throw e;
    // Файл так и не отпустили для rename — перезаписываем на месте:
    // блокировку на удаление/замену это обходит, на запись обычно не мешает.
    console.warn(`[db] rename заблокирован (${e.code}), запись на месте`);
    await fsp.copyFile(tmp, file);
  } finally {
    fsp.unlink(tmp).catch(() => {});
  }
}

// Ревизия данных — хеш содержимого db.json (переживает перезапуск сервера). Админка присылает
// ревизию, от которой начинала правки; не совпала — данные успели поменять в другой вкладке
// или на другом устройстве (409 CONFLICT).
let DB_REV = '';
const revOf = data => require('crypto').createHash('sha1').update(data).digest('hex').slice(0, 16);
const revNow = () => DB_REV;
function writeDB(db) {
  const data = JSON.stringify(db, null, 2);
  DB_REV = revOf(data);
  const job = _writeQueue.then(() => writeFileAtomic(DB_PATH, data));
  _writeQueue = job.catch(() => {});   // ошибка одной записи не рвёт очередь
  return job;
}

// Хвосты прерванных записей прошлых запусков.
function cleanupTmpFiles() {
  for (const name of fs.readdirSync(CONTENT_DIR)) {
    if (/^db\.json(\.\d+\.\d+)?\.tmp$/.test(name)) fs.rmSync(path.join(CONTENT_DIR, name), { force: true });
  }
}

// ────────────────────────────── Утилиты ──────────────────────────────
const MIME = {
  '.html': 'text/html;charset=utf-8', '.css': 'text/css;charset=utf-8', '.js': 'application/javascript;charset=utf-8',
  '.json': 'application/json;charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.ico': 'image/x-icon', '.mp4': 'video/mp4',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.otf': 'font/otf',
};
const JSON_HDR = { 'Content-Type': 'application/json;charset=utf-8' };

function send(res, status, body, hdrs = {}) {
  // ответ API: ревизия данных до запроса и после — так вкладка отличает свои записи от чужих
  if (res._rev0 !== undefined) hdrs = { ...hdrs, 'X-UCMS-Rev-Was': res._rev0, 'X-UCMS-Rev': revNow() };
  res.writeHead(status, hdrs); res.end(body);
}
function sendJson(res, status, obj) { send(res, status, JSON.stringify(obj), JSON_HDR); }

function isInside(base, target) {
  const rel = path.relative(base, target);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function serveFile(res, baseDir, urlPath) {
  let fp = path.join(baseDir, decodeURIComponent(urlPath));
  if (!isInside(baseDir, fp)) return send(res, 403, 'Forbidden');
  fs.stat(fp, (err, st) => {
    if (!err && st.isDirectory()) fp = path.join(fp, 'index.html');
    fs.readFile(fp, (err2, data) => {
      if (err2) return send(res, 404, 'Not found');
      // Локальный инструмент: всегда перепроверять, иначе после обновления
      // engine/ браузер продолжает исполнять старый app.js из кеша.
      const ext = path.extname(fp).toLowerCase();
      const hdr = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-cache' };
      // веб: SVG, открытый по прямой ссылке, не исполняет скрипты (в <img> показывается как обычно)
      if (WEB && ext === '.svg') hdr['Content-Security-Policy'] = "sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src data:";
      send(res, 200, data, hdr);
    });
  });
}

function readBody(req, limit = 30e6) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', d => {
      size += d.length;
      if (size > limit) { reject(new Error('Too large')); req.destroy(); return; }
      chunks.push(d);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
async function readJson(req, limit) { return JSON.parse((await readBody(req, limit)).toString('utf8') || '{}'); }

function escHtml(s) { return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

function openPath(target) {
  const q = `"${String(target).replace(/"/g, '')}"`;
  const cmd = process.platform === 'win32' ? `start "" ${q}` : process.platform === 'darwin' ? `open ${q}` : `xdg-open ${q}`;
  exec(cmd, () => {});
}

// Slug → безопасное имя файла. Без этого slug «../../engine/server» перезаписал бы движок.
function cleanSlug(slug) {
  return String(slug || '').trim()
    .replace(/\.html?$/, '').replace(/[\\/]+/g, '-').replace(/[^\p{L}\p{N}_-]+/gu, '-')
    .replace(/-+/g, '-').replace(/^-|-$/g, '') || 'page';
}

// Инкрементальная синхронизация каталога: копируем только новое/изменённое,
// удаляем исчезнувшее. Раньше каждая генерация копировала все uploads целиком.
function syncDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  const srcNames = new Set();
  if (fs.existsSync(src)) {
    for (const ent of fs.readdirSync(src, { withFileTypes: true })) {
      if (ent.name.startsWith('.')) continue;   // служебные файлы (uploads/.media.json) на сайт не копируем
      srcNames.add(ent.name);
      const s = path.join(src, ent.name), d = path.join(dst, ent.name);
      if (ent.isDirectory()) { syncDir(s, d); continue; }
      const ss = fs.statSync(s);
      const ds = fs.existsSync(d) ? fs.statSync(d) : null;
      if (!ds || ds.size !== ss.size || ds.mtimeMs < ss.mtimeMs) fs.copyFileSync(s, d);
    }
  }
  for (const name of fs.readdirSync(dst)) {
    if (!srcNames.has(name)) fs.rmSync(path.join(dst, name), { recursive: true, force: true });
  }
}

// ────────────────────────────── Шрифты ──────────────────────────────
function googleFontFamilies(url) {
  try {
    const u = new URL(url);
    if (!/fonts\.googleapis\.com$/.test(u.hostname)) return [];
    return u.searchParams.getAll('family').map(f => f.split(':')[0].trim()).filter(Boolean);
  } catch (e) { return []; }
}

function fontHeadHtml(importUrl) {
  if (!importUrl) return '';
  const google = googleFontFamilies(importUrl).length > 0;
  const pre = google ? '<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n' : '';
  return `${pre}<link rel="stylesheet" href="${escHtml(importUrl)}">\n`;
}

// Шрифт из админки («Настройка темы → Шрифт сайта») перекрывает токены темы.
// Пустое поле = используется шрифт самой темы. Блок дописывается в конец style.css,
// файл темы при этом не меняется.
function fontOverrideCss(family) {
  const fam = String(family || '').replace(/["';{}<>\\]/g, '').trim();
  if (!fam) return '';
  const stack = `"${fam}", ${FONT_FALLBACK}`;
  return `\n\n/* ── UCMS: шрифт из админки (Настройка темы → Шрифт сайта). Очистите поле, чтобы вернуть шрифт темы. ── */\n:root {\n  --font-body: ${stack};\n  --font-head: ${stack};\n}\n`;
}

// ── Стиль проекта (db.settings.brand): цвета, скругление, размер текста и шрифты
// поверх темы. Дописывается в конец style.css после темы — файл темы не меняется,
// при смене темы стиль проекта сохраняется. enabled: false — временно выключен.
const BRAND_COLORS = ['paper', 'panel', 'ink', 'muted', 'accent', 'line'];
function brandFont(f) {
  const family = String((f && f.family) || '').replace(/["';{}<>\\]/g, '').trim().slice(0, 60);
  if (!family) return null;
  let url = String((f && f.url) || '').trim();
  if (url && !/^https:\/\/[^\s"'<>]+$/.test(url)) url = '';
  // только название → Google Fonts, обычное начертание (запрос с весами, которых у шрифта нет,
  // Google отклоняет целиком; ссылку с нужными весами админка подставляет для шрифтов из списка)
  if (!url) url = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(family).replace(/%20/g, '+')}&display=swap`;
  return { family, url, local: !!(f && f.local) };
}
const PALETTES_FILE = path.join(projects.HOME, 'palettes.json');
function readPalettes() {
  try {
    const d = JSON.parse(fs.readFileSync(PALETTES_FILE, 'utf8'));
    return { custom: Array.isArray(d.custom) ? d.custom : [], hidden: Array.isArray(d.hidden) ? d.hidden : [] };
  } catch (e) { return { custom: [], hidden: [] }; }
}
function brandOf(db) {
  const b = db.settings.brand;
  return b && b.enabled !== false ? b : null;
}
function brandCss(db) {
  const b = brandOf(db);
  if (!b) return '';
  const vars = [];
  BRAND_COLORS.forEach(k => { const c = cssColor((b.colors || {})[k], ''); if (c) vars.push(`  --${k}: ${c};`); });
  const r = parseFloat(b.radius);
  if (isFinite(r) && r >= 0 && r <= 40) vars.push(`  --radius: ${r}px;`);
  const body = brandFont(b.fontBody), head = brandFont(b.fontHead);
  if (body) vars.push(`  --font-body: "${body.family}", ${FONT_FALLBACK};`);
  if (head) vars.push(`  --font-head: "${head.family}", ${FONT_FALLBACK};`);
  const fs = parseFloat(b.fontSize);
  const rules = [];
  if (vars.length) rules.push(`:root {\n${vars.join('\n')}\n}`);
  if (isFinite(fs) && fs >= 12 && fs <= 24) rules.push(`body { font-size: ${fs}px; }`);
  if (head) rules.push('h1, h2, h3, h4, h5, h6 { font-family: var(--font-head); }');
  return rules.length ? `\n\n/* ── UCMS: стиль проекта (Тема → Стиль проекта). Перекрывает токены темы. ── */\n${rules.join('\n')}\n` : '';
}
// <link> шрифтов стиля проекта (своя ссылка или Google Fonts; local — шрифт уже есть в теме/системе)
function brandFontLinks(db) {
  const b = brandOf(db);
  if (!b) return '';
  const urls = [brandFont(b.fontBody), brandFont(b.fontHead)].filter(f => f && !f.local).map(f => f.url);
  return [...new Set(urls)].filter(u => u !== db.settings.fontImportUrl).map(u => fontHeadHtml(u)).join('');
}

// ────────────────────────────── Генерация сайта ──────────────────────────────
function buildTree(pages) {
  const byId = {};
  pages.forEach(p => { byId[p.id] = { ...p, children: [] }; });
  const roots = [];
  pages.forEach(p => { (p.parentId && byId[p.parentId] ? byId[p.parentId].children : roots).push(byId[p.id]); });
  const sort = ns => { ns.sort((a, b) => (a.order || 0) - (b.order || 0)); ns.forEach(n => sort(n.children)); };
  sort(roots);
  return roots;
}

// Настройки блока (row.style) → классы row--* на самом .layout-row (механика — site/ucms.css).
// Обёрток нет: блок — один элемент и в шапке, и в контенте, и в подвале.
const ENUMS = {
  width: ['full', 'narrow'], pad: ['none', 's', 'm', 'l', 'xl'], valign: ['top', 'center', 'bottom'],
  gap: ['s', 'm', 'l'], hide: ['mobile', 'desktop'], align: ['left', 'center', 'right'],
};
function enumOf(key, v) { return ENUMS[key].includes(v) ? v : ''; }
function cleanAnchor(a) { return String(a || '').trim().replace(/^#/, '').replace(/[^\p{L}\p{N}_-]+/gu, '-').replace(/^-+|-+$/g, ''); }

// ── Параллакс фона-картинки ──
// Картинка выводится отдельным слоем <img> (а не background-image), чтобы её можно было двигать.
// Блоки — библиотека simpleParallax.js (site/vendor), фон страницы — свой скрипт в ucms.js
// (фиксированный слой на весь экран). Настройки — в data-px, как у simpleParallax.
const PX_ORIENT = ['up', 'down', 'left', 'right', 'up left', 'up right', 'down left', 'down right'];
function isParallax(bg) { return !!(bg && bg.type === 'image' && bg.parallax && bg.image); }
function pxSettings(bg) {
  const num = (v, d, lo, hi) => { const n = parseFloat(v); return Math.min(hi, Math.max(lo, isFinite(n) ? n : d)); };
  return {
    orientation: PX_ORIENT.includes(bg.pxOrientation) ? bg.pxOrientation : 'up',
    scale: num(bg.pxScale, 1.3, 1.05, 3),
    delay: num(bg.pxDelay, 0.4, 0, 3),
    transition: bg.pxSmooth === false ? '' : 'cubic-bezier(0,0,0,1)',
    maxTransition: Math.round(num(bg.pxMax, 0, 0, 99)),
  };
}
function parallaxLayer(bg, basePrefix, page) {
  return `<div class="ucms-bgpx${page ? ' ucms-bgpx--page' : ''}" aria-hidden="true"><img class="ucms-px" src="${escHtml(srcPath(bg.image, basePrefix))}" alt="" data-px="${escHtml(JSON.stringify(pxSettings(bg)))}"></div>`;
}

function rowAttrs(row, basePrefix) {
  const st = row.style || {};
  const cls = ['layout-row'];
  if (row.cssClass) cls.push(escHtml(String(row.cssClass).trim().replace(/\s+/g, ' ')));
  const width = enumOf('width', st.width);
  if (width) cls.push(`row--${width}`);
  if (width === 'full' && st.contain) cls.push('row--contain');
  if (enumOf('pad', st.pad)) cls.push(`row--pad-${st.pad}`);
  // свои отступы (px): переменные, на телефоне ucms.css уменьшает их на треть
  let padVars = '';
  if (st.pad === 'custom') {
    const px = v => Math.max(0, Math.min(400, parseInt(v, 10) || 0));
    cls.push('row--pad-custom');
    padVars = `--row-pt:${px(st.padTop)}px;--row-pb:${px(st.padBottom)}px;`;
  }
  if (enumOf('valign', st.valign)) cls.push(`row--va-${st.valign}`);
  if (enumOf('gap', st.gap)) cls.push(`row--gap-${st.gap}`);
  if (enumOf('align', st.align) && st.align !== 'left') cls.push(`row--${st.align}`);
  if (st.reverse) cls.push('row--rev');
  if (enumOf('hide', st.hide)) cls.push(`row--hide-${st.hide === 'mobile' ? 'm' : 'd'}`);
  const bg = st.bg && st.bg.type && st.bg.type !== 'none' ? st.bg : null;
  let style = '';
  if (bg) {
    cls.push('row--bg');
    if (bg.light) cls.push('row--light');
    // параллакс: картинка — отдельным слоем (rowLayer), в стиле блока остаётся только цвет
    style = isParallax(bg) ? bgStyle({ type: 'color', color: bg.color }, basePrefix) : bgStyle({ ...bg, fixed: false }, basePrefix);
    if (isParallax(bg)) cls.push('row--parallax');
    const ov = bg.type === 'image' ? Math.min(80, Math.max(0, parseInt(bg.overlay, 10) || 0)) : 0;
    if (ov) { cls.push('row--overlay'); style += `--ucms-overlay:rgba(0,0,0,${ov / 100});`; }
  }
  style = padVars + style;
  return { cls: cls.join(' '), id: cleanAnchor(st.anchor), style, hasBg: !!bg, layer: isParallax(bg) ? parallaxLayer(bg, basePrefix, false) : '' };
}

// Ширины колонок → flex. Проценты — доли свободного места (flex-grow), а не flex-basis:
// «50% + 50%» плюс промежуток между колонками больше 100% и переносился бы на новую строку.
// Колонки без ширины делят остаток поровну, px — фиксированные. Без ширин — без inline-стиля.
function colStyles(columns) {
  const parsed = columns.map(c => {
    const w = c.width;
    const v = w && w.value != null && w.value !== '' ? parseFloat(w.value) : NaN;
    return isFinite(v) && v > 0 ? { v, px: w.unit === 'px' } : null;
  });
  if (parsed.every(p => !p)) return parsed.map(() => '');
  const pct = parsed.reduce((a, p) => a + (p && !p.px ? p.v : 0), 0);
  const autos = parsed.filter(p => !p).length;
  const autoGrow = autos ? Math.max(1, (100 - pct) / autos) : 0;
  const r = n => Math.round(n * 100) / 100;
  return parsed.map(p => !p ? `flex:${r(autoGrow)} 1 0%`
    : p.px ? `flex:0 0 ${r(p.v)}px;max-width:${r(p.v)}px`
    : `flex:${r(p.v)} 1 0%;max-width:${r(p.v)}%`);
}

// Модули колонки; пустые (модуль вернул '') не оставляют пустых строк.
// Встроенный тип — из engine/modules, иначе — подключаемый модуль сайта (не установлен — ничего).
function renderModules(list, ctx) { return (list || []).map(b => blockModules.byType[b.type] ? blockModules.render(b, ctx) : (PKG.render(b, ctx) || '')).filter(Boolean).join('\n'); }

function renderRows(rows, ctx) {
  return (rows || []).map(row => {
    const a = rowAttrs(row, ctx.basePrefix);
    const columns = row.columns || [];
    const styles = colStyles(columns);
    const colsHtml = columns.map((col, i) => {
      const align = enumOf('align', col.align);
      return `<div class="layout-col${align ? ` col--${align}` : ''}"${styles[i] ? ` style="${styles[i]}"` : ''}>${renderModules(col.blocks, ctx)}</div>`;
    });
    const afterHtml = renderModules(row.blocks, ctx);
    const hasContent = afterHtml || colsHtml.some(h => !/^<div[^>]*><\/div>$/.test(h));
    if (!hasContent && !a.hasBg) return '';   // пустой блок без фона ничего не выводит
    return `<div class="${a.cls}"${a.id ? ` id="${escHtml(a.id)}"` : ''}${a.style ? ` style="${escHtml(a.style)}"` : ''}>` + a.layer +
      colsHtml.join('\n') + (afterHtml ? `<div class="layout-after">${afterHtml}</div>` : '') + '</div>';
  }).filter(Boolean).join('\n');
}

const CSS_COLOR = /^(#[0-9a-f]{3,8}|[a-z]+|rgba?\([\d\s.,%]+\)|hsla?\([\d\s.,%deg]+\))$/i;
function cssColor(c, fallback) { return c && CSS_COLOR.test(String(c).trim()) ? String(c).trim() : fallback; }

function bgStyle(bg, basePrefix) {
  if (!bg || !bg.type || bg.type === 'none') return '';
  if (bg.type === 'color') { const c = cssColor(bg.color, ''); return c ? `background-color:${c};` : ''; }
  if (bg.type === 'gradient') {
    const a = parseFloat(bg.gradientAngle);
    return `background-image:linear-gradient(${isFinite(a) ? a : 135}deg,${cssColor(bg.gradientFrom, '#5b3fc8')},${cssColor(bg.gradientTo, '#c99a2e')});`;
  }
  const src = srcPath(bg.image, basePrefix);
  const color = cssColor(bg.color, 'transparent');
  if (!src) return color !== 'transparent' ? `background-color:${color};` : '';
  const pattern = bg.type === 'pattern';
  const decl = [
    `background-color:${color}`,
    `background-image:url('${src.replace(/'/g, '%27')}')`,
    `background-repeat:${pattern ? 'repeat' : 'no-repeat'}`,
    `background-size:${pattern ? 'auto' : (bg.stretch === false ? 'auto' : 'cover')}`,
    `background-position:${pattern ? 'top left' : (bg.position || 'center')}`,
  ];
  if (bg.fixed) decl.push('background-attachment:fixed');
  return decl.join(';') + ';';
}

function clearOutput() {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  for (const ent of fs.readdirSync(OUTPUT_DIR, { withFileTypes: true })) {
    const fp = path.join(OUTPUT_DIR, ent.name);
    if (ent.isFile() && (ent.name.endsWith('.html') || ent.name === 'sitemap.xml' || ent.name === 'robots.txt')) fs.unlinkSync(fp);
    else if (ent.isDirectory() && ent.name !== 'uploads') fs.rmSync(fp, { recursive: true, force: true });
  }
}

// Коллекции из настроек: безопасный уникальный slug папки, без конфликтов со служебными папками.
const RESERVED_DIRS = new Set(['uploads', 'vendor', 'index']);
function normCollections(list, langs) {
  const used = new Set(langs.map(l => l.code));
  return (Array.isArray(list) ? list : []).filter(c => c && c.id).map(c => {
    const base = cleanSlug(c.slug || c.name || 'items');
    let slug = base;
    for (let i = 2; used.has(slug) || RESERVED_DIRS.has(slug); i++) slug = `${base}-${i}`;
    used.add(slug);
    return { ...c, slug };
  });
}

// Шапка записи: дата, заголовок, теги, обложка — до блоков записи.
function entryHeadHtml(p, coll, ctx, title) {
  const parts = [];
  if (coll.showDate !== false && collLib.validDate(p.date)) parts.push(`<time class="coll-date" datetime="${escHtml(p.date)}">${escHtml(collLib.formatDate(p.date, ctx.lang))}</time>`);
  if (coll.showTitle !== false && title) parts.push(`<h1>${escHtml(title)}</h1>`);
  if (coll.showTags && Array.isArray(p.tags) && p.tags.length) parts.push(`<div class="coll-tags">${p.tags.map(t => `<span>${escHtml(t)}</span>`).join('')}</div>`);
  // обложка над текстом — только если включено в коллекции (showCoverTop); в списках записей она есть всегда
  if (coll.showCoverTop === true && p.cover) parts.push(`<figure class="coll-cover"><img src="${escHtml(srcPath(p.cover, ctx.basePrefix))}" alt=""${ctx.img(p.cover, '(max-width: 1200px) 100vw, 1200px')}></figure>`);
  return parts.length ? `<div class="layout-row coll-head-row"><div class="layout-col"><header class="coll-head">${parts.join('')}</header></div></div>` : '';
}

// Навигация записи: соседние записи (в порядке списка) и ссылка на страницу-список.
// Подписи навигации записи на языке страницы
const NAV_LABELS = {
  ru: ['Предыдущая', 'Следующая', 'Все записи'], uk: ['Попередня', 'Наступна', 'Усі записи'], be: ['Папярэдняя', 'Наступная', 'Усе запісы'],
  kk: ['Алдыңғы', 'Келесі', 'Барлық жазбалар'], en: ['Previous', 'Next', 'All posts'], de: ['Vorheriger', 'Nächster', 'Alle Beiträge'],
  fr: ['Précédent', 'Suivant', 'Tous les articles'], es: ['Anterior', 'Siguiente', 'Todas las entradas'], it: ['Precedente', 'Successivo', 'Tutti gli articoli'],
  pt: ['Anterior', 'Seguinte', 'Todas as publicações'], pl: ['Poprzedni', 'Następny', 'Wszystkie wpisy'],
};
// Где показывать навигацию: navTop / navBottom (по умолчанию обе). Старое showNav: false — нигде.
function collNavAt(coll, where) {
  const v = where === 'top' ? coll.navTop : coll.navBottom;
  return v == null ? coll.showNav !== false : v !== false;
}
// Навигация записи: «← Предыдущая · список · Следующая →». При сортировке по дате
// предыдущая — более старая запись, следующая — более новая; при ручной — по порядку списка.
// На телефоне остаются стрелки и ссылка на список (ucms.css).
function entryNavHtml(p, coll, ctx, where) {
  if (!collNavAt(coll, where)) return '';
  const list = ctx.entriesOf(coll.id);
  const i = list.findIndex(e => e.id === p.id);
  const listPage = ctx.pagesById[coll.listPageId];
  if (i < 0 || (list.length < 2 && !listPage)) return '';
  const byDate = coll.sort !== 'manual';
  const prev = byDate ? list[i + 1] : list[i - 1];
  const next = byDate ? list[i - 1] : list[i + 1];
  const L = NAV_LABELS[String(ctx.lang || '').slice(0, 2)] || NAV_LABELS.en;
  const titleOf = e => { const tr = ctx.lang !== ctx.defaultLang && e.translations[ctx.lang]; return (tr && tr.title) || e.title; };
  const link = (e, dir) => {
    if (!e) return '<span></span>';
    const label = dir === 'prev' ? `<span class="coll-nav__dir"><i aria-hidden="true">←</i><b>${escHtml(L[0])}</b></span>` : `<span class="coll-nav__dir"><b>${escHtml(L[1])}</b><i aria-hidden="true">→</i></span>`;
    return `<a class="coll-nav__${dir}" href="${escHtml(blockShared.pageHref(e, ctx))}" rel="${dir}" title="${escHtml(titleOf(e))}">${label}<span class="coll-nav__t">${escHtml(titleOf(e))}</span></a>`;
  };
  const back = listPage ? `<a class="coll-nav__back" href="${escHtml(blockShared.pageHref(listPage, ctx))}" title="${escHtml(L[2])}">${escHtml(titleOf(listPage))}</a>` : '<span></span>';
  return `<div class="layout-row coll-nav-row coll-nav-row--${where}"><div class="layout-col"><nav class="coll-nav coll-nav--${where}" aria-label="${escHtml(L[2])}">${link(prev, 'prev')}${back}${link(next, 'next')}</nav></div></div>`;
}

// Модель сайта для генерации и предпросмотра: языки, коллекции, уникальные slug'и,
// дерево меню, записи коллекций. drafts — включить черновики записей (предпросмотр:
// черновик можно открыть по адресу, но в списки записей он не попадает).
function siteModel(db, { drafts = false } = {}) {
  const langs = db.settings.languages.length ? db.settings.languages : [{ code: 'ru', isDefault: true }];
  const defLang = (langs.find(l => l.isDefault) || langs[0]).code;
  const multi = langs.length > 1;

  const colls = normCollections(db.settings.collections, langs);
  const collsById = {};
  colls.forEach(c => { collsById[c.id] = c; });
  const collOf = p => (p.collection && collsById[p.collection]) || null;

  // Уникальные безопасные slug'и (на каждый язык и папку отдельно): дубли не затирают друг друга.
  const pages = db.pages.filter(p => drafts || !(p.draft && collOf(p)))
    .map(p => ({ ...p, slug: cleanSlug(p.slug), translations: { ...p.translations } }));
  langs.forEach(({ code }) => {
    const used = new Set();
    pages.forEach(p => {
      const tr = code !== defLang && p.translations[code];
      const dir = collOf(p) ? `${p.collection}/` : '';
      const base = tr && tr.slug ? cleanSlug(tr.slug) : p.slug;
      let slug = base;
      for (let i = 2; used.has(dir + slug); i++) slug = `${base}-${i}`;
      used.add(dir + slug);
      if (code === defLang) p.slug = slug;
      else p.translations[code] = { ...(p.translations[code] || {}), slug };
    });
  });

  const tree = buildTree(pages.filter(p => !collOf(p)));   // в меню и дереве — только обычные страницы
  const pagesById = {};
  pages.forEach(p => { pagesById[p.id] = p; });
  const entries = {};
  colls.forEach(c => { entries[c.id] = collLib.sortEntries(pages.filter(p => p.collection === c.id && !p.draft), c); });
  return {
    db, langs, defLang, multi, langPrefix: multi ? '../' : '', colls, collsById, collOf, pages, tree, pagesById,
    entriesOf: id => entries[id] || [],
    siteUrl: cleanSiteUrl(db.settings.siteUrl), fontLinks: fontHeadHtml(db.settings.fontImportUrl) + brandFontLinks(db),
  };
}

function slugIn(m, pg, lang) { return (lang !== m.defLang && pg.translations[lang] && pg.translations[lang].slug) || pg.slug; }
// Путь страницы от папки языка, без .html: «about» или «blog/post»
function pageRelPath(m, p, lang) { const c = m.collOf(p); return c ? `${c.slug}/${slugIn(m, p, lang)}` : slugIn(m, p, lang); }
// Путь от корня сайта: «about.html» или «en/blog/post.html»
function pageUrlPath(m, p, lang) { return `${m.multi ? `${lang}/` : ''}${pageRelPath(m, p, lang)}.html`; }

// HTML одной страницы на одном языке. preview — отметка черновика поверх страницы.
function renderPage(m, p, lang, { preview = false } = {}) {
  PKG.refresh();
  const db = m.db, defLang = m.defLang;
  const tr = lang !== defLang ? p.translations[lang] : null;
  const slug = slugIn(m, p, lang);
  const pageTitle = (tr && tr.title) || p.title;
  const siteTitle = (lang !== defLang && db.settings.siteTitleTranslations[lang]) || db.settings.siteTitle;
  const coll = m.collOf(p);
  const pageBase = coll ? '../' : '';                 // запись лежит в папке коллекции — на уровень глубже
  const basePrefix = m.langPrefix + pageBase;
  const listPage = coll ? m.pagesById[coll.listPageId] : null;
  const ctx = { tree: m.tree, lang, defaultLang: defLang, languages: m.langs, basePrefix, pageBase, siteTitle, page: p, inSubfolder: m.multi,
    currentSlug: coll ? (listPage ? slugIn(m, listPage, lang) : '') : slug,   // у записи в меню подсвечивается страница-список
    pagesById: m.pagesById, collsById: m.collsById, entriesOf: m.entriesOf,
    img: (src, sizes) => imgAttrs(src, basePrefix, sizes), usedPkgs: new Set() };
  ctx.renderRows = rows => renderRows(rows, ctx);   // модули-контейнеры («Вкладки») выводят свои блоки
  const showH = db.settings.header.enabled !== false && p.showHeader !== false;
  const showF = db.settings.footer.enabled !== false && p.showFooter !== false;
  const pagePx = isParallax(p.background);
  const bodyStyle = pagePx ? bgStyle({ type: 'color', color: p.background.color }, basePrefix) : bgStyle(p.background, basePrefix);
  const seo = p.seo || {};
  const sticky = db.settings.header.sticky ? ' site-header--sticky' : '';
  const headerHtml = showH ? `<header class="site-header${sticky}">${renderRows(db.settings.header.rows, ctx)}</header>` : '';
  const mainInner = coll
    ? [entryNavHtml(p, coll, ctx, 'top'), entryHeadHtml(p, coll, ctx, pageTitle), renderRows(p.rows, ctx), entryNavHtml(p, coll, ctx, 'bottom')].filter(Boolean).join('\n')
    : renderRows(p.rows, ctx);
  const mainHtml = `<main class="site-main${coll ? ' coll-entry' : ''}">${mainInner}</main>`;
  const footerHtml = showF ? `<footer class="site-footer">${renderRows(db.settings.footer.rows, ctx)}</footer>` : '';
  // simpleParallax подключаем только на страницах, где есть параллакс у блоков
  const needPxLib = /class="ucms-bgpx"/.test(headerHtml + mainHtml + footerHtml);
  const description = (tr && tr.description) || seo.description || (coll ? collLib.entryExcerpt(p, lang, defLang, 200) : '');
  const draftMark = preview && p.draft
    ? '<div style="position:fixed;left:50%;bottom:16px;transform:translateX(-50%);z-index:99999;padding:8px 16px;border-radius:999px;background:#b26b00;color:#fff;font:600 13px/1.3 system-ui,sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.2)">Черновик — на сайт не попадёт</div>' : '';
  return [
    '<!DOCTYPE html>',
    `<html lang="${escHtml(lang)}">`,
    '<head>',
    '<meta charset="UTF-8">',
    '<meta name="viewport" content="width=device-width,initial-scale=1">',
    `<title>${escHtml(pageTitle)} — ${escHtml(siteTitle)}</title>`,
    preview ? `<meta name="ucms-page" content="${escHtml(p.id)}">` : '',   // предпросмотр: админка узнаёт, какая страница открыта
    seoHead({ siteUrl: m.siteUrl, urlPath: pageUrlPath(m, p, lang), title: pageTitle, siteTitle, lang, basePrefix, image: seo.image || (coll ? collLib.entryCover(p) : ''), noindex: !!seo.noindex,
      description, article: coll ? { date: collLib.validDate(p.date) } : null }),
    faviconHead(db.settings, basePrefix),
    `${m.fontLinks}<link rel="stylesheet" href="${basePrefix}ucms.css">`,
    `<link rel="stylesheet" href="${basePrefix}style.css">`,
    needPxLib ? `<script src="${basePrefix}vendor/simple-parallax.min.js" defer></script>` : '',
    `<script src="${basePrefix}ucms.js" defer></script>`,
    PKG.headTags(ctx.usedPkgs, basePrefix),
    '</head>',
    `<body${bodyStyle ? ` style="${escHtml(bodyStyle)}"` : ''}>`,
    pagePx ? parallaxLayer(p.background, basePrefix, true) : '',
    headerHtml, mainHtml, footerHtml, draftMark,
    '</body>',
    '</html>',
  ].filter(Boolean).join('\n');
}

function siteStyleCss(db) { return (db.settings.css || defaultCss()) + fontOverrideCss(db.settings.fontFamily) + brandCss(db); }

function generateSite(db) {
  const m = siteModel(db);
  const sitemap = [];   // адреса для sitemap.xml
  clearOutput();

  m.langs.forEach(({ code: lang }) => {
    const langDir = m.multi ? path.join(OUTPUT_DIR, lang) : OUTPUT_DIR;
    fs.mkdirSync(langDir, { recursive: true });
    const written = new Set();
    m.pages.forEach(p => {
      const coll = m.collOf(p);
      const relPath = pageRelPath(m, p, lang);
      if (!(p.seo && p.seo.noindex)) sitemap.push(pageUrlPath(m, p, lang));
      if (coll) fs.mkdirSync(path.join(langDir, coll.slug), { recursive: true });
      fs.writeFileSync(path.join(langDir, `${relPath}.html`), renderPage(m, p, lang), 'utf8');
      if (!coll) written.add(relPath);
    });
    // Нет страницы со slug «index» → /output/ отдавал 404. Ставим редирект на первую страницу.
    if (!written.has('index') && m.tree[0]) {
      fs.writeFileSync(path.join(langDir, 'index.html'), redirectHtml(`${slugIn(m, m.tree[0], lang)}.html`), 'utf8');
    }
  });

  fs.writeFileSync(path.join(OUTPUT_DIR, 'style.css'), siteStyleCss(db), 'utf8');
  for (const f of ['ucms.css', 'ucms.js']) fs.copyFileSync(path.join(SITE_DIR, f), path.join(OUTPUT_DIR, f));
  syncDir(path.join(SITE_DIR, 'vendor'), path.join(OUTPUT_DIR, 'vendor'));   // simpleParallax.js (MIT)

  // Доп. файлы активной темы (шрифты, картинки) — в корень output.
  const atd = themeDir(db.settings.theme);
  if (fs.existsSync(atd)) {
    for (const ent of fs.readdirSync(atd, { withFileTypes: true })) {
      if (ent.name === 'theme.css' || ent.name === 'theme.json') continue;
      const src = path.join(atd, ent.name), dst = path.join(OUTPUT_DIR, ent.name);
      if (ent.isDirectory()) syncDir(src, dst); else fs.copyFileSync(src, dst);
    }
  }
  syncDir(UPLOADS_DIR, path.join(OUTPUT_DIR, 'uploads'));
  PKG.copyAssets(OUTPUT_DIR);   // оформление и файлы подключаемых модулей → ucms-modules/<id>/
  if (m.multi) fs.writeFileSync(path.join(OUTPUT_DIR, 'index.html'), redirectHtml(`${m.defLang}/index.html`), 'utf8');
  // sitemap.xml и robots.txt — только с адресом сайта (в sitemap нужны абсолютные URL)
  if (m.siteUrl) {
    const urls = sitemap.map(u => `  <url><loc>${escHtml(`${m.siteUrl}/${u}`)}</loc></url>`).join('\n');
    fs.writeFileSync(path.join(OUTPUT_DIR, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`, 'utf8');
    if (!fs.existsSync(path.join(themeDir(db.settings.theme), 'robots.txt'))) {
      fs.writeFileSync(path.join(OUTPUT_DIR, 'robots.txt'), `User-agent: *\nAllow: /\nSitemap: ${m.siteUrl}/sitemap.xml\n`, 'utf8');
    }
  }
  return m.pages.length * m.langs.length;
}

// ── Предпросмотр: страницы собираются на лету из db.json, без записи в output/ ──
// /preview/ повторяет структуру output/ (те же относительные ссылки), поэтому
// навигация по сайту внутри предпросмотра работает как на хостинге.
// /preview/__page/<id>?lang=xx — переход к странице по id (из админки).
function servePreview(req, res, rel) {
  const db = readDB();
  const m = siteModel(db, { drafts: true });
  const nostore = { 'Cache-Control': 'no-store' };
  const htmlHdr = { 'Content-Type': 'text/html;charset=utf-8', ...nostore };
  rel = decodeURIComponent(rel).replace(/^\/+/, '');

  const byId = /^__page\/([^/?]+)$/.exec(rel);
  if (byId) {
    const lang = new URL(req.url, 'http://x').searchParams.get('lang') || m.defLang;
    const p = m.pagesById[byId[1]];
    const code = m.langs.some(l => l.code === lang) ? lang : m.defLang;
    const target = p ? pageUrlPath(m, p, code) : (m.multi ? `${code}/index.html` : 'index.html');
    return send(res, 302, '', { Location: `/preview/${target}`, ...nostore });
  }

  // Статика: runtime сайта, стиль, загруженные файлы, файлы темы
  const parts = rel.split('/');
  if (m.multi && m.langs.some(l => l.code === parts[0]) && parts.length > 1 && !/\.html$/.test(rel)) parts.shift();   // ../ из языковой папки
  const asset = parts.join('/');
  if (asset === 'style.css') return send(res, 200, siteStyleCss(db), { 'Content-Type': 'text/css;charset=utf-8', ...nostore });
  if (asset === 'ucms.css' || asset === 'ucms.js') return serveFile(res, SITE_DIR, `/${asset}`);
  if (asset.startsWith('vendor/')) return serveFile(res, SITE_DIR, `/${asset}`);
  if (asset.startsWith('uploads/')) return serveFile(res, UPLOADS_DIR, `/${asset.slice('uploads/'.length)}`);
  const pa = /^ucms-modules\/([a-z][a-z0-9-]{1,39})\/(.+)$/.exec(asset);
  if (pa) { PKG.refresh(); const abs = PKG.assetPath(pa[1], pa[2]); return abs ? serveFile(res, path.dirname(abs), '/' + path.basename(abs)) : send(res, 404, 'Not found'); }

  // Страницы
  let lang = m.defLang, pagePath = rel;
  if (m.multi) {
    if (!rel || rel === 'index.html') return send(res, 302, '', { Location: `/preview/${m.defLang}/index.html`, ...nostore });
    const code = rel.split('/')[0];
    if (!m.langs.some(l => l.code === code)) return send(res, 404, 'Not found', nostore);
    lang = code; pagePath = rel.slice(code.length + 1);
  }
  if (!pagePath) pagePath = 'index.html';
  if (/\.html$/.test(pagePath)) {
    const want = pagePath.replace(/\.html$/, '');
    const p = m.pages.find(x => pageRelPath(m, x, lang) === want);
    if (p) return send(res, 200, renderPage(m, p, lang, { preview: true }), htmlHdr);
    if (want === 'index' && m.tree[0]) return send(res, 302, '', { Location: `${slugIn(m, m.tree[0], lang)}.html`, ...nostore });
    return send(res, 404, '<!DOCTYPE html><meta charset="utf-8"><body style="font:15px system-ui;padding:40px;color:#666">Страница не найдена</body>', htmlHdr);
  }
  // Прочие файлы темы (шрифты, картинки) — из папки активной темы
  return serveFile(res, themeDir(db.settings.theme), `/${asset}`);
}

// SEO: description, Open Graph, canonical, noindex. Абсолютные адреса — только если
// в настройках указан адрес сайта (siteUrl); без него og:image и canonical не пишем.
function seoHead({ siteUrl, urlPath, title, siteTitle, description, image, noindex, lang, basePrefix, article }) {
  const out = [];
  const abs = rel => siteUrl ? `${siteUrl}/${String(rel).replace(/^\/+/, '')}` : '';
  if (description) out.push(`<meta name="description" content="${escHtml(description)}">`);
  if (noindex) out.push('<meta name="robots" content="noindex, nofollow">');
  out.push(`<meta property="og:type" content="${article ? 'article' : 'website'}">`, `<meta property="og:title" content="${escHtml(title)}">`, `<meta property="og:site_name" content="${escHtml(siteTitle)}">`);
  out.push(`<meta property="og:locale" content="${escHtml(lang)}">`);
  if (description) out.push(`<meta property="og:description" content="${escHtml(description)}">`);
  if (article && article.date) out.push(`<meta property="article:published_time" content="${escHtml(article.date)}">`);
  if (siteUrl) {
    out.push(`<link rel="canonical" href="${escHtml(abs(urlPath))}">`, `<meta property="og:url" content="${escHtml(abs(urlPath))}">`);
    if (image) out.push(`<meta property="og:image" content="${escHtml(/^https?:/.test(image) ? image : abs(image))}">`, '<meta name="twitter:card" content="summary_large_image">');
  } else if (image) {
    out.push(`<meta property="og:image" content="${escHtml(srcPath(image, basePrefix))}">`);
  }
  return out.join('\n');
}

// Иконка сайта: из настроек («Сайт и модули → Иконка сайта»), иначе favicon.* из папки темы.
// Иконка админки (оранжевая «U») на сайт не попадает никогда.
const FAVICON_TYPES = { '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.gif': 'image/gif', '.webp': 'image/webp', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg' };
function faviconHead(settings, basePrefix) {
  let href = settings.favicon ? srcPath(settings.favicon, basePrefix) : '';
  if (!href) {
    const own = ['favicon.svg', 'favicon.png', 'favicon.ico'].find(f => fs.existsSync(path.join(themeDir(settings.theme), f)));
    if (own) href = `${basePrefix}${own}`;
  }
  if (!href) return '';
  const type = FAVICON_TYPES[path.extname(href.split('?')[0]).toLowerCase()];
  const touch = /\.(png|jpe?g)$/i.test(href) ? `\n<link rel="apple-touch-icon" href="${escHtml(href)}">` : '';
  return `<link rel="icon" href="${escHtml(href)}"${type ? ` type="${type}"` : ''}>${touch}`;
}

function cleanSiteUrl(u) { const s = String(u || '').trim().replace(/\/+$/, ''); return /^https?:\/\/[^\s"'<>]+$/i.test(s) ? s : ''; }

function redirectHtml(url) {
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta http-equiv="refresh" content="0;url=${escHtml(url)}"><link rel="canonical" href="${escHtml(url)}"></head><body></body></html>`;
}

// ────────────────────────────── AI перевод ──────────────────────────────
function callAnthropic(apiKey, model, text) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify({ model, max_tokens: 4096, messages: [{ role: 'user', content: text }] });
    const req = https.request({
      hostname: 'api.anthropic.com', path: '/v1/messages', method: 'POST', timeout: 60000,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    }, r => {
      let d = '';
      r.on('data', c => { d += c; });
      r.on('end', () => { try { const p = JSON.parse(d); if (p.error) reject(new Error(p.error.message)); else resolve(p); } catch (e) { reject(e); } });
    });
    req.on('timeout', () => req.destroy(new Error('Таймаут запроса к API (60 с)')));
    req.on('error', reject);
    req.end(payload);
  });
}

// ────────────────────────────── Публикация (FTP/FTPS) ──────────────────────────────
let publisher = null;   // создаётся для активного проекта в useProject()
// Одна публикация за раз; админка опрашивает статус.
let publishJob = { running: false, phase: '', done: 0, total: 0, current: '', result: null, error: null, finishedAt: null };

// force — опубликовать поверх проекта, изменённого на сервере с другого компьютера
function startPublish(force) {
  generateSite(readDB());   // публикуем всегда свежую сборку
  publishJob = { running: true, phase: 'connect', done: 0, total: 0, current: '', result: null, error: null, code: '', remote: null, finishedAt: null };
  syncStatusCache = null;
  publisher.publish(p => Object.assign(publishJob, p), { force: !!force })
    .then(result => Object.assign(publishJob, { running: false, phase: 'done', result, finishedAt: Date.now() }))
    .catch(e => Object.assign(publishJob, { running: false, phase: 'error', error: e.message, code: e.code || '', remote: e.remote || null, finishedAt: Date.now() }));
}

// ── Проект на сервере: статус, «Скачать правки» (в открытый проект), «С сервера» (новый проект) ──
let syncStatusCache = null;   // { at, value } — статус с сервера (FTP-подключение не на каждое открытие админки)
let syncJob = { running: false, phase: '', done: 0, total: 0, current: '', result: null, error: null, code: '' };
function runSyncJob(work) {
  if (syncJob.running || publishJob.running) throw new Error('Уже идёт обмен с сервером — дождитесь окончания');
  syncJob = { running: true, phase: 'connect', done: 0, total: 0, current: '', result: null, error: null, code: '' };
  work(p => Object.assign(syncJob, p))
    .then(result => Object.assign(syncJob, { running: false, phase: 'done', result }))
    .catch(e => Object.assign(syncJob, { running: false, phase: 'error', error: e.message, code: e.code || '' }));
}
// Получить проект с сервера поверх открытого: перед заменой — резервная копия и версия в «Истории»
async function applyPulled(pkg) {
  makeBackup('before-pull');
  await _writeQueue;
  try { HISTORY.snapshot('manual', 'Перед получением правок с сервера'); } catch (e) { console.warn('[history]', e.message); }
  const keep = ((readDB().settings || {}).translation || {}).apiKey || '';
  const db = remoteProject.writePackage(pkg, CONTENT_DIR, { keepApiKey: keep });
  await writeDB(migrateDB(db));
}

// ────────────────────────────── Экспорт / импорт сайта ──────────────────────────────
// Архив сайта: ucms-site.json (описание) + db.json + uploads/ + themes/.
// Не входят: output/ (собирается заново), publish.json (пароль FTP),
// .publish/ (состояние публикации) и backups/.
const BACKUPS_KEEP = 10;

function collectFiles(dir, prefix, out) {
  if (!fs.existsSync(dir)) return out;
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, ent.name), rel = `${prefix}/${ent.name}`;
    if (ent.isDirectory()) collectFiles(abs, rel, out);
    else out.push({ name: rel, data: fs.readFileSync(abs) });
  }
  return out;
}
// history — добавить историю версий (index.json и снимки .json.gz): полная резервная копия
function siteArchive(opts) {
  const db = readDB();
  const files = [
    { name: 'ucms-site.json', data: Buffer.from(JSON.stringify({ format: 'ucms-site', version: 1, exportedAt: new Date().toISOString(), siteTitle: db.settings.siteTitle }, null, 2)) },
    { name: 'db.json', data: Buffer.from(JSON.stringify(db, null, 2)) },
  ];
  collectFiles(UPLOADS_DIR, 'uploads', files);
  collectFiles(THEMES_DIR, 'themes', files);
  collectFiles(path.join(CONTENT_DIR, 'modules'), 'modules', files);   // подключаемые модули — переезжают с сайтом
  if (opts && opts.history) {
    const hdir = path.join(CONTENT_DIR, 'history');
    if (fs.existsSync(hdir)) for (const f of fs.readdirSync(hdir)) if (f === 'index.json' || /^[\d-]+\.json\.gz$/.test(f)) files.push({ name: `history/${f}`, data: fs.readFileSync(path.join(hdir, f)) });
  }
  return createZip(files);
}
// Метка времени по часам компьютера: 2026-10-06-14-05-09
function stamp() { const d = new Date(), p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`; }
function asciiName(s) { return String(s || 'site').replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'site'; }

function sendDownload(res, name, buf, type) {
  res.writeHead(200, {
    'Content-Type': type, 'Content-Length': buf.length, 'Cache-Control': 'no-store',
    'Content-Disposition': `attachment; filename="${name}"; filename*=UTF-8''${encodeURIComponent(name)}`,
  });
  res.end(buf);
}

// Разбор загруженного файла (zip или json) → { db, files, summary }. Ничего не пишет.
function parseImport(buf) {
  let db, files = [], history = [];
  const isZip = buf.length > 4 && buf.readUInt32LE(0) === 0x04034b50;
  if (isZip) {
    const entries = readZip(buf);
    const dbEntry = entries.find(e => e.name === 'db.json' || e.name.endsWith('/db.json'));
    if (!dbEntry) throw new Error('В архиве нет db.json — это не архив сайта UCMS');
    const root = dbEntry.name.slice(0, -'db.json'.length);   // архив могли переупаковать с папкой внутри
    db = JSON.parse(dbEntry.data.toString('utf8'));
    for (const e of entries) {
      if (!e.name.startsWith(root)) continue;
      const rel = e.name.slice(root.length);
      if (/^history\/(index\.json|[\d-]+\.json\.gz)$/.test(rel)) { history.push({ name: rel.slice(8), data: e.data }); continue; }
      if (!/^(uploads|themes|modules)\//.test(rel)) continue;
      if (rel.startsWith('modules/') && !/^modules\/[a-z][a-z0-9-]{1,39}\/[A-Za-z0-9._\/-]+$/.test(rel)) continue;
      if (rel.split('/').some(seg => seg === '..' || seg === '') || path.isAbsolute(rel)) throw new Error(`Недопустимый путь в архиве: ${rel}`);
      files.push({ rel, data: e.data });
    }
  } else {
    try { db = JSON.parse(buf.toString('utf8').replace(/^\uFEFF/, '')); }
    catch (e) { throw new Error('Файл не похож на архив (.zip) или данные (.json) сайта UCMS'); }
  }
  if (!db || !db.settings || !Array.isArray(db.pages)) throw new Error('Файл не похож на данные сайта UCMS (нет settings/pages)');
  const themes = [...new Set(files.filter(f => /^themes\/[^/]+\//.test(f.rel)).map(f => f.rel.split('/')[1]))];
  return {
    db, files, isZip, history,
    summary: {
      history: Math.max(0, history.length - 1),
      kind: isZip ? 'site' : 'content',
      siteTitle: db.settings.siteTitle || '',
      pages: db.pages.length,
      languages: (db.settings.languages || []).map(l => l.code),
      uploads: files.filter(f => f.rel.startsWith('uploads/')).length,
      modules: [...new Set(files.filter(f => f.rel.startsWith('modules/')).map(f => f.rel.split('/')[1]))],
      themes,
    },
  };
}

// Веб: автокопия сайта раз в сутки, если с прошлой копии были правки (на сервере, в папке backups).
// Защищает от своих ошибок; от отказа хостинга — копия на компьютере (подключённый сайт) или «Перенос».
function autoBackupTick() {
  if (!WEB || !ACTIVE || needSetup()) return;
  try {
    const last = fs.existsSync(BACKUPS_DIR) ? fs.readdirSync(BACKUPS_DIR).filter(f => /^auto-.*\.zip$/.test(f)).sort().pop() : null;
    const lastAt = last ? fs.statSync(path.join(BACKUPS_DIR, last)).mtimeMs : 0;
    if (Date.now() - lastAt < 20 * 3600e3) return;
    if (lastAt && fs.statSync(DB_PATH).mtimeMs <= lastAt) return;   // правок не было
    makeBackup('auto');
  } catch (e) { console.warn('[backup]', e.message); }
}
function makeBackup(reason) {
  fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  const name = `${reason}-${stamp()}.zip`;
  fs.writeFileSync(path.join(BACKUPS_DIR, name), siteArchive());
  // храним по видам: ежедневные автокопии не вытесняют копии перед импортом и обновлением
  const all = fs.readdirSync(BACKUPS_DIR).filter(f => f.endsWith('.zip') && f.startsWith(reason + '-')).sort();
  const keep = reason === 'auto' ? 7 : BACKUPS_KEEP;
  all.slice(0, Math.max(0, all.length - keep)).forEach(f => fs.rmSync(path.join(BACKUPS_DIR, f), { force: true }));
  return name;
}

async function applyImport(parsed) {
  const backup = makeBackup('before-import');
  await _writeQueue;
  try { HISTORY.snapshot('before-import', ''); } catch (e) { console.warn('[history]', e.message); }
  const hasModules = parsed.isZip && parsed.files.some(f => f.rel.startsWith('modules/'));
  if (parsed.isZip) {
    // Архив сайта заменяет картинки и темы целиком
    for (const dir of [UPLOADS_DIR, THEMES_DIR]) { fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true }); }
    // Модули: в архиве есть — заменяют установленные (архивы до 1.14 их не содержат — установленные остаются).
    // Модуль — это код сайта, поэтому из архива его ставит только тот, кому можно ставить модули.
    if (!parsed.allowModules) parsed.files = parsed.files.filter(f => !f.rel.startsWith('modules/'));
    else if (hasModules) fs.rmSync(path.join(CONTENT_DIR, 'modules'), { recursive: true, force: true });
    for (const f of parsed.files) {
      const abs = path.join(CONTENT_DIR, f.rel);
      if (!isInside(CONTENT_DIR, abs)) continue;
      fs.mkdirSync(path.dirname(abs), { recursive: true });
      fs.writeFileSync(abs, f.data);
    }
  }
  await writeDB(migrateDB(parsed.db));
  // архив без модулей (до 1.14, или .json): блоки тарифов, цифр… — их модули из движка; с модулями — как в архиве
  if (!hasModules) ensureSiteModules(true);
  else { try { fs.writeFileSync(path.join(CONTENT_DIR, 'modules', '.from-engine'), new Date().toISOString() + '\n'); } catch (e) { /* нет папки */ } }
  if (parsed.history && parsed.history.length) { try { HISTORY.importEntries(parsed.history); } catch (e) { console.warn('[history]', e.message); } }
  return backup;
}

// ────────────────────────────── Проекты ──────────────────────────────
// Сервер работает с одним активным проектом. Переключение — только когда
// дописаны все сохранения и не идёт публикация.
function useProject(p) {
  CONTENT_DIR = path.resolve(p.path);
  DB_PATH = path.join(CONTENT_DIR, 'db.json');
  THEMES_DIR = path.join(CONTENT_DIR, 'themes');
  OUTPUT_DIR = path.join(CONTENT_DIR, 'output');
  UPLOADS_DIR = path.join(CONTENT_DIR, 'uploads');
  BACKUPS_DIR = path.join(CONTENT_DIR, 'backups');
  for (const d of [CONTENT_DIR, OUTPUT_DIR, UPLOADS_DIR]) fs.mkdirSync(d, { recursive: true });
  publisher = createPublisher({ contentDir: CONTENT_DIR, outputDir: OUTPUT_DIR, version: VERSION });
  syncStatusCache = null;
  HISTORY = createHistory({ dir: path.join(CONTENT_DIR, 'history'), dbPath: DB_PATH });
  publishJob = { running: false, phase: '', done: 0, total: 0, current: '', result: null, error: null, finishedAt: null };
  ACTIVE = { id: p.id, name: p.name, path: CONTENT_DIR };
  cleanupTmpFiles();
  readDB();   // создаёт db.json и тему, если их ещё нет
  ensureSiteModules();
  DB_REV = revOf(fs.readFileSync(DB_PATH, 'utf8'));
  if (!WEB) projects.update(p.id, { openedAt: new Date().toISOString() });
}
// ── Подключённый сайт веб-UCMS (локальная версия) ──
// Данные живут на сервере; локальный сервер передаёт запросы админки туда с ключом доступа.
// Браузер с чужим доменом не общается — ключ не покидает этот компьютер.
function normRemoteUrl(u) {
  let s = String(u || '').trim();
  if (!/^https?:\/\//i.test(s)) s = (/^(localhost|127\.0\.0\.1)(:|\/|$)/i.test(s) ? 'http://' : 'https://') + s;
  let url; try { url = new URL(s); } catch (e) { throw new Error('Неверный адрес сайта UCMS'); }
  const local = /^(localhost|127\.0\.0\.1|\[::1\])$/i.test(url.hostname);
  if (url.protocol !== 'https:' && !local) throw new Error('Адрес должен начинаться с https:// — по http ключ доступа передавался бы открытым');
  return (url.origin + url.pathname.replace(/\/(admin\/?.*)?$/, '')).replace(/\/+$/, '');
}
function remoteJson(base, token, method, pth, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(base + pth), mod = u.protocol === 'https:' ? https : http;
    const data = body === undefined ? null : Buffer.from(JSON.stringify(body));
    const rq = mod.request(u, { method, timeout: 20000, headers: { Authorization: 'Bearer ' + token, 'User-Agent': 'UCMS/' + VERSION, Accept: 'application/json',
      ...(data ? { 'Content-Type': 'application/json', 'Content-Length': data.length } : {}) } }, r => {
      const chunks = []; let n = 0;
      r.on('data', c => { n += c.length; if (n > 4 * 1048576) rq.destroy(new Error('Слишком большой ответ')); else chunks.push(c); });
      r.on('end', () => {
        let d = null; try { d = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (e) { /* не JSON */ }
        if (r.statusCode === 401) return reject(Object.assign(new Error('Сервер не принял ключ доступа — возможно, его отозвали. Создайте новый в веб-админке: «Настройки сайта → UCMS → Ключи доступа».'), { code: 'REMOTE_AUTH' }));
        if (!d) return reject(new Error(`По адресу ${base} нет UCMS (ответ ${r.statusCode})`));
        if (r.statusCode >= 400 || d.ok === false) return reject(new Error(d.error || 'Ответ ' + r.statusCode));
        resolve(d);
      });
    });
    rq.on('timeout', () => rq.destroy(new Error('сервер не ответил за 20 с')));
    rq.on('error', e => reject(e.code === 'REMOTE_AUTH' ? e : new Error('Сервер сайта недоступен: ' + (e.code || e.message))));
    rq.end(data);
  });
}
// Сведения о подключённом сайте: кто мы там, куда публикуется, адрес
async function remoteInfo(url, token) {
  const d = await remoteJson(url, token, 'GET', '/api/projects');
  if (d.mode !== 'web') throw new Error('По этому адресу не веб-версия UCMS');
  const cur = (d.projects || [])[0] || {};
  return { user: d.user || '', role: d.role || '', perms: d.perms || null, siteTitle: cur.siteTitle || cur.name || '', siteUrl: d.siteUrl || '', publishDir: d.publishDir || '', version: d.version || '' };
}
// Копия подключённого сайта на этом компьютере (с историей версий): раз в сутки при работе с сайтом
// и по кнопке. Хостинг откажет — сайт останется здесь, его можно загрузить в любую UCMS.
const REMOTE_COPIES_KEEP = 7;
function remoteCopiesDir(id) { return path.join(projects.HOME, 'remote', id, 'copies'); }
function lastRemoteCopy(id) {
  try {
    const d = remoteCopiesDir(id);
    const f = fs.readdirSync(d).filter(x => /\.zip$/.test(x)).sort().pop();
    return f ? { name: f, at: fs.statSync(path.join(d, f)).mtimeMs, size: fs.statSync(path.join(d, f)).size } : null;
  } catch (e) { return null; }
}
const remoteCopyJobs = new Map();   // id → Promise (одна загрузка на сайт)
function remoteCopy(p, token, force) {
  if (remoteCopyJobs.has(p.id)) return remoteCopyJobs.get(p.id);
  const last = lastRemoteCopy(p.id);
  if (!force && last && Date.now() - last.at < 20 * 3600e3) return Promise.resolve(last);
  const dir = remoteCopiesDir(p.id);
  fs.mkdirSync(dir, { recursive: true });
  const name = `site-${stamp()}.zip`, tmp = path.join(dir, name + '.part');
  const job = new Promise((resolve, reject) => {
    const u = new URL(p.url + '/api/export?type=site&history=1'), mod = u.protocol === 'https:' ? https : http;
    const rq = mod.get(u, { headers: { Authorization: 'Bearer ' + token, 'User-Agent': 'UCMS/' + VERSION }, timeout: 300000 }, r => {
      if (r.statusCode !== 200) { r.resume(); return reject(new Error(r.statusCode === 401 ? 'ключ доступа не принят' : 'ответ ' + r.statusCode)); }
      const out = fs.createWriteStream(tmp);   // потоком на диск: архив с медиа может быть большим
      r.pipe(out);
      out.on('finish', () => {
        try {
          const fd = fs.openSync(tmp, 'r'), sig = Buffer.alloc(4); fs.readSync(fd, sig, 0, 4, 0); fs.closeSync(fd);
          if (sig.readUInt32LE(0) !== 0x04034b50) throw new Error('сервер прислал не архив');
          fs.renameSync(tmp, path.join(dir, name));
          const all = fs.readdirSync(dir).filter(x => /\.zip$/.test(x)).sort();
          all.slice(0, Math.max(0, all.length - REMOTE_COPIES_KEEP)).forEach(x => fs.rmSync(path.join(dir, x), { force: true }));
          resolve(lastRemoteCopy(p.id));
        } catch (e) { reject(e); }
      });
      out.on('error', reject); r.on('error', reject);
    });
    rq.on('timeout', () => rq.destroy(new Error('сервер не ответил')));
    rq.on('error', reject);
  }).catch(e => { fs.rmSync(tmp, { force: true }); throw new Error('Копия сайта не сохранена: ' + e.message); })
    .finally(() => remoteCopyJobs.delete(p.id));
  remoteCopyJobs.set(p.id, job);
  return job;
}
// Пока открыт подключённый сайт — раз в час проверяем, не пора ли сделать копию
const remoteCopyTimer = setInterval(() => {
  if (ACTIVE && ACTIVE.remote && !ACTIVE.remote.dead) remoteCopy({ id: ACTIVE.id, url: ACTIVE.remote.url }, ACTIVE.remote.token).catch(e => console.warn('[copy]', e.message));
}, 3600e3);
if (remoteCopyTimer.unref) remoteCopyTimer.unref();

async function useRemote(p) {
  const token = projects.getToken(p.id);
  if (!token) throw new Error('Нет ключа доступа к сайту — подключите его заново');
  const info = await remoteInfo(p.url, token);
  await _writeQueue;
  // локальные папки — только служебные (копии сайта), данные сайта здесь не хранятся
  CONTENT_DIR = path.join(projects.HOME, 'remote', p.id);
  DB_PATH = path.join(CONTENT_DIR, 'db.json'); THEMES_DIR = path.join(CONTENT_DIR, 'themes'); OUTPUT_DIR = path.join(CONTENT_DIR, 'output');
  UPLOADS_DIR = path.join(CONTENT_DIR, 'uploads'); BACKUPS_DIR = path.join(CONTENT_DIR, 'backups');
  fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  syncStatusCache = null;
  ACTIVE = { id: p.id, name: info.siteTitle || p.name, path: '', remote: { url: p.url, token, ...info } };
  projects.update(p.id, { openedAt: new Date().toISOString(), siteTitle: info.siteTitle, user: info.user, role: info.role });
  remoteCopy(p, token).catch(e => console.warn('[copy]', e.message));   // в фоне, открытие не ждёт
}
// Передать запрос админки на сервер сайта (потоком: загрузки и скачивания не копятся в памяти)
function proxyRemote(req, res) {
  const R = ACTIVE.remote;
  // ключ уже отвергнут: дальше не стучимся — иначе сервер сочтёт это подбором и закроет вход с этого адреса
  if (R.dead) { req.resume(); return sendJson(res, 502, { ok: false, code: 'REMOTE_AUTH', error: 'Сервер сайта не принял ключ доступа — возможно, его отозвали. Подключите сайт заново со списка проектов.' }); }
  const u = new URL(R.url + req.url), mod = u.protocol === 'https:' ? https : http;
  const h = { authorization: 'Bearer ' + R.token, 'user-agent': 'UCMS/' + VERSION };
  for (const k of ['content-type', 'content-length', 'accept', 'range', 'if-none-match', 'if-modified-since', 'x-ucms-base-rev', 'x-ucms-force']) if (req.headers[k]) h[k] = req.headers[k];
  const up = mod.request(u, { method: req.method, headers: h, timeout: 600000 }, ur => {
    if (ur.statusCode === 401) {   // не отдаём браузеру «войдите» — вход здесь не нужен, дело в ключе
      ur.resume(); R.dead = true;
      return sendJson(res, 502, { ok: false, code: 'REMOTE_AUTH', error: 'Сервер сайта не принял ключ доступа — возможно, его отозвали. Подключите сайт заново со списка проектов.' });
    }
    const oh = { ...ur.headers };
    delete oh['set-cookie']; delete oh['strict-transport-security']; delete oh.connection; delete oh['keep-alive'];
    res.writeHead(ur.statusCode, oh);
    ur.pipe(res);
  });
  up.on('timeout', () => up.destroy(new Error('сервер не ответил')));
  up.on('error', e => {
    if (!res.headersSent) sendJson(res, 502, { ok: false, code: 'REMOTE_DOWN', error: 'Сервер сайта недоступен: ' + (e.code || e.message) });
    else res.destroy();
  });
  res.on('close', () => { if (!res.writableFinished) up.destroy(); });   // браузер ушёл — не держим соединение
  req.pipe(up);
}

async function switchProject(id) {
  const p = projects.get(id);
  if (!p) throw new Error('Проект не найден');
  if (p.kind === 'remote') {
    if (WEB) throw new Error('Недоступно в веб-версии');
    if (publishJob.running) throw new Error('Идёт публикация — дождитесь окончания');
    return useRemote(p);
  }
  if (!projects.isProjectDir(p.path) && !projects.isEmptyDir(p.path)) throw new Error(`В папке нет db.json: ${p.path}`);
  if (publishJob.running) throw new Error('Идёт публикация — дождитесь окончания');
  await _writeQueue;   // старый проект дописан до конца
  useProject(p);
}
// Первый запуск 1.1: данные из <папка UCMS>/content становятся первым проектом.
function bootProjects() {
  if (WEB) {   // веб: один сайт — папка UCMS_SITE (по умолчанию <UCMS_HOME>/site)
    const dir = WEB_SITE_DIR;
    let name = 'Сайт';
    try { name = JSON.parse(fs.readFileSync(path.join(dir, 'db.json'), 'utf8')).settings.siteTitle || name; } catch (e) { /* новый сайт */ }
    useProject({ id: 'site', name, path: dir });
    return;
  }
  const reg = projects.load();
  if (!reg.projects.length && fs.existsSync(path.join(LEGACY_CONTENT, 'db.json'))) {
    let name = 'Мой сайт';
    try { name = JSON.parse(fs.readFileSync(path.join(LEGACY_CONTENT, 'db.json'), 'utf8')).settings.siteTitle || name; } catch (e) { /* ignore */ }
    projects.add(LEGACY_CONTENT, name);
  }
  const all = projects.load();
  const start = all.projects.find(p => p.id === all.last && projects.isProjectDir(p.path)) || all.projects.find(p => projects.isProjectDir(p.path));
  if (start) useProject(start);
}

// Копия проекта без собранного сайта, резервных копий и настроек публикации
function copyProjectDir(src, dst) {
  const SKIP = new Set(['output', 'backups', '.publish', 'publish.json']);
  fs.mkdirSync(dst, { recursive: true });
  for (const ent of fs.readdirSync(src, { withFileTypes: true })) {
    if (SKIP.has(ent.name) || /\.tmp$/.test(ent.name)) continue;
    fs.cpSync(path.join(src, ent.name), path.join(dst, ent.name), { recursive: true });
  }
}
function checkNewDir(dir) {
  if (!dir || !path.isAbsolute(dir)) throw new Error('Укажите полный путь к папке');
  if (!projects.isEmptyDir(dir)) throw new Error('Папка не пуста — выберите пустую или новую папку');
}
function projectsPayload() {
  if (WEB) {   // веб: «проект» один, пути на сервере не показываем
    let siteTitle = ACTIVE.name;
    try { siteTitle = readDB().settings.siteTitle || siteTitle; } catch (e) { /* ignore */ }
    return { ok: true, mode: 'web', projects: [{ id: 'site', name: siteTitle, siteTitle, path: '' }], active: 'site', version: VERSION,
      publishDir: PUBLISH_DIR, siteUrl: SITE_URL };
  }
  const l = projects.list();
  l.projects.forEach(p => { if (p.remote) p.copy = lastRemoteCopy(p.id); });
  const R = ACTIVE && ACTIVE.remote;
  return { ok: true, projects: l.projects, active: ACTIVE && ACTIVE.id, defaultRoot: projects.defaultRoot(), registry: projects.REG, version: VERSION,
    remote: R ? { url: R.url, user: R.user, role: R.role, perms: R.perms, siteUrl: R.siteUrl, publishDir: R.publishDir, version: R.version, copy: lastRemoteCopy(ACTIVE.id) } : null };
}

// Обзор папок для выбора места проекта (сервер слушает только этот компьютер)
function listDirs(dir) {
  const roots = process.platform === 'win32'
    ? 'CDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(l => `${l}:\\`).filter(d => { try { return fs.existsSync(d); } catch (e) { return false; } })
    : ['/'];
  const home = os.homedir();
  if (!dir) dir = home;
  let abs = path.resolve(dir);
  // Папки ещё нет (например, «Документы/UCMS Projects») — показываем ближайшую существующую
  while (!fs.existsSync(abs) && path.dirname(abs) !== abs) abs = path.dirname(abs);
  const dirs = fs.readdirSync(abs, { withFileTypes: true })
    .filter(e => { try { return e.isDirectory() && !/^[.$]/.test(e.name); } catch (er) { return false; } })
    .map(e => e.name).sort((a, b) => a.localeCompare(b));
  const parent = path.dirname(abs) === abs ? null : path.dirname(abs);
  return { path: abs, parent, dirs, roots, home, sep: path.sep, isProject: projects.isProjectDir(abs) };
}

// ────────────────────────────── Медиатека ──────────────────────────────
// Имя файла: кириллица → латиница, остальное лишнее → «_»
const TRANSLIT = { а:'a',б:'b',в:'v',г:'g',д:'d',е:'e',ё:'e',ж:'zh',з:'z',и:'i',й:'y',к:'k',л:'l',м:'m',н:'n',о:'o',п:'p',р:'r',с:'s',т:'t',у:'u',ф:'f',х:'h',ц:'ts',ч:'ch',ш:'sh',щ:'sch',ъ:'',ы:'y',ь:'',э:'e',ю:'yu',я:'ya',
  і:'i',ї:'yi',є:'ye',ґ:'g',ә:'a',ғ:'g',қ:'q',ң:'n',ө:'o',ұ:'u',ү:'u',һ:'h' };
function safeFileName(name) {
  const s = String(name || 'file').toLowerCase().replace(/[а-яёіїєґәғқңөұүһ]/g, c => TRANSLIT[c] || '');
  const clean = s.replace(/[^a-z0-9.\-_]+/g, '_').replace(/_+/g, '_').replace(/^[_.]+/, '');
  // точка — только перед расширением: «x.php.jpg» → «x-php.jpg» (на сервере не исполнится как PHP)
  const i = clean.lastIndexOf('.');
  const out = i > 0 ? clean.slice(0, i).replace(/\./g, '-') + clean.slice(i) : clean.replace(/\./g, '-');
  return out.slice(-80) || 'file';
}
// '/uploads/a/b.png' → абсолютный путь внутри uploads (или null)
function uploadAbs(p) {
  const rel = String(p || '').replace(/^\/+/, '');
  if (!rel.startsWith('uploads/')) return null;
  const abs = path.join(CONTENT_DIR, rel);
  return isInside(UPLOADS_DIR, abs) ? abs : null;
}
const VARIANT_RE = /-w(\d+)\.webp$/i;
// Уменьшенные копии файла: [{ w, abs }] по возрастанию ширины
function variantsOf(abs) {
  if (!/\.webp$/i.test(abs)) return [];
  const dir = path.dirname(abs), base = path.basename(abs).replace(/\.webp$/i, '');
  let names = [];
  try { names = fs.readdirSync(dir); } catch (e) { return []; }
  return names.filter(n => n.startsWith(base + '-w') && VARIANT_RE.test(n) && n.slice(base.length).match(/^-w\d+\.webp$/i))
    .map(n => ({ w: parseInt(n.match(VARIANT_RE)[1], 10), abs: path.join(dir, n) })).sort((x, y) => x.w - y.w);
}
function isVariantFile(abs) {
  const m = path.basename(abs).match(/^(.*)-w\d+\.webp$/i);
  return !!m && fs.existsSync(path.join(path.dirname(abs), `${m[1]}.webp`));
}
// Папки и теги медиатеки — uploads/.media.json:
// { folders: [{ id, name }], files: { '/uploads/…': { folder, tags: [] } } }.
// Файлы на диске не перемещаются: папка — только метка, ссылки на сайте не меняются.
// Чтение-изменение-запись .media.json — строго по очереди (иначе быстрые действия подряд теряют изменения)
let _metaQueue = Promise.resolve();
function withMediaMeta(fn) {
  const run = _metaQueue.then(async () => { const meta = readMediaMeta(); const out = await fn(meta); await writeMediaMeta(meta); return out; });
  _metaQueue = run.catch(() => {});
  return run;
}
function mediaMetaPath() { return path.join(UPLOADS_DIR, '.media.json'); }
function readMediaMeta() {
  try {
    const m = JSON.parse(fs.readFileSync(mediaMetaPath(), 'utf8'));
    return { folders: Array.isArray(m.folders) ? m.folders : [], files: m.files && typeof m.files === 'object' ? m.files : {} };
  } catch (e) { return { folders: [], files: {} }; }
}
async function writeMediaMeta(meta) {
  // убираем пустые записи, чтобы файл не рос
  for (const k of Object.keys(meta.files)) {
    const f = meta.files[k];
    if (!f || (!f.folder && !(f.tags && f.tags.length))) delete meta.files[k];
  }
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  await writeFileAtomic(mediaMetaPath(), JSON.stringify(meta, null, 1));
}
function cleanTag(t) { return String(t || '').trim().replace(/\s+/g, ' ').slice(0, 40); }
function cleanFolderName(t) { return String(t || '').trim().replace(/\s+/g, ' ').slice(0, 60); }

function removeMediaFile(abs) {
  variantsOf(abs).forEach(v => fs.rmSync(v.abs, { force: true }));
  fs.rmSync(abs, { force: true });
}
function mediaSettings(db) {
  const m = (db.settings && db.settings.media) || {};
  return { optimize: m.optimize !== false, maxWidth: parseInt(m.maxWidth, 10) || 2400, quality: parseInt(m.quality, 10) || 82 };
}
// Все файлы uploads (без уменьшенных копий) + сколько раз каждый упомянут в db.json
function listMedia() {
  const dbText = JSON.stringify(readDB());
  const meta = readMediaMeta(), folderIds = new Set(meta.folders.map(f => f.id));
  const out = [];
  (function walk(dir) {
    if (!fs.existsSync(dir)) return;
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      const abs = path.join(dir, ent.name);
      if (ent.isDirectory()) { walk(abs); continue; }
      if (ent.name.startsWith('.') || isVariantFile(abs)) continue;
      const rel = path.relative(CONTENT_DIR, abs).split(path.sep).join('/');
      const st = fs.statSync(abs), vars = variantsOf(abs), dim = imageSize(abs);
      const m = meta.files['/' + rel] || {};
      out.push({
        path: '/' + rel, name: ent.name.replace(/^\d{10,}-/, ''), dir: rel.split('/')[1] || '',
        folder: m.folder && folderIds.has(m.folder) ? m.folder : '', tags: Array.isArray(m.tags) ? m.tags : [],
        size: st.size, total: st.size + vars.reduce((a, v) => a + fs.statSync(v.abs).size, 0),
        width: dim ? dim.w : null, height: dim ? dim.h : null, variants: vars.map(v => v.w),
        thumb: vars.length ? '/' + path.relative(CONTENT_DIR, vars[0].abs).split(path.sep).join('/') : '/' + rel,
        used: dbText.split(rel).length - 1, mtime: st.mtimeMs,
      });
    }
  })(UPLOADS_DIR);
  return out.sort((a, b) => b.mtime - a.mtime);
}
// Для генератора: srcset/sizes/width/height картинки из uploads
function imgAttrs(src, basePrefix, sizes) {
  const abs = uploadAbs(src);
  if (!abs) return '';
  const dim = imageSize(abs), vars = variantsOf(abs);
  let out = dim ? ` width="${dim.w}" height="${dim.h}"` : '';
  if (vars.length) {
    const list = vars.filter(v => !dim || v.w < dim.w)
      .map(v => `${srcPath('/' + path.relative(CONTENT_DIR, v.abs).split(path.sep).join('/'), basePrefix)} ${v.w}w`);
    if (dim) list.push(`${srcPath(src, basePrefix)} ${dim.w}w`);
    if (list.length > 1) out += ` srcset="${escHtml(list.join(', '))}" sizes="${escHtml(sizes || '100vw')}"`;
  }
  return out;
}

// ────────────────────────────── Обновление движка (lib/update.js) ──────────────────────────────
// Перед заменой файлов: дописать сохранения, не во время публикации, версия открытого проекта — в «Историю».
const updater = createUpdater({
  root: PROJECT_ROOT, version: VERSION, home: projects.HOME,
  onBeforeInstall: async (to, kind) => {
    if (publishJob.running) throw new Error('Идёт публикация — дождитесь окончания');
    await _writeQueue;
    if (HISTORY && !(ACTIVE && ACTIVE.remote)) { try { HISTORY.snapshot('manual', `${kind === 'rollback' ? 'Перед возвратом' : 'Перед обновлением'} UCMS ${VERSION} → ${to}`); } catch (e) { console.warn('[history]', e.message); } }
    if (WEB) { try { makeBackup('before-update'); } catch (e) { console.warn('[backup]', e.message); } }   // веб: полная копия сайта перед обновлением
  },
});
// ────────────────────────────── Веб-версия: вход и защита ──────────────────────────────
const SID = 'ucms_sid';
// Веб: картинки, видео, шрифты и документы для ссылок «Файл». Скриптов и HTML нет.
const UPLOAD_EXT = /\.(jpe?g|png|gif|webp|avif|svg|ico|bmp|mp4|webm|mov|pdf|woff2?|ttf|otf|docx?|xlsx?|pptx?|odt|ods|odp|rtf|txt|csv|zip|rar|7z)$/i;
// Закрыто в веб-версии: проекты и папки сервера, внешний редактор, ИИ-перевод (ключ API), FTP и проект на FTP
const WEB_BLOCKED = /^\/api\/(projects\/|fs\/|open-external|translate|publish\/|sync\/|remote\/)/;
// Только владелец: обновление движка, пользователи, замена всего сайта архивом, удаление версий истории
const OWNER_ONLY = /^\/api\/(update|users|modules\/(install|install-from|remove))(\/|$)/;
// Остальное — по правам пользователя (владельцу можно всё). Правки самих данных (/api/data) —
// по разделам, см. guardData. [адрес, право, только изменения (не GET)]
const PERM_ROUTES = [
  [/^\/api\/(upload|media\/)/, 'media', true],
  [/^\/api\/theme-/, 'design', true],
  [/^\/api\/generate$/, 'publish', true],
  [/^\/api\/history\/(restore|delete)$/, 'history', true],
  [/^\/api\/(export|import|backups)(\/|$)/, 'transfer', false],
];
// Можно ли пользователю запроса это действие (локальная версия — без пользователей, можно всё)
function can(req, perm) { const u = req.ucmsUser; return !WEB || !u || u.role === 'owner' || (u.perms || []).includes(perm); }
function accessDenied(req, res, p) {
  const u = req.ucmsUser;
  if (u.role === 'owner') return false;
  if (OWNER_ONLY.test(p) && !(req.method === 'GET' && p === '/api/update')) { sendJson(res, 403, { ok: false, code: 'ROLE', error: 'Доступно только владельцу сайта' }); return true; }
  for (const [re, perm, writeOnly] of PERM_ROUTES) {
    if (re.test(p) && (!writeOnly || req.method !== 'GET') && !can(req, perm)) { sendJson(res, 403, { ok: false, code: 'PERM', perm, error: 'Нет доступа: ' + PERM_NAMES[perm] }); return true; }
  }
  return false;
}
const PERM_NAMES = { content: 'страницы и записи', layout: 'шапка и подвал', design: 'оформление', settings: 'настройки сайта',
  media: 'медиафайлы', publish: 'публикация', history: 'восстановление версий', transfer: 'перенос и резервные копии', keys: 'ключи доступа' };
// Сохранение данных: разделы, на которые нет прав, остаются как были на сервере (правки в них не принимаются).
// Не отказ целиком — админка присылает весь db.json, а мелкие служебные поля могут отличаться.
const DATA_AREAS = { header: 'layout', footer: 'layout', css: 'design', fontFamily: 'design', fontImportUrl: 'design', theme: 'design', brand: 'design',
  collections: 'content', sectionTemplates: 'content', media: 'media', migrated: null, knownModules: null, translation: null };
function guardData(req, db) {
  if (can(req, 'content') && can(req, 'layout') && can(req, 'design') && can(req, 'settings') && can(req, 'media')) return [];
  const cur = readDB(), kept = new Set();
  if (!can(req, 'content')) { db.pages = cur.pages; kept.add('content'); }
  db.settings = db.settings || {};
  for (const k of new Set([...Object.keys(db.settings), ...Object.keys(cur.settings)])) {
    const area = k in DATA_AREAS ? DATA_AREAS[k] : 'settings';
    if (!area || can(req, area)) continue;
    if (JSON.stringify(db.settings[k]) === JSON.stringify(cur.settings[k])) continue;
    if (k in cur.settings) db.settings[k] = cur.settings[k]; else delete db.settings[k];
    kept.add(area);
  }
  return [...kept];
}

function cookieOf(req, name) {
  const m = new RegExp(`(?:^|;\\s*)${name}=([^;]*)`).exec(req.headers.cookie || '');
  return m ? decodeURIComponent(m[1]) : '';
}
// Адрес посетителя (для паузы после неверных паролей). За прокси — X-Real-IP или ПОСЛЕДНИЙ адрес
// X-Forwarded-For: его дописал наш прокси; первые элементы присылает сам клиент и может подделать.
function clientIp(req) {
  if (TRUST_PROXY) {
    if (req.headers['x-real-ip']) return String(req.headers['x-real-ip']).trim();
    if (req.headers['x-forwarded-for']) return String(req.headers['x-forwarded-for']).split(',').pop().trim();
  }
  return req.socket.remoteAddress || '';
}
function isHttps(req) { return process.env.UCMS_SECURE === '1' || (TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https'); }
function sidCookie(req, token, maxAge) {
  return `${SID}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${isHttps(req) ? '; Secure' : ''}`;
}
// Запрос изменяет данные — он должен прийти со страницы этого же сайта (защита от CSRF)
function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return req.headers['sec-fetch-site'] !== 'cross-site';
  // сравниваем имя хоста без порта: прокси (nginx на нестандартном порту) может передать адрес без него
  const host = String((TRUST_PROXY && req.headers['x-forwarded-host']) || req.headers.host || '').split(',')[0].trim();
  try { return new URL(origin).hostname === new URL(`http://${host}`).hostname; } catch (e) { return false; }
}

// Мастер установки: запрос должен нести код установки (заголовок X-UCMS-Setup). Подбор — как у пароля.
function setupGuard(req, res) {
  const ip = clientIp(req), wait = auth.blocked(ip);
  if (wait) { sendJson(res, 429, { ok: false, code: 'LOCKED', minutes: wait, error: `Слишком много попыток. Попробуйте через ${wait} мин.` }); return false; }
  if (!setup.codeOk(req.headers['x-ucms-setup'])) { auth.failed(ip); sendJson(res, 403, { ok: false, code: 'CODE', error: 'Неверный код установки' }); return false; }
  auth.succeeded(ip);
  return true;
}

// Пропускает запрос дальше (true) или отвечает сам (false)
function webGate(req, res, p) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  const adminArea = p.startsWith('/admin') || p.startsWith('/api/') || p.startsWith('/preview') || p.startsWith('/output');
  if (adminArea) { res.setHeader('X-Frame-Options', 'SAMEORIGIN'); res.setHeader('Referrer-Policy', 'same-origin'); }
  // Ключ доступа (локальная UCMS, подключённая к сайту): без cookie — подделка запроса с чужой страницы
  // невозможна, поэтому проверка «свой сайт» не нужна. Неверный ключ считается как неверный пароль.
  const bearer = /^Bearer\s+(\S+)$/i.exec(req.headers.authorization || '');
  if (bearer) {
    if (!p.startsWith('/api/') && !p.startsWith('/preview') && !p.startsWith('/output') && !p.startsWith('/uploads/')) { send(res, 404, 'Not found'); return false; }
    if (needSetup()) { sendJson(res, 503, { ok: false, code: 'SETUP', error: 'UCMS ещё не установлена' }); return false; }
    const ip = clientIp(req), wait = auth.blocked(ip);
    if (wait) { sendJson(res, 429, { ok: false, code: 'LOCKED', minutes: wait, error: `Слишком много попыток. Попробуйте через ${wait} мин.` }); return false; }
    const k = auth.byKey(bearer[1], ev => auth.journal({ ...ev, ip }));
    if (!k) { auth.failed(ip); auth.journal({ ev: 'key-fail', ip }); sendJson(res, 401, { ok: false, code: 'KEY', error: 'Ключ доступа не действует' }); return false; }
    // ключом нельзя выпускать ключи и менять пароль — только из браузера со входом по паролю
    if (p.startsWith('/api/auth/') || p.startsWith('/api/setup/')) { sendJson(res, 403, { ok: false, error: 'Недоступно по ключу доступа' }); return false; }
    if (WEB_BLOCKED.test(p)) { sendJson(res, 404, { ok: false, error: 'Недоступно в веб-версии' }); return false; }
    req.ucmsUser = { user: k.user, role: k.role, perms: k.perms, key: k.key };
    if (!can(req, 'keys')) { sendJson(res, 403, { ok: false, code: 'PERM', perm: 'keys', error: 'Нет доступа: ключи доступа' }); return false; }
    return !accessDenied(req, res, p);
  }
  if (!/^(GET|HEAD|OPTIONS)$/.test(req.method) && !sameOrigin(req)) { sendJson(res, 403, { ok: false, error: 'Запрос с чужого сайта отклонён' }); return false; }
  if (p === '/admin/projects.html') { send(res, 302, '', { Location: '/admin/' }); return false; }
  if (needSetup()) {   // мастер установки: открыт только он и его оформление
    if (p === '/api/ping' || p === '/api/auth/state' || p.startsWith('/api/setup/')) return true;
    if (p === '/admin/setup.html' || /^\/admin\/(admin\.css|ucms\.ico|apple-touch-icon\.png|i18n\/[a-z]+\.js)$/.test(p)) return true;
    if (p.startsWith('/api/')) { sendJson(res, 503, { ok: false, code: 'SETUP', error: 'UCMS ещё не установлена' }); return false; }
    send(res, 302, '', { Location: '/admin/setup.html' }); return false;
  }
  if (p === '/admin/setup.html') { send(res, 302, '', { Location: '/admin/' }); return false; }
  if (p.startsWith('/api/setup/')) { sendJson(res, 404, { ok: false, error: 'Установка уже завершена' }); return false; }
  if (p === '/api/ping' || p.startsWith('/api/auth/')) return true;
  if (WEB_BLOCKED.test(p)) { sendJson(res, 404, { ok: false, error: 'Недоступно в веб-версии' }); return false; }
  const needLogin = p.startsWith('/api/') || p.startsWith('/preview') || p.startsWith('/output') || p === '/admin' || p === '/admin/' || p === '/admin/index.html';
  if (!needLogin) return true;
  const s = auth.session(cookieOf(req, SID));
  if (s) {
    req.ucmsUser = s;
    return !accessDenied(req, res, p);
  }
  if (p.startsWith('/api/')) { sendJson(res, 401, { ok: false, code: 'AUTH', error: 'Нужно войти' }); return false; }
  send(res, 302, '', { Location: '/admin/login.html?next=' + encodeURIComponent(req.url) });
  return false;
}

// Опубликованный сайт (папка output) — с корня адреса. До первой публикации — заглушка.
// Если сайт публикуется в отдельную папку (UCMS_PUBLISH_DIR), его отдаёт веб-сервер хостинга,
// а адрес админки ведёт в админку.
function serveSite(res, p) {
  if (PUBLISH_DIR) return p === '/' ? send(res, 302, '', { Location: '/admin/' }) : send(res, 404, 'Not found');
  if (!fs.existsSync(path.join(OUTPUT_DIR, 'index.html'))) {
    return send(res, p === '/' ? 200 : 404, '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Сайт скоро появится</title></head>' +
      '<body style="margin:0;min-height:100vh;display:grid;place-items:center;font:16px/1.5 system-ui,sans-serif;color:#555;background:#f6f6f4"><div style="text-align:center;padding:24px">' +
      '<div style="font-size:22px;font-weight:600;color:#222;margin-bottom:6px">Сайт ещё не опубликован</div>Откройте <a href="/admin/">админку</a> и нажмите «Опубликовать».</div></body></html>',
    { 'Content-Type': 'text/html;charset=utf-8', 'Cache-Control': 'no-cache' });
  }
  return serveFile(res, OUTPUT_DIR, p);
}

// ────────────────────────────── API ──────────────────────────────
const routes = {
  'GET /api/data': async (req, res) => {
    const db = readDB();
    if (WEB && db.settings.translation) db.settings.translation.apiKey = '';   // ключи в браузер не отдаём
    sendJson(res, 200, db);
  },
  'GET /api/ping': async (req, res) => sendJson(res, 200, { ok: true, app: 'ucms', version: VERSION, mode: WEB ? 'web' : 'local' }),

  /* ── Вход (веб-версия) ── */
  'GET /api/auth/state': async (req, res) => {
    const s = WEB ? auth.session(cookieOf(req, SID)) : null;
    sendJson(res, 200, { ok: true, mode: WEB ? 'web' : 'local', configured: WEB ? auth.configured() : true, setup: needSetup(), user: s ? s.user : null, role: s ? s.role : null });
  },
  'POST /api/auth/login': async (req, res) => {
    if (!WEB) return sendJson(res, 404, { ok: false, error: 'Вход нужен только в веб-версии' });
    const ip = clientIp(req), wait = auth.blocked(ip);
    if (wait) return sendJson(res, 429, { ok: false, code: 'LOCKED', minutes: wait, error: `Слишком много попыток. Попробуйте через ${wait} мин.` });
    if (!auth.configured()) return sendJson(res, 503, { ok: false, code: 'NO_PASSWORD', error: 'Пароль не задан' });
    const { user, password } = await readJson(req, 4096);
    const who = await auth.check(user, password);
    if (!who) { auth.failed(ip); auth.journal({ ev: 'login-fail', user: String(user || '').slice(0, 40), ip }); return sendJson(res, 401, { ok: false, code: 'BAD', error: 'Неверный логин или пароль' }); }
    auth.succeeded(ip);
    auth.journal({ ev: 'login', user: who, ip });
    const token = auth.login(who);
    send(res, 200, JSON.stringify({ ok: true, user: who }), { ...JSON_HDR, 'Set-Cookie': sidCookie(req, token, 60 * 86400) });
  },
  // Смена пароля из админки (без SSH): текущий пароль + новый. Все прочие входы сбрасываются.
  'POST /api/auth/password': async (req, res) => {
    if (!WEB) return sendJson(res, 404, { ok: false, error: 'Только в веб-версии' });
    const s = auth.session(cookieOf(req, SID));
    if (!s) return sendJson(res, 401, { ok: false, code: 'AUTH', error: 'Нужно войти' });
    const ip = clientIp(req), wait = auth.blocked(ip);
    if (wait) return sendJson(res, 429, { ok: false, error: `Слишком много попыток. Попробуйте через ${wait} мин.` });
    const { current, next } = await readJson(req, 4096);
    if (!(await auth.check(s.user, current))) { auth.failed(ip); return sendJson(res, 400, { ok: false, error: 'Текущий пароль неверный' }); }
    try { await auth.setPassword(s.user, next); } catch (e) { return sendJson(res, 400, { ok: false, error: e.message }); }
    auth.succeeded(ip);
    auth.journal({ ev: 'password', user: s.user, ip });
    send(res, 200, JSON.stringify({ ok: true }), { ...JSON_HDR, 'Set-Cookie': sidCookie(req, auth.login(s.user), 60 * 86400) });
  },
  // Ключи доступа своей учётной записи (только со входом по паролю — ключом ключ не выпустить)
  'GET /api/auth/keys': async (req, res) => {
    const s = WEB && auth.session(cookieOf(req, SID));
    if (!s) return sendJson(res, 401, { ok: false, code: 'AUTH', error: 'Нужно войти' });
    sendJson(res, 200, { ok: true, keys: auth.listKeys(s.user) });
  },
  'POST /api/auth/keys/create': async (req, res) => {
    const s = WEB && auth.session(cookieOf(req, SID));
    if (!s) return sendJson(res, 401, { ok: false, code: 'AUTH', error: 'Нужно войти' });
    const ip = clientIp(req), wait = auth.blocked(ip);
    if (wait) return sendJson(res, 429, { ok: false, error: `Слишком много попыток. Попробуйте через ${wait} мин.` });
    if (s.role !== 'owner' && !(s.perms || []).includes('keys')) return sendJson(res, 403, { ok: false, code: 'PERM', error: 'Нет доступа: ключи доступа' });
    const { name, password } = await readJson(req, 4096);
    // ключ живёт долго — выпускаем только после пароля, даже если вход уже выполнен
    if (!(await auth.check(s.user, password))) { auth.failed(ip); return sendJson(res, 400, { ok: false, error: 'Неверный пароль' }); }
    auth.succeeded(ip);
    const k = auth.createKey(s.user, name);
    auth.journal({ ev: 'key-create', user: s.user, key: String(name || '').slice(0, 60), ip });
    sendJson(res, 200, { ok: true, token: k.token, keys: auth.listKeys(s.user) });
  },
  'POST /api/auth/keys/revoke': async (req, res) => {
    const s = WEB && auth.session(cookieOf(req, SID));
    if (!s) return sendJson(res, 401, { ok: false, code: 'AUTH', error: 'Нужно войти' });
    const { id } = await readJson(req, 4096);
    const k = auth.listKeys(s.user).find(x => x.id === id);
    auth.revokeKey(s.user, id);
    auth.journal({ ev: 'key-revoke', user: s.user, key: k ? k.name : id, ip: clientIp(req) });
    sendJson(res, 200, { ok: true, keys: auth.listKeys(s.user) });
  },
  'POST /api/auth/logout': async (req, res) => {
    if (WEB) { const s = auth.session(cookieOf(req, SID)); if (s) auth.journal({ ev: 'logout', user: s.user, ip: clientIp(req) }); auth.logout(cookieOf(req, SID)); }
    send(res, 200, JSON.stringify({ ok: true }), { ...JSON_HDR, 'Set-Cookie': sidCookie(req, '', 0) });
  },

  /* ── Мастер установки (веб, пока нет пользователей; webGate закрывает эти адреса после установки) ── */
  'GET /api/setup/state': async (req, res) => {
    const file = setup.ensureCode();
    sendJson(res, 200, { ok: true, setup: needSetup(), version: VERSION,
      codeFile: path.relative(path.dirname(PROJECT_ROOT), file).split(path.sep).join('/') });
  },
  'POST /api/setup/code': async (req, res) => { if (setupGuard(req, res)) sendJson(res, 200, { ok: true }); },
  'GET /api/setup/check': async (req, res) => {
    if (!setupGuard(req, res)) return;
    sendJson(res, 200, { ok: true, items: await setup.check(req, { trustProxy: TRUST_PROXY }), uploadMb: UPLOAD_MB });
  },
  'GET /api/setup/pid': async (req, res) => { if (setupGuard(req, res)) send(res, 200, JSON.stringify({ pid: process.pid }), { ...JSON_HDR, 'Cache-Control': 'no-store' }); },
  // Тест загрузки: тело не копим в памяти, только считаем байты
  'POST /api/setup/upload-test': async (req, res) => {
    if (!setupGuard(req, res)) return req.resume();
    let n = 0;
    await new Promise((resolve, reject) => {
      req.on('data', d => { n += d.length; if (n > 120 * 1048576) { req.destroy(); reject(new Error('Too large')); } });
      req.on('end', resolve); req.on('error', reject);
    });
    sendJson(res, 200, { ok: true, bytes: n });
  },
  'GET /api/setup/slow': async (req, res) => {
    if (!setupGuard(req, res)) return;
    const s = Math.min(120, Math.max(1, parseInt(new URL(req.url, 'http://x').searchParams.get('s'), 10) || 10));
    const t = setTimeout(() => sendJson(res, 200, { ok: true, s }), s * 1000);
    res.on('close', () => clearTimeout(t));   // браузер ушёл — таймер не держим
  },
  'GET /api/setup/dirs': async (req, res) => {
    if (!setupGuard(req, res)) return;
    sendJson(res, 200, { ok: true, dirs: setup.domainDirs(), siteDir: WEB_SITE_DIR, dataDir: projects.HOME,
      envPublishDir: process.env.UCMS_PUBLISH_DIR !== undefined ? PUBLISH_DIR : null,
      envSiteUrl: process.env.UCMS_SITE_URL !== undefined ? SITE_URL : null });
  },
  'POST /api/setup/dir': async (req, res) => {
    if (!setupGuard(req, res)) return;
    const { dir } = await readJson(req, 4096);
    try { const abs = setup.validatePublishDir(String(dir || '').trim()); sendJson(res, 200, { ok: true, info: setup.describeDir(abs) }); }
    catch (e) { sendJson(res, 200, { ok: false, error: e.message }); }
  },
  'POST /api/setup/finish': async (req, res) => {
    if (!setupGuard(req, res)) return;
    if (!needSetup()) return sendJson(res, 409, { ok: false, error: 'Установка уже завершена' });
    const b = await readJson(req, 16384);
    const user = String(b.user || '').trim();
    const siteUrl = String(b.siteUrl || '').trim().replace(/\/+$/, '');
    if (siteUrl && !/^https?:\/\/[^\s/?#]+(\/[^\s?#]*)?$/i.test(siteUrl)) return sendJson(res, 400, { ok: false, field: 'siteUrl', error: 'Адрес сайта: начните с https://' });
    let dir = '';
    try { dir = setup.validatePublishDir(String(b.publishDir || '').trim()); }
    catch (e) { return sendJson(res, 400, { ok: false, field: 'publishDir', error: e.message }); }
    const LANGS = { ru: 'Русский', en: 'English', kk: 'Қазақша' };
    const lang = LANGS[b.lang] ? b.lang : '';
    try { await auth.setPassword(user, String(b.password || '')); }
    catch (e) { return sendJson(res, 400, { ok: false, field: 'user', error: e.message }); }
    setup.writeConfig({ publishDir: dir, siteUrl, installedAt: new Date().toISOString(), version: VERSION });
    loadWebConfig();
    const db = readDB();
    const title = String(b.siteTitle || '').trim().slice(0, 120);
    if (title) { db.settings.siteTitle = title; ACTIVE.name = title; }
    // язык меняем только у нового сайта с одним языком — перенесённый сайт не трогаем
    if (lang && db.settings.languages.length === 1) db.settings.languages = [{ code: lang, label: LANGS[lang], isDefault: true }];
    await writeDB(db);
    setup.dropCode();
    _installed = true;
    auth.journal({ ev: 'setup', user, ip: clientIp(req) });
    console.log(`  Установка завершена: владелец «${user}»${dir ? `, публикация в ${dir}` : ''}.`);
    send(res, 200, JSON.stringify({ ok: true, user, publishDir: dir, siteUrl: SITE_URL }), { ...JSON_HDR, 'Set-Cookie': sidCookie(req, auth.login(user), 60 * 86400) });
  },

  'GET /api/projects': async (req, res) => {
    const pl = projectsPayload();
    if (WEB && req.ucmsUser) { pl.user = req.ucmsUser.user; pl.role = req.ucmsUser.role; pl.perms = req.ucmsUser.perms; pl.allPerms = auth.PERMS; }
    sendJson(res, 200, pl);
  },

  /* ── Пользователи (веб, только владелец — OWNER_ONLY в webGate) ── */
  'GET /api/users': async (req, res) => sendJson(res, 200, { ok: true, users: auth.listUsers(), me: req.ucmsUser.user, journal: auth.readJournal(100) }),
  'POST /api/users/add': async (req, res) => {
    const { user, password, owner, perms } = await readJson(req, 4096);
    const name = await auth.addUser(user, password, { owner: !!owner, perms });
    auth.journal({ ev: 'user-add', user: name, by: req.ucmsUser.user, role: owner ? 'owner' : 'user', ip: clientIp(req) });
    sendJson(res, 200, { ok: true, users: auth.listUsers() });
  },
  // Доступ пользователя: владелец (всё) или набор прав
  'POST /api/users/access': async (req, res) => {
    const { user, owner, perms } = await readJson(req, 4096);
    if (String(user || '').toLowerCase() === req.ucmsUser.user.toLowerCase() && owner === false) throw new Error('Свои права владельца снять нельзя — это может сделать другой владелец');
    auth.updateUser(user, { owner: owner === undefined ? undefined : !!owner, perms });
    auth.journal({ ev: 'user-access', user, by: req.ucmsUser.user, role: owner ? 'owner' : undefined, ip: clientIp(req) });
    sendJson(res, 200, { ok: true, users: auth.listUsers() });
  },
  'POST /api/users/password': async (req, res) => {
    const { user, password } = await readJson(req, 4096);
    await auth.resetUserPassword(user, password);
    auth.journal({ ev: 'user-password', user, by: req.ucmsUser.user, ip: clientIp(req) });
    sendJson(res, 200, { ok: true });
  },
  'POST /api/users/remove': async (req, res) => {
    const { user } = await readJson(req, 4096);
    if (String(user || '').toLowerCase() === req.ucmsUser.user.toLowerCase()) throw new Error('Нельзя удалить самого себя');
    auth.removeUser(user);
    auth.journal({ ev: 'user-remove', user, by: req.ucmsUser.user, ip: clientIp(req) });
    sendJson(res, 200, { ok: true, users: auth.listUsers() });
  },

  /* ── Обновление движка ── */
  'GET /api/update': async (req, res) => sendJson(res, 200, updater.status()),
  'POST /api/update/check': async (req, res) => sendJson(res, 200, await updater.check()),
  'POST /api/update/settings': async (req, res) => sendJson(res, 200, updater.settings(await readJson(req))),
  'POST /api/update/apply': async (req, res) => {
    const r = await updater.apply();
    sendJson(res, 200, { ...r, restarting: updater.restart(server) });
  },
  'POST /api/update/rollback': async (req, res) => {
    const r = await updater.rollback((await readJson(req)).id);
    sendJson(res, 200, { ...r, restarting: updater.restart(server) });
  },
  'POST /api/projects/open': async (req, res) => { await switchProject((await readJson(req)).id); sendJson(res, 200, projectsPayload()); },
  // Подключить сайт веб-UCMS по адресу и ключу доступа (или сменить ключ у уже подключённого)
  'POST /api/projects/connect': async (req, res) => {
    const b = await readJson(req, 8192);
    const url = normRemoteUrl(b.url), token = String(b.token || '').trim();
    if (!/^ucms_[0-9a-f]{8}_[A-Za-z0-9_-]{20,64}$/.test(token)) throw new Error('Ключ доступа выглядит иначе: ucms_…  Скопируйте его целиком из веб-админки');
    const info = await remoteInfo(url, token);
    const p = projects.addRemote(url, token, { siteTitle: info.siteTitle, user: info.user, role: info.role });
    if (ACTIVE && ACTIVE.id === p.id) ACTIVE.remote = { ...ACTIVE.remote, token, ...info, dead: false };
    sendJson(res, 200, { ...projectsPayload(), connected: p.id });
  },
  'POST /api/projects/create': async (req, res) => {
    const { name, path: dir } = await readJson(req);
    const title = String(name || '').trim() || 'Новый сайт';
    checkNewDir(dir);
    if (publishJob.running) throw new Error('Идёт публикация — дождитесь окончания');
    await _writeQueue;
    const p = projects.add(dir, title);
    useProject(p);
    const db = readDB(); db.settings.siteTitle = title; await writeDB(db);
    sendJson(res, 200, projectsPayload());
  },
  'POST /api/projects/add': async (req, res) => {
    const { path: dir } = await readJson(req);
    if (!dir || !projects.isProjectDir(dir)) throw new Error('В этой папке нет проекта UCMS (нет db.json)');
    let name = path.basename(dir);
    try { name = JSON.parse(fs.readFileSync(path.join(dir, 'db.json'), 'utf8')).settings.siteTitle || name; } catch (e) { /* ignore */ }
    projects.add(dir, name);
    sendJson(res, 200, projectsPayload());
  },
  'POST /api/projects/duplicate': async (req, res) => {
    const { id, path: dir, name } = await readJson(req);
    const src = projects.get(id); if (!src) throw new Error('Проект не найден');
    if (src.kind === 'remote') throw new Error('Подключённый сайт копируется через «Перенос»: скачайте архив и загрузите в новый проект');
    checkNewDir(dir);
    if (ACTIVE && ACTIVE.id === id) await _writeQueue;
    copyProjectDir(src.path, dir);
    const title = String(name || '').trim();
    if (title) { const fp = path.join(dir, 'db.json'); const db = JSON.parse(fs.readFileSync(fp, 'utf8')); db.settings.siteTitle = title; fs.writeFileSync(fp, JSON.stringify(db, null, 2)); }
    projects.add(dir, title || `${src.name} (копия)`);
    sendJson(res, 200, projectsPayload());
  },
  'POST /api/projects/relocate': async (req, res) => {
    const { id, path: dir } = await readJson(req);
    if (!projects.isProjectDir(dir)) throw new Error('В этой папке нет проекта UCMS (нет db.json)');
    projects.update(id, { path: path.resolve(dir) });
    if (ACTIVE && ACTIVE.id === id) useProject(projects.get(id));
    sendJson(res, 200, projectsPayload());
  },
  'POST /api/projects/remove': async (req, res) => {   // только из списка, файлы остаются
    const { id } = await readJson(req);
    if (ACTIVE && ACTIVE.id === id) { await _writeQueue; ACTIVE = null; }
    projects.remove(id);
    sendJson(res, 200, projectsPayload());
  },
  // Копия подключённого сайта на компьютер — сейчас
  'POST /api/projects/remote-copy': async (req, res) => {
    const p = projects.get((await readJson(req)).id);
    if (!p || p.kind !== 'remote') throw new Error('Проект не найден');
    const token = projects.getToken(p.id);
    if (!token) throw new Error('Нет ключа доступа к сайту — подключите его заново');
    sendJson(res, 200, { ok: true, copy: await remoteCopy(p, token, true), dir: remoteCopiesDir(p.id) });
  },
  'POST /api/projects/reveal': async (req, res) => {
    const p = projects.get((await readJson(req)).id);
    if (p && p.kind === 'remote') { const d = remoteCopiesDir(p.id); fs.mkdirSync(d, { recursive: true }); openPath(d); return sendJson(res, 200, { ok: true }); }
    if (p && fs.existsSync(p.path)) openPath(p.path);
    sendJson(res, 200, { ok: true });
  },
  'GET /api/fs/dirs': async (req, res) => {
    const dir = new URL(req.url, 'http://x').searchParams.get('path') || '';
    try { sendJson(res, 200, { ok: true, ...listDirs(dir) }); }
    catch (e) { sendJson(res, 400, { ok: false, error: `Не удалось открыть папку: ${e.message}` }); }
  },

  // Экспорт: ?type=site (zip: данные + картинки + темы) или ?type=json (только db.json)
  'GET /api/export': async (req, res) => {
    const type = new URL(req.url, 'http://x').searchParams.get('type');
    const db = readDB(), base = `ucms-${asciiName(db.settings.siteTitle)}-${stamp()}`;
    if (type === 'json') return sendDownload(res, `${base}.json`, Buffer.from(JSON.stringify(db, null, 2)), 'application/json');
    const withHistory = new URL(req.url, 'http://x').searchParams.get('history') === '1';
    sendDownload(res, `${base}${withHistory ? '-full' : ''}.zip`, siteArchive({ history: withHistory }), 'application/zip');
  },
  // Импорт: тело — файл как есть. ?dry=1 — только показать, что будет заменено.
  'POST /api/import': async (req, res) => {
    const dry = new URL(req.url, 'http://x').searchParams.get('dry') === '1';
    let parsed;
    try { parsed = parseImport(await readBody(req, WEB ? 300e6 : 1024e6)); }
    catch (e) { return sendJson(res, 400, { ok: false, error: e.message }); }
    if (dry) return sendJson(res, 200, { ok: true, summary: parsed.summary });
    parsed.allowModules = !WEB || !req.ucmsUser || req.ucmsUser.role === 'owner';
    const backup = await applyImport(parsed);
    sendJson(res, 200, { ok: true, summary: parsed.summary, backup });
  },
  /* ── Подключаемые модули сайта ── */
  'GET /api/modules/packages': async (req, res) => sendJson(res, 200, { ok: true, ...PKG.adminList() }),
  // Установка из .zip. Модуль с кодом (render.js) — только после подтверждения (?confirm=1)
  'POST /api/modules/install': async (req, res) => {
    const q = new URL(req.url, 'http://x').searchParams;
    let info;
    try { info = PKG.inspectZip(await readBody(req, 21 * 1048576)); } catch (e) { return sendJson(res, 400, { ok: false, error: e.message }); }
    const cur = PKG.refresh().byId[info.man.id];
    const about = { id: info.man.id, name: info.man.name, version: info.man.version || '', author: info.man.author || '', hasCode: info.hasCode, update: !!cur, from: cur ? cur.ver : '' };
    if (info.hasCode && q.get('confirm') !== '1') return sendJson(res, 200, { ok: true, needConfirm: true, module: about });
    PKG.install(info);
    if (req.ucmsUser) auth.journal({ ev: 'module-install', user: req.ucmsUser.user, key: `${info.man.id} ${info.man.version || ''}`.trim(), ip: clientIp(req) });
    sendJson(res, 200, { ok: true, module: about, ...PKG.adminList() });
  },
  // Удаление: блоки этого модуля на страницах остаются (данные не теряются), на сайте не выводятся
  'POST /api/modules/remove': async (req, res) => {
    const { id, force } = await readJson(req, 4096);
    const used = usedTypes(readDB()).get(id) || 0;
    if (used && !force) return sendJson(res, 200, { ok: true, inUse: used });
    PKG.remove(id);
    if (req.ucmsUser) auth.journal({ ev: 'module-remove', user: req.ucmsUser.user, key: id, ip: clientIp(req) });
    sendJson(res, 200, { ok: true, ...PKG.adminList() });
  },
  // Что можно поставить: модули движка и каталога на GitHub
  'GET /api/modules/available': async (req, res) => sendJson(res, 200, { ok: true, ...(await PKG.available()) }),
  // Установка из движка или каталога. Источник проверен (движок / sha256 каталога) — без подтверждения кода
  'POST /api/modules/install-from': async (req, res) => {
    const { id, source } = await readJson(req, 4096);
    const p = await PKG.installFrom(String(id || ''), source === 'catalog' ? 'catalog' : 'bundled');
    if (req.ucmsUser) auth.journal({ ev: 'module-install', user: req.ucmsUser.user, key: `${p.man.id} ${p.ver}`, ip: clientIp(req) });
    sendJson(res, 200, { ok: true, module: { id: p.man.id, name: p.man.name, version: p.ver }, ...PKG.adminList() });
  },
  'GET /api/modules/export': async (req, res) => {
    const id = new URL(req.url, 'http://x').searchParams.get('id') || '';
    const p = PKG.refresh().byId[id];
    if (!p) return sendJson(res, 404, { ok: false, error: 'Модуль не найден' });
    sendDownload(res, `${id}-${p.ver}.zip`, PKG.exportZip(id), 'application/zip');
  },
  'GET /api/backups': async (req, res) => {
    const list = fs.existsSync(BACKUPS_DIR) ? fs.readdirSync(BACKUPS_DIR).filter(f => f.endsWith('.zip')).sort().reverse()
      .map(f => ({ name: f, size: fs.statSync(path.join(BACKUPS_DIR, f)).size })) : [];
    sendJson(res, 200, { ok: true, backups: list });
  },
  'POST /api/backups/create': async (req, res) => sendJson(res, 200, { ok: true, name: makeBackup('manual') }),

  'POST /api/data': async (req, res) => {
    // Правки начаты с другой ревизии — данные уже поменяли (другая вкладка, другое устройство, откат версии)
    const base = req.headers['x-ucms-base-rev'];
    if (base && base !== revNow() && !req.headers['x-ucms-force']) return sendJson(res, 409, { ok: false, code: 'CONFLICT', error: 'Сайт изменён в другом окне' });
    const db = await readJson(req);
    const kept = guardData(req, db);   // разделы без прав — как на сервере
    if (WEB && db.settings) {   // ключ ИИ-перевода из браузера не принимаем: оставляем тот, что в файле
      const cur = readDB().settings.translation || {};
      db.settings.translation = { ...(db.settings.translation || {}), apiKey: cur.apiKey || '' };
    }
    // Шрифт из админки сохраняем в активную тему — до миграции, которая читает его обратно.
    const st = db.settings || {};
    if (st.theme && typeof st.fontFamily === 'string' && fs.existsSync(themeDir(st.theme))) writeThemeFont(st.theme, st);
    // История: состояние до новой порции правок (не чаще раза в 10 минут)
    await _writeQueue;
    try { HISTORY.maybeAuto(); } catch (e) { console.warn('[history]', e.message); }
    if (req.ucmsUser) HISTORY.setAuthor(req.ucmsUser.user);
    await writeDB(migrateDB(db));
    sendJson(res, 200, { ok: true, ...(kept.length ? { kept } : {}) });
  },

  /* ── Палитры «Стиля проекта»: общие для всех проектов (~/.ucms/palettes.json) ──
     custom — свои палитры { id, name, colors }, hidden — id скрытых стандартных */
  'GET /api/palettes': async (req, res) => sendJson(res, 200, { ok: true, ...readPalettes() }),
  'POST /api/palettes': async (req, res) => {
    const body = await readJson(req);
    const clean = {
      custom: (Array.isArray(body.custom) ? body.custom : []).slice(0, 60).map(p => ({
        id: String(p.id || '').replace(/[^\w-]/g, '').slice(0, 40) || `p${Date.now().toString(36)}`,
        name: String(p.name || '').trim().slice(0, 40) || 'Палитра',
        colors: Object.fromEntries(BRAND_COLORS.map(k => [k, cssColor((p.colors || {})[k], '')]).filter(e => e[1])),
      })),
      hidden: (Array.isArray(body.hidden) ? body.hidden : []).map(x => String(x).replace(/[^\w-]/g, '')).filter(Boolean).slice(0, 60),
    };
    fs.mkdirSync(projects.HOME, { recursive: true });
    fs.writeFileSync(PALETTES_FILE, JSON.stringify(clean, null, 2), 'utf8');
    sendJson(res, 200, { ok: true, ...clean });
  },

  /* ── История версий (lib/history.js) ── */
  'GET /api/history': async (req, res) => sendJson(res, 200, { ok: true, versions: HISTORY.list() }),
  'GET /api/history/diff': async (req, res) => {
    const id = new URL(req.url, 'http://x').searchParams.get('id') || '';
    sendJson(res, 200, { ok: true, diff: diffDb(migrateDB(HISTORY.read(id)), readDB()) });
  },
  'POST /api/history/save': async (req, res) => {
    const { label } = await readJson(req);
    await _writeQueue;
    const entry = HISTORY.snapshot('manual', String(label || '').trim() || 'Версия');
    sendJson(res, 200, { ok: true, entry });
  },
  'POST /api/history/rename': async (req, res) => {
    const { id, label } = await readJson(req);
    sendJson(res, 200, { ok: true, entry: HISTORY.rename(id, label) });
  },
  'POST /api/history/delete': async (req, res) => {
    const { id } = await readJson(req);
    HISTORY.remove(id);
    sendJson(res, 200, { ok: true });
  },
  // part: 'all' | 'page:<id>' | 'header' | 'footer'. Перед откатом — снимок текущего состояния.
  'POST /api/history/restore': async (req, res) => {
    const { id, part } = await readJson(req);
    const ver = migrateDB(HISTORY.read(id));
    await _writeQueue;
    const before = HISTORY.snapshot('before-restore', '');
    await writeDB(migrateDB(applyPart(ver, readDB(), part || 'all')));
    sendJson(res, 200, { ok: true, before: before && before.id });
  },

  'POST /api/generate': async (req, res) => {
    const count = generateSite(readDB());
    // веб-версия с папкой публикации: собранный сайт сразу переносится туда (только изменения)
    if (PUBLISH_DIR) return sendJson(res, 200, { ok: true, count, published: publishToDir({ outputDir: OUTPUT_DIR, targetDir: PUBLISH_DIR, contentDir: CONTENT_DIR }), siteUrl: SITE_URL });
    sendJson(res, 200, { ok: true, count, siteUrl: SITE_URL });
  },

  'GET /api/theme-css': async (req, res) => {
    const db = readDB();
    send(res, 200, db.settings.css || '', { 'Content-Type': 'text/plain;charset=utf-8', 'Cache-Control': 'no-store' });
  },

  'GET /api/themes': async (req, res) => sendJson(res, 200, { ok: true, themes: listThemes(), active: readDB().settings.theme || 'default' }),

  'POST /api/theme-css-save': async (req, res) => {
    const body = await readJson(req);
    const cf = themeCssFile(readDB().settings.theme);
    fs.mkdirSync(path.dirname(cf), { recursive: true });
    fs.writeFileSync(cf, String(body.css == null ? '' : body.css), 'utf8');
    sendJson(res, 200, { ok: true });
  },

  'POST /api/theme-switch': async (req, res) => {
    const { name } = await readJson(req);
    const cf = themeCssFile(name);
    if (!fs.existsSync(cf)) return sendJson(res, 404, { ok: false, error: 'Тема не найдена' });
    const css = fs.readFileSync(cf, 'utf8');
    const db = readDB(); db.settings.theme = cleanThemeName(name); db.settings.css = css;
    Object.assign(db.settings, readThemeFont(name) || DEFAULT_FONT);
    await writeDB(db);
    sendJson(res, 200, { ok: true, css, active: db.settings.theme, themes: listThemes(), font: { fontFamily: db.settings.fontFamily, fontImportUrl: db.settings.fontImportUrl } });
  },

  'POST /api/theme-create': async (req, res) => {
    const body = await readJson(req);
    const clean = cleanThemeName(body.name);
    if (!clean) return sendJson(res, 400, { ok: false, error: 'Пустое имя темы' });
    const td = path.join(THEMES_DIR, clean);
    if (fs.existsSync(td)) return sendJson(res, 400, { ok: false, error: 'Тема с таким именем уже есть' });
    const db = readDB();
    const css = body.from === 'current' ? (db.settings.css || defaultCss()) : defaultCss();
    fs.mkdirSync(td, { recursive: true });
    fs.writeFileSync(path.join(td, 'theme.css'), css, 'utf8');
    const font = body.from === 'current' ? { fontFamily: db.settings.fontFamily, fontImportUrl: db.settings.fontImportUrl } : DEFAULT_FONT;
    writeThemeFont(clean, font);
    db.settings.theme = clean; db.settings.css = css; Object.assign(db.settings, font); await writeDB(db);
    sendJson(res, 200, { ok: true, name: clean, css, active: clean, themes: listThemes(), font });
  },

  'POST /api/open-external': async (req, res) => {
    const { file } = await readJson(req).catch(() => ({}));
    if ((file || 'css') === 'css') {
      const db = readDB(); const cf = themeCssFile(db.settings.theme);
      if (!fs.existsSync(cf)) { fs.mkdirSync(path.dirname(cf), { recursive: true }); fs.writeFileSync(cf, db.settings.css || '', 'utf8'); }
      openPath(cf);
    }
    sendJson(res, 200, { ok: true });
  },

  // Загрузка файла. variants — уменьшенные копии для srcset (их готовит админка
  // в браузере): [{ w, data }] → <имя>-w<ширина>.webp рядом с основным файлом.
  'POST /api/upload': async (req, res) => {
    const { name, data, kind, variants, folder } = await readJson(req, WEB ? UPLOAD_MB * 1.5e6 : 400e6);   // base64 + копии: ~1.4× размера файла
    if (WEB && !UPLOAD_EXT.test(String(name || ''))) throw new Error('Такой тип файла загружать нельзя (картинки, видео, шрифты, документы, архивы)');
    const sub = String(kind || '').replace(/[^a-z0-9]/gi, '').toLowerCase() || 'misc';
    const dir = path.join(UPLOADS_DIR, sub);
    fs.mkdirSync(dir, { recursive: true });
    const safe = `${Date.now()}-${safeFileName(name)}`;
    fs.writeFileSync(path.join(dir, safe), Buffer.from(String(data || ''), 'base64'));
    if (Array.isArray(variants) && /\.webp$/i.test(safe)) {
      for (const v of variants) {
        const w = parseInt(v.w, 10);
        if (w > 0 && w < 10000 && v.data) fs.writeFileSync(path.join(dir, `${safe.replace(/\.webp$/i, '')}-w${w}.webp`), Buffer.from(String(v.data), 'base64'));
      }
    }
    if (folder) {   // загрузили, находясь в папке медиатеки, — файл попадает в неё
      await withMediaMeta(meta => { if (meta.folders.some(f => f.id === folder)) meta.files[`/uploads/${sub}/${safe}`] = { folder, tags: [] }; });
    }
    sendJson(res, 200, { ok: true, path: `uploads/${sub}/${safe}` });
  },

  'GET /api/media': async (req, res) => sendJson(res, 200, { ok: true, items: listMedia(), folders: readMediaMeta().folders, settings: mediaSettings(readDB()) }),
  // Папки и теги: op = folderAdd | folderRename | folderDelete | move | tagAdd | tagRemove | tagRename
  'POST /api/media/meta': async (req, res) => {
    const b = await readJson(req);
    const result = await withMediaMeta(meta => {
    const entry = p => (meta.files[p] = meta.files[p] || { folder: '', tags: [] });
    const paths = (b.paths || []).filter(p => uploadAbs(p));
    let created = null;
    if (b.op === 'folderAdd') {
      const name = cleanFolderName(b.name); if (!name) throw new Error('Пустое название папки');
      created = { id: 'f' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), name };
      meta.folders.push(created);
    } else if (b.op === 'folderRename') {
      const f = meta.folders.find(x => x.id === b.id); const name = cleanFolderName(b.name);
      if (f && name) f.name = name;
    } else if (b.op === 'folderDelete') {   // файлы из папки остаются, просто «без папки»
      meta.folders = meta.folders.filter(x => x.id !== b.id);
      for (const f of Object.values(meta.files)) if (f.folder === b.id) f.folder = '';
    } else if (b.op === 'move') {
      const to = b.folder && meta.folders.some(x => x.id === b.folder) ? b.folder : '';
      paths.forEach(p => { entry(p).folder = to; });
    } else if (b.op === 'tagAdd') {
      const tag = cleanTag(b.tag); if (!tag) throw new Error('Пустой тег');
      paths.forEach(p => { const e = entry(p); e.tags = e.tags || []; if (!e.tags.some(t => t.toLowerCase() === tag.toLowerCase())) e.tags.push(tag); });
    } else if (b.op === 'tagRemove') {
      paths.forEach(p => { const e = meta.files[p]; if (e && e.tags) e.tags = e.tags.filter(t => t !== b.tag); });
    } else if (b.op === 'tagRename') {   // переименовать тег у всех файлов
      const tag = cleanTag(b.to); if (!tag) throw new Error('Пустой тег');
      for (const e of Object.values(meta.files)) if (e.tags) e.tags = [...new Set(e.tags.map(t => t === b.tag ? tag : t))];
    } else throw new Error('Неизвестная операция');
    return { folders: meta.folders, created };
    });
    sendJson(res, 200, { ok: true, ...result });
  },
  // Удалить файлы (вместе с уменьшенными копиями). Ссылки в db.json не трогаются.
  'POST /api/media/delete': async (req, res) => {
    const { paths } = await readJson(req);
    let n = 0;
    await withMediaMeta(meta => {
      for (const p of paths || []) { const abs = uploadAbs(p); if (abs && fs.existsSync(abs)) { removeMediaFile(abs); delete meta.files[p]; n++; } }
    });
    sendJson(res, 200, { ok: true, deleted: n });
  },
  // Заменить файл на оптимизированный: все ссылки в db.json from → to, старый файл удаляется.
  'POST /api/media/replace': async (req, res) => {
    const { from, to } = await readJson(req);
    const a = uploadAbs(from), b = uploadAbs(to);
    if (!a || !b || !fs.existsSync(b)) throw new Error('Файл не найден');
    const key = rel => rel.replace(/^\/+/, '');
    const json = JSON.stringify(readDB()).split(key(from)).join(key(to));
    await writeDB(JSON.parse(json));
    if (fs.existsSync(a) && a !== b) removeMediaFile(a);
    await withMediaMeta(meta => { if (meta.files[from]) { meta.files[to] = meta.files[from]; delete meta.files[from]; } });
    sendJson(res, 200, { ok: true });
  },

  'GET /api/publish/config': async (req, res) => sendJson(res, 200, { ok: true, config: publisher.publicConfig() }),
  'POST /api/publish/config': async (req, res) => sendJson(res, 200, { ok: true, config: publisher.saveConfig(await readJson(req)) }),
  'POST /api/publish/test': async (req, res) => {
    try { sendJson(res, 200, await publisher.test()); }
    catch (e) { sendJson(res, 200, { ok: false, error: e.message }); }
  },
  'POST /api/publish/start': async (req, res) => {
    if (publishJob.running || syncJob.running) return sendJson(res, 409, { ok: false, error: 'Публикация уже идёт' });
    const { force } = await readJson(req).catch(() => ({}));
    try { startPublish(force); sendJson(res, 200, { ok: true }); }
    catch (e) { sendJson(res, 200, { ok: false, error: e.message }); }
  },

  /* ── Проект на сервере ── */
  'GET /api/sync/status': async (req, res) => {
    const fresh = new URL(req.url, 'http://x').searchParams.get('fresh') === '1';
    if (!fresh && syncStatusCache && Date.now() - syncStatusCache.at < 60e3) return sendJson(res, 200, { ok: true, ...syncStatusCache.value });
    try {
      const value = await publisher.status();
      syncStatusCache = { at: Date.now(), value };
      sendJson(res, 200, { ok: true, ...value });
    } catch (e) { sendJson(res, 200, { ok: false, error: e.message }); }
  },
  'POST /api/sync/pull': async (req, res) => {
    runSyncJob(progress => publisher.pull(progress, applyPulled).then(r => { syncStatusCache = null; return r; }));
    sendJson(res, 200, { ok: true });
  },
  'GET /api/sync/job': async (req, res) => sendJson(res, 200, { ok: true, job: syncJob }),

  // «Добавить существующий → С сервера»: найти проект и скачать его в новую папку
  'POST /api/remote/inspect': async (req, res) => {
    const { config, password } = await readJson(req);
    try { sendJson(res, 200, { ok: true, ...(await inspectRemote(config || {}, password)) }); }
    catch (e) { sendJson(res, 200, { ok: false, error: e.message, code: e.code || '' }); }
  },
  'POST /api/remote/clone': async (req, res) => {
    const { config, password, path: dir } = await readJson(req);
    checkNewDir(dir);
    runSyncJob(async progress => {
      try {
        const r = await cloneRemote(config || {}, password, path.resolve(dir), VERSION, progress);
        const p = projects.add(dir, r.title || path.basename(dir));
        return { ...r, id: p.id };
      } catch (e) {   // папка была пустой (checkNewDir) — убираем недокачанное, чтобы можно было повторить
        fs.rmSync(dir, { recursive: true, force: true });
        throw e;
      }
    });
    sendJson(res, 200, { ok: true });
  },
  'GET /api/remote/job': async (req, res) => sendJson(res, 200, { ok: true, job: syncJob }),
  'GET /api/publish/status': async (req, res) => sendJson(res, 200, { ok: true, job: publishJob }),
  'POST /api/publish/reset': async (req, res) => { publisher.resetState(); sendJson(res, 200, { ok: true }); },

  'POST /api/translate': async (req, res) => {
    const { sourceLabel, targetLabel, items } = await readJson(req);
    const tr = readDB().settings.translation || {};
    if (!tr.apiKey) return sendJson(res, 400, { ok: false, error: 'API-ключ не задан — откройте «Языки»' });
    const prompt = `Переведи каждую строку JSON-массива с "${sourceLabel}" на "${targetLabel}". HTML-теги сохрани. Пустые строки оставь пустыми. Ответь СТРОГО JSON-массивом той же длины, без markdown.\n${JSON.stringify(items)}`;
    try {
      const r = await callAnthropic(tr.apiKey, tr.model || DEFAULT_MODEL, prompt);
      const txt = (r.content || []).map(b => b.text || '').join('');
      let translated = null;
      try { translated = JSON.parse(txt); } catch (e) { const m = txt.match(/\[[\s\S]*\]/); if (m) translated = JSON.parse(m[0]); }
      if (!Array.isArray(translated)) throw new Error('Ответ модели не является массивом');
      sendJson(res, 200, { ok: true, items: translated });
    } catch (e) { sendJson(res, 500, { ok: false, error: e.message }); }
  },
};

// ────────────────────────────── HTTP-сервер ──────────────────────────────

const server = http.createServer(async (req, res) => {
  try {
    const p = new URL(req.url, 'http://localhost').pathname;
    if (WEB) { if (webGate(req, res, p) === false) return; }
    else {
      // Локальная версия без пароля: чужая страница в браузере не должна менять данные (CSRF),
      // а чужой домен, указывающий на 127.0.0.1, — читать их (DNS rebinding).
      if (!process.env.HOST && !/^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(req.headers.host || '')) return send(res, 403, 'Forbidden host');
      if (!/^(GET|HEAD|OPTIONS)$/.test(req.method) && !sameOrigin(req)) return sendJson(res, 403, { ok: false, error: 'Запрос с чужого сайта отклонён' });
      if (p === '/') return send(res, 302, '', { Location: '/admin/projects.html' });
    }

    // Запросы проекта: нужен открытый проект, и он должен совпадать с тем, что
    // открыт во вкладке (заголовок X-UCMS-Project) — иначе в другой вкладке переключили проект.
    const projectScoped = (p.startsWith('/api/') && !/^\/api\/(ping|projects|fs\/|palettes|update|remote|setup\/|auth\/)/.test(p)) || p.startsWith('/output/') || p.startsWith('/uploads/') || p.startsWith('/preview/');
    if (projectScoped) {
      if (!ACTIVE) return sendJson(res, 409, { ok: false, code: 'NO_PROJECT', error: 'Проект не выбран' });
      const want = req.headers['x-ucms-project'];
      if (want && want !== ACTIVE.id) return sendJson(res, 409, { ok: false, code: 'PROJECT_SWITCHED', error: 'В другой вкладке открыт другой проект', active: { id: ACTIVE.id, name: ACTIVE.name } });
      if (ACTIVE.remote) {   // подключённый сайт: всё — на сервер, кроме FTP-публикации и ИИ-перевода
        if (/^\/api\/(publish|sync)\//.test(p)) return sendJson(res, 409, { ok: false, code: 'REMOTE', error: 'Сайт публикуется на своём сервере — FTP не нужен' });
        if (/^\/api\/(translate|open-external)$/.test(p)) return sendJson(res, 409, { ok: false, code: 'REMOTE', error: 'Для подключённого сайта недоступно' });
        return proxyRemote(req, res);
      }
    }

    const route = routes[`${req.method} ${p}`];
    if (route) {
      if (p.startsWith('/api/')) res._rev0 = revNow();
      try { return await route(req, res); }
      catch (e) { if (!res.headersSent) return sendJson(res, 400, { ok: false, error: e.message }); throw e; }
    }

    if (p.startsWith('/api/backups/') && req.method === 'GET') {
      const name = path.basename(decodeURIComponent(p.slice('/api/backups/'.length)));
      const fp = path.join(BACKUPS_DIR, name);
      if (!/\.zip$/.test(name) || !fs.existsSync(fp)) return send(res, 404, 'Not found');
      return sendDownload(res, name, fs.readFileSync(fp), 'application/zip');
    }
    if (p.startsWith('/uploads/')) return serveFile(res, UPLOADS_DIR, p.slice('/uploads'.length));
    if (p === '/output' || p === '/admin') return send(res, 302, '', { Location: `${p}/` });
    if (p.startsWith('/output/')) return serveFile(res, OUTPUT_DIR, p.slice('/output'.length));
    if (p === '/preview') return send(res, 302, '', { Location: '/preview/' });
    if (p.startsWith('/preview/')) return servePreview(req, res, p.slice('/preview/'.length));
    if (p.startsWith('/admin/')) return serveFile(res, ADMIN_DIR, p === '/admin/' ? '/index.html' : p.slice('/admin'.length));
    if (WEB && !p.startsWith('/api/')) return serveSite(res, p);   // всё остальное — опубликованный сайт
    send(res, 404, 'Not found');
  } catch (e) {
    console.error(e);
    if (!res.headersSent) sendJson(res, 500, { ok: false, error: e.message });
  }
});

// Локальная версия — только этот компьютер: у админки нет входа по паролю. HOST=0.0.0.0 — открыть в локальной
// сети (на свой риск). Веб-версия — вход по паролю; снаружи её закрывают nginx и HTTPS (docs/WEB.md).
async function start() {
  if (process.argv[2] === 'passwd') return passwdCli(projects.HOME);
  // Пароль из переменных окружения (хостинг без SSH): при первом запуске, а с UCMS_RESET_PASSWORD=1 —
  // сброс забытого пароля. После входа переменные лучше убрать из настроек приложения.
  if (WEB && process.env.UCMS_ADMIN_PASSWORD && (!auth.configured() || process.env.UCMS_RESET_PASSWORD === '1')) {
    await auth.setPassword(process.env.UCMS_ADMIN_USER || auth.user() || 'admin', process.env.UCMS_ADMIN_PASSWORD);
    console.log('  Пароль администратора задан из переменных окружения.');
  }
  const setupFile = needSetup() ? setup.ensureCode() : '';
  // Passenger (хостинг) подменяет listen и сам решает, когда приложение «слушает»: открываем сайт
  // сразу, не дожидаясь обратного вызова.
  let booted = false;
  const boot = () => { if (!booted) { booted = true; bootProjects(); } };
  if (process.env.UCMS_PASSENGER === '1') boot();
  if (WEB) {
    const t = setInterval(autoBackupTick, 3600e3); if (t.unref) t.unref();
    const t0 = setTimeout(autoBackupTick, 5 * 60e3); if (t0.unref) t0.unref();
  }
  server.listen(PORT, process.env.HOST || '127.0.0.1', () => {
    boot();
    const base = `http://localhost:${PORT}/`;
    console.log('─────────────────────────────────────────');
    console.log(`  UCMS ${VERSION}${WEB ? ' · веб-версия' : ''}`);
    if (WEB) {
      console.log(`  Сайт:         ${base}`);
      console.log(`  Админка:      ${base}admin/`);
      console.log(`  Данные:       ${ACTIVE.path}`);
      if (setupFile) console.log(`  Установка:    откройте ${base}admin/ — код установки в файле ${setupFile}`);
      else console.log(`  Вход:         пользователей ${auth.listUsers().length}, владелец «${auth.user()}»`);
    } else {
      console.log(`  Проекты:      ${base}`);
      console.log(`  Открыт:       ${ACTIVE ? `${ACTIVE.name} — ${ACTIVE.path}` : 'нет (выберите проект на стартовой странице)'}`);
      console.log(`  Список:       ${projects.REG}`);
    }
    console.log('─────────────────────────────────────────');
    if (process.env.OPEN_BROWSER === '1' && !WEB) openPath(base);
  });
}
start().catch(e => { console.error(e); process.exit(1); });

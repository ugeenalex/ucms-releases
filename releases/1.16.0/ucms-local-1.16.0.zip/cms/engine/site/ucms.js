/* UCMS runtime для сгенерированного сайта (engine/site/ucms.js).
   Один файл на весь сайт (кешируется браузером), подключается с defer.
   Все обработчики — делегированием на document: ни одного инлайн-onclick,
   ни одного глобального имени, ничего не нужно «отвязывать». */
(function () {
  'use strict';

  var doc = document;
  var MENU_ROOTS = '.block-menu, .langswitch-drop';

  /* ══ Оверлей (фото / видео). Единственный на странице; Esc закрывает. ══ */
  var overlay = null;

  function onOverlayKey(e) { if (e.key === 'Escape') closeOverlay(); }

  function closeOverlay() {
    if (!overlay) return;
    overlay.remove();                                  // вместе с iframe — видео останавливается
    overlay = null;
    doc.removeEventListener('keydown', onOverlayKey); // слушатель живёт ровно пока открыт оверлей
  }

  function openOverlay(content, caption) {
    closeOverlay();
    overlay = doc.createElement('div');
    overlay.className = 'lb-overlay';
    content.addEventListener('click', function (e) { e.stopPropagation(); });
    overlay.appendChild(content);

    var close = doc.createElement('button');
    close.type = 'button';
    close.className = 'lb-close';
    close.setAttribute('aria-label', 'Закрыть');
    close.innerHTML = '&times;';
    overlay.appendChild(close);

    if (caption) {
      var cap = doc.createElement('div');
      cap.className = 'lb-cap';
      cap.textContent = caption;
      overlay.appendChild(cap);
    }
    overlay.addEventListener('click', closeOverlay);
    doc.addEventListener('keydown', onOverlayKey);
    doc.body.appendChild(overlay);
  }

  function openImage(src, caption) {
    var img = doc.createElement('img');
    img.src = src;
    img.alt = caption || '';
    openOverlay(img, caption);
  }

  function openVideo(url) {
    var box = doc.createElement('div');
    box.className = 'lb-video';
    var frame = doc.createElement('iframe');
    frame.src = url + (url.indexOf('?') >= 0 ? '&' : '?') + 'autoplay=1';
    frame.allow = 'autoplay; fullscreen; encrypted-media; picture-in-picture';
    frame.setAttribute('allowfullscreen', '');
    box.appendChild(frame);
    openOverlay(box);
  }

  /* ══ Галереи ══ */
  function wrapIndex(i, n) { return ((i % n) + n) % n; }

  // Слайдер: активный слайд + индикатор (точки или превью — у обоих data-gal-dot).
  function sliderGo(root, to) {
    var slides = root.querySelectorAll('.gallery-slide');
    if (!slides.length) return;
    var cur = parseInt(root.dataset.idx || '0', 10) || 0;
    var next = wrapIndex(to, slides.length);
    if (slides[cur]) slides[cur].classList.remove('active');
    slides[next].classList.add('active');
    var marks = root.querySelectorAll('[data-gal-dot]');
    for (var i = 0; i < marks.length; i++) marks[i].classList.toggle('active', i === next);
    // Превью: прокрутить ленту превью к активному (без прокрутки всей страницы)
    var strip = root.querySelector('.gallery-thumbs');
    if (strip && marks[next]) {
      var m = marks[next], left = m.offsetLeft - (strip.clientWidth - m.offsetWidth) / 2;
      strip.scrollTo({ left: Math.max(0, left), behavior: 'smooth' });
    }
    root.dataset.idx = String(next);
    root._apLast = Date.now();   // ручное переключение откладывает автоперелистывание
  }

  // Лента: текущий кадр по центру, но без пустоты у краёв.
  function carouselGo(root, to) {
    var view = root.querySelector('.gallery-scroll');
    var track = root.querySelector('.gallery-scroll-track');
    if (!view || !track || !track.children.length) return;
    var idx = wrapIndex(to, track.children.length);
    var item = track.children[idx];
    var viewport = view.clientWidth;
    var maxOffset = Math.max(0, track.scrollWidth - viewport);
    var offset = Math.max(0, Math.min(item.offsetLeft - (viewport - item.offsetWidth) / 2, maxOffset));
    track.style.transform = 'translateX(' + (-Math.round(offset)) + 'px)';
    root.dataset.idx = String(idx);
    root._apLast = Date.now();
  }

  function galleryStepRoot(root, dir) {
    var i = (parseInt(root.dataset.idx || '0', 10) || 0) + dir;
    if (root.classList.contains('gallery-slider')) sliderGo(root, i);
    else if (root.classList.contains('gallery-carousel')) carouselGo(root, i);
  }
  function galleryStep(btn, dir) { var root = btn.closest('.block-gallery'); if (root) galleryStepRoot(root, dir); }

  /* ══ Автоперелистывание (data-autoplay = секунды). Один общий таймер на все
     галереи; пауза при наведении/фокусе и на скрытой вкладке; выключено при
     «уменьшить движение» в системе. ══ */
  var autoRoots = Array.prototype.slice.call(doc.querySelectorAll('[data-autoplay]'));
  if (autoRoots.length && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    autoRoots.forEach(function (r) {
      r._apLast = Date.now();
      r.addEventListener('mouseenter', function () { r._apPause = true; });
      r.addEventListener('mouseleave', function () { r._apPause = false; r._apLast = Date.now(); });
      r.addEventListener('focusin', function () { r._apPause = true; });
      r.addEventListener('focusout', function () { r._apPause = false; r._apLast = Date.now(); });
    });
    setInterval(function () {
      if (doc.hidden) return;
      var now = Date.now();
      autoRoots.forEach(function (r) {
        var delay = (parseInt(r.getAttribute('data-autoplay'), 10) || 0) * 1000;
        if (delay && !r._apPause && now - (r._apLast || 0) >= delay) galleryStepRoot(r, 1);
      });
    }, 250);
  }

  /* ══ Меню и выбор языка ══ */
  function panelOf(root) {
    return root.querySelector('.menu-drop__body, .langswitch-menu, .menu-list > ul');
  }

  // Панель не должна уходить за край экрана: прижимаем к нужной стороне.
  function alignPanel(panel) {
    panel.classList.remove('is-align-right', 'is-align-left');
    var r = panel.getBoundingClientRect();
    var vw = doc.documentElement.clientWidth;
    if (r.right > vw - 8) panel.classList.add('is-align-right');
    else if (r.left < 8) panel.classList.add('is-align-left');
  }

  function setOpen(root, open) {
    root.classList.toggle('is-open', open);
    var btn = root.querySelector('.menu-burger, .langswitch-trigger');
    if (btn) btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (root._panel) {                       // меню на весь экран
      root._panel.classList.toggle('is-open', open);
      doc.documentElement.classList.toggle('ucms-menu-open', open);
      if (open) { var c = root._panel.querySelector('.menu-full__close'); if (c) c.focus(); }
      else if (btn && root._panel.contains(doc.activeElement)) btn.focus();
      return;
    }
    var panel = panelOf(root);
    if (open && panel) alignPanel(panel);
  }

  /* ══ Меню на весь экран ══
     Панель переносим в <body>: если у шапки есть transform/backdrop-filter,
     position:fixed внутри неё считался бы от шапки, а не от экрана.
     Соцсети — копия модуля «Соцсети» со страницы (шапка → подвал → любой). */
  doc.querySelectorAll('.menu-full').forEach(function (nav) {
    var panel = nav.querySelector('.menu-full__panel'); if (!panel) return;
    panel._nav = nav; nav._panel = panel;
    doc.body.appendChild(panel);
    var slot = panel.querySelector('[data-social]');
    var src = doc.querySelector('.site-header .block-social') || doc.querySelector('.site-footer .block-social') || doc.querySelector('.block-social');
    if (slot && src) slot.appendChild(src.cloneNode(true));
  });
  // Tab не уходит из открытой панели
  function trapFocus(e) {
    var panel = doc.querySelector('.menu-full__panel.is-open'); if (!panel) return;
    var f = panel.querySelectorAll('a[href], button'); if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && doc.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && doc.activeElement === last) { e.preventDefault(); first.focus(); }
  }

  function closeMenus(except) {
    doc.querySelectorAll('.block-menu.is-open, .langswitch-drop.is-open').forEach(function (n) {
      if (n !== except) setOpen(n, false);
    });
  }

  function closeSubmenus(except) {
    doc.querySelectorAll('.menu-list li.is-sub-open').forEach(function (li) {
      if (li !== except && !li.contains(except)) li.classList.remove('is-sub-open');
    });
  }

  // Тач без наведения: первый тап по пункту с подменю раскрывает его,
  // второй — переходит по ссылке. Решаем по факту: подменю сейчас скрыто?
  function handleParentTap(link, e) {
    var li = link.parentElement;
    var sub = li.querySelector(':scope > ul');
    if (!sub || getComputedStyle(sub).display !== 'none') return false;
    e.preventDefault();
    closeSubmenus(li);
    li.classList.add('is-sub-open');
    alignPanel(sub);
    return true;
  }

  /* ══ Делегирование ══ */
  // ── Вкладки (модуль «Вкладки»): ARIA tabs, стрелки/Home/End, открытие по #tab-… ──
  function tabsActivate(tab, focus) {
    var box = tab.closest('[data-tabs]'); if (!box || tab.classList.contains('is-on')) { if (focus) tab.focus(); return; }
    var list = tab.parentNode;
    Array.prototype.forEach.call(list.children, function (b) {
      var on = b === tab;
      b.classList.toggle('is-on', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); b.tabIndex = on ? 0 : -1;
      var p = doc.getElementById(b.getAttribute('aria-controls')); if (p) p.hidden = !on;
    });
    if (focus) tab.focus();
    tabsReveal(tab);
    // галереи и слайдеры в открытой вкладке пересчитывают размеры (пока вкладка была скрыта, ширина была 0)
    try { window.dispatchEvent(new Event('resize')); } catch (e) { /* старые браузеры */ }
  }
  // Прокрутка списка вкладок: стрелки ‹ › видны, только когда есть что прокручивать
  // (классы has-prev / has-next у .tabs-nav); на сенсорных экранах стрелок нет — листают пальцем.
  function tabsNavUpdate(nav) {
    var l = nav.querySelector('.tabs-list'); if (!l) return;
    var max = l.scrollWidth - l.clientWidth;
    nav.classList.toggle('has-prev', max > 1 && l.scrollLeft > 1);
    nav.classList.toggle('has-next', max > 1 && l.scrollLeft < max - 1);
  }
  function tabsNavAll() { doc.querySelectorAll('.tabs-nav').forEach(tabsNavUpdate); }
  // Стрелка: докрутить до ближайшей вкладки, которая видна не полностью
  function tabsStep(arrow) {
    var nav = arrow.closest('.tabs-nav'), l = nav.querySelector('.tabs-list');
    var lr = l.getBoundingClientRect(), next = arrow.classList.contains('tabs-arrow--next');
    var pad = arrow.offsetWidth || 32, tabs = Array.prototype.slice.call(l.children), target = null;
    if (next) tabs.some(function (t) { var r = t.getBoundingClientRect(); if (r.right > lr.right - pad + 1) { target = r.right - (lr.right - pad); return true; } return false; });
    else tabs.slice().reverse().some(function (t) { var r = t.getBoundingClientRect(); if (r.left < lr.left + pad - 1) { target = r.left - (lr.left + pad); return true; } return false; });
    if (target) l.scrollBy({ left: target, behavior: 'smooth' });
  }
  // Выбранная вкладка (клик, клавиатура, #адрес) — целиком в видимой части списка
  function tabsReveal(tab) {
    var l = tab.parentNode; if (l.scrollWidth <= l.clientWidth) return;
    var nav = l.parentNode, pad = nav.classList.contains('tabs-nav') ? 36 : 0;
    var lr = l.getBoundingClientRect(), r = tab.getBoundingClientRect(), d = 0;
    if (r.left < lr.left + pad) d = r.left - lr.left - pad;
    else if (r.right > lr.right - pad) d = r.right - lr.right + pad;
    if (d) l.scrollBy({ left: d, behavior: 'smooth' });
  }
  // scroll не всплывает — ловим на перехвате; resize — один слушатель, пересчёт раз в кадр
  doc.addEventListener('scroll', function (e) {
    var t = e.target; if (t && t.classList && t.classList.contains('tabs-list')) tabsNavUpdate(t.parentNode);
  }, true);
  var tabsRaf = 0;
  window.addEventListener('resize', function () {
    if (tabsRaf) return;
    tabsRaf = requestAnimationFrame(function () { tabsRaf = 0; tabsNavAll(); });
  });
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', tabsNavAll); else tabsNavAll();
  window.addEventListener('load', tabsNavAll);   // шрифты загрузились — ширины вкладок изменились

  doc.addEventListener('keydown', function (e) {
    var tab = e.target.closest && e.target.closest('.tabs-tab'); if (!tab) return;
    var tabs = Array.prototype.slice.call(tab.parentNode.children), i = tabs.indexOf(tab);
    var vertical = tab.parentNode.getAttribute('aria-orientation') === 'vertical';
    var prev = vertical ? 'ArrowUp' : 'ArrowLeft', next = vertical ? 'ArrowDown' : 'ArrowRight', to = -1;
    if (e.key === prev) to = (i - 1 + tabs.length) % tabs.length;
    else if (e.key === next) to = (i + 1) % tabs.length;
    else if (e.key === 'Home') to = 0;
    else if (e.key === 'End') to = tabs.length - 1;
    if (to < 0) return;
    e.preventDefault(); tabsActivate(tabs[to], true);
  });
  function tabsFromHash() {
    var id = decodeURIComponent((location.hash || '').slice(1)); if (!id) return;
    var el = doc.getElementById(id); if (!el) return;
    var tab = el.classList.contains('tabs-tab') ? el : null;
    if (!tab) {   // якорь внутри скрытой вкладки — открываем её
      var panel = el.closest && el.closest('.tabs-panel');
      tab = panel ? doc.getElementById(panel.getAttribute('aria-labelledby')) : null;
    }
    if (tab) tabsActivate(tab, false);
  }
  window.addEventListener('hashchange', tabsFromHash);
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', tabsFromHash); else tabsFromHash();

  // ── Карточки и списки записей: фильтр + постраничный показ (data-page у группы) ──
  function pageSize(g) { return parseInt(g.getAttribute('data-page'), 10) || 0; }
  function cardsApply(g, animate) {
    var f = g._filter || '*', per = pageSize(g), limit = per ? (g._shown || per) : 0, n = 0;
    g.querySelectorAll('.card').forEach(function (c) {
      var match = f === '*' || (' ' + (c.getAttribute('data-tags') || '') + ' ').indexOf(' ' + f + ' ') >= 0;
      if (match) n++;
      var show = match && (!limit || n <= limit), was = !c.hidden;
      c.hidden = !show;
      if (show && animate && (!was || f !== g._lastFilter)) { c.classList.remove('is-in'); void c.offsetWidth; c.classList.add('is-in'); }   // перезапуск анимации появления
    });
    g._lastFilter = f;
    var btn = g.querySelector('.coll-more');
    if (btn) btn.hidden = !limit || n <= limit;
  }

  doc.addEventListener('click', function (e) {
    var t = e.target;
    if (!(t instanceof Element)) return;

    var toggle = t.closest('.menu-burger, .langswitch-trigger');
    if (toggle) {
      var root = toggle.closest(MENU_ROOTS);
      if (root) {
        var willOpen = !root.classList.contains('is-open');
        closeMenus(root);
        setOpen(root, willOpen);
      }
      return;
    }

    // Клик внутри полноэкранного меню: ссылка или крестик закрывают его
    var fp = t.closest('.menu-full__panel');
    if (fp) { if (t.closest('a[href], .menu-full__close')) setOpen(fp._nav, false); return; }

    var parentLink = t.closest('.menu-list li.has-children > a');
    if (parentLink && handleParentTap(parentLink, e)) return;

    var lb = t.closest('.lightbox-trigger');
    if (lb) { e.preventDefault(); openImage(lb.href, lb.getAttribute('data-caption') || ''); return; }

    var vid = t.closest('.video-lightbox-trigger');
    if (vid) { var url = vid.getAttribute('data-video'); if (url) openVideo(url); return; }

    var nav = t.closest('[data-gal-step]');
    if (nav) { galleryStep(nav, parseInt(nav.getAttribute('data-gal-step'), 10) || 0); return; }

    // Вкладки
    var tb = t.closest('.tabs-tab');
    if (tb) { tabsActivate(tb, false); return; }
    var ta = t.closest('.tabs-arrow');
    if (ta) { tabsStep(ta); return; }

    // Фильтр карточек: «Все» или ключевое слово (data-tags у карточек)
    var fb = t.closest('.cards-filter__btn');
    if (fb) {
      var group = fb.closest('.block-cards-group');
      group.querySelectorAll('.cards-filter__btn').forEach(function (b) {
        var on = b === fb; b.classList.toggle('is-active', on); b.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      group._filter = fb.getAttribute('data-filter') || '*';
      group._shown = 0;   // смена фильтра — снова первая «страница»
      cardsApply(group, true);
      return;
    }

    // «Показать ещё» в списке записей коллекции
    var more = t.closest('.coll-more');
    if (more) {
      var cg = more.closest('.block-cards-group');
      cg._shown = (cg._shown || pageSize(cg)) + pageSize(cg);
      cardsApply(cg, true);
      return;
    }

    var dot = t.closest('[data-gal-dot]');
    if (dot) { var sl = dot.closest('.gallery-slider'); if (sl) sliderGo(sl, parseInt(dot.getAttribute('data-gal-dot'), 10) || 0); return; }

    // Клик вне меню — закрыть всё открытое
    if (!t.closest(MENU_ROOTS)) closeMenus(null);
    if (!t.closest('.menu-list li.has-children')) closeSubmenus(null);
  });

  doc.addEventListener('keydown', function (e) {
    if (e.key === 'Tab') { trapFocus(e); return; }
    if (e.key !== 'Escape') return;
    closeMenus(null);
    closeSubmenus(null);
  });

  /* ══ Цифры: досчитываются, когда блок появляется на экране ══ */
  function animateCount(el) {
    var target = parseFloat(el.getAttribute('data-count'));
    var decimals = (String(el.getAttribute('data-count')).split('.')[1] || '').length;
    var start = null, dur = 1400;
    function frame(ts) {
      if (start === null) start = ts;
      var k = Math.min(1, (ts - start) / dur), eased = 1 - Math.pow(1 - k, 3);
      el.textContent = (target * eased).toFixed(decimals);
      if (k < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }
  var counters = doc.querySelectorAll('[data-count]');
  if (counters.length && 'IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        io.unobserve(en.target);          // каждое число анимируется один раз
        animateCount(en.target);
      });
    }, { threshold: 0.4 });
    counters.forEach(function (el) { io.observe(el); });
  }

  /* ══ Таймеры: один общий интервал на все; останавливается, когда все истекли ══ */
  var timers = Array.prototype.slice.call(doc.querySelectorAll('[data-until]'));
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function tickTimers() {
    var now = Date.now();
    timers = timers.filter(function (el) {
      var left = Math.max(0, Date.parse(el.getAttribute('data-until')) - now);
      var s = Math.floor(left / 1000);
      var v = { d: Math.floor(s / 86400), h: Math.floor(s / 3600) % 24, m: Math.floor(s / 60) % 60, s: s % 60 };
      el.querySelectorAll('[data-u]').forEach(function (c) { var k = c.getAttribute('data-u'); c.textContent = k === 'd' ? v.d : pad(v[k]); });
      if (left > 0) return true;
      var done = el.getAttribute('data-done');
      if (done) { var g = el.querySelector('.cd-grid'); if (g) g.outerHTML = '<div class="cd-done">' + done.replace(/[<>&]/g, '') + '</div>'; }
      return false;
    });
    if (!timers.length && timerId) { clearInterval(timerId); timerId = null; }
  }
  var timerId = null;
  if (timers.length) { tickTimers(); if (timers.length) timerId = setInterval(tickTimers, 1000); }

  /* ══ Параллакс фона ══
     Блоки — simpleParallax.js (vendor/simple-parallax.min.js, MIT), по своему
     экземпляру на картинку: настройки у каждой свои (data-px).
     Фон страницы — фиксированный слой: смещение зависит от прокрутки всей
     страницы, настройки те же (направление, масштаб, задержка, ограничение).
     При «уменьшить движение» в системе картинки остаются неподвижными. */
  var reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  function pxOpts(img) { try { return JSON.parse(img.getAttribute('data-px') || '{}'); } catch (e) { return {}; } }
  if (window.SimpleParallax) {
    doc.querySelectorAll('.ucms-bgpx:not(.ucms-bgpx--page) img.ucms-px').forEach(function (img) {
      new window.SimpleParallax(img, pxOpts(img));   // слушатели библиотека держит сама, один rAF на все экземпляры
    });
  }
  var pagePx = doc.querySelector('.ucms-bgpx--page img');
  if (pagePx && !reduceMotion) {
    var po = pxOpts(pagePx), scale = po.scale || 1.3, dir = po.orientation || 'up';
    if (po.delay) pagePx.style.transition = 'transform ' + po.delay + 's ' + (po.transition || 'linear');
    var pxQueued = false;
    var paintPx = function () {
      pxQueued = false;
      var max = Math.max(1, doc.documentElement.scrollHeight - innerHeight);
      var p = Math.min(1, window.scrollY / max);
      if (po.maxTransition) p = Math.min(p, po.maxTransition / 100);
      // смещение в пределах «запаса», который даёт масштаб: от -запас/2 до +запас/2
      var dy = (p - 0.5) * (scale - 1) * innerHeight, dx = (p - 0.5) * (scale - 1) * innerWidth;
      var x = /left/.test(dir) ? -dx : /right/.test(dir) ? dx : 0;
      var y = /up/.test(dir) ? -dy : /down/.test(dir) ? dy : 0;
      pagePx.style.transform = 'translate3d(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px,0) scale(' + scale + ')';
    };
    var queuePx = function () { if (!pxQueued) { pxQueued = true; requestAnimationFrame(paintPx); } };
    window.addEventListener('scroll', queuePx, { passive: true });
    window.addEventListener('resize', queuePx);
    paintPx();
  }

  /* ══ Закреплённая шапка: тень после начала прокрутки и высота для якорей ══ */
  var stickyHead = doc.querySelector('.site-header--sticky');
  if (stickyHead) {
    var setH = function () { doc.documentElement.style.setProperty('--ucms-header-h', stickyHead.offsetHeight + 'px'); };
    if ('ResizeObserver' in window) new ResizeObserver(setH).observe(stickyHead); else setH();
    var onScrollHead = function () { stickyHead.classList.toggle('is-scrolled', window.scrollY > 4); };
    window.addEventListener('scroll', onScrollHead, { passive: true });
    onScrollHead();
  }

  // Пересчёт каруселей при изменении ширины (один rAF на пачку resize-событий)
  var resizeQueued = false;
  window.addEventListener('resize', function () {
    if (resizeQueued) return;
    resizeQueued = true;
    requestAnimationFrame(function () {
      resizeQueued = false;
      doc.querySelectorAll('.gallery-carousel').forEach(function (c) {
        carouselGo(c, parseInt(c.dataset.idx || '0', 10) || 0);
      });
    });
  });
})();

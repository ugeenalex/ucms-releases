'use strict';
const { escHtml, blockField } = require('./_shared');

// Подписи полей на языке страницы (сайт может быть многоязычным).
const LABELS = {
  ru: { name: 'Имя', email: 'Email', phone: 'Телефон', message: 'Сообщение', send: 'Отправить' },
  en: { name: 'Name', email: 'Email', phone: 'Phone', message: 'Message', send: 'Send' },
  kk: { name: 'Аты', email: 'Email', phone: 'Телефон', message: 'Хабарлама', send: 'Жіберу' },
  uk: { name: "Ім'я", email: 'Email', phone: 'Телефон', message: 'Повідомлення', send: 'Надіслати' },
  de: { name: 'Name', email: 'E-Mail', phone: 'Telefon', message: 'Nachricht', send: 'Senden' },
  fr: { name: 'Nom', email: 'E-mail', phone: 'Téléphone', message: 'Message', send: 'Envoyer' },
  es: { name: 'Nombre', email: 'Correo', phone: 'Teléfono', message: 'Mensaje', send: 'Enviar' },
};

module.exports = {
  type: 'form', label: 'Обратная связь',
  render(block, ctx) {
    if (block.formType === 'embed') {
      if (!block.embedUrl) return '';
      const h = parseInt(block.embedHeight, 10) || 600;
      return `<div class="block block-form form-embed"><iframe src="${escHtml(block.embedUrl)}" title="Форма" height="${h}" loading="lazy"></iframe></div>`;
    }
    const L = LABELS[ctx.lang] || (ctx.lang === ctx.defaultLang ? LABELS.ru : LABELS.en);
    const title = blockField(block, 'title', ctx.lang, ctx.defaultLang) || '';
    const f = block.fields || {};
    let fields = '';
    if (f.name !== false)    fields += `<label><span>${L.name}</span><input type="text" name="name" autocomplete="name" required></label>`;
    if (f.email !== false)   fields += `<label><span>${L.email}</span><input type="email" name="email" autocomplete="email" required></label>`;
    if (f.phone)             fields += `<label><span>${escHtml(L.phone)}</span><input type="tel" name="phone" autocomplete="tel"></label>`;
    if (f.message !== false) fields += `<label><span>${escHtml(L.message)}</span><textarea name="message" rows="5"></textarea></label>`;
    // Без адреса приёма атрибут action не пишем (пустой отправлял бы форму на эту же страницу)
    const action = block.endpoint ? ` action="${escHtml(block.endpoint)}"` : '';
    const titleHtml = title ? `<h3 class="form-title">${escHtml(title)}</h3>` : '';
    return `<div class="block block-form form-simple">${titleHtml}<form${action} method="POST">${fields}<button type="submit">${escHtml(L.send)}</button></form></div>`;
  },
};

'use strict';
const { escHtml, pageHref } = require('./_shared');
module.exports = {
  type: 'sitename', label: 'Имя сайта',
  render(block, ctx) {
    // Ведём на главную ТЕКУЩЕГО языка (первая корневая страница), а не на корневой
    // редирект — иначе посетитель со второго языка выбрасывается на язык по умолчанию.
    const home = ctx.tree && ctx.tree[0];
    const href = home ? pageHref(home, ctx) : `${ctx.pageBase || ''}index.html`;
    return `<div class="block block-sitename"><a class="sitename-link" href="${escHtml(href)}">${escHtml(ctx.siteTitle || '')}</a></div>`;
  },
};

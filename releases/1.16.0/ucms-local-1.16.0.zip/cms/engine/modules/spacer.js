'use strict';
// Отступ: пустое место заданной высоты, отдельно для компьютера и телефона.
function px(v, def) { const n = parseInt(v, 10); return Math.min(400, Math.max(0, isFinite(n) ? n : def)); }
module.exports = {
  type: 'spacer', label: 'Отступ',
  render(block) {
    const h = px(block.height, 48), hm = px(block.heightMobile, Math.round(h * 0.6));
    return `<div class="block block-spacer" style="--sp:${h}px;--sp-m:${hm}px" aria-hidden="true"></div>`;
  },
};

'use strict';
const { escHtml, srcPath } = require('./_shared');
function ytId(u) { const m = String(u).match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/); return m ? m[1] : null; }
function yt(u) { const id = ytId(u); return id ? `https://www.youtube.com/embed/${id}` : null; }
function vm(u) { const m = String(u).match(/vimeo\.com\/(\d+)/); return m ? `https://player.vimeo.com/video/${m[1]}` : null; }
module.exports = {
  type: 'video', label: 'Видео',
  render(block, ctx) {
    if (!block.url) return '';
    const src = yt(block.url) || vm(block.url) || block.url;
    // «Предпросмотр по клику»: постер с обложкой, открывающий видео в модальном окне.
    // Обложка: ручная (block.cover) → иначе авто-миниатюра YouTube → иначе градиент.
    if (block.preview) {
      let img = '';
      if (block.cover) {
        img = `<img src="${escHtml(srcPath(block.cover, ctx.basePrefix))}" alt="" loading="lazy">`;
      } else {
        const id = ytId(block.url);
        if (id) img = `<img src="https://img.youtube.com/vi/${id}/maxresdefault.jpg" onerror="this.onerror=null;this.src='https://img.youtube.com/vi/${id}/hqdefault.jpg'" alt="" loading="lazy">`;
      }
      return `<div class="block block-video"><button type="button" class="video-lightbox-trigger video-poster" data-video="${escHtml(src)}" aria-label="Смотреть видео">${img}<span class="video-play" aria-hidden="true"></span></button></div>`;
    }
    return `<div class="block block-video"><div class="video-frame"><iframe src="${escHtml(src)}" loading="lazy" allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture" allowfullscreen></iframe></div></div>`;
  },
};

'use strict';
// Карточки: картинка + заголовок + текст + кнопка, сеткой в 1–4 колонки.
// Опционально — фильтр по ключевым словам: кнопки над сеткой (переключает ucms.js).
const { escHtml, blockField, srcPath, resolveLink, linkAttrs, imgExtra } = require('./_shared');

// whole=true — кликабельна вся карточка (растянутая ссылка поверх), иначе — кнопка «Подробнее».
function cardHtml(it, ctx, tagIds, whole, cols) {
  const title = blockField(it, 'title', ctx.lang, ctx.defaultLang) || '';
  const text = blockField(it, 'text', ctx.lang, ctx.defaultLang) || '';
  const btn = blockField(it, 'btnText', ctx.lang, ctx.defaultLang) || '';
  const href = resolveLink(it.link, ctx);
  const ext = linkAttrs(it.link);
  const tags = tagIds ? (it.tags || []).filter(id => tagIds.has(id)) : [];
  const linked = whole && href;
  return `<article class="card${linked ? ' card--link' : ''}"${tags.length ? ` data-tags="${escHtml(tags.join(' '))}"` : ''}>` +
    (linked ? `<a class="card-cover" href="${escHtml(href)}"${ext} aria-label="${escHtml(title || btn || 'Открыть')}"></a>` : '') +
    (it.image ? `<div class="card-media"><img src="${escHtml(srcPath(it.image, ctx.basePrefix))}" alt="${escHtml(title)}" loading="lazy"${imgExtra(it.image, ctx, `(max-width: 720px) 100vw, ${Math.round(100 / (cols || 3))}vw`)}></div>` : '') +
    '<div class="card-body">' + (title ? `<h3 class="card-title">${escHtml(title)}</h3>` : '') +
    (text ? `<p class="card-text">${escHtml(text).replace(/\r?\n/g, '<br>')}</p>` : '') +
    (whole ? (linked && btn ? `<span class="card-link">${escHtml(btn)}</span>` : '')   // подпись-подсказка, сама ссылка — вся карточка
      : href ? `<a class="card-link" href="${escHtml(href)}"${ext}>${escHtml(btn || 'Подробнее')}</a>` : '') + '</div></article>';
}

module.exports = {
  type: 'cards', label: 'Карточки',
  render(block, ctx) {
    const items = (block.items || []).filter(it => it.title || it.text || it.image);
    if (!items.length) return '';
    const cols = Math.min(4, Math.max(1, parseInt(block.cols, 10) || 3));
    const style = `--cards-cols:${cols}`;
    const whole = block.clickMode === 'card';

    // Фильтр: показываем только слова, которые есть хотя бы у одной карточки
    const used = new Set(items.flatMap(it => it.tags || []));
    const tags = block.filter ? (block.tags || []).filter(t => t.id && (t.name || '').trim() && used.has(t.id)) : [];
    if (!tags.length) return `<div class="block block-cards" style="${style}">${items.map(it => cardHtml(it, ctx, null, whole, cols)).join('')}</div>`;

    const ids = new Set(tags.map(t => t.id));
    const all = blockField(block, 'allLabel', ctx.lang, ctx.defaultLang) || 'Все';
    const btns = [`<button type="button" class="cards-filter__btn is-active" data-filter="*" aria-pressed="true">${escHtml(all)}</button>`]
      .concat(tags.map(t => `<button type="button" class="cards-filter__btn" data-filter="${escHtml(t.id)}" aria-pressed="false">${escHtml(blockField(t, 'name', ctx.lang, ctx.defaultLang))}</button>`));
    return `<div class="block block-cards-group"><div class="cards-filter" role="group" aria-label="Фильтр">${btns.join('')}</div>` +
      `<div class="block-cards" style="${style}">${items.map(it => cardHtml(it, ctx, ids, whole, cols)).join('')}</div></div>`;
  },
};

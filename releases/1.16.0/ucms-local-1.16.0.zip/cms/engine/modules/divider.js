'use strict';
// Разделитель. Цвет и отступы — в теме; толщина из админки (inline, чтобы тема её не перебила).
module.exports = {
  type: 'divider', label: 'Разделитель',
  render(block) {
    const w = Math.min(40, Math.max(1, parseInt(block.width, 10) || 2));
    return `<hr class="block block-divider" style="border-top-width:${w}px">`;
  },
};

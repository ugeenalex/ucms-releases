'use strict';
// Хлебные крошки: строятся из дерева страниц (родители текущей страницы).
const { escHtml, pageHref } = require('./_shared');
function titleOf(p, ctx) {
  const tr = ctx.lang !== ctx.defaultLang && p.translations && p.translations[ctx.lang];
  return (tr && tr.title) || p.title;
}
module.exports = {
  type: 'crumbs', label: 'Хлебные крошки',
  render(block, ctx) {
    if (!ctx.page || !ctx.pagesById) return '';
    const chain = [];
    // Родитель записи коллекции — страница-список коллекции
    const parentOf = p => {
      const coll = p.collection && ctx.collsById && ctx.collsById[p.collection];
      const pid = coll ? coll.listPageId : p.parentId;
      return pid ? ctx.pagesById[pid] : null;
    };
    for (let p = ctx.page, guard = 0; p && guard < 20; p = parentOf(p), guard++) chain.unshift(p);
    const home = ctx.tree && ctx.tree[0];
    if (home && chain[0].id !== home.id) chain.unshift(ctx.pagesById[home.id] || home);
    if (chain.length < 2 && !block.showOnHome) return '';
    const parts = chain.map((p, i) => i === chain.length - 1
      ? `<span aria-current="page">${escHtml(titleOf(p, ctx))}</span>`
      : `<a href="${escHtml(pageHref(p, ctx))}">${escHtml(titleOf(p, ctx))}</a>`);
    return `<nav class="block block-crumbs" aria-label="Навигация">${parts.join('<span class="crumbs-sep" aria-hidden="true">/</span>')}</nav>`;
  },
};

'use strict';
// «Вкладки»: горизонтальные или вертикальные. Внутри каждой вкладки — обычные блоки
// (ряды с колонками и модулями), их выводит тот же renderRows, что и страницу
// (ctx.renderRows). Переключение, клавиатура (стрелки, Home/End) и открытие вкладки
// по адресу #tab-… — в ucms.js; без JS видна первая вкладка.
const { escHtml, blockField } = require('./_shared');

module.exports = {
  type: 'tabs', label: 'Вкладки',
  render(block, ctx) {
    const items = (block.items || []).filter(it => it && it.id);
    if (!items.length || typeof ctx.renderRows !== 'function') return '';
    const vertical = block.orient === 'v';
    const base = `tab-${String(block.id).replace(/[^\w-]/g, '')}`;
    const tabs = items.map((it, i) => {
      const title = blockField(it, 'title', ctx.lang, ctx.defaultLang) || `${i + 1}`;
      const id = `${base}-${String(it.id).replace(/[^\w-]/g, '')}`;
      return `<button type="button" class="tabs-tab${i === 0 ? ' is-on' : ''}" role="tab" id="${id}" aria-controls="${id}-p" aria-selected="${i === 0}" tabindex="${i === 0 ? 0 : -1}">${escHtml(title)}</button>`;
    }).join('');
    const panels = items.map((it, i) => {
      const id = `${base}-${String(it.id).replace(/[^\w-]/g, '')}`;
      return `<div class="tabs-panel" role="tabpanel" id="${id}-p" aria-labelledby="${id}" tabindex="0"${i === 0 ? '' : ' hidden'}>${ctx.renderRows(it.rows || [])}</div>`;
    }).join('');
    const style = block.tabStyle === 'pills' ? ' tabs--pills' : '';
    return `<div class="block block-tabs tabs--${vertical ? 'v' : 'h'}${style}" data-tabs>` +
      // список прокручивается: на ПК — стрелками по одной вкладке, на телефоне — пальцем (ucms.js)
      '<div class="tabs-nav">' +
      '<button type="button" class="tabs-arrow tabs-arrow--prev" tabindex="-1" aria-hidden="true">‹</button>' +
      `<div class="tabs-list" role="tablist" aria-orientation="${vertical ? 'vertical' : 'horizontal'}">${tabs}</div>` +
      '<button type="button" class="tabs-arrow tabs-arrow--next" tabindex="-1" aria-hidden="true">›</button></div>' +
      `<div class="tabs-panels">${panels}</div></div>`;
  },
};

'use strict';
const { escHtml, blockField, linkTag } = require('./_shared');
module.exports = {
  type: 'title', label: 'Заголовок',
  render(block, ctx) {
    const lvRaw = block.level;
    const lvNum = typeof lvRaw === 'string' ? parseInt(lvRaw.replace(/[^0-9]/g,''), 10) : parseInt(lvRaw, 10);
    const level = Math.min(Math.max(isNaN(lvNum) ? 2 : lvNum, 1), 4);
    const text  = blockField(block, 'text', ctx.lang, ctx.defaultLang) || '';
    if (!text.trim()) return '';
    const inner = escHtml(text);
    const content = linkTag(block.link, ctx, inner);
    return `<h${level} class="block block-heading">${content}</h${level}>`;
  },
};

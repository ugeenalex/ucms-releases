'use strict';
// Общие функции коллекций (блог, новости, портфолио, каталог) — для генератора
// (страница записи) и модуля «Список записей».
// Запись коллекции — обычная страница с полем collection (id коллекции) и полями
// записи: date (ГГГГ-ММ-ДД), cover, excerpt, tags[]. Переводы анонса — translations[lang].excerpt.
const { blockField } = require('./_shared');

function forEachModule(rows, fn) {
  (rows || []).forEach(r => {
    (r.columns || []).forEach(c => (c.blocks || []).forEach(fn));
    (r.blocks || []).forEach(fn);
  });
}

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", nbsp: ' ', mdash: '—', ndash: '–', laquo: '«', raquo: '»', hellip: '…' };
function htmlToText(html) {
  return String(html || '')
    .replace(/<(br|\/p|\/li|\/h\d)[^>]*>/gi, ' ')
    .replace(/<[^>]+>/g, '')
    .replace(/&(#?\w+);/g, (m, e) => ENT[e] != null ? ENT[e] : /^#\d+$/.test(e) ? String.fromCodePoint(+e.slice(1)) : m)
    .replace(/\s+/g, ' ').trim();
}

function cut(text, max) {
  if (text.length <= max) return text;
  const s = text.slice(0, max);
  const sp = s.lastIndexOf(' ');
  return `${(sp > max * 0.6 ? s.slice(0, sp) : s).replace(/[\s,.;:—–-]+$/, '')}…`;
}

// Анонс: своё поле (с переводом) или начало первого «Текста» записи.
function entryExcerpt(page, lang, defLang, max) {
  const tr = lang !== defLang && page.translations && page.translations[lang];
  const own = (tr && tr.excerpt) || page.excerpt;
  if (own && String(own).trim()) return String(own).trim();
  let text = '';
  forEachModule(page.rows, b => {
    if (!text && b.type === 'text') text = htmlToText(blockField(b, 'html', lang, defLang));
  });
  return cut(text, max || 180);
}

// Обложка: своё поле или первая картинка записи («Изображение», затем «Галерея»).
function entryCover(page) {
  if (page.cover) return page.cover;
  let src = '';
  forEachModule(page.rows, b => {
    if (src) return;
    if (b.type === 'image' && b.src) src = b.src;
    else if (b.type === 'gallery') { const it = (b.items || []).find(x => x && x.src); if (it) src = it.src; }
  });
  return src;
}

function validDate(d) { return /^\d{4}-\d{2}-\d{2}$/.test(String(d || '')) ? String(d) : ''; }

// «8 октября 2026» на языке страницы (Intl, без библиотек).
const fmtCache = new Map();
function formatDate(date, lang) {
  const d = validDate(date);
  if (!d) return '';
  try {
    if (!fmtCache.has(lang)) fmtCache.set(lang, new Intl.DateTimeFormat(lang, { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }));
    return fmtCache.get(lang).format(new Date(`${d}T00:00:00Z`)).replace(/\s?г\.$/, '');   // «1 октября 2026», без «г.»
  } catch (e) { return d.split('-').reverse().join('.'); }
}

// Порядок записей: по дате (новые сверху) или вручную (order).
function sortEntries(list, coll) {
  const byOrder = (a, b) => (a.order || 0) - (b.order || 0);
  if (coll && coll.sort === 'manual') return list.slice().sort(byOrder);
  return list.slice().sort((a, b) => (validDate(b.date) || '').localeCompare(validDate(a.date) || '') || byOrder(a, b));
}

module.exports = { entryExcerpt, entryCover, formatDate, validDate, sortEntries, htmlToText };

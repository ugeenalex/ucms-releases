'use strict';
// Реестр серверных модулей. Тип модуля = ключ из шаблона admin/modules.js.
// Добавить новый тип = создать файл в этой папке + добавить require() здесь.
// Необязательные модули (тарифы, цифры, таймер, карта, таблица, цитата, вопросы, соцсети, команда)
// с 1.15 — подключаемые: engine/packages, ставятся в папку сайта (lib/packages.js).
const modules = [
  require('./title'),      // заголовок H1-H4
  require('./text'),       // форматированный текст
  require('./image'),      // изображение со ссылкой
  require('./video'),      // видео (YouTube/Vimeo/встроенное)
  require('./divider'),    // горизонтальный разделитель
  require('./html'),       // произвольный HTML
  require('./gallery'),    // галерея (сетка/прокрутка/слайдер)
  require('./form'),       // форма обратной связи / встроенная форма
  require('./menu'),       // меню сайта
  require('./sitename'),   // название сайта
  require('./lang'),       // переключатель языков
  require('./button'),     // кнопка-ссылка
  require('./spacer'),     // отступ заданной высоты
  require('./features'),   // преимущества: иконка + заголовок + текст
  require('./cards'),      // карточки: картинка + текст + кнопка
  require('./crumbs'),     // хлебные крошки
  require('./collection'), // список записей коллекции (блог, новости, портфолио)
  require('./tabs'),       // вкладки: в каждой — свои блоки (конструктор внутри модуля)
];

const byType = {};
modules.forEach(m => { byType[m.type] = m; });

module.exports = {
  modules,
  byType,
  render(block, ctx) {
    const m = byType[block.type];
    return m ? (m.render(block, ctx) || '') : '';
  },
};

'use strict';
const { escHtml, pageSlug, pageHref, srcPath } = require('./_shared');

const BURGER = '<span></span><span></span><span></span>';
const CLOSE = '<span></span><span></span>';

// Свои значки кнопок «Меню» и «Закрыть» (картинки из медиатеки). Меню обычно стоит
// в шапке, а шапка общая для всех страниц — значки получаются на весь сайт.
// Закрыть без своей картинки — стандартный крестик.
function icons(block, ctx) {
  if (block.burgerIcons !== 'custom' || !block.iconMenu) return null;
  const size = Math.min(96, Math.max(12, parseInt(block.iconSize, 10) || 24));
  const img = (src, cls) => `<img class="menu-ico ${cls}" src="${escHtml(srcPath(src, ctx.basePrefix))}" alt="" width="${size}" height="${size}">`;
  return {
    size,
    open: img(block.iconMenu, 'menu-ico--open') + (block.iconClose ? img(block.iconClose, 'menu-ico--close') : ''),
    close: block.iconClose ? img(block.iconClose, 'menu-ico--close-panel') : CLOSE,
    frame: block.iconFrame !== false,
  };
}

function renderNodes(nodes, ctx) {
  const visible = nodes.filter(n => n.showInMenu !== false);
  if (!visible.length) return '';
  let h = '<ul>';
  for (const n of visible) {
    const tr = ctx.lang !== ctx.defaultLang && n.translations && n.translations[ctx.lang];
    const title = (tr && tr.title) || n.title;
    const sub = renderNodes(n.children, ctx);
    const active = pageSlug(n, ctx) === ctx.currentSlug ? ' class="active" aria-current="page"' : '';
    const arrow = sub ? ' <span class="menu-arrow" aria-hidden="true">▾</span>' : '';
    h += `<li${sub ? ' class="has-children"' : ''}><a href="${escHtml(pageHref(n, ctx))}"${active}>${escHtml(title)}${arrow}</a>${sub}</li>`;
  }
  return h + '</ul>';
}

// Оставляет выбранные страницы (и ветки, где выбран хотя бы один потомок).
function filterTree(nodes, selected) {
  const result = [];
  for (const n of nodes) {
    const kids = filterTree(n.children, selected);
    if (selected[n.title] || kids.length) result.push({ ...n, children: kids });
  }
  return result;
}

// Полноэкранное меню: открывается бургером (на телефоне — и в режиме «Списком»).
// Соцсети подставляет ucms.js копией модуля «Соцсети» со страницы (data-social).
function fullPanel(inner, block, ctx, ic) {
  const home = ctx.tree && ctx.tree[0];
  const brand = block.showName !== false && ctx.siteTitle
    ? `<a class="menu-full__brand" href="${escHtml(home ? pageHref(home, ctx) : `${ctx.pageBase || ''}index.html`)}">${escHtml(ctx.siteTitle)}</a>` : '';
  return '<div class="menu-full__panel" role="dialog" aria-modal="true" aria-label="Меню">' +
    `<button type="button" class="menu-full__close${ic && block.iconClose ? ' menu-full__close--custom' : ''}" aria-label="Закрыть меню"${ic ? ` style="--menu-ico:${ic.size}px"` : ''}>${ic ? ic.close : CLOSE}</button>` +
    `${brand}<div class="menu-full__nav">${inner}</div>` +
    (block.showSocial !== false ? '<div class="menu-full__social" data-social></div>' : '') + '</div>';
}

module.exports = {
  type: 'menu', label: 'Меню сайта',
  render(block, ctx) {
    let nodes = ctx.tree || [];
    if (block.pagesMode === 'selected' && block.selected && Object.keys(block.selected).length) {
      nodes = filterTree(nodes, block.selected);
    }
    const inner = renderNodes(nodes, ctx);
    if (!inner) return '';
    const full = block.burgerView !== 'dropdown';   // по умолчанию — на весь экран
    const ic = icons(block, ctx);
    const bcls = ic ? ` menu-burger--custom${ic.frame ? '' : ' menu-burger--bare'}` : '';
    const burger = `<button type="button" class="menu-burger${block.menuType === 'drop' ? ' menu-drop__toggle' : ''}${bcls}" aria-label="Меню" aria-expanded="false" aria-haspopup="dialog"${ic ? ` style="--menu-ico:${ic.size}px"` : ''}>${ic ? ic.open : BURGER}</button>`;
    if (block.menuType === 'drop') {
      return `<nav class="block block-menu menu-drop${full ? ' menu-full' : ''}">${burger}${full ? fullPanel(inner, block, ctx, ic) : `<div class="menu-drop__body">${inner}</div>`}</nav>`;
    }
    return `<nav class="block block-menu menu-list${full ? ' menu-full' : ''}">${burger}${inner}${full ? fullPanel(inner, block, ctx, ic) : ''}</nav>`;
  },
};

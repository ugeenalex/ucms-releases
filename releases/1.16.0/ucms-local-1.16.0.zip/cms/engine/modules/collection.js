'use strict';
// «Список записей» коллекции (блог, новости, портфолио, каталог): карточки или список,
// дата, анонс, обложка, фильтр по тегам записей и «Показать ещё».
// Разметка — как у «Карточек» (.block-cards-group / .card), поэтому фильтр и
// постраничный показ обслуживает тот же код ucms.js, а темы стилизуют одинаково.
const { escHtml, blockField, srcPath, pageHref, imgExtra } = require('./_shared');
const { entryExcerpt, entryCover, formatDate, validDate } = require('./_coll');

// Подписи по умолчанию на языке страницы (если в модуле не заданы свои)
const DEF = {
  all: { ru: 'Все', kk: 'Барлығы', uk: 'Усі', be: 'Усе', en: 'All', de: 'Alle', fr: 'Tous', es: 'Todos', it: 'Tutti', pt: 'Todos', pl: 'Wszystkie' },
  more: { ru: 'Показать ещё', kk: 'Тағы көрсету', uk: 'Показати ще', be: 'Паказаць яшчэ', en: 'Show more', de: 'Mehr anzeigen', fr: 'Afficher plus', es: 'Mostrar más', it: 'Mostra altro', pt: 'Mostrar mais', pl: 'Pokaż więcej' },
};
const defLabel = (key, lang) => DEF[key][String(lang || '').slice(0, 2)] || DEF[key].en;

function entryTitle(p, ctx) {
  const tr = ctx.lang !== ctx.defaultLang && p.translations && p.translations[ctx.lang];
  return (tr && tr.title) || p.title || '';
}

module.exports = {
  type: 'collection', label: 'Список записей',
  render(block, ctx) {
    const coll = ctx.collsById && ctx.collsById[block.collection];
    if (!coll || typeof ctx.entriesOf !== 'function') return '';
    let list = ctx.entriesOf(coll.id).filter(p => !ctx.page || p.id !== ctx.page.id);   // на странице записи — без неё самой
    const onlyTags = Array.isArray(block.onlyTags) ? block.onlyTags.filter(Boolean) : [];
    if (onlyTags.length) list = list.filter(p => (p.tags || []).some(t => onlyTags.includes(t)));
    const limit = parseInt(block.limit, 10) || 0;
    if (limit > 0) list = list.slice(0, limit);
    if (!list.length) {
      const empty = blockField(block, 'emptyText', ctx.lang, ctx.defaultLang);
      return empty ? `<div class="block block-coll"><p class="coll-empty">${escHtml(empty)}</p></div>` : '';
    }

    const layout = block.layout === 'list' ? 'list' : 'grid';
    const cols = layout === 'list' ? 1 : Math.min(4, Math.max(1, parseInt(block.cols, 10) || 3));
    const per = Math.max(0, parseInt(block.perPage, 10) || 0);
    const showCover = block.showCover !== false, showDate = block.showDate !== false, showExcerpt = block.showExcerpt !== false;
    const read = blockField(block, 'readLabel', ctx.lang, ctx.defaultLang) || '';

    // Теги для фильтра: только встречающиеся у выведенных записей, в порядке первого появления.
    const tagKey = new Map();
    if (block.filter) list.forEach(p => (p.tags || []).forEach(t => { if (t && !tagKey.has(t)) tagKey.set(t, `t${tagKey.size + 1}`); }));
    const filterOn = tagKey.size > 1;

    const sizes = layout === 'list' ? '(max-width: 720px) 100vw, 320px' : `(max-width: 720px) 100vw, ${Math.round(100 / cols)}vw`;
    const cards = list.map((p, i) => {
      const title = entryTitle(p, ctx);
      const href = pageHref(p, ctx);
      const cover = showCover ? entryCover(p) : '';
      const excerpt = showExcerpt ? entryExcerpt(p, ctx.lang, ctx.defaultLang) : '';
      const date = showDate && validDate(p.date) ? `<time class="card-date" datetime="${escHtml(p.date)}">${escHtml(formatDate(p.date, ctx.lang))}</time>` : '';
      const keys = filterOn ? (p.tags || []).map(t => tagKey.get(t)).filter(Boolean) : [];
      return `<article class="card card--link"${keys.length ? ` data-tags="${keys.join(' ')}"` : ''}${per && i >= per ? ' hidden' : ''}>` +
        `<a class="card-cover" href="${escHtml(href)}" aria-label="${escHtml(title)}"></a>` +
        (cover ? `<div class="card-media"><img src="${escHtml(srcPath(cover, ctx.basePrefix))}" alt="" loading="lazy"${imgExtra(cover, ctx, sizes)}></div>` : '') +
        '<div class="card-body">' + date +
        `<h3 class="card-title">${escHtml(title)}</h3>` +
        (excerpt ? `<p class="card-text">${escHtml(excerpt)}</p>` : '') +
        (read ? `<span class="card-link">${escHtml(read)}</span>` : '') + '</div></article>';
    }).join('');

    let filter = '';
    if (filterOn) {
      const all = blockField(block, 'allLabel', ctx.lang, ctx.defaultLang) || defLabel('all', ctx.lang);
      filter = '<div class="cards-filter" role="group">' +
        `<button type="button" class="cards-filter__btn is-active" data-filter="*" aria-pressed="true">${escHtml(all)}</button>` +
        [...tagKey].map(([name, key]) => `<button type="button" class="cards-filter__btn" data-filter="${key}" aria-pressed="false">${escHtml(name)}</button>`).join('') + '</div>';
    }
    const moreLabel = blockField(block, 'moreLabel', ctx.lang, ctx.defaultLang) || defLabel('more', ctx.lang);
    const more = per && list.length > per ? `<button type="button" class="coll-more">${escHtml(moreLabel)}</button>` : '';

    return `<div class="block block-cards-group block-coll coll--${layout}"${per ? ` data-page="${per}"` : ''}>${filter}` +
      `<div class="block-cards" style="--cards-cols:${cols}">${cards}</div>${more}</div>`;
  },
};

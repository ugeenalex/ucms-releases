'use strict';
const { escHtml, blockField, linkTag } = require('./_shared');
module.exports = {
  type: 'button', label: 'Кнопка',
  render(block, ctx) {
    const text = escHtml(blockField(block, 'text', ctx.lang, ctx.defaultLang) || 'Кнопка');
    const link = linkTag(block.link, ctx, text, 'btn-cta');
    // Без ссылки — просто плашка: кнопка, которая ничего не делает, путает и посетителя, и скринридер
    const inner = link !== text ? link : `<span class="btn-cta">${text}</span>`;
    return `<div class="block block-button">${inner}</div>`;
  },
};

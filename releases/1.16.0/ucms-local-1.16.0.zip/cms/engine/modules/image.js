'use strict';
const { escHtml, blockField, linkTag, srcPath, imgExtra } = require('./_shared');
module.exports = {
  type: 'image', label: 'Изображение',
  render(block, ctx) {
    if (!block.src) return '';
    const alt     = blockField(block, 'alt',     ctx.lang, ctx.defaultLang) || '';
    const caption = blockField(block, 'caption', ctx.lang, ctx.defaultLang) || '';
    const src     = srcPath(block.src, ctx.basePrefix);
    const sizes   = block.size === 'natural' ? '' : '(max-width: 720px) 100vw, min(1440px, 100vw)';
    const imgTag  = `<img src="${escHtml(src)}" alt="${escHtml(alt)}" loading="lazy"${imgExtra(block.src, ctx, sizes || undefined)}>`;
    let wrapped;
    if (block.preview) {
      wrapped = `<a href="${escHtml(src)}" class="lightbox-trigger" data-caption="${escHtml(caption)}">${imgTag}</a>`;
    } else {
      wrapped = linkTag(block.link, ctx, imgTag);
    }
    const cap = caption ? `<figcaption>${escHtml(caption)}</figcaption>` : '';
    return `<figure class="block block-image${block.size === 'natural' ? ' img-natural' : ''}">${wrapped}${cap}</figure>`;
  },
};

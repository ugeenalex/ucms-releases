'use strict';
const { escHtml, pageSlug } = require('./_shared');
module.exports = {
  type: 'lang', label: 'Выбор языка',
  render(block, ctx) {
    // Переключатель имеет смысл только для 2+ языков — тогда страницы лежат в папках языков.
    if (!ctx.languages || ctx.languages.length < 2 || !ctx.page) return '';
    const items = ctx.languages.map(l => ({
      label: l.label || l.code.toUpperCase(),
      href: `${ctx.pageBase || ''}../${l.code}/${pageSlug(ctx.page, { ...ctx, lang: l.code })}.html`,
      isCur: l.code === ctx.lang,
    }));
    if (block.langMode === 'drop') {
      const cur = items.find(i => i.isCur) || items[0];
      const opts = items.map(i => `<a href="${escHtml(i.href)}"${i.isCur ? ' class="active"' : ''}>${escHtml(i.label)}</a>`).join('');
      return `<div class="block block-langswitch langswitch-drop"><button type="button" class="langswitch-trigger" aria-haspopup="true" aria-expanded="false">${escHtml(cur.label)} ▾</button><div class="langswitch-menu">${opts}</div></div>`;
    }
    const links = items.map(i => `<a href="${escHtml(i.href)}"${i.isCur ? ' class="active"' : ''}>${escHtml(i.label)}</a>`).join('');
    return `<nav class="block block-langswitch langswitch-list">${links}</nav>`;
  },
};

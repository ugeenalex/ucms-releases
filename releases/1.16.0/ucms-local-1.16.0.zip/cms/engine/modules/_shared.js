'use strict';

function escHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// Поле блока с учётом перевода: translations[lang][field] → базовое значение.
function blockField(block, field, lang, defLang) {
  if (lang && lang !== defLang) {
    const tr = block.translations && block.translations[lang];
    if (tr && tr[field] != null && tr[field] !== '') return tr[field];
  }
  return block[field];
}

function linkKind(link) {
  const lt = link && (link.linkType || link.type);
  if (lt === 'inner') return 'internal';
  return lt || 'none';
}

// Slug страницы на языке контекста (перевод slug → базовый slug).
// Путь страницы от корня языка без .html: «about» или, у записи коллекции, «blog/post».
function pageSlug(page, ctx) {
  const tr = ctx.lang && ctx.lang !== ctx.defaultLang && page.translations && page.translations[ctx.lang];
  const slug = (tr && tr.slug) || page.slug;
  const coll = page.collection && ctx.collsById && ctx.collsById[page.collection];
  return coll ? `${coll.slug}/${slug}` : slug;
}
// Ссылка на страницу из текущей: ctx.pageBase — '../' для записей (они на уровень глубже)
function pageHref(page, ctx, anchor) {
  return `${ctx.pageBase || ''}${pageSlug(page, ctx)}.html${anchor ? `#${anchor}` : ''}`;
}

function resolveLink(link, ctx) {
  const kind = linkKind(link);
  if (kind === 'external') return link.url || null;
  if (kind === 'file') return link.file ? srcPath(link.file, ctx.basePrefix) : null;   // файл из медиатеки
  if (kind === 'internal') {
    let page = link.pageId && ctx.pagesById ? ctx.pagesById[link.pageId] : null;
    // Старые данные элементов списков: ссылка сохранялась по названию страницы (link.page)
    if (!page && link.page && ctx.pagesById) page = Object.values(ctx.pagesById).find(p => p.title === link.page) || null;
    if (!page) return null;
    const anchor = String(link.anchor || '').replace(/^#/, '').replace(/[^\p{L}\p{N}_-]+/gu, '-');
    // Якорь на этой же странице — просто #якорь (плавный переход без перезагрузки)
    if (anchor && ctx.page && page.id === ctx.page.id) return `#${anchor}`;
    return pageHref(page, ctx, anchor);
  }
  return null;
}

// Имя файла для скачивания: без метки времени, которую добавляет загрузка («1729…-price.pdf» → «price.pdf»)
function fileName(p) { return String(p || '').split('/').pop().replace(/^\d{10,}-/, '') || 'file'; }

// Доп. атрибуты ссылки: внешняя — в новой вкладке; файл — скачать (download) или открыть в новой вкладке
function linkAttrs(link) {
  const kind = linkKind(link);
  if (kind === 'external') return ' target="_blank" rel="noopener noreferrer"';
  if (kind === 'file') return link.download === false ? ' target="_blank" rel="noopener"' : ` download="${escHtml(fileName(link.file))}"`;
  return '';
}

// <a …>inner</a> или просто inner, если ссылки нет. cls — необязательный класс.
function linkTag(link, ctx, inner, cls) {
  const href = resolveLink(link, ctx);
  if (!href) return inner;
  const c = cls ? ` class="${cls}"` : '';
  return `<a${c} href="${escHtml(href)}"${linkAttrs(link)}>${inner}</a>`;
}

// Путь к загруженному файлу относительно страницы. Админка хранит '/uploads/…'
// (абсолютный от корня сервера) — на хостинге в подпапке и при file:// это ломается,
// поэтому ведущий слэш срезаем и добавляем префикс уровня ('../' для языковых папок).
function srcPath(src, basePrefix) {
  if (!src) return '';
  if (/^(?:https?:)?\/\//.test(src) || /^data:/.test(src)) return src;
  return `${basePrefix || ''}${String(src).replace(/^\/+/, '')}`;
}

// Атрибуты srcset/sizes/width/height картинки из медиатеки (генератор кладёт ctx.img)
function imgExtra(src, ctx, sizes) { return ctx && typeof ctx.img === 'function' ? ctx.img(src, sizes) : ''; }

module.exports = { imgExtra, escHtml, blockField, linkKind, linkAttrs, fileName, pageSlug, pageHref, resolveLink, linkTag, srcPath };

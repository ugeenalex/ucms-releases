'use strict';
const { blockField, resolveLink } = require('./_shared');

// Ссылки на страницы сайта в тексте хранятся как ucms:page/<id>[#якорь] —
// здесь они превращаются в адрес для текущего языка (папки, переведённые slug'и).
// Страница удалена — ссылка становится «#», чтобы не вести в никуда.
function resolvePageLinks(html, ctx) {
  return html.replace(/href="ucms:page\/([^"#]+)(?:#([^"]*))?"/g, (m, id, anchor) =>
    `href="${resolveLink({ type: 'internal', pageId: id, anchor: anchor || '' }, ctx) || '#'}"`);
}

module.exports = {
  type: 'text', label: 'Текст',
  render(block, ctx) {
    const html = blockField(block, 'html', ctx.lang, ctx.defaultLang) || '';
    if (!html.replace(/<p>\s*(<br\s*\/?>)?\s*<\/p>/gi, '').trim()) return '';   // пустой текст — без пустой обёртки
    return `<div class="block block-text">${resolvePageLinks(html, ctx)}</div>`;
  },
};

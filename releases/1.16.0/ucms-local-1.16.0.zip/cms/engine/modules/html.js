'use strict';
const { blockField } = require('./_shared');
module.exports = {
  type: 'html', label: 'HTML-код',
  render(block, ctx) {
    // Админка хранит код в 'code' (перевод — translations[lang].code); старые данные — в 'html'.
    // Пустой 'code' не должен затенять заполненный 'html' (так пропадал текст в подвале).
    const code = blockField(block, 'code', ctx.lang, ctx.defaultLang);
    const html = code || blockField(block, 'html', ctx.lang, ctx.defaultLang) || '';
    if (!String(html).trim()) return '';
    return `<div class="block block-html">${html}</div>`;
  },
};

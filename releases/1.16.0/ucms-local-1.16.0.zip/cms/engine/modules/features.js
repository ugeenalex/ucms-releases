'use strict';
// Преимущества: сетка «иконка + заголовок + текст».
const { escHtml, blockField, srcPath } = require('./_shared');
module.exports = {
  type: 'features', label: 'Преимущества',
  render(block, ctx) {
    const items = (block.items || []).filter(it => (it.title || it.text || '').trim());
    if (!items.length) return '';
    const cols = Math.min(4, Math.max(1, parseInt(block.cols, 10) || 3));
    const html = items.map(it => {
      const title = blockField(it, 'title', ctx.lang, ctx.defaultLang) || '';
      const text = blockField(it, 'text', ctx.lang, ctx.defaultLang) || '';
      return '<div class="feat-item">' +
        (it.image ? `<div class="feat-icon feat-icon--img" aria-hidden="true"><img src="${escHtml(srcPath(it.image, ctx.basePrefix))}" alt="" loading="lazy"></div>`
          : it.icon ? `<div class="feat-icon" aria-hidden="true">${escHtml(it.icon)}</div>` : '') +   // icon — эмодзи из старых версий
        `<div class="feat-body">${title ? `<h3 class="feat-title">${escHtml(title)}</h3>` : ''}${text ? `<p class="feat-text">${escHtml(text).replace(/\r?\n/g, '<br>')}</p>` : ''}</div></div>`;
    }).join('');
    const size = Math.min(160, Math.max(16, parseInt(block.iconSize, 10) || 48));
    return `<div class="block block-features${block.iconSide === 'left' ? ' feat-left' : ''}" style="--feat-cols:${cols}${size !== 48 ? `;--feat-icon:${size}px` : ''}">${html}</div>`;
  },
};

'use strict';
const { escHtml, blockField, srcPath, linkTag, imgExtra } = require('./_shared');

function captionOf(it, ctx) {
  return blockField(it, 'caption', ctx.lang, ctx.defaultLang) || it.alt || '';
}

function renderImg(it, ctx, preview, sizes) {
  const alt = captionOf(it, ctx);
  const src = srcPath(it.src, ctx.basePrefix);
  const img = `<img src="${escHtml(src)}" alt="${escHtml(alt)}" loading="lazy"${imgExtra(it.src, ctx, sizes)}>`;
  if (preview) return `<a href="${escHtml(src)}" class="lightbox-trigger" data-caption="${escHtml(alt)}">${img}</a>`;
  return linkTag(it.link, ctx, img);
}

function figcaption(it, ctx) {
  const alt = captionOf(it, ctx);
  return alt ? `<figcaption>${escHtml(alt)}</figcaption>` : '';
}

// Стрелки: стандартные (theme), свои картинки (arrowPrev/arrowNext; если задана только
// «вперёд» — «назад» её зеркальная копия) или без стрелок.
function arrowBtn(dir, block, ctx) {
  const next = dir > 0;
  const label = next ? 'Вперёд' : 'Назад';
  let inner = next ? '&#8250;' : '&#8249;';
  if (block.arrows === 'custom') {
    const own = next ? block.arrowNext : block.arrowPrev;
    const src = own || (next ? block.arrowPrev : block.arrowNext);
    const mirror = !own && src ? ' class="is-mirrored"' : '';
    if (src) inner = `<img src="${escHtml(srcPath(src, ctx.basePrefix))}" alt=""${mirror}>`;
  }
  return `<button class="gallery-${next ? 'next' : 'prev'}" data-gal-step="${dir}" type="button" aria-label="${label}">${inner}</button>`;
}

function navParts(block, count, ctx) {
  const on = count > 1 && block.arrows !== 'none';
  return { prev: on ? arrowBtn(-1, block, ctx) : '', next: on ? arrowBtn(1, block, ctx) : '', bottom: block.arrowPos === 'bottom' };
}

// Классы и переменные блока галереи-слайдера/ленты
function rootAttrs(block, extraCls) {
  const cls = ['block', 'block-gallery', extraCls];
  if (block.arrows === 'custom') cls.push('gal-arrows-custom');
  if (block.arrowPos === 'bottom') cls.push('gal-arrows-bottom');
  const size = Math.min(120, Math.max(20, parseInt(block.arrowSize, 10) || 40));
  const auto = Math.min(60, Math.max(0, parseInt(block.autoplay, 10) || 0));
  return `class="${cls.join(' ')}" data-idx="0"${auto ? ` data-autoplay="${auto}"` : ''}${size !== 40 ? ` style="--gal-arrow:${size}px"` : ''}`;
}

module.exports = {
  type: 'gallery', label: 'Галерея',
  render(block, ctx) {
    const items = (block.items || []).filter(it => it.src);
    if (!items.length) return '';
    const preview = !!block.preview;
    const mode = block.mode || 'grid';
    const h = Math.max(100, parseInt(block.height, 10) || 450);

    if (mode === 'slider') {
      const nav = navParts(block, items.length, ctx);
      const slides = items.map((it, i) =>
        `<div class="gallery-slide${i === 0 ? ' active' : ''}">${renderImg(it, ctx, preview, '100vw')}${figcaption(it, ctx)}</div>`).join('');
      const ind = items.length > 1 ? (block.indicator || 'dots') : 'none';
      const dots = ind === 'dots'
        ? `<div class="gallery-dots">${items.map((_, i) =>
            `<button class="gallery-dot${i === 0 ? ' active' : ''}" data-gal-dot="${i}" type="button" aria-label="Слайд ${i + 1}"></button>`).join('')}</div>`
        : '';
      const thumbs = ind === 'thumbs'
        ? `<div class="gallery-thumbs">${items.map((it, i) =>
            `<button class="gallery-thumb${i === 0 ? ' active' : ''}" data-gal-dot="${i}" type="button" aria-label="Слайд ${i + 1}"><img src="${escHtml(srcPath(it.src, ctx.basePrefix))}" alt="" loading="lazy"${imgExtra(it.src, ctx, '84px')}></button>`).join('')}</div>`
        : '';
      const sides = nav.bottom ? '' : nav.prev + nav.next;
      const below = nav.bottom && (nav.prev || dots) ? `<div class="gallery-nav">${nav.prev}${dots}${nav.next}</div>` : dots;
      return `<div ${rootAttrs(block, 'gallery-slider')}><div class="gallery-slides" style="height:${h}px">${slides}${sides}</div>${below}${thumbs}</div>`;
    }

    if (mode === 'scroll') {
      // Лента: ширина кадра — из CSS (80% контейнера), высота — из block.height
      const nav = navParts(block, items.length, ctx);
      const its = items.map(it =>
        `<div class="gallery-scroll-item" style="height:${h}px">${renderImg(it, ctx, preview, '80vw')}${figcaption(it, ctx)}</div>`).join('');
      const below = nav.bottom && nav.prev ? `<div class="gallery-nav">${nav.prev}${nav.next}</div>` : '';
      return `<div ${rootAttrs(block, 'gallery-carousel')}><div class="gallery-scroll" style="height:${h}px">` +
        `${nav.bottom ? '' : nav.prev + nav.next}<div class="gallery-scroll-track">${its}</div></div>${below}</div>`;
    }

    const cols = Math.min(6, Math.max(1, parseInt(block.cols, 10) || 3));
    const its = items.map(it =>
      `<div class="gallery-item"><figure>${renderImg(it, ctx, preview, `(max-width: 720px) 50vw, ${Math.round(100 / cols)}vw`)}${figcaption(it, ctx)}</figure></div>`).join('');
    // --gallery-cols-sm: сколько колонок оставить на узком экране (не больше 2 и не больше заданного)
    return `<div class="block block-gallery gallery-grid" style="--gallery-cols:${cols};--gallery-cols-sm:${Math.min(cols, 2)}">${its}</div>`;
  },
};

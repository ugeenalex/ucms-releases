@echo off
chcp 65001 >nul
title UCMS
echo Запуск UCMS... Чтобы остановить сервер, закройте это окно.
node "%~dp0start.js" %*
if errorlevel 1 pause

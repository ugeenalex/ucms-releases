# Веб-версия UCMS

> Хостинг с панелью Plesk или cPanel (Node.js через Passenger) — см. `docs/PLESK.md`.
> Здесь — свой сервер: VPS или WSL, nginx, pm2.

Тот же движок, запущенный на сервере. Включается переменной `UCMS_MODE=web`
(или скриптом `start-web.sh`).

| | Локальная версия | Веб-версия |
|---|---|---|
| Сайтов | много (список проектов) | один на установку |
| Вход | нет (только этот компьютер) | логин и пароль |
| Где сайт | `/output/`, на хостинг — по FTP | с корня адреса: `https://example.com/` |
| «Опубликовать» | FTP | собрать сайт — посетители сразу видят новую версию |
| ИИ-перевод | есть (ключ в `db.json`) | нет — ключ в браузер не отдаётся и из него не принимается |
| Обзор папок, внешний редактор | есть | нет |
| Админка | `/admin/` | `/admin/` (без входа — страница входа) |

Данные сайта — обычная папка проекта (`db.json`, `uploads/`, `themes/`…): её можно
перенести между локальной и веб-версией как есть или через «Сайт и модули → Перенос».

## Защита

- Первый запуск — мастер установки (`/admin/`): код из файла `setup-code.txt` в папке
  приложения, проверка сервера, владелец, папка публикации. Без кода мастер не пускает.
- Пользователи: владелец (всё) и пользователи с отмеченными правами — «Настройки сайта → UCMS».
- Пароли хранятся как хеш (scrypt) в `~/.ucms/auth.json`, вход — cookie `HttpOnly`,
  сессия живёт 14 дней с последнего действия (не больше 60 дней).
- 5 неверных паролей с одного адреса — пауза 15 минут.
- Запросы, меняющие данные, принимаются только со страниц этого же сайта (CSRF).
- Загрузка: только картинки, видео, PDF, шрифты; файл до 50 МБ (`UCMS_UPLOAD_MB`).
  SVG по прямой ссылке открывается без выполнения скриптов.
- Одновременная работа: если сайт изменили в другой вкладке или на другом устройстве,
  сохранение не затрёт чужие правки — админка спросит, что делать.

Сменить пароль: в админке или `./start-web.sh passwd` (входы этого пользователя сбрасываются).
Журнал входов — `~/.ucms/journal.log` и «Пользователи → Журнал входов».

## Настройки (переменные окружения)

| Переменная | По умолчанию | |
|---|---|---|
| `PORT` | `3000` | порт |
| `HOST` | `127.0.0.1` | `0.0.0.0` — принимать запросы из сети (без nginx, для проверки) |
| `UCMS_SITE` | `~/.ucms/site` | папка сайта; новая папка — новый пустой сайт |
| `UCMS_PUBLISH_DIR`, `UCMS_SITE_URL` | из мастера | папка публикации и адрес сайта (главнее мастера) |
| `UCMS_HOME` | `~/.ucms` | где лежат пароль, сессии, палитры |
| `UCMS_UPLOAD_MB` | `50` | предел одного загружаемого файла |
| `UCMS_TRUST_PROXY` | — | `1` за nginx: адрес посетителя и протокол из его заголовков |
| `UCMS_SECURE` | — | `1` — cookie входа только по HTTPS |
| `UCMS_ADMIN_USER`, `UCMS_ADMIN_PASSWORD` | — | владелец без мастера (контейнеры); с `UCMS_RESET_PASSWORD=1` — сброс пароля |

---

## Обкатка на компьютере: WSL (Windows)

Внутри WSL всё как на настоящем Linux-сервере (VPS): те же команды, те же пути.

### Шаг 0. Код и Node.js

Node.js 18+ (`node -v`). Проект кладите в домашнюю папку WSL, а не на диск `C:`
(`/mnt/c/...` в WSL работает заметно медленнее):

```bash
# вариант 1 — из архива, распакованного в Загрузки Windows
cp -r /mnt/c/Users/<имя>/Downloads/UCMS ~/UCMS

# вариант 2 — из GitHub
git clone https://github.com/ugeenalex/UCMS.git ~/UCMS
cd ~/UCMS && git checkout ucms-1.6
```

Папки WSL видны в Проводнике: `\\wsl$\Ubuntu\home\<имя>\`.

### Шаг 1. Запуск на этом компьютере

```bash
cd ~/UCMS/cms
bash start-web.sh passwd     # логин и пароль (ввод пароля не отображается)
bash start-web.sh            # Ctrl+C — остановить
```

В браузере Windows: сайт — `http://localhost:3000/`, админка — `http://localhost:3000/admin/`.
До первой публикации на сайте заглушка «Сайт ещё не опубликован».

Что проверить: вход и выход, неверный пароль, «Публикация → Опубликовать изменения»,
сайт на `/`, две вкладки админки одновременно (правка в одной, сохранение в другой).

Перенести свой сайт из локальной версии: в локальной админке «Сайт и модули →
Перенос → Весь сайт (.zip)», в веб-версии — там же «Загрузить».

Если `localhost:3000` из Windows не открывается — запустите с `HOST=0.0.0.0 bash start-web.sh`.

### Шаг 2. С телефона по домашней сети

```bash
HOST=0.0.0.0 bash start-web.sh
```

WSL сидит за своей виртуальной сетью, поэтому Windows нужно пробросить порт.
Команды — в PowerShell **от имени администратора**.

Вариант А (Windows 11 22H2+): «зеркальная» сеть WSL. В файле
`%UserProfile%\.wslconfig`:

```ini
[wsl2]
networkingMode=mirrored
```

затем `wsl --shutdown`, снова открыть Ubuntu и разрешить входящие на порт 3000:

```powershell
New-NetFirewallHyperVRule -Name UCMS -DisplayName "UCMS 3000" -Direction Inbound -VMCreatorId '{40E0AC32-46A5-438A-A0B2-2B479E8F2E90}' -Protocol TCP -LocalPorts 3000
```

Вариант Б (любая Windows 10/11): проброс порта. Адрес WSL — `hostname -I` в Ubuntu
(меняется после перезагрузки — тогда команду повторить):

```powershell
netsh interface portproxy add v4tov4 listenport=3000 listenaddress=0.0.0.0 connectport=3000 connectaddress=<адрес WSL>
netsh advfirewall firewall add rule name="UCMS 3000" dir=in action=allow protocol=TCP localport=3000
```

Адрес компьютера в сети — `ipconfig` в Windows (IPv4, обычно `192.168.x.x`).
С телефона: `http://192.168.x.x:3000/admin/`.

Убрать после проверки: `netsh interface portproxy delete v4tov4 listenport=3000 listenaddress=0.0.0.0`
и правило брандмауэра «UCMS 3000».

### Шаг 3. Как на сервере: pm2 + nginx

```bash
# pm2 — держит сервер запущенным, перезапускает при сбое
sudo npm install -g pm2
cd ~/UCMS/cms
pm2 start ucms-web.config.js
pm2 logs ucms                 # журнал; pm2 restart ucms — после обновления движка

# nginx — принимает запросы на порт 80 и передаёт UCMS
sudo apt install -y nginx
sudo cp docs/nginx-ucms.conf /etc/nginx/sites-available/ucms
sudo ln -s /etc/nginx/sites-available/ucms /etc/nginx/sites-enabled/ucms
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo service nginx restart
```

Теперь сайт открывается без порта: `http://localhost/`, админка — `http://localhost/admin/`.

Автозапуск pm2 после перезагрузки (`pm2 startup`) в WSL работает, только если в WSL
включён systemd (`/etc/wsl.conf` → `[boot] systemd=true`). Для обкатки не обязательно.

## На настоящем сервере (VPS)

То же, что в шаге 3, плюс:

1. Домен → A-запись на IP сервера; в `nginx-ucms.conf` — `server_name example.com;`.
2. HTTPS: `sudo apt install certbot python3-certbot-nginx && sudo certbot --nginx -d example.com`.
3. В `ucms-web.config.js` включить `UCMS_SECURE: '1'`, `pm2 restart ucms`.
4. `pm2 startup` и `pm2 save` — запуск после перезагрузки.
5. Резервные копии: папка сайта (`UCMS_SITE`) целиком; история версий и копии
   «Перенос» лежат в ней же.

Нужен VPS или хостинг с Node.js **и постоянным диском**: данные — файлы. Платформы,
которые стирают диск при перезапуске, без подключённого постоянного диска не подходят.

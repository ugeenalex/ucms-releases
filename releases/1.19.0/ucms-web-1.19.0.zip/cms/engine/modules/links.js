'use strict';
/**
 * «Ссылки» — список ссылок для подвала, боковых колонок и панелей меню.
 *
 * Источник: подстраницы раздела (block.parent — id страницы, пусто — страницы верхнего уровня; все или
 * выбранные — block.pagesMode / block.selected[id]) или только свои пункты (block.source === 'manual').
 * Свои пункты (block.items) добавляются после страниц. Настройки пунктов-страниц — block.pageOpts
 * [{ page: id, desc, image, icon, badge, bold, size, radius, shape }]. Описание страницы по умолчанию — её SEO-описание.
 * Значок: скругление в px (block.radius, пусто — как в теме) или форма block.shape: oval | rhombus | triangle | star;
 * у пункта — свои radius / shape (пусто — общие). Старое radius: 'circle' читается как форма «Овал».
 * Вид: list (список), rich (значок + название + описание), tiles (плитки с картинкой сверху).
 */
const { escHtml, blockField, pageHref, pageSlug, resolveLink, linkAttrs, srcPath } = require('./_shared');

const RADIUS = r => (r === 'circle' ? '50%' : r === 'theme' || r == null || r === '' || isNaN(parseInt(r, 10)) ? 'var(--radius, 10px)' : `${Math.min(200, Math.max(0, parseInt(r, 10)))}px`);
const SHAPES = ['oval', 'rhombus', 'triangle', 'star'];
const shapeOf = o => (SHAPES.includes(o.shape) ? o.shape : o.shape !== 'round' && o.radius === 'circle' ? 'oval' : '');   // 'round' — обычная
const SIZE = (v, def) => Math.min(200, Math.max(12, parseInt(v, 10) || def));

function findNode(nodes, id) {
  for (const n of nodes || []) {
    if (n.id === id) return n;
    const f = findNode(n.children, id);
    if (f) return f;
  }
  return null;
}
const trOf = (n, ctx) => (ctx.lang !== ctx.defaultLang && n.translations && n.translations[ctx.lang]) || null;

module.exports = {
  type: 'links', label: 'Ссылки',
  render(block, ctx) {
    const items = Array.isArray(block.items) ? block.items : [];
    const byPage = {};
    (Array.isArray(block.pageOpts) ? block.pageOpts : []).forEach(it => { if (it && it.page) byPage[it.page] = it; });
    const rows = [];
    let parent = null;
    if (block.source !== 'manual') {
      parent = block.parent ? findNode(ctx.tree, block.parent) : null;
      let pages = block.parent ? (parent ? parent.children : []) : (ctx.tree || []);
      if (block.pagesMode === 'selected') pages = pages.filter(p => block.selected && block.selected[p.id]);
      pages.forEach(p => {
        const o = byPage[p.id] || {}, tr = trOf(p, ctx), seo = p.seo || {};
        rows.push({
          title: (tr && tr.title) || p.title,
          href: pageHref(p, ctx), ext: '',
          active: pageSlug(p, ctx) === ctx.currentSlug,
          desc: blockField(o, 'desc', ctx.lang, ctx.defaultLang) || (tr && tr.description) || seo.description || '',
          o,
        });
      });
    }
    items.filter(it => it).forEach(it => {
      const title = blockField(it, 'title', ctx.lang, ctx.defaultLang) || '';
      if (!title.trim()) return;
      const href = resolveLink(it.link, ctx);
      rows.push({ title, href, ext: href ? linkAttrs(it.link) : '', active: false, desc: blockField(it, 'desc', ctx.lang, ctx.defaultLang) || '', o: it });
    });
    if (!rows.length) return '';

    const view = ['rich', 'tiles'].includes(block.view) ? block.view : 'list';
    const media = !!block.media;   // значки и картинки включаются для всего модуля
    const showDesc = block.showDesc !== false;
    const size = SIZE(block.iconSize, view === 'tiles' ? 120 : 40);
    const cols = Math.min(4, Math.max(1, parseInt(block.cols, 10) || 1));
    const list = rows.map(r => {
      const o = r.o || {};
      let m = '';
      if (media && (o.image || o.icon)) {
        const own = [], shape = o.shape === 'round' ? '' : shapeOf(o) || shapeOf(block);   // 'round' у пункта — обычная, даже если общая — фигура
        if (o.size) own.push(`--links-ico:${SIZE(o.size, size)}px`);
        if (o.radius != null && o.radius !== '') own.push(`--links-r:${RADIUS(o.radius)}`);
        m = `<span class="links-media${o.image ? '' : ' links-media--emoji'}${shape ? ` links-media--${shape}` : ''}"${own.length ? ` style="${own.join(';')}"` : ''} aria-hidden="true">` +
          (o.image ? `<img src="${escHtml(srcPath(o.image, ctx.basePrefix))}" alt="" loading="lazy">` : escHtml(o.icon)) + '</span>';
      } else if (media && view !== 'list') m = '<span class="links-media links-media--empty" aria-hidden="true"></span>';
      const badge = blockField(o, 'badge', ctx.lang, ctx.defaultLang);
      const body = `<span class="links-body"><span class="links-name">${escHtml(r.title)}${badge ? `<span class="links-badge">${escHtml(badge)}</span>` : ''}</span>` +
        (showDesc && r.desc ? `<span class="links-desc">${escHtml(r.desc).replace(/\r?\n/g, '<br>')}</span>` : '') + '</span>';
      const cls = ['links-item'];
      if (o.bold) cls.push('is-bold');
      if (r.active) cls.push('is-active');
      const inner = m + body;
      return `<li class="${cls.join(' ')}">` + (r.href
        ? `<a class="links-a" href="${escHtml(r.href)}"${r.ext}${r.active ? ' aria-current="page"' : ''}>${inner}</a>`
        : `<span class="links-a">${inner}</span>`) + '</li>';
    }).join('');

    // заголовок: свой, название раздела (auto) или нет
    const heading = block.heading || 'auto';
    let title = '';
    if (heading === 'custom') title = blockField(block, 'title', ctx.lang, ctx.defaultLang) || '';
    else if (heading === 'auto' && parent) title = (trOf(parent, ctx) || {}).title || parent.title;
    const moreText = blockField(block, 'moreText', ctx.lang, ctx.defaultLang);
    const moreLink = block.more && block.more.link;   // «Показать все →»: block.showMore, текст — block.moreText
    const moreHref = block.showMore && moreText ? resolveLink(moreLink, ctx) : null;
    const vars = [`--links-cols:${cols}`, `--links-ico:${size}px`, `--links-r:${RADIUS(block.radius)}`];
    return `<nav class="block block-links links--${view}" style="${vars.join(';')}"${title ? '' : ' aria-label="Ссылки"'}>` +
      (title ? `<div class="links-title">${escHtml(title)}</div>` : '') +
      `<ul class="links-list">${list}</ul>` +
      (moreHref ? `<a class="links-more" href="${escHtml(moreHref)}"${linkAttrs(moreLink)}>${escHtml(moreText)}</a>` : '') + '</nav>';
  },
};

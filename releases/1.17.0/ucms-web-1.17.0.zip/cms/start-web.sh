#!/usr/bin/env bash
# UCMS — веб-версия (Linux, WSL, VPS). Подробно: docs/WEB.md
#   ./start-web.sh           запуск (сайт — http://localhost:3000/, админка — /admin/)
#   ./start-web.sh passwd    задать логин и пароль
# Настройки — переменные окружения: PORT, HOST, UCMS_SITE (папка сайта), UCMS_HOME,
# UCMS_UPLOAD_MB, UCMS_TRUST_PROXY=1 (за nginx), UCMS_SECURE=1 (только HTTPS).
cd "$(dirname "$0")" || exit 1
export UCMS_MODE=web
exec node engine/server.js "$@"

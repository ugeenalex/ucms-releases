'use strict';
// UCMS — файл запуска веб-версии для хостинга с Node.js (Plesk, cPanel: Passenger).
// В панели хостинга: «Корневой каталог приложения» — папка cms, «Файл запуска» — app.js.
// Настройки — переменные окружения приложения (docs/PLESK.md): UCMS_PUBLISH_DIR, UCMS_SITE_URL,
// UCMS_ADMIN_USER / UCMS_ADMIN_PASSWORD (первый вход) и другие.
process.env.UCMS_MODE = process.env.UCMS_MODE || 'web';
// Passenger сам перезапускает приложение после выхода процесса — значит, обновление движка
// может завершить процесс (код 75), как при запуске через start.js.
if (typeof PhusionPassenger !== 'undefined' || process.env.PASSENGER_APP_ENV) {
  process.env.UCMS_LAUNCHER = '1';
  process.env.UCMS_PASSENGER = '1';
  // запросы приходят через прокси хостинга (nginx/Apache): адрес посетителя и https — из его заголовков
  if (process.env.UCMS_TRUST_PROXY === undefined) process.env.UCMS_TRUST_PROXY = '1';
}
require('./engine/server.js');

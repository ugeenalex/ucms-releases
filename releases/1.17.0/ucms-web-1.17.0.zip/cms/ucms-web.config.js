// Запуск веб-версии через pm2 (перезапуск при сбое и после перезагрузки сервера).
//   pm2 start ucms-web.config.js      pm2 logs ucms      pm2 restart ucms
// Подробно — docs/WEB.md, шаг 3.
module.exports = {
  apps: [{
    name: 'ucms',
    script: 'engine/server.js',
    cwd: __dirname,
    max_memory_restart: '300M',
    env: {
      UCMS_MODE: 'web',
      PORT: '3000',
      HOST: '127.0.0.1',          // снаружи — только через nginx
      UCMS_TRUST_PROXY: '1',      // адрес посетителя и https — из заголовков nginx
      // UCMS_SITE: '/home/<пользователь>/ucms-site',   // папка сайта (по умолчанию ~/.ucms/site)
      // UCMS_SECURE: '1',        // когда сайт работает только по HTTPS
    },
  }],
};

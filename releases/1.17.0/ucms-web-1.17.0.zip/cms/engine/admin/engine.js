/* ============================================================
   «Настройки сайта → UCMS» (веб-версия): версия движка, обновление и откат,
   смена своего пароля, двухфакторный вход (у каждого — свой, по желанию), пользователи и журнал входов (только владелец).
   API пользователей: GET /api/users, POST /api/users/add | role | password | remove.
   Локальная версия делает то же на странице «Проекты» (projects.js).
   API: GET /api/update, POST /api/update/check | settings | apply | rollback.
   ============================================================ */
(function () {
  'use strict';
  var App = window.App;
  var E = { st: null, busy: '', err: '', notes: false, users: null, uerr: '', journal: false, keys: null, kerr: '', token: '', tf: null, tfSetup: null, tfCodes: null, tferr: '' };
  function isOwner() { return (App.webInfo || {}).role === 'owner'; }

  function K() { return App.kit; }
  function esc(s) { return K().esc(s); }
  function fmt(ms) {
    if (!ms) return '';
    var d = new Date(ms), p = function (n) { return String(n).padStart(2, '0'); };
    return p(d.getDate()) + '.' + p(d.getMonth() + 1) + '.' + d.getFullYear() + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }
  function rerender() { if (App._state.view === 'engine') App.renderView(); }
  // описание релиза (markdown из CHANGELOG) → безопасный HTML: списки, **жирный**, `код`
  function notesHTML(md) {
    var inline = function (s) { return esc(s).replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/`([^`]+)`/g, '<code>$1</code>'); };
    var out = [], list = null, item = null;
    String(md || '').replace(/\r/g, '').split('\n').forEach(function (line) {
      var li = /^\s*[-*]\s+(.*)$/.exec(line);
      if (li) { if (!list) { list = []; out.push(list); } item = [li[1]]; list.push(item); return; }
      if (/^\s+\S/.test(line) && item) { item.push(line.trim()); return; }
      list = null; item = null;
      if (line.trim()) out.push(line.replace(/^#+\s*/, ''));
    });
    return out.map(function (b) {
      return Array.isArray(b) ? '<ul>' + b.map(function (it) { return '<li>' + inline(it.join(' ')) + '</li>'; }).join('') + '</ul>' : '<p>' + inline(b) + '</p>';
    }).join('');
  }

  App.loadEngine = function () {
    if (isOwner()) App.loadUsers();
    if (App.can('keys')) App.loadKeys();
    App.loadTwofa();
    return App.api.get('/api/update').then(function (d) { E.st = d; rerender(); }).catch(function (e) { E.err = e.message; rerender(); });
  };

  // ── Ключи доступа: подключение локальной UCMS к этому сайту ──
  App.loadKeys = function () {
    return App.api.get('/api/auth/keys').then(function (d) { E.keys = d.keys; rerender(); }).catch(function (e) { E.kerr = e.message; rerender(); });
  };
  App.keyCreate = function () {
    var n = document.getElementById('key-name'), p = document.getElementById('key-pass');
    var c = document.getElementById('key-code');
    var name = n ? n.value.trim() : '', pass = p ? p.value : '', code = c ? c.value.trim() : '';
    if (!name) { E.kerr = _t('Назовите ключ — например, по имени компьютера'); return rerender(); }
    if (!pass) { E.kerr = _t('Введите свой пароль'); return rerender(); }
    if (c && !code) { E.kerr = _t('Введите код из приложения'); return rerender(); }
    E.kerr = '';
    App.api.post('/api/auth/keys/create', { name: name, password: pass, code: code }).then(function (d) { E.keys = d.keys; E.token = d.token; rerender(); })
      .catch(function (e) { E.kerr = e.message; rerender(); });
  };
  App.keyRevoke = function (id, name) {
    if (!confirm(_t('Отозвать ключ') + ' «' + name + '»? ' + _t('Подключённая с ним локальная UCMS потеряет доступ.'))) return;
    App.api.post('/api/auth/keys/revoke', { id: id }).then(function (d) { E.keys = d.keys; rerender(); }).catch(function (e) { E.kerr = e.message; rerender(); });
  };
  App.keyCopy = function () {
    var el = document.getElementById('key-token'); if (!el) return;
    el.select();
    (navigator.clipboard ? navigator.clipboard.writeText(E.token) : Promise.reject()).then(function () { App.toast && App.toast(_t('Ключ скопирован')); }, function () { document.execCommand('copy'); });
  };
  App.keyDone = function () { E.token = ''; rerender(); };
  function keysPanel() {
    var k = K(), UI = k.UI;
    var html = '<section class="ad-panel"><div class="ad-panel__t">' + _t('Ключи доступа') + '</div>' +
      '<span class="ad-f__hint">' + _t('Подключение локальной UCMS к этому сайту: «Проекты → Добавить существующий → Сайт UCMS». Ключ действует с вашей ролью, пока вы его не отзовёте.') + '</span>';
    if (E.token) {
      return html + '<div class="key-new"><b>' + _t('Ключ создан. Скопируйте его сейчас — повторно он не показывается.') + '</b>' +
        '<input id="key-token" class="ad-in ad-in--mono" readonly value="' + k.escAttr(E.token) + '" onclick="this.select()">' +
        '<div class="ad-btnrow">' + UI.btn(_t('Копировать'), 'App.keyCopy()', { variant: 'dark', sm: true }) + UI.btn(_t('Готово'), 'App.keyDone()', { sm: true }) + '</div></div></section>';
    }
    var keys = E.keys || [];
    html += keys.length ? '<div class="usr-list">' + keys.map(function (x) {
      return '<div class="usr-row"><div class="usr-row__n"><b>' + esc(x.name) + '</b><small>' + _t('создан') + ' ' + fmt(Date.parse(x.createdAt)) +
        ' · ' + (x.seen ? _t('работал') + ' ' + fmt(x.seen) : _t('ещё не использовался')) + '</small></div>' +
        k.ib('del', _t('Отозвать'), 'App.keyRevoke(' + k.jsArg(x.id) + ',' + k.jsArg(x.name) + ')', { danger: true }) + '</div>';
    }).join('') + '</div>' : (E.keys ? '<p class="ad-f__hint">' + _t('Ключей пока нет') + '</p>' : '');
    html += '<div class="usr-add usr-add--key' + (E.tf && E.tf.enabled ? ' is-2fa' : '') + '"><input id="key-name" class="ad-in" placeholder="' + k.escAttr(_t('Название, например «Ноутбук»')) + '" maxlength="60" autocomplete="off">' +
      '<input id="key-pass" class="ad-in" type="password" placeholder="' + k.escAttr(_t('Ваш пароль')) + '" autocomplete="current-password">' +
      (E.tf && E.tf.enabled ? '<input id="key-code" class="ad-in ad-in--mono" inputmode="numeric" autocomplete="one-time-code" maxlength="12" placeholder="' + k.escAttr(_t('Код')) + '">' : '') +
      UI.btn(_t('Создать ключ'), 'App.keyCreate()', { variant: 'dark' }) + '</div>';
    if (E.kerr) html += '<div class="ad-pub__msg is-err">' + esc(E.kerr) + '</div>';
    return html + '</section>';
  }

  // ── Двухфакторный вход (своя учётная запись) ──
  App.loadTwofa = function () {
    return App.api.get('/api/auth/2fa').then(function (d) { E.tf = d; rerender(); }).catch(function (e) { E.tferr = e.message; rerender(); });
  };
  function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
  function tfCall(url, body) {
    E.tferr = '';
    return App.api.post(url, body).catch(function (e) { E.tferr = e.message; rerender(); throw e; });
  }
  App.tfBegin = function () {
    var p = val('tf-pass');
    if (!p) { E.tferr = _t('Введите свой пароль'); return rerender(); }
    tfCall('/api/auth/2fa/begin', { password: p }).then(function (d) { E.tfSetup = d; rerender(); var c = document.getElementById('tf-code'); if (c) c.focus(); }, function () {});
  };
  App.tfCancel = function () { E.tfSetup = null; E.tferr = ''; rerender(); };
  App.tfEnable = function () {
    var c = val('tf-code').trim();
    if (!c) { E.tferr = _t('Введите код из приложения'); return rerender(); }
    tfCall('/api/auth/2fa/enable', { code: c }).then(function (d) { E.tfSetup = null; E.tfCodes = d.recovery; E.tf = d; rerender(); App.loadKeys && App.can('keys') && App.loadKeys(); }, function () {});
  };
  // Выключить / новые резервные коды — пароль и код
  App.tfAction = function (what) {
    var p = val('tf-pass2'), c = val('tf-code2').trim();
    if (!p || !c) { E.tferr = _t('Введите пароль и код из приложения (или резервный код)'); return rerender(); }
    if (what === 'disable' && !confirm(_t('Выключить двухфакторный вход? Для входа снова будет достаточно пароля.'))) return;
    tfCall('/api/auth/2fa/' + what, { password: p, code: c }).then(function (d) {
      E.tf = d; if (d.recovery) E.tfCodes = d.recovery;
      if (what === 'disable') App.toast && App.toast(_t('Двухфакторный вход выключен'));
      rerender();
    }, function () {});
  };
  App.tfForget = function () {
    if (!confirm(_t('Забыть все запомненные браузеры? При следующем входе в каждом из них понадобится код.'))) return;
    tfCall('/api/auth/2fa/forget', {}).then(function (d) { E.tf = d; d.thisBrowser = false; rerender(); App.toast && App.toast(_t('Браузеры забыты')); }, function () {});
  };
  function codesText() {
    return 'UCMS — ' + _t('резервные коды двухфакторного входа') + '\n' + location.host + ' · ' + (App._state.user || '') + '\n' +
      _t('Каждый код действует один раз.') + '\n\n' + (E.tfCodes || []).join('\n') + '\n';
  }
  App.tfCopy = function () {
    (navigator.clipboard ? navigator.clipboard.writeText(codesText()) : Promise.reject()).then(function () { App.toast && App.toast(_t('Коды скопированы')); }, function () {});
  };
  App.tfDownload = function () {
    var a = document.createElement('a'), url = URL.createObjectURL(new Blob([codesText()], { type: 'text/plain;charset=utf-8' }));
    a.href = url; a.download = 'ucms-recovery-codes-' + location.hostname + '.txt';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  };
  App.tfCodesDone = function () { E.tfCodes = null; rerender(); };
  function twofaPanel() {
    var k = K(), UI = k.UI, t = E.tf;
    var html = '<section class="ad-panel"><div class="ad-panel__t">' + _t('Двухфакторный вход') + '</div>';
    var msg = E.tferr ? '<div class="ad-pub__msg is-err">' + esc(E.tferr) + '</div>' : '';
    if (!t) return html + '<p class="ad-f__hint">' + (E.tferr ? esc(E.tferr) : _t('Загрузка…')) + '</p></section>';
    if (E.tfCodes) {   // резервные коды — один раз, сразу после включения или замены
      return html + '<div class="key-new"><b>' + _t('Сохраните резервные коды — они показываются один раз.') + '</b>' +
        '<span class="ad-f__hint">' + _t('Код нужен, если телефона нет под рукой. Каждый действует один раз. Храните их не в телефоне — например, в менеджере паролей или распечатанными.') + '</span>' +
        '<div class="tf-codes">' + E.tfCodes.map(function (c) { return '<code>' + esc(c) + '</code>'; }).join('') + '</div>' +
        '<div class="ad-btnrow">' + UI.btn(_t('Копировать'), 'App.tfCopy()', { sm: true }) + UI.btn(_t('Скачать .txt'), 'App.tfDownload()', { sm: true }) +
        UI.btn(_t('Я сохранил коды'), 'App.tfCodesDone()', { sm: true, variant: 'dark' }) + '</div></div></section>';
    }
    if (E.tfSetup) {
      var s = E.tfSetup, sec = s.secret.replace(/(.{4})/g, '$1 ').trim();
      return html + '<span class="ad-f__hint">' + _t('1. Отсканируйте QR-код приложением-аутентификатором: Google Authenticator, Microsoft Authenticator, Яндекс Ключ, 1Password, Bitwarden…') + '</span>' +
        '<div class="tf-setup"><div class="tf-qr">' + s.qr + '</div><div class="tf-setup__side">' +
        '<span class="ad-f__hint">' + _t('Не сканируется — введите ключ вручную:') + '</span><code class="tf-secret">' + esc(sec) + '</code></div></div>' +
        '<div class="ad-f"><label class="ad-f__l" for="tf-code">' + _t('2. Введите код из приложения') + '</label>' +
        '<input id="tf-code" class="ad-in ad-in--mono tf-code" inputmode="numeric" autocomplete="one-time-code" maxlength="7" placeholder="000000" onkeydown="if(event.key===\'Enter\')App.tfEnable()"></div>' + msg +
        '<div class="ad-btnrow">' + UI.btn(_t('Включить'), 'App.tfEnable()', { variant: 'dark' }) + UI.btn(_t('Отмена'), 'App.tfCancel()', { variant: 'line' }) + '</div></section>';
    }
    if (!t.enabled) {
      return html + '<span class="ad-f__hint">' + _t('Кроме пароля при входе понадобится код из приложения на телефоне. Даже если пароль узнают, без телефона в админку не войти.') + '</span>' +
        '<div class="tf-row"><input id="tf-pass" class="ad-in" type="password" placeholder="' + k.escAttr(_t('Ваш пароль')) + '" autocomplete="current-password" onkeydown="if(event.key===\'Enter\')App.tfBegin()">' +
        UI.btn(_t('Настроить'), 'App.tfBegin()', { variant: 'dark' }) + '</div>' + msg + '</section>';
    }
    html += '<div class="tf-on">' + k.ico('check', 16) + '<span><b>' + _t('Включён') + '</b> · ' + fmt(Date.parse(t.enabledAt)) + '</span></div>' +
      '<span class="ad-f__hint">' + _t('Резервных кодов осталось') + ': ' + t.recoveryLeft + (t.recoveryLeft <= 3 ? ' — ' + _t('создайте новые') : '') + '. ' +
      _t('Запомненных браузеров') + ': ' + t.trusted + (t.thisBrowser ? ' (' + _t('включая этот') + ')' : '') + '.</span>';
    if (t.trusted) html += '<div>' + UI.btn(_t('Забыть запомненные браузеры'), 'App.tfForget()', { sm: true, variant: 'line' }) + '</div>';
    html += '<div class="ad-f__l" style="margin-top:4px">' + _t('Новые резервные коды или выключение — пароль и код') + '</div>' +
      '<div class="usr-add usr-add--3"><input id="tf-pass2" class="ad-in" type="password" placeholder="' + k.escAttr(_t('Ваш пароль')) + '" autocomplete="current-password">' +
      '<input id="tf-code2" class="ad-in ad-in--mono" inputmode="numeric" autocomplete="one-time-code" maxlength="12" placeholder="' + k.escAttr(_t('Код')) + '">' +
      UI.btn(_t('Новые коды'), 'App.tfAction(\'recovery\')', { variant: 'line' }) + '</div>' + msg +
      '<div>' + UI.btn(_t('Выключить двухфакторный вход'), 'App.tfAction(\'disable\')', { sm: true, variant: 'line', cls: 'tf-danger' }) + '</div>';
    return html + '</section>';
  }

  // ── Пользователи ──
  App.loadUsers = function () {
    return App.api.get('/api/users').then(function (d) { E.users = d; E.uerr = ''; rerender(); }).catch(function (e) { E.uerr = e.message; rerender(); });
  };
  function usersCall(url, body, okMsg) {
    E.uerr = '';
    return App.api.post(url, body).then(function () { if (okMsg) App.toast && App.toast(okMsg); return App.loadUsers(); })
      .catch(function (e) { E.uerr = e.message; rerender(); });
  }
  // Права: что можно пользователю (владельцу — всё). Порядок и названия — как в настройках.
  var PERMS = [
    ['content', 'Страницы и записи', 'страницы, записи коллекций, шаблоны секций'],
    ['layout', 'Шапка и подвал', ''],
    ['media', 'Медиафайлы', 'загрузка, замена и удаление файлов'],
    ['design', 'Оформление', 'тема, стиль проекта, CSS'],
    ['settings', 'Настройки сайта', 'название, языки, модули, SEO, favicon'],
    ['publish', 'Публикация', 'кнопка «Опубликовать»'],
    ['history', 'Восстановление версий', 'вернуть версию из «Истории»'],
    ['transfer', 'Перенос и резервные копии', 'скачать и загрузить сайт архивом'],
    ['keys', 'Ключи доступа', 'работа с компьютера через локальную UCMS'],
  ];
  var NEW_PERMS = ['content', 'media', 'publish'];   // отмечено по умолчанию у нового пользователя
  function permChecks(prefix, cur, onchange, disabled) {
    return '<div class="usr-perms">' + PERMS.map(function (p) {
      var on = cur.indexOf(p[0]) >= 0;
      return '<label class="usr-perm' + (disabled ? ' is-off' : '') + '"><input type="checkbox" data-perm="' + p[0] + '"' + (on ? ' checked' : '') + (disabled ? ' disabled' : '') +
        (onchange ? ' onchange="' + onchange + '"' : '') + '><span><b>' + _t(p[1]) + '</b>' + (p[2] ? '<small>' + _t(p[2]) + '</small>' : '') + '</span></label>';
    }).join('') + '</div>';
  }
  function readChecks(root) { return Array.prototype.map.call(root.querySelectorAll('input[data-perm]:checked'), function (i) { return i.getAttribute('data-perm'); }); }
  function permSummary(u) {
    if (u.role === 'owner') return _t('полный доступ');
    var names = PERMS.filter(function (p) { return (u.perms || []).indexOf(p[0]) >= 0; }).map(function (p) { return _t(p[1]).toLowerCase(); });
    return names.length ? names.join(', ') : _t('только просмотр');
  }
  App.userAdd = function () {
    var v = function (id) { var el = document.getElementById(id); return el ? el.value : ''; };
    var u = v('usr-login').trim(), p = v('usr-pass'), box = document.getElementById('usr-new');
    var owner = !!(document.getElementById('usr-owner') || {}).checked;
    if (!u) { E.uerr = _t('Введите логин'); return rerender(); }
    if (p.length < 8) { E.uerr = _t('Пароль короче 8 символов'); return rerender(); }
    E.newPerms = null; E.newOwner = false;
    usersCall('/api/users/add', { user: u, password: p, owner: owner, perms: owner ? [] : readChecks(box) }, _t('Пользователь добавлен'));
  };
  // Новый пользователь: «владелец» выключает галочки (ему доступно всё); выбор помним до добавления
  App.userNewOwner = function (on) {   // без перерисовки: логин и пароль в полях остаются
    var box = document.getElementById('usr-new'); if (!box) return;
    if (on) E.newPerms = readChecks(box);
    E.newOwner = on;
    box.querySelectorAll('input[data-perm]').forEach(function (i) {
      i.disabled = on; i.checked = on || (E.newPerms || NEW_PERMS).indexOf(i.getAttribute('data-perm')) >= 0;
      i.closest('.usr-perm').classList.toggle('is-off', on);
    });
  };
  App.userNewPerm = function () { E.newPerms = readChecks(document.getElementById('usr-new')); };
  App.userOpen = function (u) { E.openUser = E.openUser === u ? null : u; rerender(); };
  App.userOwner = function (u, on) {
    if (on && !confirm(_t('Сделать') + ' ' + u + ' ' + _t('владельцем? Владелец может всё, включая пользователей и обновление движка.'))) return rerender();
    usersCall('/api/users/access', { user: u, owner: on });
  };
  App.userPerms = function (u) {
    var box = document.querySelector('[data-uperms="' + CSS.escape(u) + '"]'); if (!box) return;
    usersCall('/api/users/access', { user: u, perms: readChecks(box) });
  };
  App.userPass = function (u) {
    var p = prompt(_t('Новый пароль для') + ' ' + u + ' (' + _t('не меньше 8 символов') + ')');
    if (p == null) return;
    if (p.length < 8) { E.uerr = _t('Пароль короче 8 символов'); return rerender(); }
    usersCall('/api/users/password', { user: u, password: p }, _t('Пароль изменён. Передайте его пользователю.'));
  };
  App.userRemove = function (u) {
    if (!confirm(_t('Удалить пользователя') + ' ' + u + '?')) return;
    usersCall('/api/users/remove', { user: u }, _t('Пользователь удалён'));
  };
  App.user2faReset = function (u) {
    if (!confirm(_t('Сбросить двухфакторный вход пользователю') + ' ' + u + '? ' + _t('Он войдёт только по паролю и сможет настроить его заново.'))) return;
    usersCall('/api/users/2fa-reset', { user: u }, _t('Двухфакторный вход сброшен'));
  };
  App.userJournal = function () { E.journal = !E.journal; rerender(); };
  var EV = {
    'login': 'вход', 'login-fail': 'неверный пароль', 'logout': 'выход', 'password': 'сменил пароль', 'setup': 'установка UCMS',
    'key-create': 'создан ключ доступа', 'key-revoke': 'отозван ключ доступа', 'key-use': 'работа по ключу', 'key-fail': 'неверный ключ доступа',
    'user-add': 'добавлен пользователь', 'user-remove': 'удалён пользователь', 'user-role': 'изменена роль', 'user-access': 'изменены права', 'user-password': 'новый пароль пользователю',
    '2fa-on': 'включил двухфакторный вход', '2fa-off': 'выключил двухфакторный вход', '2fa-reset': 'сброшен двухфакторный вход',
    '2fa-fail': 'неверный код', '2fa-recovery': 'вход по резервному коду', '2fa-codes': 'новые резервные коды', '2fa-forget': 'забыл браузеры',
    'ai-key-set': 'задан ключ ИИ-перевода', 'ai-key-remove': 'удалён ключ ИИ-перевода', 'module-install': 'установлен модуль', 'module-remove': 'удалён модуль'
  };
  function roleName(r) { return r === 'owner' ? _t('Владелец') : _t('Пользователь'); }
  function usersPanel() {
    var k = K(), UI = k.UI, d = E.users;
    var html = '<section class="ad-panel"><div class="ad-panel__t">' + _t('Пользователи') + '</div>' +
      '<span class="ad-f__hint">' + _t('Владелец может всё, включая пользователей и обновление движка. Остальным доступно только отмеченное — права можно поменять в любой момент.') + '</span>';
    if (!d) return html + '<p class="ad-f__hint">' + (E.uerr ? esc(E.uerr) : _t('Загрузка…')) + '</p></section>';
    html += '<div class="usr-list">' + d.users.map(function (u) {
      var me = u.user.toLowerCase() === String(d.me).toLowerCase(), open = E.openUser === u.user;
      var row = '<div class="usr-row"><div class="usr-row__n"><b>' + esc(u.user) +
        (u.twofa ? '<span class="tf-badge" title="' + k.escAttr(_t('Двухфакторный вход включён')) + '">2FA</span>' : '') + '</b>' + (me ? ' <small>' + _t('это вы') + '</small>' : '') +
        '<small>' + esc(permSummary(u)) + '</small>' +
        '<small>' + (u.seen ? _t('был в сети') + ' ' + fmt(u.seen) : _t('нет активных входов')) + '</small></div>' +
        (me ? '<span class="pj-badge">' + roleName(u.role) + '</span>' : UI.btn(open ? _t('Свернуть') : _t('Права'), 'App.userOpen(' + k.jsArg(u.user) + ')', { sm: true, variant: 'line' }) +
          k.ib('key', _t('Задать новый пароль'), 'App.userPass(' + k.jsArg(u.user) + ')') + k.ib('del', _t('Удалить'), 'App.userRemove(' + k.jsArg(u.user) + ')', { danger: true })) +
        '</div>';
      if (open && !me) {
        var isO = u.role === 'owner';
        row += '<div class="usr-edit" data-uperms="' + k.escAttr(u.user) + '">' +
          '<label class="usr-perm usr-perm--owner"><input type="checkbox"' + (isO ? ' checked' : '') + ' onchange="App.userOwner(' + k.jsArg(u.user) + ',this.checked)"><span><b>' + _t('Владелец') + '</b><small>' + _t('всё, включая пользователей и обновление движка') + '</small></span></label>' +
          permChecks('', isO ? PERMS.map(function (p) { return p[0]; }) : (u.perms || []), isO ? '' : 'App.userPerms(' + k.jsArg(u.user) + ')', isO) +
          (u.twofa ? '<div>' + UI.btn(_t('Сбросить двухфакторный вход'), 'App.user2faReset(' + k.jsArg(u.user) + ')', { sm: true, variant: 'line' }) + '</div>' : '') + '</div>';
      }
      return row;
    }).join('') + '</div>';
    var nOwner = !!E.newOwner, nPerms = E.newPerms || NEW_PERMS;
    html += '<div class="ad-panel__t" style="margin-top:6px">' + _t('Добавить пользователя') + '</div>' +
      '<div class="usr-add usr-add--3"><input id="usr-login" class="ad-in" placeholder="' + k.escAttr(_t('Логин')) + '" autocomplete="off" autocapitalize="none" spellcheck="false">' +
      '<input id="usr-pass" class="ad-in" type="password" placeholder="' + k.escAttr(_t('Пароль')) + '" autocomplete="new-password">' +
      UI.btn(_t('Добавить'), 'App.userAdd()', { variant: 'dark' }) + '</div>' +
      '<div class="usr-edit" id="usr-new"><label class="usr-perm usr-perm--owner"><input type="checkbox" id="usr-owner"' + (nOwner ? ' checked' : '') + ' onchange="App.userNewOwner(this.checked)"><span><b>' + _t('Владелец') + '</b><small>' + _t('всё, включая пользователей и обновление движка') + '</small></span></label>' +
      permChecks('n', nOwner ? PERMS.map(function (p) { return p[0]; }) : nPerms, 'App.userNewPerm()', nOwner) + '</div>';
    if (E.uerr) html += '<div class="ad-pub__msg is-err">' + esc(E.uerr) + '</div>';
    html += '<div>' + UI.btn(E.journal ? _t('Скрыть журнал входов') : _t('Журнал входов'), 'App.userJournal()', { sm: true, variant: 'line' }) + '</div>';
    if (E.journal) {
      html += '<div class="usr-log">' + (d.journal.length ? d.journal.map(function (j) {
        var bad = j.ev === 'login-fail';
        return '<div class="usr-log__i' + (bad ? ' is-bad' : '') + '"><span>' + fmt(j.at) + '</span><span>' + esc(j.user || '') + '</span><span>' + _t(EV[j.ev] || j.ev) +
          (j.role ? ' · ' + roleName(j.role) : '') + (j.key ? ' · «' + esc(j.key) + '»' : '') + (j.by ? ' · ' + esc(j.by) : '') + '</span><span class="usr-log__ip">' + esc(j.ip || '') + '</span></div>';
      }).join('') : '<p class="ad-f__hint">' + _t('Записей пока нет') + '</p>') + '</div>';
    }
    return html + '</section>';
  }
  function waitRestart(version) {
    var t0 = Date.now();
    E.busy = _t('Перезапуск UCMS…'); rerender();
    (function poll() {
      fetch('/api/ping', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (d) {
        if (d.version === version) { location.reload(); return; }
        throw new Error('old');
      }).catch(function () {
        if (Date.now() - t0 > 90000) { E.busy = ''; E.err = _t('Сервер не запустился сам. Перезапустите приложение в панели хостинга.'); rerender(); return; }
        setTimeout(poll, 1500);
      });
    })();
  }
  function after(d) {
    if (d.restarting) return waitRestart(d.version);
    E.busy = ''; E.err = _t('Версия') + ' ' + d.version + ' ' + _t('установлена. Перезапустите приложение в панели хостинга.'); rerender();
  }
  App.engineCheck = function () {
    E.busy = _t('Проверяю…'); E.err = ''; rerender();
    App.api.post('/api/update/check', {}).then(function (d) { E.st = d; E.busy = ''; rerender(); }).catch(function (e) { E.busy = ''; E.err = e.message; rerender(); });
  };
  App.engineSet = function (k, v) {
    var b = {}; b[k] = v;
    App.api.post('/api/update/settings', b).then(function (d) { E.st = d; rerender(); if (k === 'prerelease') App.engineCheck(); });
  };
  App.engineNotes = function () { E.notes = !E.notes; rerender(); };
  App.engineApply = function () {
    var a = E.st && E.st.available; if (!a) return;
    if (!confirm(_t('Обновить UCMS до версии') + ' ' + a.version + '?\n' + _t('Сайты и проекты не изменятся. Текущая версия сохранится — к ней можно будет вернуться.'))) return;
    E.busy = _t('Скачиваю и проверяю обновление…'); E.err = ''; rerender();
    App.persistNow().catch(function () {}).then(function () { return App.api.post('/api/update/apply', {}); })
      .then(after).catch(function (e) { E.busy = ''; E.err = _t('Обновление не установлено:') + ' ' + e.message; App.loadEngine(); });
  };
  App.engineRollback = function (id, ver) {
    if (!confirm(_t('Вернуть UCMS версии') + ' ' + ver + '?')) return;
    E.busy = _t('Возвращаю прежнюю версию…'); E.err = ''; rerender();
    App.api.post('/api/update/rollback', { id: id }).then(after).catch(function (e) { E.busy = ''; E.err = e.message; rerender(); });
  };

  // Смена пароля (хостинг без SSH — только отсюда)
  App.enginePass = function () {
    var v = function (id) { var el = document.getElementById(id); return el ? el.value : ''; };
    var cur = v('eng-cur'), nx = v('eng-new'), rp = v('eng-rep'), msg = document.getElementById('eng-pmsg');
    var say = function (t, ok) { if (msg) { msg.className = 'ad-pub__msg ' + (ok ? 'is-ok' : 'is-err'); msg.textContent = t; msg.hidden = false; } };
    if (nx.length < 8) return say(_t('Новый пароль — не короче 8 символов'));
    if (nx !== rp) return say(_t('Новые пароли не совпадают'));
    App.api.post('/api/auth/password', { current: cur, next: nx }).then(function () {
      ['eng-cur', 'eng-new', 'eng-rep'].forEach(function (id) { var el = document.getElementById(id); if (el) el.value = ''; });
      say(_t('Пароль изменён. На других устройствах нужно будет войти заново.'), true);
    }).catch(function (e) { say(e.message); });
  };
  function passPanel() {
    var inp = function (id, label, ac) { return '<div class="ad-f"><label class="ad-f__l" for="' + id + '">' + label + '</label><input id="' + id + '" class="ad-in" type="password" autocomplete="' + ac + '"></div>'; };
    return '<section class="ad-panel"><div class="ad-panel__t">' + _t('Вход в админку') + '</div>' +
      '<div class="ad-f"><span class="ad-f__l">' + _t('Логин') + '</span><div class="ad-in" style="display:flex;align-items:center">' + esc(App._state.user || '') + '</div></div>' +
      inp('eng-cur', _t('Текущий пароль'), 'current-password') + inp('eng-new', _t('Новый пароль'), 'new-password') + inp('eng-rep', _t('Ещё раз'), 'new-password') +
      '<div class="ad-pub__msg" id="eng-pmsg" hidden></div>' +
      '<div>' + K().UI.btn(_t('Сменить пароль'), 'App.enginePass()', { variant: 'dark' }) + '</div></section>';
  }

  App.renderEngineView = function () {
    var k = K(), UI = k.UI, u = E.st;
    if (!isOwner()) {   // пользователь: версия, свои права и пароль; обновлением и пользователями управляет владелец
      return k.secHead('UCMS', _t('Ваша учётная запись. Обновлением движка и пользователями управляет владелец сайта.')) +
        // слева версия и двухфакторный вход (одна под другой), справа пароль — без пустой половины
        '<div class="ad-grid2"><div class="ad-stack"><section class="ad-panel"><div class="ad-panel__t">' + _t('Версия') + '</div>' +
        '<div class="ad-in ad-in--mono" style="display:flex;align-items:center">UCMS ' + esc(u ? u.version : '') + '</div>' +
        '<span class="ad-f__hint">' + _t('Ваши права') + ': ' + esc(permSummary(App.webInfo || {})) + '</span></section>' + twofaPanel() + '</div>' + passPanel() + '</div>' +
        (App.can('keys') ? '<div style="margin-top:16px">' + keysPanel() + '</div>' : '');
    }
    var html = k.secHead('UCMS', _t('Версия движка и обновления, вход в админку и пользователи.'));
    if (!u) return html + (E.err ? '<div class="ad-pub__msg is-err">' + esc(E.err) + '</div>' : '<p class="ad-f__hint">' + _t('Загрузка…') + '</p>');
    var a = u.available, b = (u.backups || [])[0];
    html += '<div class="ad-grid2"><section class="ad-panel"><div class="ad-panel__t">' + _t('Обновления') + '</div>' +
      '<div class="ad-f"><span class="ad-f__l">' + _t('Версия') + '</span><div class="ad-in ad-in--mono" style="display:flex;align-items:center">UCMS ' + esc(u.version) + '</div></div>' +
      '<span class="ad-f__hint">' + _t('проверено') + ': ' + (u.checkedAt ? fmt(u.checkedAt) : _t('ещё не проверялось')) + (!a && u.checkedAt && !u.error ? ' · ' + _t('установлена последняя версия') : '') + '</span>' +
      (u.error ? '<div class="ad-pub__msg is-err">' + esc(u.error) + '</div>' : '');
    if (a) {
      html += '<div class="pj-upd"><div class="pj-upd__h">' + k.ico('cloud', 18) +
        '<div><b>' + _t('Доступна новая версия UCMS') + ' ' + esc(a.version) + (a.prerelease ? ' · ' + _t('тестовая') : '') + '</b></div></div>' +
        '<div class="ad-btnrow">' + UI.btn(_t('Что нового'), 'App.engineNotes()', { sm: true, variant: 'line' }) +
        (E.busy ? '' : UI.btn(_t('Обновить'), 'App.engineApply()', { sm: true, variant: 'primary' })) + '</div>' +
        (E.notes ? '<div class="pj-upd__notes" style="padding-left:4px">' + (notesHTML(a.notes) || esc(a.name)) + '</div>' : '') + '</div>';
    }
    if (E.busy) html += '<div class="ad-pub__msg"><span class="pj-spin" style="width:16px;height:16px;border-width:2px"></span><span>' + esc(E.busy) + '</span></div>';
    if (E.err) html += '<div class="ad-pub__msg is-err">' + esc(E.err) + '</div>';
    html += '<div class="ad-btnrow">' + UI.btn(_t('Проверить сейчас'), 'App.engineCheck()', { sm: true }) + '</div>' +
      UI.sw(_t('Проверять автоматически'), u.auto, 'App.engineSet(\'auto\',' + !u.auto + ')') +
      UI.sw(_t('Тестовые версии'), u.prerelease, 'App.engineSet(\'prerelease\',' + !u.prerelease + ')') +
      (b ? '<div>' + UI.btn(_t('Вернуть версию') + ' ' + b.version, 'App.engineRollback(' + k.jsArg(b.id) + ',' + k.jsArg(b.version) + ')', { sm: true, icon: 'undo' }) + '</div>' : '') +
      (!u.launcher ? '<span class="ad-f__hint">' + _t('После обновления перезапустите приложение в панели хостинга.') + '</span>' : '') +
      '</section>' + passPanel() + '</div>' + '<div class="ad-grid2" style="margin-top:16px">' + twofaPanel() + keysPanel() + '</div>' +
      '<div style="margin-top:16px">' + usersPanel() + '</div>';
    return html;
  };
})();

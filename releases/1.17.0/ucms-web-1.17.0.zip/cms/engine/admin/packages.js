'use strict';
/*
 * Подключаемые модули сайта (1.14) — админка.
 *
 * Сервер отдаёт описания установленных пакетов (GET /api/modules/packages): поля модуля,
 * поля элемента списка, подписи на языках. По описанию здесь строится всё, что у встроенных
 * модулей написано руками: редактор, значения по умолчанию, вид на холсте, переводимые поля.
 * Встраивание в app.js — через App.PKG[тип] (newModule, listAdd, modMeta, modPreview).
 *
 * Управление (установка из .zip, удаление, скачать модуль) — App.renderPackagesPanel()
 * в «Сайт и модули».
 */
(function () {
  window.App = window.App || {};
  App.PKG = App.PKG || {};
  var P = { list: [], errors: [], busy: '', err: '', note: '', avail: null, availErr: '', catErr: '' };
  var own = { editor: {}, tr: {}, mod: {} };   // что зарегистрировал сам packages.js (а не движок: admin/modules/*.js)
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var lang = function () { return window.ADMIN_LANG || 'ru'; };
  // Подпись: строка, { ru, en, kk } или ключ из i18n пакета
  function txt(pkg, v) {
    if (v && typeof v === 'object') return v[lang()] || v.ru || v.en || '';
    var s = String(v == null ? '' : v), d = pkg && pkg.i18n && pkg.i18n[lang()];
    return (d && d[s]) || s;
  }
  function uid(p) { return (App.uid ? App.uid(p) : p + Math.random().toString(36).slice(2, 9)); }
  function defOf(f, pkg) {
    if (f.type === 'link') return { linkType: 'none' };
    if (f.type === 'toggle') return !!f.default;
    if (f.type === 'image') return f.default || '';
    if (f.type === 'select') return f.default != null ? String(f.default) : String((f.options[0] || {}).value || '');
    if (f.type === 'number') return f.default != null ? f.default : '';
    return f.default != null ? txt(pkg, f.default) : '';
  }
  function itemOf(pkg) {
    var it = { id: uid('g') };
    (pkg.item.fields || []).forEach(function (f) { it[f.key] = defOf(f, pkg); });
    return it;
  }

  // ── Регистрация пакетов: каталог, редактор, перевод, холст ──
  App.registerPackages = function (d) {
    var list = (d && d.packages) || [];
    P.list = list; P.errors = (d && d.errors) || [];
    // убрать снятые с сайта
    Object.keys(App.PKG).forEach(function (id) {
      if (list.some(function (p) { return p.id === id; })) return;
      delete App.PKG[id];
      if (own.mod[id]) {   // модуль из архива — убрать из каталога; необязательный модуль движка остаётся (скрыт, пока не установлен)
        for (var i = MODULES.length - 1; i >= 0; i--) if (MODULES[i].key === id) MODULES.splice(i, 1);
        delete MODULE_LABEL[id]; delete own.mod[id];
      }
    });
    list.forEach(function (pkg) {
      var label = txt(pkg, pkg.name);
      var at = MODULES.findIndex(function (m) { return m.key === pkg.id; });
      if (at < 0 || own.mod[pkg.id]) {
        var def = { key: pkg.id, label: label, pkg: true };
        if (pkg.icon) def.icon = pkg.icon; else def.glyph = esc(pkg.glyph || label.slice(0, 2));
        if (at >= 0) MODULES[at] = def; else MODULES.push(def);
        MODULE_LABEL[pkg.id] = label;
        own.mod[pkg.id] = true;
      }
      var tr = function (fields) {
        return (fields || []).filter(function (f) { return (f.type === 'text' || f.type === 'textarea') && f.translate !== false; })
          .map(function (f) { return [f.key, txt(pkg, f.label || f.key), f.type === 'textarea' ? 'area' : 'line']; });
      };
      // у необязательных модулей движка свои списки переводимых полей (app.js) — не трогаем
      if (App.TRANSLATABLE && (!App.TRANSLATABLE[pkg.id] || own.tr[pkg.id])) { App.TRANSLATABLE[pkg.id] = tr(pkg.fields); own.tr[pkg.id] = true; }
      if (App.ITEM_TRANSLATABLE && pkg.item && (!App.ITEM_TRANSLATABLE[pkg.id] || own.tr[pkg.id])) App.ITEM_TRANSLATABLE[pkg.id] = tr(pkg.item.fields);
      App.PKG[pkg.id] = {
        pkg: pkg,
        create: function (base) {
          (pkg.fields || []).forEach(function (f) { base[f.key] = defOf(f, pkg); });
          if (pkg.item) base.items = [0, 1, 2].slice(0, Math.max(1, Math.min(6, parseInt(pkg.item.start, 10) || 3))).map(function () { return itemOf(pkg); });
          return base;
        },
        newItem: pkg.item ? function () { return itemOf(pkg); } : null,
        meta: function (m) { return pkg.item ? String((m.items || []).length) : ''; },
        preview: function (m, h) { return preview(pkg, m, h); },
      };
      // редактор движка (admin/modules/<id>.js) удобнее построенного по описанию — оставляем его
      if (!CMS.editors[pkg.id] || own.editor[pkg.id]) { CMS.editor(pkg.id, function (mod, ctx) { return editor(pkg, mod, ctx); }); own.editor[pkg.id] = true; }
    });
    var sw = App._state && App._state.moduleSw;
    if (sw) list.forEach(function (p) { if (sw[p.id] === undefined) sw[p.id] = true; });
  };

  // ── Вид на холсте: первое текстовое поле + картинка; у списков — элементы ──
  function firstText(fields, o, h) {
    var f = (fields || []).filter(function (x) { return x.type === 'text' || x.type === 'textarea'; })[0];
    return f ? h.tv(o, f.key) : '';
  }
  function firstImage(fields, o) {
    var f = (fields || []).filter(function (x) { return x.type === 'image'; })[0];
    return f ? o[f.key] : '';
  }
  function preview(pkg, m, h) {
    var head = firstText(pkg.fields, m, h), img = firstImage(pkg.fields, m), html = '';
    if (img) html += '<img class="ad-pv__img" src="' + esc(img) + '" alt="" loading="lazy">';
    if (head) html += '<div class="ad-pv ad-pv--t4">' + esc(head) + '</div>';
    if (pkg.item) {
      var items = m.items || [];
      html += items.length ? '<div class="ad-pv__cards" style="grid-template-columns:repeat(' + Math.min(4, items.length) + ',minmax(0,1fr))">' + items.slice(0, 8).map(function (it) {
        var im = firstImage(pkg.item.fields, it), t = firstText(pkg.item.fields, it, h);
        return '<div>' + (im ? '<img src="' + esc(im) + '" alt="" loading="lazy">' : '') + '<span>' + esc(t || txt(pkg, pkg.item.label || 'Элемент')) + '</span></div>';
      }).join('') + '</div>' : h.muted(_t('Пусто'));
    }
    return html || h.muted(txt(pkg, pkg.name));
  }

  // ── Редактор по описанию полей ──
  function editor(pkg, mod, ctx) {
    var ui = ctx.ui, J = ctx.jsArg, html = '';
    (pkg.fields || []).forEach(function (f) { html += field(pkg, f, mod, ctx, null); });
    if (pkg.item) {
      mod.items = mod.items || [];
      html += ui.list(ctx, mod.items, txt(pkg, pkg.item.title || pkg.item.label || 'Элементы'), txt(pkg, pkg.item.label || 'Элемент'), function (it, set) {
        return (pkg.item.fields || []).map(function (f) { return field(pkg, f, it, ctx, set); }).join('');
      }, pkg.item.hint ? esc(txt(pkg, pkg.item.hint)) : '');
    }
    if (!pkg.compatible) html = ui.note(_t('Модулю нужна более новая версия UCMS:') + ' ' + esc(pkg.ucms)) + html;
    return html || ui.note(_t('У модуля нет настроек.'));
  }
  // set — у элемента списка: set(key) → onchange-выражение; у модуля — null (ctx.set)
  function field(pkg, f, o, ctx, set) {
    var ui = ctx.ui, J = ctx.jsArg, label = txt(pkg, f.label || f.key), hint = f.hint ? esc(txt(pkg, f.hint)) : '';
    var v = o[f.key];
    var setExpr = function (val, noRender) {
      return set ? 'App.listSet(' + [ctx.tree, ctx.mod.id, o.id, f.key].map(J).join(',') + ',' + val + ')' + (noRender ? '' : ';' + ctx.call('renderModule'))
        : ctx.set(f.key, val, noRender);
    };
    switch (f.type) {
      case 'text':
        return ui.field(label, ui.input({ value: v, placeholder: txt(pkg, f.placeholder || ''), oninput: set ? set(f.key) : ctx.set(f.key, 'this.value', true) }), hint);
      case 'textarea':
        return ui.field(label, '<textarea class="ad-in ad-tr__ta" rows="' + (parseInt(f.rows, 10) || 3) + '" placeholder="' + ctx.escAttr(txt(pkg, f.placeholder || '')) + '" oninput="' +
          ctx.escAttr(set ? set(f.key) : ctx.set(f.key, 'this.value', true)) + '">' + ctx.esc(v) + '</textarea>', hint);
      case 'number':
        return ui.field(label, ui.input({ value: v, type: 'number', placeholder: f.placeholder ? txt(pkg, f.placeholder) : '', oninput: set ? set(f.key) : ctx.set(f.key, 'this.value', true) }), hint);
      case 'color':
        return ui.field(label, '<input type="color" class="ad-in" style="height:36px;padding:2px" value="' + ctx.escAttr(/^#[0-9a-f]{6}$/i.test(v || '') ? v : (f.default || '#000000')) + '" oninput="' + ctx.escAttr(setExpr('this.value', true)) + '">', hint);
      case 'toggle':
        if (v === undefined) v = !!f.default;
        return ui.sw(label, !!v, setExpr(v ? 'false' : 'true'));
      case 'datetime':
        return ui.field(label, '<input class="ad-in" type="datetime-local" value="' + ctx.escAttr(v || '') + '" onchange="' + ctx.escAttr(setExpr('this.value')) + '">', hint);
      case 'select':
        if ((f.options || []).length <= 4 && !f.dropdown) return ui.field(label, ui.segm(f.options.map(function (op) { return [String(op.value), txt(pkg, op.label || op.value)]; }), String(v), function (k) { return setExpr(J(k)); }), hint);
        return ui.field(label, '<select class="ad-in" onchange="' + ctx.escAttr(setExpr('this.value')) + '">' + f.options.map(function (op) {
          return '<option value="' + ctx.escAttr(op.value) + '"' + (String(op.value) === String(v) ? ' selected' : '') + '>' + esc(txt(pkg, op.label || op.value)) + '</option>';
        }).join('') + '</select>', hint);
      case 'image':
        var btnAttrs = set ? 'class="ad-gi__thumb ad-li-up" data-item="' + ctx.escAttr(o.id) + '" data-field="' + ctx.escAttr(f.key) + '"'
          : 'class="ad-gi__thumb ad-mod-up" data-field="' + ctx.escAttr(f.key) + '"';
        var thumb = '<button type="button" ' + btnAttrs + ' title="' + ctx.escAttr(_t('Загрузить изображение')) + '">' + (v ? '<img src="' + ctx.escAttr(v) + '" alt="">' : ui.ico('upload', 18)) + '</button>';
        return ui.field(label, '<div class="ad-gi__row">' + thumb + (v ? ui.btn(_t('Убрать'), setExpr("''"), { sm: true }) : '') + '</div>', hint);
      case 'link':
        return ctx.linkField(ctx.tree, ctx.mod.id, o.link, ctx.pages, set ? ctx.itemPath(o.id) : ctx.path, label);
    }
    return '';
  }

  // ── Управление модулями («Сайт и модули») ──
  function canManage() { return !App.webInfo || App.webInfo.role === 'owner'; }
  function rerender() { if (App.renderView) App.renderView(); else if (App.render) App.render(); }
  function reload(d) { App.registerPackages(d); if (App.renderRoot) App.renderRoot(); else rerender(); }
  App.pkgInstall = function () {
    var inp = document.createElement('input');
    inp.type = 'file'; inp.accept = '.zip,application/zip';
    inp.onchange = function () { if (inp.files[0]) send(inp.files[0], false); };
    inp.click();
  };
  function send(file, confirmed) {
    P.busy = _t('Устанавливаю модуль…'); P.err = ''; P.note = ''; rerender();
    fetch('/api/modules/install' + (confirmed ? '?confirm=1' : ''), { method: 'POST', body: file, headers: { 'Content-Type': 'application/zip' } })
      .then(function (r) { return r.json(); }).then(function (d) {
        P.busy = '';
        if (!d.ok) { P.err = _t(d.error || 'Ошибка'); return rerender(); }
        var m = d.module, nm = txt(m, m.name);
        if (d.needConfirm) {
          if (confirm(_t('Модуль') + ' «' + nm + '» ' + _t('содержит серверный код (render.js). Он выполняется на сервере сайта с полным доступом к нему. Устанавливайте только модули, которым доверяете. Установить?'))) return send(file, true);
          return rerender();
        }
        P.note = (m.update ? _t('Модуль обновлён:') : _t('Модуль установлен:')) + ' ' + nm + (m.version ? ' ' + m.version : '');
        P.avail = null; reload(d);
      }).catch(function (e) { P.busy = ''; P.err = e.message; rerender(); });
  }
  App.pkgRemove = function (id, force) {
    var pkg = P.list.filter(function (p) { return p.id === id; })[0]; if (!pkg) return;
    if (!force && !confirm(_t('Удалить модуль') + ' «' + txt(pkg, pkg.name) + '»?')) return;
    P.busy = _t('Удаляю…'); P.err = ''; rerender();
    App.api.post('/api/modules/remove', { id: id, force: !!force }).then(function (d) {
      P.busy = '';
      if (d.inUse) {
        if (confirm(_t('Модуль используется на сайте:') + ' ' + d.inUse + ' ' + _t('шт. Блоки останутся на страницах, но на сайте выводиться не будут, пока модуль не установят снова. Удалить?'))) return App.pkgRemove(id, true);
        return rerender();
      }
      P.note = _t('Модуль удалён'); P.avail = null; reload(d);
    }).catch(function (e) { P.busy = ''; P.err = e.message; rerender(); });
  };
  // Доступные для установки: модули движка и каталога на GitHub
  var availLoading = false;
  // Число модулей сайта, для которых есть обновление, — значок у «Сайт и модули» (только тому, кто может обновить)
  function countUpdates() {
    var n = canManage() && P.avail ? P.avail.filter(function (a) { return a.update && a.compatible; }).length : 0;
    if (n !== (App.pkgUpdates || 0)) { App.pkgUpdates = n; if (App.renderSide) App.renderSide(); }
  }
  App.loadAvailable = function (quiet) {
    if (availLoading) return;
    availLoading = true;
    App.api.get('/api/modules/available').then(function (d) { availLoading = false; P.avail = d.modules || []; P.catErr = d.catalogError || ''; countUpdates(); if (!quiet) rerender(); })
      .catch(function (e) { availLoading = false; P.avail = []; P.availErr = e.message; if (!quiet) rerender(); });
  };
  // После загрузки админки — тихая проверка (каталог на сервере кэшируется на час)
  App.checkPkgUpdates = function () { if (canManage()) App.loadAvailable(true); };
  // «Обновить все»: по одному, при ошибке — стоп с сообщением (остальные не трогаем)
  App.pkgUpdateAll = function () {
    var list = (P.avail || []).filter(function (a) { return a.update && a.compatible; });
    if (!list.length || P.busy) return;
    var done = [], i = 0;
    P.err = ''; P.note = '';
    (function next() {
      if (i >= list.length) {
        P.busy = ''; P.note = _t('Обновлено модулей:') + ' ' + done.length + ' (' + done.join(', ') + ')';
        P.avail = null; App.api.get('/api/modules/packages').then(reload, rerender);
        return;
      }
      var a = list[i++];
      P.busy = _t('Обновляю') + ' ' + txt(a, a.name) + '… (' + i + '/' + list.length + ')'; rerender();
      App.api.post('/api/modules/install-from', { id: a.id, source: a.source }).then(function () { done.push(txt(a, a.name) + ' ' + a.version); next(); })
        .catch(function (e) {
          P.busy = ''; P.err = txt(a, a.name) + ': ' + e.message + (done.length ? ' · ' + _t('уже обновлены:') + ' ' + done.join(', ') : '');
          P.avail = null; App.api.get('/api/modules/packages').then(reload, rerender);
        });
    })();
  };
  App.pkgInstallFrom = function (id, source) {
    P.busy = _t('Устанавливаю модуль…'); P.err = ''; P.note = ''; rerender();
    App.api.post('/api/modules/install-from', { id: id, source: source }).then(function (d) {
      P.busy = ''; P.note = _t('Модуль установлен:') + ' ' + txt(d.module, d.module.name) + ' ' + d.module.version;
      P.avail = null; reload(d);
    }).catch(function (e) { P.busy = ''; P.err = e.message; rerender(); });
  };
  function availPanel(canEdit) {
    if (P.avail === null) { App.loadAvailable(); return '<p class="ad-f__hint">' + _t('Загрузка…') + '</p>'; }
    var rows = P.avail.filter(function (a) { return !a.installed || a.update; });
    var ups = P.avail.filter(function (a) { return a.update && a.compatible; }).length;
    var html = (canEdit && ups > 1 ? '<div><button type="button" class="ad-b ad-b--sm ad-b--primary"' + (P.busy ? ' disabled' : '') + ' onclick="App.pkgUpdateAll()">' + _t('Обновить все') + ' (' + ups + ')</button></div>' : '') +
      (rows.length ? '<div class="usr-list">' + rows.map(function (a) {
      var ic = a.icon ? '<svg viewBox="0 0 18 18" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + a.icon + '</svg>' : '<span style="font-size:11px;font-weight:600">' + esc(a.glyph || '') + '</span>';
      return '<div class="usr-row"><div class="ad-modrow__icon" style="background:var(--fill);color:var(--mut-2)">' + ic + '</div>' +
        '<div class="usr-row__n"><b>' + esc(txt(a, a.name)) + ' <small style="display:inline">' + esc(a.version) + '</small></b>' +
        '<small>' + esc(txt(a, a.description)) + (a.source === 'catalog' ? ' · ' + _t('из каталога') : '') + '</small>' +
        (a.update ? '<small style="color:var(--ac)">' + _t('установлена') + ' ' + esc(a.installed) + ' — ' + _t('есть обновление') + '</small>' : '') +
        (a.compatible ? '' : '<small style="color:var(--danger)">' + _t('нужна UCMS') + ' ' + esc(a.ucms) + '</small>') + '</div>' +
        (canEdit && a.compatible ? '<button type="button" class="ad-b ad-b--sm ad-b--line"' + (P.busy ? ' disabled' : '') + ' onclick="App.pkgInstallFrom(' + esc(JSON.stringify(a.id)) + ',' + esc(JSON.stringify(a.source)) + ')">' + (a.update ? _t('Обновить') : _t('Установить')) + '</button>' : '') + '</div>';
    }).join('') + '</div>' : '<p class="ad-f__hint">' + _t('Все доступные модули уже установлены.') + '</p>');
    if (P.catErr) html += '<span class="ad-f__hint">' + _t('Каталог на GitHub недоступен — показаны модули, которые идут с UCMS.') + '</span>';
    return html;
  }
  App.renderPackagesPanel = function () {
    var UI = App.UI || {}, own = canManage();
    // часть панели «Модули» в «Сайт и модули» — под выключателями модулей
    var html = '<div class="ad-pkgs" data-pkgs><div class="ad-panel__t">' + _t('Подключаемые модули') + '</div>' +
      '<span class="ad-f__hint">' + _t('Дополнительные модули: установка, обновление и удаление. Хранятся в папке сайта и переезжают вместе с ним. Свой модуль — docs/MODULES.md.') + '</span>';
    html += '<div class="ad-f__l">' + _t('Установлены в сайт') + '</div>';
    html += P.list.length ? '<div class="usr-list">' + P.list.map(function (p) {
      return '<div class="usr-row"><div class="ad-modrow__icon" style="background:var(--ac-soft);color:var(--ac)">' + moduleIconHTML(p.id, 18) + '</div>' +
        '<div class="usr-row__n"><b>' + esc(txt(p, p.name)) + ' <small style="display:inline">' + esc(p.version) + '</small></b>' +
        '<small>' + esc([p.author, p.description ? txt(p, p.description) : ''].filter(Boolean).join(' · ')) + '</small>' +
        (p.hasCode && !p.official ? '<small style="color:var(--warn)">' + _t('с серверным кодом') + '</small>' : '') +
        (p.compatible ? '' : '<small style="color:var(--danger)">' + _t('нужна UCMS') + ' ' + esc(p.ucms) + '</small>') + '</div>' +
        '<a class="ad-ib" href="/api/modules/export?id=' + encodeURIComponent(p.id) + '" download title="' + esc(_t('Скачать модуль (.zip)')) + '" aria-label="' + esc(_t('Скачать модуль (.zip)')) + '">' + (window.Icons ? Icons.svg('download', 16) : '↓') + '</a>' +
        (own ? '<button type="button" class="ad-ib ad-ib--danger" title="' + esc(_t('Удалить модуль')) + '" aria-label="' + esc(_t('Удалить модуль')) + '" onclick="App.pkgRemove(' + esc(JSON.stringify(p.id)) + ')">' + (window.Icons ? Icons.svg('trash', 16) : '×') + '</button>' : '') + '</div>';
    }).join('') + '</div>' : '<p class="ad-f__hint">' + _t('Подключаемых модулей пока нет.') + '</p>';
    P.errors.forEach(function (e) { html += '<div class="ad-pub__msg is-err">' + esc(e.id) + ': ' + esc(e.error) + '</div>'; });
    if (P.err) html += '<div class="ad-pub__msg is-err">' + esc(P.err) + '</div>';
    if (P.note) html += '<div class="ad-pub__msg is-ok">' + esc(P.note) + '</div>';
    if (own) html += '<div><button type="button" class="ad-b ad-b--line"' + (P.busy ? ' disabled' : '') + ' onclick="App.pkgInstall()">' + (window.Icons ? Icons.svg('upload', 14) : '') + esc(P.busy || _t('Установить из файла…')) + '</button></div>';
    else html += '<span class="ad-f__hint">' + _t('Устанавливает и удаляет модули владелец сайта.') + '</span>';
    html += '<div class="ad-f__l" style="margin-top:6px">' + _t('Доступные для установки') + '</div>' + availPanel(own);
    return html + '</div>';
  };
})();

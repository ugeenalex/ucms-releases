'use strict';
/**
 * Проект на сервере: исходники сайта рядом с опубликованным сайтом, чтобы открыть
 * проект на другом компьютере («Добавить существующий → С сервера») и получать правки.
 *
 * Папка проекта на сервере (по умолчанию — выше публичной папки сайта, её не видно из интернета):
 *   manifest.json            — что лежит, версия данных (rev), когда и с какого компьютера
 *   project-<rev>.zip        — пакет (или .ucms — тот же пакет, зашифрованный паролем проекта)
 *   .htaccess, index.html    — запасная защита, если папка всё же окажется публичной
 *
 * Пакет: db.json (без ключа ИИ-перевода), themes/**, media.json (папки и теги медиатеки),
 * uploads.json (список файлов uploads с sha1). Сами картинки не дублируются: они уже
 * опубликованы в <папка сайта>/uploads и при получении проекта скачиваются оттуда.
 * Пароли FTP и проекта в пакет не попадают никогда.
 *
 * Шифрование: AES-256-GCM, ключ — scrypt(пароль проекта, соль). Обязательно, если папка
 * проекта внутри папки сайта (хостинг не даёт писать выше неё).
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { createZip, readZip } = require('../lib/zip');

const FORMAT = 'ucms-project';
const FORMAT_VERSION = 1;
const PUBLIC_ROOTS = /^(public_html|www|htdocs|httpdocs|html|web|wwwroot|public|site)$/i;
const MAGIC = Buffer.from('UCMSENC1');

const posixNorm = p => {
  const n = path.posix.normalize('/' + String(p || '/').replace(/\\/g, '/'));
  return n.length > 1 ? n.replace(/\/+$/, '') : '/';
};

// Папка проекта по умолчанию: рядом с публичной папкой.
//   /public_html → /ucms-project · /public_html/blog → /ucms-project-blog · /site1 → /ucms-project-site1
//   / (FTP открывается прямо в папке сайта) → /.ucms-project — только с шифрованием
function autoProjectDir(siteDir) {
  const parts = posixNorm(siteDir).split('/').filter(Boolean);
  if (!parts.length) return '/.ucms-project';
  const i = parts.findIndex(p => PUBLIC_ROOTS.test(p));
  const base = i >= 0 ? parts.slice(0, i) : parts.slice(0, -1);
  const rest = (i >= 0 ? parts.slice(i + 1) : parts.slice(-1)).join('-').replace(/[^\w.-]+/g, '-');
  return '/' + [...base, rest ? `ucms-project-${rest}` : 'ucms-project'].join('/');
}
function isInside(siteDir, dir) {
  const s = posixNorm(siteDir), d = posixNorm(dir);
  return s === '/' || d === s || d.startsWith(s + '/');
}
// Где и как хранить проект для этих настроек публикации
function target(cfg) {
  const site = posixNorm(cfg.dir || '/');
  const dir = cfg.projectDir ? posixNorm(cfg.projectDir) : autoProjectDir(site);
  const inside = isInside(site, dir);
  return { enabled: cfg.projectSync !== false, dir, auto: !cfg.projectDir, inside, encrypted: inside || !!cfg.encrypt, site };
}

// ── шифрование ──
function deriveKey(password, salt) {
  return crypto.scryptSync(String(password), salt, 32, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
}
function encrypt(buf, password) {
  const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', deriveKey(password, salt), iv);
  const body = Buffer.concat([c.update(buf), c.final()]);
  return Buffer.concat([MAGIC, salt, iv, c.getAuthTag(), body]);
}
function decrypt(buf, password) {
  if (buf.length < 52 || !buf.slice(0, 8).equals(MAGIC)) throw new Error('Файл проекта повреждён');
  const salt = buf.slice(8, 24), iv = buf.slice(24, 36), tag = buf.slice(36, 52);
  const d = crypto.createDecipheriv('aes-256-gcm', deriveKey(password, salt), iv);
  d.setAuthTag(tag);
  try { return Buffer.concat([d.update(buf.slice(52)), d.final()]); }
  catch (e) { const err = new Error('Неверный пароль проекта'); err.code = 'BAD_PASSWORD'; throw err; }
}

// ── пакет ──
function listFiles(dir, base = dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, e.name);
    if (e.isDirectory()) listFiles(abs, base, out);
    else out.push(path.relative(base, abs).split(path.sep).join('/'));
  }
  return out;
}
const sha1 = b => crypto.createHash('sha1').update(b).digest('hex');

// Версия данных: хеш содержимого пакета — одинаковые данные дают одинаковый rev
function revOf(entries) {
  const h = crypto.createHash('sha256');
  [...entries].sort((a, b) => (a.name < b.name ? -1 : 1)).forEach(e => { h.update(e.name); h.update('\0'); h.update(sha1(e.data)); h.update('\0'); });
  return h.digest('hex').slice(0, 20);
}

function buildPackage(contentDir) {
  const db = JSON.parse(fs.readFileSync(path.join(contentDir, 'db.json'), 'utf8'));
  if (db.settings && db.settings.translation) db.settings.translation.apiKey = '';   // ключ ИИ-перевода — только на своём компьютере
  const entries = [{ name: 'db.json', data: Buffer.from(JSON.stringify(db, null, 2)) }];
  const themes = path.join(contentDir, 'themes');
  listFiles(themes).forEach(rel => entries.push({ name: `themes/${rel}`, data: fs.readFileSync(path.join(themes, rel)) }));
  const meta = path.join(contentDir, 'uploads', '.media.json');
  if (fs.existsSync(meta)) entries.push({ name: 'media.json', data: fs.readFileSync(meta) });
  const up = path.join(contentDir, 'uploads');
  const uploads = listFiles(up).filter(rel => !rel.split('/').some(s => s.startsWith('.')))
    .map(rel => { const b = fs.readFileSync(path.join(up, rel)); return { rel, size: b.length, sha1: sha1(b) }; });
  entries.push({ name: 'uploads.json', data: Buffer.from(JSON.stringify(uploads)) });
  const title = (db.settings && db.settings.siteTitle) || '';
  return { entries, rev: revOf(entries), title, pages: Array.isArray(db.pages) ? db.pages.length : 0, uploads };
}

// Пакет с сервера → { db, themes: [{rel,data}], media, uploads, rev }
function parsePackage(buf) {
  const entries = readZip(buf);
  for (const e of entries) {
    if (e.name.split('/').some(s => s === '..' || s === '') || path.isAbsolute(e.name)) throw new Error(`Недопустимый путь в пакете: ${e.name}`);
  }
  const get = n => entries.find(e => e.name === n);
  if (!get('db.json')) throw new Error('В пакете нет db.json');
  const db = JSON.parse(get('db.json').data.toString('utf8'));
  if (!db.settings || !Array.isArray(db.pages)) throw new Error('Пакет не похож на проект UCMS');
  return {
    db, rev: revOf(entries),
    themes: entries.filter(e => e.name.startsWith('themes/')).map(e => ({ rel: e.name.slice(7), data: e.data })),
    media: get('media.json') ? get('media.json').data : null,
    uploads: get('uploads.json') ? JSON.parse(get('uploads.json').data.toString('utf8')) : [],
  };
}

// ── сервер ──
const joinRemote = (dir, name) => path.posix.join(dir, name);

async function readManifest(client, dir) {
  try {
    const m = JSON.parse((await client.get(joinRemote(dir, 'manifest.json'), 1024 * 1024)).toString('utf8'));
    return m && m.format === FORMAT && m.rev && m.file ? m : null;
  } catch (e) {
    if (e.code === 550 || e.code === 450) return null;   // файла нет
    if (e instanceof SyntaxError) return null;
    throw e;
  }
}

// Найти проект: папка из настроек (или по умолчанию), затем скрытая папка внутри сайта
async function findProject(client, cfg) {
  const t = target(cfg);
  const dirs = [...new Set([t.dir, autoProjectDir(t.site), joinRemote(t.site, '.ucms-project')])];
  for (const dir of dirs) {
    const m = await readManifest(client, dir);
    if (m) return { dir, manifest: m };
  }
  return null;
}

async function fetchPackage(client, dir, manifest, password) {
  let buf = await client.get(joinRemote(dir, manifest.file), 300 * 1024 * 1024);
  if (manifest.encrypted) {
    if (!password) { const e = new Error('Нужен пароль проекта'); e.code = 'NEED_PASSWORD'; throw e; }
    buf = decrypt(buf, password);
  }
  const pkg = parsePackage(buf);
  if (pkg.rev !== manifest.rev) throw new Error('Пакет проекта на сервере повреждён (версия не совпала)');
  return pkg;
}

// Отправить пакет. prev — манифест, который был на сервере (старый файл пакета удаляется)
async function pushProject(client, { contentDir, cfg, version, prev }) {
  const t = target(cfg);
  const pkg = buildPackage(contentDir);
  if (prev && prev.rev === pkg.rev) return { rev: pkg.rev, unchanged: true, dir: t.dir };
  if (t.encrypted && !cfg.projectPassword) {
    const e = new Error(t.inside
      ? 'Проект хранится внутри папки сайта — задайте пароль проекта в «Публикации», чтобы зашифровать его'
      : 'Задайте пароль проекта для шифрования');
    e.code = 'NEED_PASSWORD'; throw e;
  }
  const zip = createZip(pkg.entries);
  const body = t.encrypted ? encrypt(zip, cfg.projectPassword) : zip;
  const file = `project-${pkg.rev.slice(0, 12)}.${t.encrypted ? 'ucms' : 'zip'}`;
  await client.mkdirp(t.dir);
  try {
    await client.put(body, joinRemote(t.dir, file));
  } catch (e) {
    if ([550, 553, 552, 450, 451].includes(e.code) && !t.inside) {
      const err = new Error(`Хостинг не дал записать в ${t.dir}. Укажите папку проекта внутри папки сайта и задайте пароль проекта — тогда он будет храниться зашифрованным.`);
      err.code = 'NO_WRITE'; throw err;
    }
    throw e;
  }
  const manifest = {
    format: FORMAT, formatVersion: FORMAT_VERSION, rev: pkg.rev, file, encrypted: t.encrypted,
    updatedAt: new Date().toISOString(), computer: os.hostname(), engine: version, size: body.length,
    // название и число страниц — только у незашифрованного проекта
    ...(t.encrypted ? {} : { title: pkg.title, pages: pkg.pages }),
  };
  if (!prev) {   // запасная защита папки (Apache); index.html — чтобы не было списка файлов
    await client.put(Buffer.from('Require all denied\nDeny from all\n'), joinRemote(t.dir, '.htaccess')).catch(() => {});
    await client.put(Buffer.from(''), joinRemote(t.dir, 'index.html')).catch(() => {});
  }
  await client.put(Buffer.from(JSON.stringify(manifest, null, 2)), joinRemote(t.dir, 'manifest.json'));
  if (prev && prev.file && prev.file !== file) await client.remove(joinRemote(t.dir, prev.file)).catch(() => {});
  return { rev: pkg.rev, dir: t.dir, encrypted: t.encrypted, manifest };
}

// Файлы uploads: скачать недостающие/изменившиеся из <сайт>/uploads. onFile(done, total, rel)
async function downloadUploads(client, cfg, list, uploadsDir, onFile) {
  const site = posixNorm(cfg.dir || '/');
  let done = 0; const missing = [], got = {};
  for (const f of list) {
    onFile && onFile(done, list.length, f.rel);
    const abs = path.join(uploadsDir, ...f.rel.split('/'));
    if (!path.resolve(abs).startsWith(path.resolve(uploadsDir) + path.sep)) { done++; continue; }
    if (fs.existsSync(abs)) {
      const b = fs.readFileSync(abs);
      if (b.length === f.size && sha1(b) === f.sha1) { got[f.rel] = f.sha1; done++; continue; }
    }
    try {
      const b = await client.get(joinRemote(site, `uploads/${f.rel}`));
      if (sha1(b) !== f.sha1) { missing.push(f.rel); done++; continue; }
      fs.mkdirSync(path.dirname(abs), { recursive: true });
      fs.writeFileSync(abs, b);
      got[f.rel] = f.sha1;
    } catch (e) {
      if (e.code === 550 || e.code === 450) missing.push(f.rel); else throw e;
    }
    done++;
  }
  onFile && onFile(done, list.length, '');
  return { missing, got };
}

// Записать полученный пакет в папку проекта (новую или существующую). Ключ ИИ-перевода в пакете не
// хранится (он в secrets.json); если пакет собран старой версией и ключ там есть — не записываем.
function writePackage(pkg, contentDir) {
  const db = pkg.db;
  if (db.settings && db.settings.translation) delete db.settings.translation.apiKey;
  fs.mkdirSync(contentDir, { recursive: true });
  const themes = path.join(contentDir, 'themes');
  fs.rmSync(themes, { recursive: true, force: true });
  for (const t of pkg.themes) {
    const abs = path.join(themes, ...t.rel.split('/'));
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, t.data);
  }
  fs.mkdirSync(path.join(contentDir, 'uploads'), { recursive: true });
  if (pkg.media) fs.writeFileSync(path.join(contentDir, 'uploads', '.media.json'), pkg.media);
  return db;
}

module.exports = { autoProjectDir, target, isInside, buildPackage, parsePackage, readManifest, findProject, fetchPackage, pushProject, downloadUploads, writePackage, encrypt, decrypt };

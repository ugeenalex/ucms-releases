# UCMS 1.8 — архитектура и руководство разработчика

Документ для того, кто будет дорабатывать движок. Пользовательская
инструкция — в `README.md`, контракт тем — в `docs/THEMES.md`.

## 1. Принципы

1. **Ноль зависимостей.** Только Node.js (≥ 18) и браузер. Сторонний код —
   только в `vendor/` (Coloris, simpleParallax.js; MIT, лицензии рядом).
2. **Движок отдельно, проекты отдельно.** `engine/` — код (обновление = замена),
   каждый сайт — своя папка данных где угодно на диске (см. §3.1).
3. **Генерация — чистая функция** `db.json + тема → output/`.
   Сайт статичный, без сервера.
4. **Раскладку задаёт админка, вид — тема.** Механика раскладки (ширины,
   отступы, колонки, выравнивание, видимость) — в `engine/site/ucms.css` с
   нулевой специфичностью по умолчанию; тема — токены и внешний вид модулей.
5. **Скелет страницы всегда виден:** Блок → Колонки → Модули — в холсте,
   дереве «Структура» и хлебных крошках инспектора.
6. **Точечный рендер админки:** полная перерисовка только при загрузке, смене
   раздела и страницы; ввод в поля не пересоздаёт DOM (фокус не теряется).
7. **Безопасность по умолчанию:** сервер слушает `127.0.0.1`, HTML из
   вставки чистится, пути в архивах и slug'и проверяются, пароль FTP — отдельно
   от `db.json`.

## 2. Файлы

```
engine/
├─ projects.js          реестр проектов (~/.ucms/projects.json)
├─ server.js            HTTP-сервер, API, миграции db.json, темы, генерация сайта,
│                       экспорт/импорт, публикация (оркестрация)
├─ modules/             рендер модулей на сайт: один тип = один файл
│  ├─ index.js          реестр (require каждого модуля)
│  └─ _shared.js        escHtml, blockField (переводы), resolveLink, linkTag, srcPath
├─ site/
│  ├─ ucms.css          каркас раскладки + базовый вид новых модулей + механика меню
│  ├─ ucms.js           runtime сайта: меню, лайтбокс, галереи, автоперелистывание,
│  │                    фильтр карточек, таймер, цифры, параллакс, закреплённая шапка
│  └─ vendor/           simple-parallax.min.js (подключается только где нужен)
├─ themes/default.css   тема по умолчанию (копируется в themes/default)
├─ publish/
│  ├─ ftp.js            FTP/FTPS-клиент на net/tls (AUTH TLS, PASV, MKD, STOR, DELE)
│  └─ index.js          публикация: хэши, только изменённое, удаление исчезнувшего
├─ lib/zip.js           ZIP запись/чтение (deflate/store, UTF-8, без ZIP64)
├─ lib/imgsize.js       размеры PNG/JPEG/GIF/WebP по заголовку файла (для width/height)
├─ lib/secrets.js       ключи внешних сервисов (UCMS_HOME/secrets.json, 0600) — не в db.json
├─ lib/translate.js     ИИ-перевод: Claude, OpenAI, Gemini, DeepL, OpenAI-совместимый
├─ lib/totp.js          одноразовые коды двухфакторного входа (RFC 6238, ±1 шаг, защита от повтора)
├─ lib/qr.js            QR-код в SVG без зависимостей (байтовый режим, уровень M, версии 1–15)
└─ admin/               админка (без сборщика, обычные <script>)
   ├─ projects.html/.js стартовая страница: список проектов, создание, обзор папок
   ├─ index.html        порядок скриптов важен (см. §6)
   ├─ i18n/             ru.js, en.js — словари; index.js — функция _t()
   ├─ vendor/coloris/   цветовой пикер
   ├─ icons.js          SVG-иконки (Icons.svg)
   ├─ modules.js        MODULES: ключ, подпись, иконка модуля для палитры
   ├─ syntax.js         подсветка HTML в редакторах кода
   ├─ modules/*.js      редакторы модулей в инспекторе (CMS.editor(type, fn))
   ├─ app.js            состояние, холст, инспектор, разделы, DnD, фон, переводы
   ├─ server-bridge.js  загрузка/сохранение, конвертация форматов, API-вызовы
   ├─ media.js          медиатека: оптимизация в браузере (canvas → WebP), окно выбора, раздел «Медиа»
   └─ admin.css         стили админки (токены, светлая/тёмная тема)
start.js / start.bat / start.command / create-shortcut.bat / autostart.bat
```

## 3. Данные проекта: `<папка проекта>/db.json`

### 3.1 Проекты
Реестр — `projects.js`: `~/.ucms/projects.json` (`UCMS_HOME` — другое место),
`{ projects: [{ id, name, path, createdAt, openedAt }], last }`. Сервер держит
**один активный проект** (`ACTIVE`, пути `CONTENT_DIR/DB_PATH/THEMES_DIR/
OUTPUT_DIR/UPLOADS_DIR/BACKUPS_DIR` и `publisher` переназначает `useProject()`).
Переключение (`switchProject`) ждёт очередь записи и отказывает во время
публикации. Запросы к API проекта, `/output/`, `/uploads/` без активного проекта
→ 409 `NO_PROJECT`; если вкладка прислала `X-UCMS-Project` другого проекта →
409 `PROJECT_SWITCHED` (вкладка показывает экран «открыт другой проект» и
перестаёт сохранять). Мост добавляет этот заголовок ко всем `/api/` запросам.
При первом запуске 1.1 папка `cms/content` (1.0) регистрируется как проект.


```jsonc
{
  "settings": {
    "siteTitle": "…", "siteTitleTranslations": { "en": "…" },
    "siteUrl": "https://example.com",          // для canonical/og:image/sitemap
    "favicon": "/uploads/images/…png",
    "theme": "default",                        // папка themes/ проекта
    "css": "…",                                // рабочая копия; истина — theme.css
    "fontFamily": "…", "fontImportUrl": "…",   // зеркало theme.json активной темы
    "languages": [{ "code": "ru", "label": "Русский", "isDefault": true }],
    "translation": { "provider": "anthropic", "model": "…", "glossary": "…", "tone": "…" },   // ключ — не здесь, а в UCMS_HOME/secrets.json
    "enabledModules": ["title", …], "knownModules": [ … ],
    "sectionTemplates": [{ "id", "name", "row": <ряд в формате движка> }],
    "header": { "enabled": true, "sticky": false, "rows": [ <ряд> ] },
    "footer": { "enabled": true, "rows": [ <ряд> ] },
    "brand": { "enabled": true, "colors": { "accent", "paper", "panel", "ink", "muted", "line" },
      "radius": 12, "fontSize": 17, "fontBody": { "family", "url" }, "fontHead": { "family", "url" } },
      // стиль проекта: server.js brandCss() → конец style.css, brandFontLinks() → <link> шрифтов
    "collections": [{ "id", "name", "slug",   // slug — папка записей на сайте
      "listPageId", "sort": "date|manual",
      "showTitle", "showDate", "showCoverTop", "showTags", "navTop", "navBottom" }],   // showNav: false (до 1.6.2) — навигации нет
    "migrated": { "headerMenuRight": true, "collectionModule": true }   // однократные миграции
  },
  "pages": [{
    "id", "title", "slug", "parentId", "order", "showInMenu", "showHeader", "showFooter",
    "translations": { "en": { "title", "slug", "description" } },
    "seo": { "description", "image", "noindex" },
    "background": <фон>,
    "rows": [ <ряд> ],
    // только у записей коллекции:
    "collection": "<id коллекции>", "date": "ГГГГ-ММ-ДД", "cover": "/uploads/…",
    "excerpt": "…", "tags": ["…"], "draft": true   // translations[lang].excerpt — перевод анонса
  }]
}
```
**Коллекции.** Запись — страница с `collection`; в дереве меню (`ctx.tree`) её
нет, `parentId` не используется, порядок при ручной сортировке — `order`.
Черновики (`draft`) генератор пропускает целиком. Общие функции записей —
`engine/modules/_coll.js` (`entryExcerpt`, `entryCover`, `formatDate`,
`sortEntries`).

**Ряд (= блок в админке):**
```jsonc
{
  "id": "…", "cssClass": "",
  "style": {                       // только непустые поля
    "width": "full|narrow", "contain": "1", "align": "center|right",
    "pad": "none|s|m|l|xl", "valign": "top|center|bottom", "gap": "s|m|l",
    "reverse": "1", "hide": "mobile|desktop", "anchor": "contacts",
    "bg": <фон>
  },
  "columns": [{ "id", "width": { "value": 50, "unit": "%" } | null, "align": "…", "blocks": [ <модуль> ] }],
  "blocks": [ <модуль> ]           // модули блока под колонками (если есть колонки)
}
```
Блок без колонок хранится как ряд с одной колонкой, id которой оканчивается
на `_mc` (так мост отличает его от «одной колонки»).

**Фон:** `{ type: none|color|gradient|image|pattern, color, gradientFrom,
gradientTo, gradientAngle, image, stretch, fixed, overlay (блок), light (блок),
parallax, pxOrientation, pxScale, pxDelay, pxSmooth, pxMax }`.

**Модуль:** `{ id, type, …поля типа, link?, items?, translations? }`.
- Ссылка в db: `{ type: none|external|internal, url, pageId, anchor? }`
  (в админке — `{ linkType: none|external|inner, url, page: <название> }`,
  конвертация в мосте; генератор понимает и старый вариант с `page`).
- Перевод: `translations[код_языка][поле]`; у элементов списков — так же у
  элемента. На сайте поле читается через `blockField()`.

**Прочие файлы папки проекта:** `themes/<Имя>/theme.css|theme.json|…`,
`uploads/<тип>/<время>-<имя>`, `publish.json`, `.publish/<хэш>.json`,
`backups/*.zip`, `history/<id>.json.gz` + `history/index.json` (версии,
`lib/history.js`; в экспорт и резервные копии не входят).

## 4. Сервер (`engine/server.js`)

- `readDB()` → `migrateDB()` (идемпотентные миграции, `ensureThemes`: CSS и
  шрифт берутся из файлов активной темы). `writeDB()` — атомарно (tmp + rename,
  с повторами при блокировке файла в Windows) и через очередь.
- Статика: `/` → `/admin/projects.html`, `/admin/*`, `/output/*`, `/uploads/*`
- Предпросмотр: `/preview/*` — страницы собираются на лету (`servePreview`:
  `siteModel(db, { drafts: true })` + `renderPage(…, { preview: true })`), та же
  структура адресов, что в output; `style.css`, `ucms.*`, `vendor/`, `uploads/`,
  файлы темы отдаются из исходных папок; `/preview/__page/<id>?lang=` → 302 на
  адрес страницы. В HTML предпросмотра — `<meta name="ucms-page" content="<id>">`.
  (последние два — активного проекта; `Cache-Control: no-cache`).

| API | Назначение |
|---|---|
| `GET/POST /api/data` | данные сайта (POST также пишет шрифт в theme.json) |
| `POST /api/generate` | собрать сайт |
| `POST /api/upload` | загрузка файла (base64 JSON) → `uploads/<kind>/` |
| `GET /api/theme-css`, `POST /api/theme-css-save` | CSS активной темы |
| `GET /api/themes`, `POST /api/theme-switch`, `POST /api/theme-create` | темы |
| `POST /api/open-external` | открыть theme.css во внешнем редакторе |
| `POST /api/translate` | ИИ-перевод массива строк (`lib/translate.js`: anthropic, openai, gemini, deepl, compatible) |
| `GET /api/translate/config`, `POST /api/translate/key`, `POST /api/translate/test` | сервисы и маски ключей; ключ/адрес (только владелец); проверка |
| `GET/POST /api/publish/config`, `POST /api/publish/test|start|reset`, `GET /api/publish/status` | публикация |
| `GET /api/export?type=site|json` | скачать сайт (.zip) или контент (.json) |
| `POST /api/import[?dry=1]` | загрузить архив/JSON (dry — только состав) |
| `GET /api/backups`, `GET /api/backups/<имя>`, `POST /api/backups/create` | резервные копии |
| `GET /api/ping` | `{ app: 'ucms', version }` — для start.js |
| `POST /api/upload` | `{ name, data(base64), kind, variants:[{w,data}] }` → `uploads/<kind>/<время>-<имя>` + `<имя>-w<N>.webp` |
| `GET /api/media` | файлы uploads (без копий): размер, разрешение, копии, `used` — число упоминаний в db.json |
| `POST /api/media/delete` | `{ paths }` — удалить файлы вместе с копиями (ссылки не трогает) |
| `POST /api/media/replace` | `{ from, to }` — заменить все ссылки в db.json и удалить старый файл (папка/теги переходят к новому) |
| `GET/POST /api/palettes` | палитры «Стиля проекта», общие для всех проектов: `{ custom: [{ id, name, colors }], hidden: [id стандартных] }` в `~/.ucms/palettes.json` |
| `GET /api/history` | версии: `{ id, at, reason: auto|manual|before-restore|before-import, label, size, pages, entries }`, новые сверху |
| `GET /api/history/diff?id=` | отличия версии от текущего db: `{ pages: [{ id, title, oldTitle, status: changed|removed|added, entry }], parts: [header|footer|languages|collections|site] }` |
| `POST /api/history/save` | `{ label }` — снимок текущего db с названием |
| `POST /api/history/restore` | `{ id, part: all|page:<id>|header|footer }` — перед возвратом снимок `before-restore`; тема и ключ перевода остаются текущими |
| `POST /api/history/rename` / `delete` | `{ id, label }` / `{ id }` |
| `POST /api/media/meta` | папки и теги: `op` = folderAdd/folderRename/folderDelete/move/tagAdd/tagRemove/tagRename |

Папки и теги — `uploads/.media.json`: `{ folders: [{id,name}], files: { '/uploads/…': { folder, tags } } }`.
Файлы физически не перемещаются (ссылки стабильны). Запись — через очередь
`withMediaMeta` (чтение-изменение-запись по одному). `syncDir` не копирует
файлы с точкой в имени, поэтому метаданные на сайт не попадают.
| `GET /api/projects` | список проектов (+ название, страниц, языки из db.json), активный |
| `POST /api/projects/open|create|add|duplicate|relocate|remove|reveal` | работа с проектами |
| `GET /api/fs/dirs?path=` | обзор папок (диски Windows, домашняя папка) |

### Генерация (`generateSite`)
`siteModel(db, { drafts })` — языки, коллекции, уникальные slug'и, дерево меню,
`entriesOf`; `renderPage(model, page, lang)` — HTML страницы; `pageRelPath/
pageUrlPath` — адреса. Генерация и предпросмотр используют одни функции.
1. Очистка `output` (кроме `uploads`), уникальные безопасные slug'и по языкам
   (у записей — в пределах папки коллекции). Папка коллекции не совпадает с
   кодами языков и служебными папками (`uploads`, `vendor`).
2. Для каждой страницы и языка: `<head>` (title, SEO/OG, favicon, шрифт,
   `ucms.css`, `style.css`, скрипты), шапка/контент/подвал через `renderRows`.
3. `renderRows`: ряд → один `<div class="layout-row row--…">`; колонки
   `<div class="layout-col col--…">` (flex-grow из ширин, без inline-стиля, если
   ширины не заданы); модули через `modules/index.js`; пустое не выводится.
4. `style.css` = CSS темы (+ переопределение шрифта), `ucms.css/js`, `vendor/`,
   файлы темы, синхронизация `uploads`, `sitemap.xml`/`robots.txt` (если задан
   адрес сайта), редирект `index.html` для многоязычия.
5. Запись коллекции: `<lang>/<папка>/<slug>.html`, `ctx.pageBase = '../'`,
   `basePrefix` на уровень глубже; перед блоками — шапка записи
   (`.coll-head`: дата, h1, теги, обложка), после — навигация (`.coll-nav`).
   В меню подсвечивается страница-список (`ctx.currentSlug`).

### Модуль сайта
```js
module.exports = {
  type: 'cards', label: 'Карточки',
  render(block, ctx) { return '<div class="block block-cards">…</div>'; }  // '' — ничего
};
```
`ctx`: `lang, defaultLang, languages, basePrefix ('', '../' или '../../'), pageBase
('' или '../' у записей), siteTitle, page, pagesById, tree (дерево страниц без
записей), currentSlug, collsById, entriesOf(collId), img(src, sizes)` —
`imgExtra(src, ctx, sizes)` из `_shared` даёт `width/height` и `srcset/sizes`
(если у файла есть копии `-w<N>.webp`). Всегда экранируйте
(`escHtml`), пути — `srcPath(src, ctx.basePrefix)`, ссылки — `resolveLink/linkTag`,
адрес страницы — `pageHref(page, ctx)` (учитывает папку коллекции и глубину).

## 5. Runtime сайта (`engine/site/`)
`ucms.css` подключается **перед** темой: тема может переопределить что угодно.
Значения каркаса — токены (`--content-width`, `--narrow-width`, `--gutter`,
`--col-gap`, `--row-gap`, `--block-gap`, `--main-pad`, `--header-pad`,
`--footer-pad`, `--bg-pad`, `--menu-full-bg/fg`). Выравнивание передаётся
модулям через `--ucms-justify`. `ucms.js` — один файл, обработчики
делегированием на `document`, уважает `prefers-reduced-motion`.

## 6. Админка

**Порядок скриптов** в `index.html`: тема админки (inline) → `i18n/ru.js`,
`i18n/en.js`, `i18n/index.js` (`_t`) → Coloris → `icons.js` → `modules.js` →
`syntax.js` → `modules/_registry.js` и редакторы → `app.js` → `collections.js` → `history.js` → `brand.js` → `server-bridge.js` → `media.js` → `preview.js`.

**История (`admin/history.js`).** Отмена/повтор: после действия (click/input/
change/drop/paste, пауза 600 мс) `App.undoSnap()` — JSON `buildDb()` без темы —
кладётся в стек, если изменился; `App.undoApply(json)` → `applyDb(db, true)`
(та же страница, язык, выделение) и обычное автосохранение. Лимиты: 100 шагов,
40 млн символов на стек. Версии — раздел `view = 'history'` поверх
`/api/history*`; после возврата `App.reloadData(true)`, новое состояние — шаг
отмены. Автоснимок делает сервер в `POST /api/data` (`HISTORY.maybeAuto()`:
прежнее содержимое db.json, если прошлый снимок старше 10 минут; одинаковые
подряд не дублируются по sha1).

**Коллекции в админке.** Записи живут в общем `state.pages` (строка с `coll`,
`date`, `draft`, `order`, `cover`), поля текущей записи — `state.pageEntry`;
`state.collections` ↔ `db.settings.collections`. Данные (`addCollection`,
`addEntry`, `deleteCollection`, `moveEntry`, `setEntryField`) — в
`server-bridge.js`; разметка (группа в сайдбаре, панель `drawer = 'coll:<id>'`,
поля записи, превью модуля) — `admin/collections.js` через `App.kit`
(примитивы разметки app.js).

**Состояние** — `App._state`: `view` (page|hf|theme|langs|site|publish),
`trees.page|header|footer` (UI-формат блоков: `{ id, cssClass, style, mods[],
cols[{ id, width, unit, align, mods[] }] }`), `selected { tree, kind, id }`,
`drawer`, `pages`, параметры текущей страницы, `pageBg`, `plang`, …

**Рендер:** якоря `[data-side] [data-top] [data-view] [data-insp]
[data-block] [data-card] [data-outline] [data-bg] …`; функции `App.renderBlock`,
`App.renderModule`, `App.renderInsp`, `App.renderOutline`, `renderRoot` (полный).
Ввод в инспекторе → `queuePreview()` обновляет карточку на холсте в rAF.

**Мост (`server-bridge.js`)**: `rowsToBlocks/blocksToRows`, `blockToMod/modToBlock`
(ссылки элементов любых списков), `buildDb()` (состояние → db), `persist()`,
автосохранение (раз в 4 с проверка, сохранение не чаще 30 с; выключается на время
импорта), загрузки файлов (делегированные клики по `.ad-upload__btn`,
`.ad-li-up`, `.ad-mod-up`, `.ad-bg-up`, `.ad-site-up`, `.ad-seo-up`,
`.ad-vcover__btn`, `.ad-gal-up__btn`), публикация, экспорт/импорт, ИИ-перевод.

**Редактор модуля** (`admin/modules/<тип>.js`):
```js
CMS.editor('cards', function (mod, ctx) {
  var ui = ctx.ui;
  return ui.field('Колонок', ui.segm([['1','1'],['2','2']], String(mod.cols), function (k) { return ctx.set('cols', k); })) +
    ui.list(ctx, mod.items, 'Карточки', 'Карточка', function (it, set) { return ui.input({ value: it.title, oninput: set('title') }); });
});
```
`ctx`: `tree, mod, path, itemPath(id), popId(kind), jsArg, esc, escAttr, set(field, expr, noRender),
act(body), call(fn, …args), linkField(…), pages, menuTree, siteName, embedUrl, ui`.
`ui`: `field, input, segm, sw, btn, stepper, note, list, ico, ib`. Вариант
`segm`: `[ключ, подпись, значок]` — кнопка со значком из `ICO` (app.js), подпись
в `title`/`aria-label`.

**Вложенные деревья («Вкладки»).** У модуля `tabs` элементы `items[]` —
`{ id, title, rows }` в db и `{ id, title, blocks }` в админке (конвертация в
`blockToMod/modToBlock`, рекурсивно). Каждая вкладка регистрируется как дерево
`state.trees['tab-<модуль>-<вкладка>']` (тот же массив, что `item.blocks`;
`NESTED` помнит родителя, `rootTree()` даёт страницу/шапку/подвал). Поэтому все
операции с блоками и модулями (`addMod`, `renderBlock`, DnD, выбор, инспектор)
работают внутри вкладки без изменений. Реестр пересобирается в `renderRoot`
(`syncNested`) и при рисовании карточки модуля. Клик внутри `[data-nested]` не
выбирает сам модуль. На сайте модуль выводит блоки через `ctx.renderRows`.

**Ссылки в «Тексте»:** диалог `App.textLinkOpen` (свой, без prompt); ссылка на
страницу хранится как `href="ucms:page/<id>#якорь"`, генератор (`modules/text.js`)
превращает её в адрес текущего языка. Очистка: `Clean.html` (вставка — смысловая
разметка), `Clean.plain` (кнопка без выделения — только абзацы), с выделением —
`removeFormat/unlink/formatBlock` в границах выделения.

**Прочее:** DnD (холст и дерево, одна линия-индикатор), Coloris (`[data-coloris]`,
обёртку `.clr-field` рисуем сами), очистка вставки в «Текст» (`Clean` в app.js),
тёмная тема (только токены `:root[data-theme="dark"]`), i18n (ниже).

## 7. Как добавить модуль (чек-лист)
1. `engine/modules/<тип>.js` + `require` в `engine/modules/index.js`.
2. Базовые стили — в `engine/site/ucms.css` (и/или в теме); JS — в `ucms.js`.
3. `engine/admin/modules.js` — запись в `MODULES` (ключ, подпись, иконка).
4. `engine/admin/modules/<тип>.js` — редактор; подключить в `admin/index.html`.
5. `app.js`: значения по умолчанию в `newModule()` (для списков — `LIST_ITEM`,
   `LIST_DEFAULTS`), превью `modPreview()`, подпись `modMeta()`, переводимые поля
   `App.TRANSLATABLE` / `App.ITEM_TRANSLATABLE`.
6. Тексты интерфейса — по-русски в `_t('…')`, перевод — в `admin/i18n/en.js`
   (проверка: `UCMS_I18N_MISSING` в консоли при EN).
7. Проверить: генерация, языки, выравнивание, телефон, тёмная тема админки.

## 8. Интерфейс админки на разных языках
`_t(строка)`: целиком или по фрагментам (текст между тегами и в атрибутах),
словарь `admin/i18n/<код>.js` (`{ label, dict }`): `en.js`, `kk.js`; русский —
исходный (в коде). Язык — `localStorage 'ucms-admin-lang'`, смена с перезагрузкой.
Меню выбора — `window.adminLangMenu(cls)` из `i18n/index.js` (админка и список
проектов; перед перезагрузкой — `UCMS_LANG.beforeReload`, админка сохраняет).
Новый язык: скопировать `en.js` → `<код>.js`, перевести значения, подключить в
`index.html` и `projects.html` перед `i18n/index.js`. Сообщения сервера пока только на русском.

## 9. Публикация и перенос
- **FTP/FTPS:** явный TLS (AUTH TLS), PASV с IP управляющего соединения,
  повторное использование TLS-сессии на data-каналах. Состояние по хэшам —
  `.publish/<хэш сервер|порт|логин|папка>.json`.
- **Архив сайта:** `ucms-site.json`, `db.json`, `uploads/…`, `themes/…`. Импорт
  проверяет пути, перед заменой делает `backups/before-import-*.zip`.

## 10. Как проверялось
Ручные сценарии + автотесты на время разработки (не входят в поставку, нужны
`npm i jsdom playwright`): jsdom-харнесс грузит `admin/index.html` со всеми
скриптами и подменённым `fetch` (≈ 90 проверок: данные, холст, инспектор,
переводы, модули, вставка), Playwright/Chromium — перетаскивание, тёмная тема,
меню на весь экран, галереи, параллакс, ширины блоков на 390–2560 px, импорт,
публикация на тестовые FTP/FTPS-серверы (pyftpdlib).
Коллекции (1.3): создание с готовой страницей-списком, записи (дата, черновик,
теги, анонс, обложка), ручной порядок, удаление записи и коллекции, адреса
`/blog/…` и `/en/blog/…`, переключатель языков и меню на странице записи,
«Показать ещё» и фильтр по тегам на сайте, sitemap; смоук всех 25 модулей и
разделов в RU/EN (с 1.7 — и KK) без ошибок и непереведённых строк.
История (1.4): отмена/повтор (кнопки и Ctrl+Z/Ctrl+Shift+Z, родная отмена в
полях), автоснимок и именованная версия, «Что изменилось», возврат удалённой
страницы и отмена этого возврата, возврат всей версии, дедупликация снимков,
API через curl; смоук RU/EN с разделом «История».
Предпросмотр (1.5): HTML `/preview/` побайтно совпадает со сгенерированным,
устройства и поворот (ширина iframe = ширина устройства), языки, навигация,
черновик, «Редактировать эту страницу», Esc; смоук RU/EN.

## 11. Ограничения и идеи
- Нет авторизации в админке (рассчитана на локальную работу).
- Один активный проект на сервер (две вкладки с разными проектами одновременно — нельзя).
- Нет SFTP и неявного FTPS (порт 990); нет ZIP64 (архивы до 4 ГБ).
- Сообщения сервера не переведены на английский.
- Возможные направления: история изменений/откат, ресайз и WebP для картинок,
  блог/коллекции (списки записей), формы со своим бэкендом, SFTP, предпросмотр
  сайта прямо в админке, мультиселект и копирование между страницами.

## Ревизии данных

`DB_REV` — sha1 содержимого `db.json` (переживает перезапуск). Каждый ответ маршрута
API несёт `X-UCMS-Rev-Was` (до запроса) и `X-UCMS-Rev` (после). Вкладка хранит ревизию
из `GET /api/data` и принимает новую, только если «до» совпало с её ревизией — то есть
запись была её собственной. `POST /api/data` с устаревшей `X-UCMS-Base-Rev` → 409
`CONFLICT`; `X-UCMS-Force: 1` — сохранить поверх по решению пользователя.

Запросы, меняющие данные, принимаются только со страниц этого же сервера (заголовок
`Origin`), а `Host` должен быть localhost/127.0.0.1 (если не задан `HOST`).

## Проект на сервере (publish/project.js)

Публикация (`publish/index.js`) после сайта отправляет пакет проекта в папку проекта
(`target(cfg)`: по умолчанию `autoProjectDir` — рядом с первой «публичной» папкой пути;
внутри папки сайта — только с шифрованием). На сервере: `manifest.json` (`rev`, файл,
дата, компьютер, версия движка; название — только у незашифрованного), `project-<rev>.zip`
или `.ucms` (AES-256-GCM, ключ scrypt), `.htaccess` и пустой `index.html`. Пакет: `db.json`
без `translation.apiKey`, `themes/**`, `media.json`, `uploads.json` (rel, size, sha1).
`rev` — хеш содержимого пакета; версия, отправленная или полученная этим компьютером,
хранится в `.publish/<ключ>.project.json`. Перед публикацией: `rev` на сервере ≠ известному
→ ошибка `REMOTE_NEWER` (без `force` ни сайт, ни проект не загружаются).
API: `GET /api/sync/status` (кеш 60 с), `POST /api/sync/pull` + `GET /api/sync/job` —
получить в открытый проект (резервная копия `before-pull`, снимок «Истории», замена
db/тем/медиаданных, докачка `uploads`); `POST /api/remote/inspect`, `POST /api/remote/clone`
+ `GET /api/remote/job` — новый проект с сервера (вместе с `publish.json`; скачанные
`uploads` отмечаются в состоянии публикации, чтобы не перезаливать их).

## Обновление движка (lib/update.js)

`GET /api/update` — статус; `POST /api/update/check | settings | apply | rollback`.
Источник — релизы публичного репозитория `ugeenalex/ucms-releases`: метка `vX.Y.Z`,
файлы `ucms-X.Y.Z.zip` (папка `cms/` с движком) и `ucms-X.Y.Z-sha256.txt`
(собирает `tools/make-release.js`, порядок выпуска — `docs/RELEASE.md`).
Установка: загрузка (только HTTPS, редиректы GitHub) → sha256 → CRC каждого файла →
состав и `VERSION` → `node --check` серверного кода → копия текущего движка в
`.update/backup-*` (хранятся 2) → замена файлов `MANAGED_DIRS`/`MANAGED_FILES`
(лишние файлы в `engine/`, `docs/` удаляются) → при ошибке возврат копии.
Перезапуск: сервер выходит с кодом 75, `start.js` (переменная `UCMS_LAUNCHER=1`)
поднимает его заново; без него — сообщение «перезапустите вручную».
Настройки и последний ответ GitHub — `~/.ucms/update.json`.
